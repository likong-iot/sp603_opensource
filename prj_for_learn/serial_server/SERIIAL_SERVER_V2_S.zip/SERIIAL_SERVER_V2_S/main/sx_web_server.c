/*
 * @Author: Orion
 * @Date: 2024-05-23 21:10:47
 * @LastEditors: Orion
 * @LastEditTime: 2025-06-11 18:12:29
 * @Description:
 *
 */
/*
 * @Author: Orion
 * @Date: 2024-01-23 16:09:45
 * @LastEditors: Orion
 * @LastEditTime: 2024-12-24 17:09:43
 * @FilePath: \SERIIAL_SERVER_P\main\sx_web_server.c
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */

#include "sx_web_server.h"
#include "cJSON.h"
#include <inttypes.h>
#include "esp_eth.h"
#include "esp_event.h"
#include "esp_http_server.h"
#include "esp_log.h"
#include "esp_mac.h"
#include "esp_netif.h"
#include "esp_tls.h"
#include "esp_wifi.h"
#include "lwip/inet.h"
#include "lwip/priv/tcp_priv.h"
#include "driver/gpio.h"
#include "esp_chip_info.h"
#include "esp_https_ota.h"
#include "esp_log.h"
#include "esp_netif_sntp.h"
#include "esp_ota_ops.h"
#include "esp_sleep.h"
#include "esp_sntp.h"
#include "esp_system.h"
#include "esp_timer.h"
#include "math.h"
#include "nvs.h"
#include "nvs_flash.h"
#include "sx_async_uart.h"
#include "sx_dns_server.h"
#include "sx_http_ota.h"
#include "sx_init_eth.h"
#include "sx_log.h"
#include "sx_modbus.h"
#include "sx_tcp_client.h"
#include "sx_tcp_server.h"
#include "sx_platform.h"
#include "sx_utils.h"
#include "sx_wifi_scan.h"
#include "sx_gpio.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/param.h>
#include "lwip/tcp.h"
#include "mqtt_client.h"  // 添加MQTT客户端头文件

#define MIN(a, b) ((a) < (b) ? (a) : (b))

uint8_t sta_mac[6] = {0};
uint8_t eth_mac[6] = {0};
char dIp[20];
char dNetmask[20];
char dGateway[20];
uint8_t mac_addr[6] = {0};
char device_mac[30];

char th[20] = {0};
char device_mac_end[20];
char got_ip_addrs[16];
char got_ip_netmask[16];
char got_ip_gw[16];
int httpreason = 0;

char device_sta_mac[24];
char device_eth_mac[24];
char device_name[40];

static const char *TAG = "SP501LW";

// NVS访问互斥锁，防止并发访问导致死锁
static SemaphoreHandle_t nvs_mutex = NULL;

// 系统健康检查函数
static bool system_health_check(void) {
  size_t free_heap = esp_get_free_heap_size();
  size_t min_heap = esp_get_minimum_free_heap_size();
  
  // 检查内存状况
  if (free_heap < 8192) { // 小于8KB认为危险
    ESP_LOGE(TAG, "系统内存不足: free=%d, min_ever=%d", free_heap, min_heap);
    return false;
  }
  
  // 检查任务栈使用情况
  UBaseType_t high_water_mark = uxTaskGetStackHighWaterMark(NULL);
  if (high_water_mark < 256) { // 栈剩余小于256字节
    ESP_LOGW(TAG, "任务栈使用率过高: 剩余=%d bytes", high_water_mark);
  }
  
  return true;
}

extern const char root_start[] asm("_binary_root_html_start");
extern const char root_end[] asm("_binary_root_html_end");

extern const char web_start[] asm("_binary_web_html_start");
extern const char web_end[] asm("_binary_web_html_end");

extern const char logo_start[] asm("_binary_logo_png_start");
extern const char logo_end[] asm("_binary_logo_png_end");

extern const char js_start[] asm("_binary_web_js_start");
extern const char js_end[] asm("_binary_web_js_end");

extern const char css_start[] asm("_binary_web_css_start");
extern const char css_end[] asm("_binary_web_css_end");

#define ESP_WIFI_SSID "SP501LW"
#define ESP_WIFI_PASS "12345678"
#define MAX_STA_CONN 8

httpd_handle_t http_server = NULL;

// 添加WebSocket相关变量
// static httpd_handle_t websocket_server = NULL;
// static int client_session_id = 0;  // 暂时未使用
// 定义常量和全局变量
#define MAX_WS_CLIENTS 4   // 限制最大WebSocket客户端数量
#define WS_QUEUE_SIZE 8    // WebSocket消息队列大小（8×512=4KB）
#define WS_MAX_MSG_LEN 512 // 最大消息长度（增加到512以支持大数据传输）

// 日志开关控制（默认关闭以节省资源）
static bool log_enabled = false;

typedef struct {
  int client_fd;
  bool in_use;
} ws_client_t;

static ws_client_t ws_clients[MAX_WS_CLIENTS] = {0};
static QueueHandle_t ws_msg_queue = NULL;
static TaskHandle_t ws_task_handle = NULL;



// static void disconnect_handler(void *arg, esp_event_base_t event_base,
//                                int32_t event_id, void *event_data);

// 添加工作模式配置结构体
typedef struct {
  char slave_addr[8];
  char function_code[4];
  char register_addr[8];
  char register_num[8];
  char timeout[8];
  char data_format[16];
  char interval_time[8];
  char report_format[8];
  char baud_rate[8];
  char data_bit[8];
  char stop_bit[8];
  char check_bit[8];
} modbus_item_config_t;

typedef struct {
  char work_mode[32];
  char poll_time[16];
  int modbus_items_count;
  modbus_item_config_t modbus_items[10]; // 最多10个配置项
} work_mode_config_t;


/*************************************************************************************/
/*                                START OF FILE */
/*************************************************************************************/

static void wifi_event_handler(void *arg, esp_event_base_t event_base,
                               int32_t event_id, void *event_data) {
  if (event_id == WIFI_EVENT_AP_STACONNECTED) {
    wifi_event_ap_staconnected_t *event =
        (wifi_event_ap_staconnected_t *)event_data;
    ESP_LOGI(TAG, "station " MACSTR " join, AID=%d", MAC2STR(event->mac),
             event->aid);
  } else if (event_id == WIFI_EVENT_AP_STADISCONNECTED) {
    wifi_event_ap_stadisconnected_t *event =
        (wifi_event_ap_stadisconnected_t *)event_data;
    ESP_LOGI(TAG, "station " MACSTR " leave, AID=%d", MAC2STR(event->mac),
             event->aid);
  }
}

static void wifi_init_softap(void) {
  wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
  ESP_ERROR_CHECK(esp_wifi_init(&cfg));

  esp_netif_create_default_wifi_ap();

  ESP_ERROR_CHECK(esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID,
                                             &wifi_event_handler, NULL));

  esp_read_mac(sta_mac, ESP_MAC_WIFI_STA);
  esp_read_mac(eth_mac, ESP_MAC_ETH);

  ESP_LOGI(TAG, "ESP_MAC_WIFI_STA MAC: %02x:%02x:%02x:%02x:%02x:%02x",
           sta_mac[0], sta_mac[1], sta_mac[2], sta_mac[3], sta_mac[4],
           sta_mac[5]);
  sprintf(device_mac, "%02X%02X%02X%02X%02X%02X", sta_mac[0], sta_mac[1],
          sta_mac[2], sta_mac[3], sta_mac[4], sta_mac[5]);
  sprintf(device_mac_end, "%02X%02X", sta_mac[4], sta_mac[5]);

  // esp_read_mac(sta_mac, ESP_MAC_WIFI_STA);

  sprintf(device_sta_mac, "%02X:%02X:%02X:%02X:%02X:%02X", sta_mac[0],
          sta_mac[1], sta_mac[2], sta_mac[3], sta_mac[4], sta_mac[5]);
  sprintf(device_eth_mac, "%02X:%02X:%02X:%02X:%02X:%02X", eth_mac[0],
          eth_mac[1], eth_mac[2], eth_mac[3], eth_mac[4], eth_mac[5]);

  char ap_ssid[80] = {0};
  strcpy(ap_ssid, ESP_WIFI_SSID);
  strcat(ap_ssid, "_");
  strcat(ap_ssid, device_mac_end);

  esp_err_t ret = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
  size_t ap_name, ap_password, ap_wait_time = 0;
  ret = nvs_get_str(nvs_handle, "ap_name", NULL, &ap_name);
  nvs_get_str(nvs_handle, "ap_password", NULL, &ap_password);
  nvs_get_str(nvs_handle, "ap_wait_time", NULL, &ap_wait_time);
  switch (ret) {
  case ESP_OK:
    printf("ap_name set success");
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    printf("no ap_name set");
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "ap_name", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "ap_password", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "ap_wait_time", ""));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'ap_name': %s\n", esp_err_to_name(ret));
  } else {
    // 分配缓冲区
    char *nvs_ap_name = malloc(ap_name);
    char *nvs_ap_password = malloc(ap_password);
    char *nvs_ap_wait_time = malloc(ap_wait_time);
    if (nvs_ap_name == NULL) {
      printf("Memory allocation failed\n");
    } else {
      ret = nvs_get_str(nvs_handle, "ap_name", nvs_ap_name, &ap_name);
      nvs_get_str(nvs_handle, "ap_password", nvs_ap_password, &ap_password);
      nvs_get_str(nvs_handle, "ap_wait_time", nvs_ap_wait_time, &ap_wait_time);
      if (ret == ESP_OK) {
        printf("Value for 'ap_name' is %s\n", nvs_ap_name);
        printf("Value for 'ap_password' is %s\n", nvs_ap_password);
        printf("Value for 'ap_wait_time' is %s\n", nvs_ap_wait_time);
        if (strlen(nvs_ap_name) == 0 && strlen(nvs_ap_password) == 0) {
          wifi_config_t wifi_config = {
              .ap = {.ssid = ESP_WIFI_SSID,
                     .ssid_len = strlen(ap_ssid),
                     .password = ESP_WIFI_PASS,
                     .max_connection = MAX_STA_CONN,
                     .authmode = WIFI_AUTH_WPA_WPA2_PSK},
          };

          strcpy((char *)wifi_config.ap.ssid, ap_ssid);
          wifi_config.ap.ssid_len = strlen((char *)wifi_config.sta.ssid);

          if (strlen(ESP_WIFI_PASS) == 0) {
            wifi_config.ap.authmode = WIFI_AUTH_OPEN;
          }

          ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_APSTA));
          ESP_ERROR_CHECK(esp_wifi_set_config(ESP_IF_WIFI_AP, &wifi_config));
          ESP_ERROR_CHECK(esp_wifi_start());

          esp_netif_ip_info_t ip_info;
          esp_netif_get_ip_info(esp_netif_get_handle_from_ifkey("WIFI_AP_DEF"),
                                &ip_info);

          char ip_addr[16];
          inet_ntoa_r(ip_info.ip.addr, ip_addr, 16);
          ESP_LOGI(TAG, "Set up softAP with IP: %s", ip_addr);

          ESP_LOGI(TAG, "wifi_init_softap finished. SSID:'%s' password:'%s'",
                   ESP_WIFI_SSID, ESP_WIFI_PASS);
        } else {
          wifi_config_t wifi_config = {
              .ap = {.ssid = ESP_WIFI_SSID,
                     .ssid_len = strlen(ap_ssid),
                     .password = ESP_WIFI_PASS,
                     .max_connection = MAX_STA_CONN,
                     .authmode = WIFI_AUTH_WPA_WPA2_PSK},
          };

          strcpy((char *)wifi_config.ap.ssid, nvs_ap_name);
          strcpy((char *)wifi_config.ap.password, nvs_ap_password);
          wifi_config.ap.ssid_len = strlen((char *)wifi_config.sta.ssid);
          if (strlen(nvs_ap_password) == 0) {
            wifi_config.ap.authmode = WIFI_AUTH_OPEN;
          }

          ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_APSTA));
          ESP_ERROR_CHECK(esp_wifi_set_config(ESP_IF_WIFI_AP, &wifi_config));
          ESP_ERROR_CHECK(esp_wifi_start());

          esp_netif_ip_info_t ip_info;
          esp_netif_get_ip_info(esp_netif_get_handle_from_ifkey("WIFI_AP_DEF"),
                                &ip_info);

          char ip_addr[16];
          inet_ntoa_r(ip_info.ip.addr, ip_addr, 16);
          ESP_LOGI(TAG, "Set up softAP with IP: %s", ip_addr);

          ESP_LOGI(TAG, "wifi_init_softap finished. SSID:'%s' password:'%s'",
                   nvs_ap_name, nvs_ap_password);
        }

      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
    }
    free(nvs_ap_name);
    free(nvs_ap_password);
    free(nvs_ap_wait_time);
  }

  nvs_close(nvs_handle);
}

static esp_err_t get_devinfo_get_handler(httpd_req_t *req) {

  esp_err_t ret = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));

  size_t host_names, ntp_server, is_dhcp, netconn = 0;
  ret = nvs_get_str(nvs_handle, "host_names", NULL, &host_names);
  nvs_get_str(nvs_handle, "ntp_server", NULL, &ntp_server);
  nvs_get_str(nvs_handle, "is_dhcp", NULL, &is_dhcp);
  nvs_get_str(nvs_handle, "netconn", NULL, &netconn);
  switch (ret) {
  case ESP_OK:
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    printf("no ip set");
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "host_names", "以太网串口服务器"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "ntp_server", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "is_dhcp", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "netconn", ""));
    break;
  default:
    break;
  }
  ret = nvs_get_str(nvs_handle, "is_dhcp", NULL, &is_dhcp);
  switch (ret) {
  case ESP_OK:
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "is_dhcp", "1"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "netconn", "1"));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'host_names': %s\n", esp_err_to_name(ret));
  } else {
    // 分配缓冲区
    char *nvs_host_names = malloc(host_names);
    char *nvs_ntp_server = malloc(ntp_server);
    char *nvs_is_dhcp = malloc(is_dhcp);
    char *nvs_netconn = malloc(netconn);
    if (nvs_host_names == NULL) {
      printf("Memory allocation failed\n");
    } else {
      ret = nvs_get_str(nvs_handle, "host_names", nvs_host_names, &host_names);
      nvs_get_str(nvs_handle, "ntp_server", nvs_ntp_server, &ntp_server);
      nvs_get_str(nvs_handle, "is_dhcp", nvs_is_dhcp, &is_dhcp);
      nvs_get_str(nvs_handle, "netconn", nvs_netconn, &netconn);
      if (ret == ESP_OK) {

        cJSON *root = cJSON_CreateObject();
        cJSON_AddItemToObject(root, "device_sta_mac",
                              cJSON_CreateString(device_sta_mac));
        cJSON_AddItemToObject(root, "device_eth_mac",
                              cJSON_CreateString(device_eth_mac));

        cJSON_AddItemToObject(root, "netconn", cJSON_CreateString(nvs_netconn));
        // cJSON_AddItemToObject(root, "current_time",
        //                       cJSON_CreateString(strftime_buf));
        // printf("11111当前时间是: %s\n", strftime_buf);
        // printf("nvs_netconn: %s\n", nvs_netconn);
        if (atoi(nvs_netconn) == 2) {
          cJSON_AddItemToObject(root, "eth_ip", cJSON_CreateString("---"));
          cJSON_AddItemToObject(root, "sta_ip",
                                cJSON_CreateString(got_ip_addrs));
        } else {
          cJSON_AddItemToObject(root, "eth_ip",
                                cJSON_CreateString(got_ip_addrs));
          cJSON_AddItemToObject(root, "sta_ip", cJSON_CreateString("---"));
        }
        cJSON_AddItemToObject(root, "is_dhcp", cJSON_CreateString(nvs_is_dhcp));
        cJSON_AddItemToObject(root, "uptime", cJSON_CreateString(strftime_buf));
        // 添加外网连接状态，基于心跳请求的状态
        extern bool is_network_connected;
        extern bool is_intranet_mode;

        // 构建网络状态字符串
        char network_status[64];
        if (is_network_connected) {
            if (is_intranet_mode) {
                snprintf(network_status, sizeof(network_status), "已连接 (内网模式)");
            } else {
                snprintf(network_status, sizeof(network_status), "已连接 (外网模式)");
            }
        } else {
            snprintf(network_status, sizeof(network_status), "未连接");
        }

        cJSON_AddItemToObject(root, "internet_status",
                             cJSON_CreateString(network_status));
        cJSON_AddItemToObject(root, "host_names",
                              cJSON_CreateString(nvs_host_names));
        httpd_resp_set_hdr(req, "Connection", "close");
        httpd_resp_set_type(req, "application/json");
        // char *json_data = cJSON_Print(root);
        char *json_data = cJSON_Print(root);
        httpd_resp_send(req, json_data, strlen(json_data));

        free(json_data);
        cJSON_Delete(root);

        // get_current_time();
        // esp_netif_sntp_deinit();

      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
    }
    free(nvs_host_names);
    free(nvs_ntp_server);
    free(nvs_is_dhcp);
    free(nvs_netconn);
  }

  nvs_close(nvs_handle);

  return ESP_OK;
}

static esp_err_t get_sys_get_handler(httpd_req_t *req) {
  size_t free_heap_size_bytes = xPortGetFreeHeapSize();
  size_t min_ever_free_heap_size_bytes = xPortGetMinimumEverFreeHeapSize();
  float free_heap_size_kb = free_heap_size_bytes / 1024.0;
  float min_ever_free_heap_size_kb = min_ever_free_heap_size_bytes / 1024.0;
  esp_chip_info_t chip_info;
  esp_chip_info(&chip_info);
  int64_t time_since_boot = esp_timer_get_time();
  esp_reset_reason_t res_reason = esp_reset_reason();

  // 获取当前活跃套接字数量
  int socket_count = 0;
  struct tcp_pcb *pcb = tcp_active_pcbs;
  while (pcb != NULL) {
    socket_count++;
    pcb = pcb->next;
  }

  // 获取NVS使用率
  float nvs_usage = get_nvs_usage_percentage();

  cJSON *root = cJSON_CreateObject();
  cJSON_AddItemToObject(root, "chip_info_cpu_core",
                        cJSON_CreateNumber(chip_info.cores));
  cJSON_AddItemToObject(root, "wifi_frq", cJSON_CreateNumber(2.4));
  cJSON_AddItemToObject(root, "free_heap_size",
                        cJSON_CreateNumber(free_heap_size_kb));
  cJSON_AddItemToObject(root, "min_ever_free_heap_size",
                        cJSON_CreateNumber(min_ever_free_heap_size_kb));
  cJSON_AddItemToObject(root, "time_since_boot",
                        cJSON_CreateNumber(time_since_boot));
  cJSON_AddItemToObject(root, "res_reason",
                        cJSON_CreateString(reset_reason_to_string(res_reason)));
  cJSON_AddItemToObject(root, "version", cJSON_CreateString(VERSION));
  cJSON_AddItemToObject(root, "active_sockets",
                        cJSON_CreateNumber(socket_count));
  // 添加NVS使用率
  if (nvs_usage >= 0) {
    cJSON_AddItemToObject(root, "nvs_usage", cJSON_CreateNumber(nvs_usage));
  } else {
    cJSON_AddItemToObject(root, "nvs_usage", cJSON_CreateString("获取失败"));
  }
  char *json_data = cJSON_Print(root);
  httpd_resp_set_hdr(req, "Connection", "close");
  httpd_resp_set_type(req, "application/json");
  httpd_resp_send(req, json_data, strlen(json_data));
  free(json_data);
  cJSON_Delete(root);
  return ESP_OK;
}

static esp_err_t root_get_handler(httpd_req_t *req) {
  const uint32_t root_len = root_end - root_start;
  // ESP_LOGI(TAG, "Serve root");
  httpd_resp_set_hdr(req, "Connection", "close");
  httpd_resp_set_type(req, "text/html");
  httpd_resp_send(req, root_start, root_len);
  return ESP_OK;
}

static esp_err_t get_status_get_handler(httpd_req_t *req) {
  const uint32_t web_len = web_end - web_start;
  httpd_resp_set_hdr(req, "Connection", "close");
  httpd_resp_set_type(req, "text/html");
  httpd_resp_send(req, web_start, web_len);
  return ESP_OK;
}

static esp_err_t js_get_handler(httpd_req_t *req) {
  const uint32_t js_len = js_end - js_start;
  ESP_LOGI(TAG, "Serve js");
  httpd_resp_set_type(req, "application/javascript");
  httpd_resp_send(req, js_start, js_len);
  return ESP_OK;
}
static esp_err_t css_get_handler(httpd_req_t *req) {
  const uint32_t css_len = css_end - css_start;
  httpd_resp_set_type(req, "text/css");
  httpd_resp_send(req, css_start, css_len);
  return ESP_OK;
}

static esp_err_t post_handler(httpd_req_t *req) {
  char buf[512];
  int ret, remaining = req->content_len;
  while (remaining > 0) {
    if ((ret = httpd_req_recv(req, buf, MIN(remaining, sizeof(buf)))) <= 0) {
      if (ret == HTTPD_SOCK_ERR_TIMEOUT) {
        continue;
      }
      return ESP_FAIL;
    }
    remaining -= ret;
    ESP_LOGI(TAG, "%.*s", ret, buf);
  }
  printf("%s\n", buf);
  ESP_ERROR_CHECK(nvs_init());
  save_to_nvs(buf);
  //   save_form_data(buf);
  cJSON *root = cJSON_CreateObject();
  cJSON_AddItemToObject(root, "msg", cJSON_CreateString("success"));
  cJSON_AddItemToObject(root, "code", cJSON_CreateNumber(200));
  httpd_resp_set_hdr(req, "Connection", "close");
  httpd_resp_set_type(req, "application/json");
  char *json_data = cJSON_Print(root);
  httpd_resp_send(req, json_data, strlen(json_data));

  free(json_data);
  cJSON_Delete(root);
  return ESP_OK;
}

static esp_err_t get_mqtt_post_handler(httpd_req_t *req) {
  post_handler(req);
  return ESP_OK;
}

static esp_err_t get_net_set_post_handler(httpd_req_t *req) {
  post_handler(req);
  return ESP_OK;
}

static esp_err_t get_module_set_post_handler(httpd_req_t *req) {
  post_handler(req);
  return ESP_OK;
}

static esp_err_t get_tcp_post_handler(httpd_req_t *req) {
  post_handler(req);
  return ESP_OK;
}



static esp_err_t get_http_post_handler(httpd_req_t *req) {
  post_handler(req);
  return ESP_OK;
}

static esp_err_t get_ap_set_post_handler(httpd_req_t *req) {
  post_handler(req);
  return ESP_OK;
}

static esp_err_t get_serial_set_handler(httpd_req_t *req) {

  char buf[512];
  int ret, remaining = req->content_len;
  while (remaining > 0) {
    if ((ret = httpd_req_recv(req, buf, MIN(remaining, sizeof(buf)))) <= 0) {
      if (ret == HTTPD_SOCK_ERR_TIMEOUT) {
        continue;
      }
      return ESP_FAIL;
    }
    remaining -= ret;
    ESP_LOGI(TAG, "%.*s", ret, buf);
  }

  printf("%s\n", buf);
  ESP_ERROR_CHECK(nvs_init());
  save_to_nvs(buf);


  esp_err_t rets = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
  size_t baud_rate, data_bit, check_bit, stop_bit, frame_time, frame_len = 0;
  rets = nvs_get_str(nvs_handle, "baud_rate", NULL, &baud_rate);
  nvs_get_str(nvs_handle, "data_bit", NULL, &data_bit);
  nvs_get_str(nvs_handle, "check_bit", NULL, &check_bit);
  nvs_get_str(nvs_handle, "stop_bit", NULL, &stop_bit);
  nvs_get_str(nvs_handle, "frame_time", NULL, &frame_time);
  nvs_get_str(nvs_handle, "frame_len", NULL, &frame_len);
  // nvs_get_str(nvs_handle, "flow_ctl", NULL, &flow_ctl);
  switch (rets) {
  case ESP_OK:
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "baud_rate", "9600"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "data_bit", "8"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "check_bit", "0"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "stop_bit", "1"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "frame_time", "50"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "frame_len", "512"));
    // ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "flow_ctl", "0"));
    break;
  default:
    break;
  }
  if (rets != ESP_OK) {
    printf("Error getting size of 'SERIAL': %s\n", esp_err_to_name(rets));
  } else {
    char *nvs_baud_rate = malloc(baud_rate);
    char *nvs_data_bit = malloc(data_bit);
    char *nvs_check_bit = malloc(check_bit);
    char *nvs_stop_bit = malloc(stop_bit);
    char *nvs_frame_time = malloc(frame_time);
    char *nvs_frame_len = malloc(frame_len);
    // char *nvs_flow_ctl = malloc(flow_ctl);

    if (nvs_baud_rate == NULL) {
      printf("Memory allocation failed\n");
    } else {
      rets = nvs_get_str(nvs_handle, "baud_rate", nvs_baud_rate, &baud_rate);
      nvs_get_str(nvs_handle, "data_bit", nvs_data_bit, &data_bit);
      nvs_get_str(nvs_handle, "check_bit", nvs_check_bit, &check_bit);
      nvs_get_str(nvs_handle, "stop_bit", nvs_stop_bit, &stop_bit);
      nvs_get_str(nvs_handle, "frame_time", nvs_frame_time, &frame_time);
      nvs_get_str(nvs_handle, "frame_len", nvs_frame_len, &frame_len);
      // nvs_get_str(nvs_handle, "flow_ctl", nvs_flow_ctl, &flow_ctl);
      if (rets == ESP_OK) {
        printf("Value for 'baud_rate' is %s\n", nvs_baud_rate);
        printf("Value for 'data_bit' is %s\n", nvs_data_bit);
        printf("Value for 'check_bit' is %s\n", nvs_check_bit);
        printf("Value for 'stop_bit' is %s\n", nvs_stop_bit);
        printf("Value for 'frame_time' is %s\n", nvs_frame_time);
        printf("Value for 'frame_len' is %s\n", nvs_frame_len);
        uart_parity_t parity = 0;
        if (nvs_check_bit != NULL) {
          if (strcmp(nvs_check_bit, "None") == 0) {
            parity = UART_PARITY_DISABLE;
          } else if (strcmp(nvs_check_bit, "Odd") == 0) {
            parity = UART_PARITY_ODD;
          } else if (strcmp(nvs_check_bit, "Even") == 0) {
            parity = UART_PARITY_EVEN;
          }
        }
        uart_reinit(atoi(nvs_baud_rate), atoi(nvs_data_bit), parity,
                    atof(nvs_stop_bit), atoi(nvs_frame_time),
                    atoi(nvs_frame_len));

      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(rets));
      }
      free(nvs_baud_rate);
      free(nvs_data_bit);
      free(nvs_check_bit);
      free(nvs_stop_bit);
      free(nvs_frame_time);
      free(nvs_frame_len);
      // free(nvs_flow_ctl);
    }
  }
  nvs_close(nvs_handle);

  cJSON *root = cJSON_CreateObject();
  cJSON_AddItemToObject(root, "msg", cJSON_CreateString("success"));
  cJSON_AddItemToObject(root, "code", cJSON_CreateNumber(200));
  httpd_resp_set_hdr(req, "Connection", "close");
  httpd_resp_set_type(req, "application/json");
  char *json_data = cJSON_Print(root);
  httpd_resp_send(req, json_data, strlen(json_data));
  free(json_data);
  cJSON_Delete(root);

  // cJSON_Delete(json);
  // post_handler(req);
  return ESP_OK;
}

static esp_err_t get_serial_ctl_handler(httpd_req_t *req) {
  char buf[1024];
  int ret, remaining = req->content_len;

  while (remaining > 0) {
    if ((ret = httpd_req_recv(req, buf, MIN(remaining, sizeof(buf)))) <= 0) {
      if (ret == HTTPD_SOCK_ERR_TIMEOUT) {
        continue;
      }
      return ESP_FAIL;
    }
    remaining -= ret;
    ESP_LOGI(TAG, "%.*s", ret, buf);
  }

  cJSON *json = cJSON_Parse(buf);
  if (json == NULL) {
    const char *error_ptr = cJSON_GetErrorPtr();
    if (error_ptr != NULL) {
      fprintf(stderr, "Error before: %s\n", error_ptr);
    }
    return ESP_FAIL;
  }

  cJSON *instruction = cJSON_GetObjectItemCaseSensitive(json, "instruction");
  cJSON *sendType = cJSON_GetObjectItemCaseSensitive(json, "sendType");

  if (cJSON_IsString(instruction) && instruction->valuestring != NULL) {
    if (cJSON_IsString(sendType) && strcmp(sendType->valuestring, "hex") == 0) {
      // 处理十六进制数据
      size_t len = strlen(instruction->valuestring);
      uint8_t *hex_data = malloc(len / 2);
      size_t hex_len = 0;

      // 移除空格
      char *clean_str = malloc(len + 1);
      size_t clean_len = 0;
      for (size_t i = 0; i < len; i++) {
        if (instruction->valuestring[i] != ' ') {
          clean_str[clean_len++] = instruction->valuestring[i];
        }
      }
      clean_str[clean_len] = '\0';

      // 转换为十六进制
      for (size_t i = 0; i < clean_len; i += 2) {
        char byte_str[3] = {clean_str[i], clean_str[i + 1], '\0'};
        hex_data[hex_len++] = strtol(byte_str, NULL, 16);
      }

      tx_tasks(hex_data, hex_len);
      free(hex_data);
      free(clean_str);
    } else {
      // 处理ASCII字符串 - 直接传递，tx_tasks会创建副本
      tx_tasks((uint8_t *)instruction->valuestring, strlen(instruction->valuestring));
    }
  }

  // 返回响应
  cJSON *root = cJSON_CreateObject();
  cJSON_AddItemToObject(root, "code", cJSON_CreateNumber(200));
  char *json_data = cJSON_Print(root);
  httpd_resp_set_type(req, "application/json");
  httpd_resp_send(req, json_data, strlen(json_data));

  free(json_data);
  cJSON_Delete(root);
  cJSON_Delete(json);

  return ESP_OK;
}

static esp_err_t get_uart_response_handler(httpd_req_t *req) {
    // 现在数据通过WebSocket实时发送，这个接口只返回空数据以避免重复
    // 设置响应类型
    httpd_resp_set_type(req, "application/json");
    
    // 返回空的JSON对象
    httpd_resp_sendstr(req, "{}");
    
    return ESP_OK;
}


// 添加全局变量来存储OTA进度
static int ota_progress = 0;
static char ota_status[64] = "准备中...";

// 添加新的处理函数来获取OTA进度
static esp_err_t get_ota_progress_handler(httpd_req_t *req) {
  cJSON *root = cJSON_CreateObject();
  cJSON_AddNumberToObject(root, "progress", ota_progress);
  cJSON_AddStringToObject(root, "status", ota_status);

  char *json_str = cJSON_Print(root);
  httpd_resp_set_type(req, "application/json");
  httpd_resp_send(req, json_str, strlen(json_str));

  free(json_str);
  cJSON_Delete(root);
  return ESP_OK;
}

static esp_err_t get_update_post_handler(httpd_req_t *req) {
  char buf[1024];
  int ret, remaining = req->content_len;

  while (remaining > 0) {
    if ((ret = httpd_req_recv(req, buf, sizeof(buf))) <= 0) {
      if (ret == HTTPD_SOCK_ERR_TIMEOUT) {
        // httpd_resp_send_500(req);
        continue;
      }
      return ESP_FAIL;
    }
    remaining -= ret;
    ESP_LOGI(TAG, "%.*s", ret, buf);
  }

  printf("%s\n", buf);

  httpd_resp_send(req, "DI", HTTPD_RESP_USE_STRLEN);
  return ESP_OK;
}

// 添加OTA任务函数
static void ota_task(void *pvParameter) {
  const char *url = (const char *)pvParameter;

  esp_http_client_config_t config = {
      .url = url,
      .timeout_ms = 5000,
      .keep_alive_enable = true,
  };

  esp_https_ota_config_t ota_config = {
      .http_config = &config,
  };

  esp_https_ota_handle_t https_ota_handle = NULL;
  esp_err_t err = esp_https_ota_begin(&ota_config, &https_ota_handle);

  if (err != ESP_OK) {
    snprintf(ota_status, sizeof(ota_status), "OTA开始失败: %s",
             esp_err_to_name(err));
    vTaskDelete(NULL);
    return;
  }

  while (1) {
    err = esp_https_ota_perform(https_ota_handle);
    if (err != ESP_ERR_HTTPS_OTA_IN_PROGRESS) {
      break;
    }

    // 更新进度
    int image_size = esp_https_ota_get_image_size(https_ota_handle);
    int image_done = esp_https_ota_get_image_len_read(https_ota_handle);
    if (image_size > 0) {
      ota_progress = (image_done * 100) / image_size;
      snprintf(ota_status, sizeof(ota_status), "升级中 %d%%", ota_progress);
    }
    vTaskDelay(pdMS_TO_TICKS(10));
  }

  if (err != ESP_OK) {
    snprintf(ota_status, sizeof(ota_status), "升级失败: %s",
             esp_err_to_name(err));
    esp_https_ota_abort(https_ota_handle);
  } else {
    err = esp_https_ota_finish(https_ota_handle);
    if (err == ESP_OK) {
      snprintf(ota_status, sizeof(ota_status), "升级成功，准备重启...");
      ota_progress = 100;
      vTaskDelay(pdMS_TO_TICKS(2000));
      esp_restart();
    } else {
      snprintf(ota_status, sizeof(ota_status), "固件验证失败: %s",
               esp_err_to_name(err));
    }
  }

  vTaskDelete(NULL);
}

static esp_err_t get_ota_post_handler(httpd_req_t *req) {
  char buf[1024];
  int ret, remaining = req->content_len;

  // 读取POST请求数据
  while (remaining > 0) {
    if ((ret = httpd_req_recv(req, buf, MIN(remaining, sizeof(buf)))) <= 0) {
      if (ret == HTTPD_SOCK_ERR_TIMEOUT) {
        continue;
      }
      return ESP_FAIL;
    }
    remaining -= ret;
    ESP_LOGI(TAG, "%.*s", ret, buf);
  }

  printf("ota post :%s\n", buf);

  // 解析JSON数据
  cJSON *json = cJSON_Parse(buf);
  if (json == NULL) {
    const char *error_ptr = cJSON_GetErrorPtr();
    if (error_ptr != NULL) {
      fprintf(stderr, "Error before: %s\n", error_ptr);
      snprintf(ota_status, sizeof(ota_status), "JSON解析失败");
    }
    return ESP_FAIL;
  }

  // 获取OTA URL
  cJSON *ota_url = cJSON_GetObjectItemCaseSensitive(json, "ota_url");
  if (!cJSON_IsString(ota_url) || (ota_url->valuestring == NULL)) {
    snprintf(ota_status, sizeof(ota_status), "无效的URL");
    cJSON_Delete(json);
    return ESP_FAIL;
  }

  printf("ota_url: %s\n", ota_url->valuestring);

  // 重置OTA状态
  ota_progress = 0;
  snprintf(ota_status, sizeof(ota_status), "准备中...");

  // 发送初始响应
  cJSON *root = cJSON_CreateObject();
  cJSON_AddItemToObject(root, "msg", cJSON_CreateString("success"));
  cJSON_AddItemToObject(root, "code", cJSON_CreateNumber(200));
  httpd_resp_set_hdr(req, "Connection", "close");
  httpd_resp_set_type(req, "application/json");
  char *json_data = cJSON_Print(root);
  httpd_resp_send(req, json_data, strlen(json_data));
  free(json_data);
  cJSON_Delete(root);

  // 在新任务中执行OTA更新
  char *url_copy = strdup(ota_url->valuestring); // 复制URL字符串
  if (url_copy != NULL) {
    TaskHandle_t task_handle;
    if (xTaskCreate(ota_task, "ota_task", 8192, (void *)url_copy, 5,
                    &task_handle) != pdPASS) {
      free(url_copy);
      snprintf(ota_status, sizeof(ota_status), "创建OTA任务失败");
    }
  } else {
    snprintf(ota_status, sizeof(ota_status), "内存分配失败");
  }

  cJSON_Delete(json);
  return ESP_OK;
}

static esp_err_t get_operate_get_handler(httpd_req_t *req) {
  // 在重启前确保工作模式已设置，但不强制设为默认模式
  nvs_handle_t storage_handle;
  esp_err_t err = nvs_open("storage", NVS_READWRITE, &storage_handle);
  if (err == ESP_OK) {
    // 检查是否已设置工作模式
    size_t required_size;
    err = nvs_get_str(storage_handle, "w_mode", NULL, &required_size);
    if (err == ESP_ERR_NVS_NOT_FOUND) {
      // 如果没有设置，才设置默认值为mqtt_tcp
      nvs_set_str(storage_handle, "w_mode", "mqtt_tcp");
      nvs_commit(storage_handle);
    } else {
      // 如果已设置，但值可能没有被提交，确保此时提交
      char work_mode[32];
      nvs_get_str(storage_handle, "w_mode", work_mode, &required_size);
      ESP_LOGI(TAG, "重启前确认工作模式: %s", work_mode);
      // 重新写入当前值并确保提交，防止未提交的情况
      nvs_set_str(storage_handle, "w_mode", work_mode);
      nvs_commit(storage_handle);
    }
    nvs_close(storage_handle);
  }

  httpd_resp_send(req, "{\"restart\":\"success\"}", HTTPD_RESP_USE_STRLEN);
  vTaskDelay(100);
  esp_restart();
  return ESP_OK;
}

static esp_err_t get_restore_get_handler(httpd_req_t *req) {
  // 保存当前工作模式
  char current_work_mode[32] = "mqtt_tcp";  // 默认为MQTT/TCP透传
  nvs_handle_t storage_handle;
  esp_err_t err = nvs_open("storage", NVS_READWRITE, &storage_handle);
  if (err == ESP_OK) {
    // 获取当前工作模式
    size_t required_size = sizeof(current_work_mode);
    err = nvs_get_str(storage_handle, "w_mode", current_work_mode, &required_size);
    if (err != ESP_OK) {
      // 如果获取失败，使用默认值
      strcpy(current_work_mode, "mqtt_tcp");
    }
    ESP_LOGI(TAG, "恢复出厂设置前，保存当前工作模式: %s", current_work_mode);
    nvs_close(storage_handle);
  }

  httpd_resp_send(req, "{\"restore\":\"success\"}", HTTPD_RESP_USE_STRLEN);

  // 延时确保响应发送完成
  vTaskDelay(100 / portTICK_PERIOD_MS);

  // 先停止LED闪烁定时器，防止定时器回调覆盖LED状态
  extern esp_timer_handle_t time_sync_led_timer;
  if (time_sync_led_timer != NULL) {
    esp_err_t timer_err = esp_timer_stop(time_sync_led_timer);
    if (timer_err != ESP_OK && timer_err != ESP_ERR_INVALID_STATE) {
      ESP_LOGW(TAG, "停止LED定时器失败: %s", esp_err_to_name(timer_err));
    } else {
      ESP_LOGI(TAG, "LED闪烁定时器已停止");
    }
  }

  // 擦除NVS
  ESP_LOGI(TAG, "开始擦除NVS...");
  ESP_ERROR_CHECK(nvs_flash_erase());
  vTaskDelay(100 / portTICK_PERIOD_MS);

  // 重新初始化NVS
  ESP_ERROR_CHECK(nvs_flash_init());

  // 重新设置工作模式
  err = nvs_open("storage", NVS_READWRITE, &storage_handle);
  if (err == ESP_OK) {
    nvs_set_str(storage_handle, "w_mode", current_work_mode);
    ESP_LOGI(TAG, "恢复出厂设置后，重新设置工作模式: %s", current_work_mode);
    nvs_commit(storage_handle);
    nvs_close(storage_handle);
  }

  // 所有灯全亮一秒（与按键长按重置保持一致）
  ESP_LOGI(TAG, "所有LED全亮，表示重置成功");
  LED_DAT_ON();
  LED_WIFI_ON();
  LED_LAN_ON();
  vTaskDelay(1000 / portTICK_PERIOD_MS);

  // 所有灯全灭
  LED_DAT_OFF();
  LED_WIFI_OFF();
  LED_LAN_OFF();
  vTaskDelay(100 / portTICK_PERIOD_MS);

  // 重启设备
  ESP_LOGI(TAG, "设备即将重启...");
  esp_restart();
  return ESP_OK;
}

esp_err_t http_404_error_handler(httpd_req_t *req, httpd_err_code_t err) {
  httpd_resp_set_status(req, "302 Temporary Redirect");
  httpd_resp_set_hdr(req, "Location", "/");
  httpd_resp_send(req, "Redirect to the captive portal", HTTPD_RESP_USE_STRLEN);
  // ESP_LOGI(TAG, "Redirecting to root");
  return ESP_OK;
}

// SERIAL GET Handler
static esp_err_t get_serial_set_info_get_handler(httpd_req_t *req) {
  esp_err_t ret = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
  size_t baud_rate, data_bit, check_bit, stop_bit, frame_time, frame_len = 0;
  ret = nvs_get_str(nvs_handle, "baud_rate", NULL, &baud_rate);
  nvs_get_str(nvs_handle, "data_bit", NULL, &data_bit);
  nvs_get_str(nvs_handle, "check_bit", NULL, &check_bit);
  nvs_get_str(nvs_handle, "stop_bit", NULL, &stop_bit);
  nvs_get_str(nvs_handle, "frame_time", NULL, &frame_time);
  nvs_get_str(nvs_handle, "frame_len", NULL, &frame_len);

  // nvs_get_str(nvs_handle, "flow_ctl", NULL, &flow_ctl);
  switch (ret) {
  case ESP_OK:
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "baud_rate", "9600"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "data_bit", "8"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "check_bit", "0"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "stop_bit", "1"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "frame_time", "50"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "frame_len", "512"));
    // ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "flow_ctl", "0"));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'SERIAL': %s\n", esp_err_to_name(ret));
  } else {
    char *nvs_baud_rate = malloc(baud_rate);
    char *nvs_data_bit = malloc(data_bit);
    char *nvs_check_bit = malloc(check_bit);
    char *nvs_stop_bit = malloc(stop_bit);
    char *nvs_frame_time = malloc(frame_time);
    char *nvs_frame_len = malloc(frame_len);
    // char *nvs_flow_ctl = malloc(flow_ctl);

    if (nvs_baud_rate == NULL) {
      printf("Memory allocation failed\n");
    } else {
      ret = nvs_get_str(nvs_handle, "baud_rate", nvs_baud_rate, &baud_rate);
      nvs_get_str(nvs_handle, "data_bit", nvs_data_bit, &data_bit);
      nvs_get_str(nvs_handle, "check_bit", nvs_check_bit, &check_bit);
      nvs_get_str(nvs_handle, "stop_bit", nvs_stop_bit, &stop_bit);
      nvs_get_str(nvs_handle, "frame_time", nvs_frame_time, &frame_time);
      nvs_get_str(nvs_handle, "frame_len", nvs_frame_len, &frame_len);
      // nvs_get_str(nvs_handle, "flow_ctl", nvs_flow_ctl, &flow_ctl);
      if (ret == ESP_OK) {
        printf("Value for 'baud_rate' is %s\n", nvs_baud_rate);
        printf("Value for 'data_bit' is %s\n", nvs_data_bit);
        printf("Value for 'check_bit' is %s\n", nvs_check_bit);
        printf("Value for 'stop_bit' is %s\n", nvs_stop_bit);
        printf("Value for 'frame_time' is %s\n", nvs_frame_time);
        printf("Value for 'frame_len' is %s\n", nvs_frame_len);
        // printf("Value for 'flow_ctl' is %s\n", nvs_flow_ctl);
        cJSON *root = cJSON_CreateObject();
        cJSON_AddItemToObject(root, "baud_rate",
                              cJSON_CreateString(nvs_baud_rate));
        cJSON_AddItemToObject(root, "data_bit",
                              cJSON_CreateString(nvs_data_bit));
        cJSON_AddItemToObject(root, "check_bit",
                              cJSON_CreateString(nvs_check_bit));
        cJSON_AddItemToObject(root, "stop_bit",
                              cJSON_CreateString(nvs_stop_bit));
        cJSON_AddItemToObject(root, "frame_time",
                              cJSON_CreateString(nvs_frame_time));
        cJSON_AddItemToObject(root, "frame_len",
                              cJSON_CreateString(nvs_frame_len));
        // cJSON_AddItemToObject(root, "flow_ctl",
        //                       cJSON_CreateString(nvs_flow_ctl));
        httpd_resp_set_hdr(req, "Connection", "close");
        httpd_resp_set_type(req, "application/json");
        char *json_data = cJSON_Print(root);
        httpd_resp_send(req, json_data, strlen(json_data));
        free(json_data);
        cJSON_Delete(root);
      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_baud_rate);
      free(nvs_data_bit);
      free(nvs_check_bit);
      free(nvs_stop_bit);
      free(nvs_frame_time);
      free(nvs_frame_len);
      // free(nvs_flow_ctl);
    }
  }
  nvs_close(nvs_handle);
  return ESP_OK;
}

// 协议配置检查函数
static bool check_protocol_enabled(const char *protocol) {
  nvs_handle_t nvs_handle;
  esp_err_t err = nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle);
  if (err != ESP_OK) {
    ESP_LOGE(TAG, "Failed to open NVS for protocol check: %s", esp_err_to_name(err));
    return false;
  }
  
  char key[32];
  snprintf(key, sizeof(key), "use_%s", protocol);
  
  size_t required_size = 0;
  err = nvs_get_str(nvs_handle, key, NULL, &required_size);
  if (err != ESP_OK || required_size == 0) {
    nvs_close(nvs_handle);
    return false;
  }
  
  char *value = malloc(required_size);
  if (!value) {
    nvs_close(nvs_handle);
    return false;
  }
  
  err = nvs_get_str(nvs_handle, key, value, &required_size);
  nvs_close(nvs_handle);
  
  bool enabled = false;
  if (err == ESP_OK && value && strlen(value) > 0) {
    // 只有明确设置为"1"时才认为协议已启用，空字符串表示未配置
    if (strcmp(value, "1") == 0) {
      enabled = true;
    }
  }
  
  free(value);
  return enabled;
}

// 添加工作模式设置处理函数
static esp_err_t get_work_mode_set_handler(httpd_req_t *req) {
  ESP_LOGI(TAG, "Received work mode set request");
  
  // 系统健康检查
  if (!system_health_check()) {
    ESP_LOGE(TAG, "系统健康检查失败，拒绝配置修改请求");
    httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, 
                        "系统资源不足，请稍后重试");
    return ESP_FAIL;
  }

  // 读取POST数据
  char *buf = malloc(req->content_len + 1);
  if (!buf) {
    httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "内存分配失败");
    return ESP_FAIL;
  }

  int ret = httpd_req_recv(req, buf, req->content_len);
  if (ret <= 0) {
    free(buf);
    return ESP_FAIL;
  }
  buf[req->content_len] = '\0';

  ESP_LOGI(TAG, "Received data: %s", buf);

  // 解析JSON数据
  cJSON *root = cJSON_Parse(buf);
  free(buf);

  if (!root) {
    httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "JSON解析失败");
    return ESP_FAIL;
  }

  // 获取NVS互斥锁保护
  if (nvs_mutex == NULL || xSemaphoreTake(nvs_mutex, pdMS_TO_TICKS(5000)) != pdTRUE) {
    ESP_LOGE(TAG, "Failed to acquire NVS mutex");
    cJSON_Delete(root);
    httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "系统忙，请稍后重试");
    return ESP_FAIL;
  }

  // 打开NVS
  nvs_handle_t nvs_handle;
  esp_err_t err = nvs_open("storage", NVS_READWRITE, &nvs_handle);
  if (err != ESP_OK) {
    xSemaphoreGive(nvs_mutex);
    cJSON_Delete(root);
    httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "NVS打开失败");
    return ESP_FAIL;
  }

  // 不再清除旧的配置，只更新需要的字段
  // nvs_erase_all(nvs_handle);

  // 获取当前工作模式，在切换前先保存现有配置
  char current_work_mode[32] = {0};
  size_t current_mode_len = sizeof(current_work_mode);
  esp_err_t current_mode_err = nvs_get_str(nvs_handle, "w_mode", current_work_mode, &current_mode_len);
  
  // 保存工作模式
  cJSON *work_mode = cJSON_GetObjectItem(root, "work_mode");
  if (work_mode && work_mode->valuestring) {
    // 如果当前是modbus_rtu模式，且要切换到其他模式，先保存当前modbus配置
    if (current_mode_err == ESP_OK && strcmp(current_work_mode, "modbus_rtu") == 0 && 
        strcmp(work_mode->valuestring, "modbus_rtu") != 0) {
      ESP_LOGI(TAG, "从Modbus-RTU模式切换，保持现有配置");
      // 不清除modbus配置，只更新工作模式
    }
    nvs_set_str(nvs_handle, "w_mode", work_mode->valuestring);
  }

  // 处理轮询间隔时间，包含验证逻辑
  cJSON *poll_time = cJSON_GetObjectItem(root, "poll_time");
  if (poll_time && poll_time->valuestring) {
    int poll_time_ms = atoi(poll_time->valuestring);

    // 验证轮询间隔时间的合理性
    if (poll_time_ms < 1000) {
      ESP_LOGW(TAG, "轮询间隔时间 %d ms 太小，调整为最小值 1000 ms (1秒)", poll_time_ms);
      poll_time_ms = 1000;
    } else if (poll_time_ms > 3600000) {
      ESP_LOGW(TAG, "轮询间隔时间 %d ms 太大，调整为最大值 3600000 ms (1小时)", poll_time_ms);
      poll_time_ms = 3600000;
    }

    // 将调整后的值转换为字符串并保存
    char adjusted_poll_time[16];
    snprintf(adjusted_poll_time, sizeof(adjusted_poll_time), "%d", poll_time_ms);
    nvs_set_str(nvs_handle, "poll_time", adjusted_poll_time);

    ESP_LOGI(TAG, "轮询间隔时间设置为: %d ms (%.1f 秒)", poll_time_ms, poll_time_ms / 1000.0);
  }

  // 立即提交工作模式和轮询时间的更改
  nvs_commit(nvs_handle);
  ESP_LOGI(TAG, "工作模式和轮询时间已保存并提交");

  // 处理modbus配置项 - 无论什么工作模式都要保存配置，确保切换时不丢失
  cJSON *modbus_items = cJSON_GetObjectItem(root, "modbus_items");
  if (modbus_items && cJSON_IsArray(modbus_items)) {
    // 保存Modbus配置项，无论当前模式如何
    int items_count = cJSON_GetArraySize(modbus_items);
    nvs_set_i32(nvs_handle, "m_count", items_count);
    ESP_LOGI(TAG, "保存Modbus配置项 %d 个", items_count);
    
    // 保存每个配置项到NVS
    for (int i = 0; i < items_count; i++) {
      cJSON *item = cJSON_GetArrayItem(modbus_items, i);
      if (!item) continue;

      // 获取并保存启用状态
      cJSON *enabled = cJSON_GetObjectItem(item, "enabled");
      bool is_enabled = (enabled && cJSON_IsTrue(enabled));
      
      char enabled_key[16];
      snprintf(enabled_key, sizeof(enabled_key), "m%d_en", i);
      nvs_set_u8(nvs_handle, enabled_key, is_enabled ? 1 : 0);

      // 保存配置到NVS
      const struct {
        const char *json_key;
        const char *nvs_key;
      } fields[] = {
          {"slave_addr", "s_addr"},
          {"function_code", "f_code"},
          {"register_addr", "r_addr"},
          {"register_num", "r_num"},
          {"timeout", "timeout"},
          {"data_format", "d_fmt"},
          {"interval_time", "i_time"},
          {"report_format", "r_fmt"},
          {"baud_rate", "baud_rate"},
          {"data_bit", "data_bit"},
          {"stop_bit", "stop_bit"},
          {"check_bit", "check_bit"},
      };

      for (int j = 0; j < sizeof(fields) / sizeof(fields[0]); j++) {
        cJSON *field = cJSON_GetObjectItem(item, fields[j].json_key);
        if (field && field->valuestring) {
          char nvs_key[16];
          snprintf(nvs_key, sizeof(nvs_key), "m%d%s", i, fields[j].nvs_key);
          nvs_set_str(nvs_handle, nvs_key, field->valuestring);
        }
      }
    }
  }
  
  // 处理modbus任务管理
  if (work_mode) {
    if (strcmp(work_mode->valuestring, "modbus_rtu") == 0) {
      // 当前切换到modbus_rtu模式，启动任务
    // 检查Modbus-RTU网关模式下的协议配置
    cJSON *modbus_items = cJSON_GetObjectItem(root, "modbus_items");
    if (modbus_items && cJSON_IsArray(modbus_items)) {
      int items_count = cJSON_GetArraySize(modbus_items);
      
      // 收集所有使用的上报方式
      bool has_mqtt = false, has_tcp = false, has_http = false;
      bool mqtt_enabled = false, tcp_enabled = false, http_enabled = false;
      
      for (int i = 0; i < items_count; i++) {
        cJSON *item = cJSON_GetArrayItem(modbus_items, i);
        if (!item) continue;
        
        cJSON *report_format = cJSON_GetObjectItem(item, "report_format");
        if (report_format && report_format->valuestring) {
          if (strcmp(report_format->valuestring, "MQTT") == 0) {
            has_mqtt = true;
          } else if (strcmp(report_format->valuestring, "TCP") == 0) {
            has_tcp = true;
          } else if (strcmp(report_format->valuestring, "HTTP") == 0) {
            has_http = true;
          }
        }
      }
      
      // 检查协议是否启用
      if (has_mqtt) mqtt_enabled = check_protocol_enabled("mqtt");
      if (has_tcp) tcp_enabled = check_protocol_enabled("tcp");
      if (has_http) http_enabled = check_protocol_enabled("http");
      
      // 如果有使用的协议未启用，返回错误
      if ((has_mqtt && !mqtt_enabled) || (has_tcp && !tcp_enabled) || (has_http && !http_enabled)) {
        nvs_close(nvs_handle);
        xSemaphoreGive(nvs_mutex);  // 释放互斥锁
        cJSON_Delete(root);
        
        // 构建错误响应
        cJSON *error_response = cJSON_CreateObject();
        cJSON_AddNumberToObject(error_response, "code", 400);
        
        char error_msg[256] = "请先在协议管理中启用并配置以下协议: ";
        bool first = true;
        if (has_mqtt && !mqtt_enabled) {
          if (!first) strcat(error_msg, ", ");
          strcat(error_msg, "MQTT");
          first = false;
        }
        if (has_tcp && !tcp_enabled) {
          if (!first) strcat(error_msg, ", ");
          strcat(error_msg, "TCP");
          first = false;
        }
        if (has_http && !http_enabled) {
          if (!first) strcat(error_msg, ", ");
          strcat(error_msg, "HTTP");
          first = false;
        }
        
        cJSON_AddStringToObject(error_response, "msg", error_msg);
        
        char *json_error = cJSON_Print(error_response);
        httpd_resp_set_type(req, "application/json");
        httpd_resp_sendstr(req, json_error);
        
        free(json_error);
        cJSON_Delete(error_response);
        return ESP_OK; // 正常返回，但带有错误信息
      }
    }
    
    stop_modbus_tasks(); // 停止现有任务

    if (modbus_items && cJSON_IsArray(modbus_items)) {
      int items_count = cJSON_GetArraySize(modbus_items);

      // 创建Modbus任务配置 - 配置已经在上面保存到NVS了
      ModbusTaskConfig *task_config = malloc(sizeof(ModbusTaskConfig));
      if (task_config != NULL) {
        task_config->items_count = items_count;
        task_config->items = malloc(items_count * sizeof(ModbusItemConfig));

        if (task_config->items != NULL) {
          // 遍历每个modbus项，只创建任务配置结构
          for (int i = 0; i < items_count; i++) {
            cJSON *item = cJSON_GetArrayItem(modbus_items, i);
            if (!item)
              continue;

            ModbusItemConfig *config_item = &task_config->items[i];
            memset(config_item, 0, sizeof(ModbusItemConfig));

            // 获取启用状态
            cJSON *enabled = cJSON_GetObjectItem(item, "enabled");
            config_item->enabled = (enabled && cJSON_IsTrue(enabled));

            // 填充任务配置结构
            const struct {
              const char *json_key;
              char *config_field;
              size_t field_size;
            } fields[] = {
                {"slave_addr", config_item->slave_addr, sizeof(config_item->slave_addr)},
                {"function_code", config_item->function_code, sizeof(config_item->function_code)},
                {"register_addr", config_item->register_addr, sizeof(config_item->register_addr)},
                {"register_num", config_item->register_num, sizeof(config_item->register_num)},
                {"timeout", config_item->timeout, sizeof(config_item->timeout)},
                {"data_format", config_item->data_format, sizeof(config_item->data_format)},
                {"interval_time", config_item->interval_time, sizeof(config_item->interval_time)},
                {"report_format", config_item->report_format, sizeof(config_item->report_format)},
                {"baud_rate", config_item->baud_rate, sizeof(config_item->baud_rate)},
                {"data_bit", config_item->data_bit, sizeof(config_item->data_bit)},
                {"stop_bit", config_item->stop_bit, sizeof(config_item->stop_bit)},
                {"check_bit", config_item->check_bit, sizeof(config_item->check_bit)},
            };

            for (int j = 0; j < sizeof(fields) / sizeof(fields[0]); j++) {
              cJSON *field = cJSON_GetObjectItem(item, fields[j].json_key);
              if (field && field->valuestring) {
                // 只保存到任务配置
                strncpy(fields[j].config_field, field->valuestring,
                        fields[j].field_size - 1);
              }
            }
          }

          // 启动Modbus任务
          esp_err_t err = start_modbus_task(task_config);
          if (err != ESP_OK) {
            ESP_LOGE(TAG, "Failed to start Modbus task, cleaning up memory");
            // 清理资源
            free(task_config->items);
            free(task_config);
          } else {
            ESP_LOGI(TAG, "Modbus任务启动成功，配置已传递给任务");
            // 注意：task_config的内存现在由Modbus任务管理，不要在这里释放
          }
        } else {
          free(task_config);
        }
      }
    }
    } else {
      // 切换到非modbus_rtu模式，停止modbus任务
      ESP_LOGI(TAG, "切换到非Modbus-RTU模式，停止Modbus任务");
      stop_modbus_tasks();
    }
  }

  // 提交NVS更改
  nvs_commit(nvs_handle);
  nvs_close(nvs_handle);
  
  // 释放NVS互斥锁
  xSemaphoreGive(nvs_mutex);

  // 发送响应
  cJSON *response = cJSON_CreateObject();
  cJSON_AddNumberToObject(response, "code", 200);
  cJSON_AddStringToObject(response, "msg", "success");

  char *json_response = cJSON_Print(response);
  httpd_resp_set_type(req, "application/json");
  httpd_resp_sendstr(req, json_response);

  free(json_response);
  cJSON_Delete(response);
  cJSON_Delete(root);

  return ESP_OK;
}

// 添加工作模式信息获取处理函数
static esp_err_t get_work_mode_info_handler(httpd_req_t *req) {
  nvs_handle_t nvs_handle;
  esp_err_t err = nvs_open("storage", NVS_READWRITE, &nvs_handle);
  if (err != ESP_OK) {
    // 处理 NVS 打开失败
    httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR,
                        "Failed to open NVS");
    return ESP_FAIL;
  }

  cJSON *response = cJSON_CreateObject();
  if (response == NULL) {
    nvs_close(nvs_handle);
    httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR,
                        "Failed to create JSON object");
    return ESP_FAIL;
  }

  // 获取工作模式
  char work_mode[32] = "mqtt_tcp";
  size_t len = sizeof(work_mode);
  err = nvs_get_str(nvs_handle, "w_mode", work_mode, &len);
  if (err != ESP_ERR_NVS_NOT_FOUND) { // 如果键不存在使用默认值
    cJSON_AddStringToObject(response, "work_mode", work_mode);
  } else {
    // 如果w_mode不存在，添加默认值mqtt_tcp
    cJSON_AddStringToObject(response, "work_mode", "mqtt_tcp");
  }
  // 获取轮询间隔时间
  char poll_time[32] = "30000"; // 默认值30000ms（30秒）
  size_t poll_time_len = sizeof(poll_time);
  err = nvs_get_str(nvs_handle, "poll_time", poll_time, &poll_time_len);
  if (err != ESP_ERR_NVS_NOT_FOUND) {
    cJSON_AddStringToObject(response, "poll_time", poll_time);
  } else {
    cJSON_AddStringToObject(response, "poll_time",
                            "30000"); // 如果未设置则返回默认值30秒
  }

  // 无论什么工作模式都返回modbus配置，确保配置不丢失
  int32_t items_count = 0;
  err = nvs_get_i32(nvs_handle, "m_count", &items_count);
  ESP_LOGI(TAG, "读取Modbus配置项数量: %" PRId32 " (err: %s)", items_count, esp_err_to_name(err));
  
  if (err == ESP_OK && items_count > 0) {
      cJSON *modbus_items = cJSON_AddArrayToObject(response, "modbus_items");
      if (modbus_items == NULL) {
        cJSON_Delete(response);
        nvs_close(nvs_handle);
        httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR,
                            "Failed to create modbus items array");
        return ESP_FAIL;
      }

      for (int i = 0; i < items_count; i++) {
        ESP_LOGI(TAG, "处理Modbus配置项 %d", i);
        cJSON *item = cJSON_CreateObject();
        if (item == NULL) {
          ESP_LOGE(TAG, "无法创建配置项 %d 的JSON对象", i);
          cJSON_Delete(response);
          nvs_close(nvs_handle);
          httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR,
                              "Failed to create item object");
          return ESP_FAIL;
        }

        // 读取启用状态
        uint8_t enabled = 0;
        char enabled_key[16];
        snprintf(enabled_key, sizeof(enabled_key), "m%d_en", i);
        esp_err_t enabled_err = nvs_get_u8(nvs_handle, enabled_key, &enabled);
        ESP_LOGI(TAG, "配置项 %d 启用状态: %d (err: %s)", i, enabled, esp_err_to_name(enabled_err));
        cJSON_AddBoolToObject(item, "enabled", enabled == 1);

        // 读取其他配置项
        char key[16];
        char value[32];
        size_t value_size = sizeof(value);

        const char *fields[] = {"s_addr",   "f_code",   "r_addr",
                                "r_num",    "timeout",  "d_fmt",
                                "i_time",   "r_fmt",    "baud_rate",
                                "data_bit", "stop_bit", "check_bit"};
        const char *json_fields[] = {
            "slave_addr", "function_code", "register_addr", "register_num",
            "timeout",    "data_format",   "interval_time", "report_format",
            "baud_rate",  "data_bit",      "stop_bit",      "check_bit"};

        for (int j = 0; j < sizeof(fields) / sizeof(fields[0]); j++) {
          value_size = sizeof(value); // 重置大小
          snprintf(key, sizeof(key), "m%d%s", i, fields[j]);
          esp_err_t field_err = nvs_get_str(nvs_handle, key, value, &value_size);
          if (field_err == ESP_OK) {
            cJSON_AddStringToObject(item, json_fields[j], value);
            ESP_LOGD(TAG, "配置项 %d.%s = %s", i, json_fields[j], value);
          } else {
            ESP_LOGW(TAG, "无法读取配置项 %d.%s: %s", i, json_fields[j], esp_err_to_name(field_err));
            // 添加默认值，防止前端显示异常
            cJSON_AddStringToObject(item, json_fields[j], "");
          }
        }

        cJSON_AddItemToArray(modbus_items, item);
      }
    }

  char *json_str = cJSON_Print(response);
  if (json_str == NULL) {
    cJSON_Delete(response);
    nvs_close(nvs_handle);
    httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR,
                        "Failed to print JSON");
    return ESP_FAIL;
  }

  httpd_resp_set_type(req, "application/json");
  httpd_resp_sendstr(req, json_str);

  free(json_str);
  cJSON_Delete(response);
  nvs_close(nvs_handle);

  return ESP_OK;
}

static esp_err_t get_mqtt_info_get_handler(httpd_req_t *req) {
  esp_err_t ret = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));

  // 读取字符串
  // 首先获取所需的缓冲区大小
  size_t use_mqtt, mqtt_type, mqtt_server, mqtt_port, mqtt_username,
      mqtt_password, mqtt_clientid, mqtt_sub_topic, mqtt_pub_topic, qos, retain,
      mqtt_send, mqtt_time, mqttconn = 0;
  ret = nvs_get_str(nvs_handle, "use_mqtt", NULL, &use_mqtt);
  nvs_get_str(nvs_handle, "mqtt_type", NULL, &mqtt_type);
  nvs_get_str(nvs_handle, "mqtt_server", NULL, &mqtt_server);
  nvs_get_str(nvs_handle, "mqtt_port", NULL, &mqtt_port);
  nvs_get_str(nvs_handle, "mqtt_username", NULL, &mqtt_username);
  nvs_get_str(nvs_handle, "mqtt_password", NULL, &mqtt_password);
  nvs_get_str(nvs_handle, "mqtt_clientid", NULL, &mqtt_clientid);
  nvs_get_str(nvs_handle, "mqtt_sub_topic", NULL, &mqtt_sub_topic);
  nvs_get_str(nvs_handle, "mqtt_pub_topic", NULL, &mqtt_pub_topic);
  nvs_get_str(nvs_handle, "qos", NULL, &qos);
  nvs_get_str(nvs_handle, "retain", NULL, &retain);
  nvs_get_str(nvs_handle, "mqtt_send", NULL, &mqtt_send);
  nvs_get_str(nvs_handle, "mqtt_time", NULL, &mqtt_time);
  nvs_get_str(nvs_handle, "mqttconn", NULL, &mqttconn);
  switch (ret) {
  case ESP_OK:
    printf("MQTT set success");
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    printf("no MQTT set");
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "use_mqtt", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_type", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_server", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_port", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_username", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_password", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_clientid", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_sub_topic", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_pub_topic", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "qos", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "retain", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_send", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_time", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqttconn", "0"));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'MQTT': %s\n", esp_err_to_name(ret));
  } else {
    // 分配缓冲区
    char *nvs_use_mqtt = malloc(use_mqtt);
    char *nvs_mqtt_type = malloc(mqtt_type);
    char *nvs_mqtt_server = malloc(mqtt_server);
    char *nvs_mqtt_port = malloc(mqtt_port);
    char *nvs_mqtt_username = malloc(mqtt_username);
    char *nvs_mqtt_password = malloc(mqtt_password);
    char *nvs_mqtt_clientid = malloc(mqtt_clientid);
    char *nvs_mqtt_sub_topic = malloc(mqtt_sub_topic);
    char *nvs_mqtt_pub_topic = malloc(mqtt_pub_topic);
    char *nvs_qos = malloc(qos);
    char *nvs_retain = malloc(retain);
    char *nvs_mqtt_send = malloc(mqtt_send);
    char *nvs_mqtt_time = malloc(mqtt_time);
    char *nvs_mqttconn = malloc(mqttconn);

    // 检查所有关键的malloc结果
    if (nvs_use_mqtt == NULL || nvs_mqtt_type == NULL || nvs_mqtt_server == NULL ||
        nvs_mqtt_port == NULL || nvs_mqtt_username == NULL || nvs_mqtt_password == NULL ||
        nvs_mqtt_clientid == NULL || nvs_mqtt_sub_topic == NULL || nvs_mqtt_pub_topic == NULL ||
        nvs_qos == NULL || nvs_retain == NULL || nvs_mqtt_send == NULL ||
        nvs_mqtt_time == NULL || nvs_mqttconn == NULL) {
      printf("Memory allocation failed for MQTT config\n");
      // 释放已分配的内存
      if (nvs_use_mqtt) free(nvs_use_mqtt);
      if (nvs_mqtt_type) free(nvs_mqtt_type);
      if (nvs_mqtt_server) free(nvs_mqtt_server);
      if (nvs_mqtt_port) free(nvs_mqtt_port);
      if (nvs_mqtt_username) free(nvs_mqtt_username);
      if (nvs_mqtt_password) free(nvs_mqtt_password);
      if (nvs_mqtt_clientid) free(nvs_mqtt_clientid);
      if (nvs_mqtt_sub_topic) free(nvs_mqtt_sub_topic);
      if (nvs_mqtt_pub_topic) free(nvs_mqtt_pub_topic);
      if (nvs_qos) free(nvs_qos);
      if (nvs_retain) free(nvs_retain);
      if (nvs_mqtt_send) free(nvs_mqtt_send);
      if (nvs_mqtt_time) free(nvs_mqtt_time);
      if (nvs_mqttconn) free(nvs_mqttconn);

      nvs_close(nvs_handle);
      httpd_resp_send_500(req);
      return ESP_FAIL;
    } else {
      // 读取字符串到分配的缓冲区
      ret = nvs_get_str(nvs_handle, "use_mqtt", nvs_use_mqtt, &use_mqtt);
      nvs_get_str(nvs_handle, "mqtt_type", nvs_mqtt_type, &mqtt_type);
      nvs_get_str(nvs_handle, "mqtt_server", nvs_mqtt_server, &mqtt_server);
      nvs_get_str(nvs_handle, "mqtt_port", nvs_mqtt_port, &mqtt_port);
      nvs_get_str(nvs_handle, "mqtt_username", nvs_mqtt_username,
                  &mqtt_username);
      nvs_get_str(nvs_handle, "mqtt_password", nvs_mqtt_password,
                  &mqtt_password);
      nvs_get_str(nvs_handle, "mqtt_clientid", nvs_mqtt_clientid,
                  &mqtt_clientid);
      nvs_get_str(nvs_handle, "mqtt_sub_topic", nvs_mqtt_sub_topic,
                  &mqtt_sub_topic);
      nvs_get_str(nvs_handle, "mqtt_pub_topic", nvs_mqtt_pub_topic,
                  &mqtt_pub_topic);
      nvs_get_str(nvs_handle, "qos", nvs_qos, &qos);
      nvs_get_str(nvs_handle, "retain", nvs_retain, &retain);
      nvs_get_str(nvs_handle, "mqtt_send", nvs_mqtt_send, &mqtt_send);
      nvs_get_str(nvs_handle, "mqtt_time", nvs_mqtt_time, &mqtt_time);

      nvs_get_str(nvs_handle, "mqttconn", nvs_mqttconn, &mqttconn);

      // 🔍 添加MQTT状态调试信息
      ESP_LOGI(TAG, "=== MQTT状态检查 ===");
      ESP_LOGI(TAG, "📊 NVS中的mqttconn: '%s' (长度: %zu)", nvs_mqttconn ? nvs_mqttconn : "(null)", mqttconn);
      ESP_LOGI(TAG, "📊 use_mqtt配置: '%s'", nvs_use_mqtt ? nvs_use_mqtt : "(null)");

      // 检查MQTT客户端句柄状态
      extern esp_mqtt_client_handle_t client;
      ESP_LOGI(TAG, "📊 MQTT客户端句柄: %s", (client != NULL) ? "存在" : "不存在");

      // 🔧 获取MQTT实际连接状态
      extern bool get_mqtt_connection_status(void);
      bool mqtt_real_status = get_mqtt_connection_status();
      ESP_LOGI(TAG, "📊 MQTT实际连接状态: %s", mqtt_real_status ? "已连接" : "未连接");

      if (ret == ESP_OK) {
        cJSON *root = cJSON_CreateObject();
        cJSON_AddItemToObject(root, "use_mqtt",
                              cJSON_CreateString(nvs_use_mqtt));
        cJSON_AddItemToObject(root, "mqtt_type",
                              cJSON_CreateString(nvs_mqtt_type));
        cJSON_AddItemToObject(root, "mqtt_server",
                              cJSON_CreateString(nvs_mqtt_server));
        cJSON_AddItemToObject(root, "mqtt_port",
                              cJSON_CreateString(nvs_mqtt_port));
        cJSON_AddItemToObject(root, "mqtt_username",
                              cJSON_CreateString(nvs_mqtt_username));
        cJSON_AddItemToObject(root, "mqtt_password",
                              cJSON_CreateString(nvs_mqtt_password));
        cJSON_AddItemToObject(root, "mqtt_clientid",
                              cJSON_CreateString(nvs_mqtt_clientid));
        cJSON_AddItemToObject(root, "mqtt_sub_topic",
                              cJSON_CreateString(nvs_mqtt_sub_topic));
        cJSON_AddItemToObject(root, "mqtt_pub_topic",
                              cJSON_CreateString(nvs_mqtt_pub_topic));
        cJSON_AddItemToObject(root, "qos", cJSON_CreateString(nvs_qos));
        cJSON_AddItemToObject(root, "retain", cJSON_CreateString(nvs_retain));
        cJSON_AddItemToObject(root, "mqtt_send",
                              cJSON_CreateString(nvs_mqtt_send));
        cJSON_AddItemToObject(root, "mqtt_time",
                              cJSON_CreateString(nvs_mqtt_time));
        // 🔧 使用实际连接状态而不是NVS中可能过时的状态
        cJSON_AddItemToObject(root, "mqttconn",
                              cJSON_CreateString(mqtt_real_status ? "1" : "0"));
        ESP_LOGI(TAG, "📤 返回MQTT状态: NVS='%s', 实际='%s', 最终返回='%s'",
                 nvs_mqttconn, mqtt_real_status ? "1" : "0", mqtt_real_status ? "1" : "0");
        httpd_resp_set_hdr(req, "Connection", "close");
        httpd_resp_set_type(req, "application/json");
        char *json_data = cJSON_Print(root);
        httpd_resp_send(req, json_data, strlen(json_data));

        free(json_data);
        cJSON_Delete(root);

      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_use_mqtt);
      free(nvs_mqtt_type);
      free(nvs_mqtt_server);
      free(nvs_mqtt_port);
      free(nvs_mqtt_username);
      free(nvs_mqtt_password);
      free(nvs_mqtt_clientid);
      free(nvs_mqtt_sub_topic);
      free(nvs_mqtt_pub_topic);
      free(nvs_qos);
      free(nvs_retain);
      free(nvs_mqtt_send);
      free(nvs_mqtt_time);
      free(nvs_mqttconn);
    }
  }

  nvs_close(nvs_handle);

  return ESP_OK;
}

static esp_err_t get_tcp_info_get_handler(httpd_req_t *req) {
  esp_err_t ret = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
  size_t use_tcp, tcpconn, tcp_server, tcp_port = 0;
  size_t reg_packet = 0, heart_packet = 0, reg_format = 0, heart_format = 0, heart_interval = 0;
  ret = nvs_get_str(nvs_handle, "use_tcp", NULL, &use_tcp);
  nvs_get_str(nvs_handle, "tcpconn", NULL, &tcpconn);
  nvs_get_str(nvs_handle, "tcp_server", NULL, &tcp_server);
  nvs_get_str(nvs_handle, "tcp_port", NULL, &tcp_port);
  nvs_get_str(nvs_handle, "reg_packet", NULL, &reg_packet);
  nvs_get_str(nvs_handle, "heart_packet", NULL, &heart_packet);
  nvs_get_str(nvs_handle, "reg_format", NULL, &reg_format);
  nvs_get_str(nvs_handle, "heart_format", NULL, &heart_format);
  nvs_get_str(nvs_handle, "heart_interval", NULL, &heart_interval);
  switch (ret) {
  case ESP_OK:
    printf("TCP set success");
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    printf("no TCP set");
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "use_tcp", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "tcpconn", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "tcp_server", "192.168.1.100"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "tcp_port", "8888"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "reg_packet", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "heart_packet", device_mac)); // 默认WiFi MAC地址（无冒号格式）
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "reg_format", "hex"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "heart_format", "hex"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "heart_interval", "30"));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'my_key': %s\n", esp_err_to_name(ret));
  } else {
    char *nvs_use_tcp = malloc(use_tcp);
    char *nvs_tcpconn = malloc(tcpconn);
    char *nvs_tcp_server = malloc(tcp_server);
    char *nvs_tcp_port = malloc(tcp_port);
    char *nvs_reg_packet = reg_packet > 0 ? malloc(reg_packet) : NULL;
    char *nvs_heart_packet = heart_packet > 0 ? malloc(heart_packet) : NULL;
    char *nvs_reg_format = reg_format > 0 ? malloc(reg_format) : NULL;
    char *nvs_heart_format = heart_format > 0 ? malloc(heart_format) : NULL;
    char *nvs_heart_interval = heart_interval > 0 ? malloc(heart_interval) : NULL;

    if (nvs_tcp_port == NULL) {
      printf("Memory allocation failed\n");
    } else {
      ret = nvs_get_str(nvs_handle, "use_tcp", nvs_use_tcp, &use_tcp);
      nvs_get_str(nvs_handle, "tcpconn", nvs_tcpconn, &tcpconn);
      nvs_get_str(nvs_handle, "tcp_server", nvs_tcp_server, &tcp_server);
      nvs_get_str(nvs_handle, "tcp_port", nvs_tcp_port, &tcp_port);
      if (nvs_reg_packet) nvs_get_str(nvs_handle, "reg_packet", nvs_reg_packet, &reg_packet);
      if (nvs_heart_packet) nvs_get_str(nvs_handle, "heart_packet", nvs_heart_packet, &heart_packet);
      if (nvs_reg_format) nvs_get_str(nvs_handle, "reg_format", nvs_reg_format, &reg_format);
      if (nvs_heart_format) nvs_get_str(nvs_handle, "heart_format", nvs_heart_format, &heart_format);
      if (nvs_heart_interval) nvs_get_str(nvs_handle, "heart_interval", nvs_heart_interval, &heart_interval);

      if (ret == ESP_OK) {
        cJSON *root = cJSON_CreateObject();
        cJSON_AddItemToObject(root, "use_tcp", cJSON_CreateString(nvs_use_tcp));
        cJSON_AddItemToObject(root, "tcpconn", cJSON_CreateString(nvs_tcpconn));
        cJSON_AddItemToObject(root, "tcp_server",
                              cJSON_CreateString(nvs_tcp_server));
        cJSON_AddItemToObject(root, "tcp_port",
                              cJSON_CreateString(nvs_tcp_port));
        cJSON_AddItemToObject(root, "tcp_client_count",
                              cJSON_CreateNumber(tcp_client_count));
        cJSON_AddItemToObject(root, "tcp_server_conn",
                              cJSON_CreateNumber(global_tcp_server));

        // 添加注册包和心跳包信息
        if (nvs_reg_packet) {
          cJSON_AddItemToObject(root, "reg_packet", cJSON_CreateString(nvs_reg_packet));
        } else {
          cJSON_AddItemToObject(root, "reg_packet", cJSON_CreateString(""));
        }

        if (nvs_heart_packet) {
          cJSON_AddItemToObject(root, "heart_packet", cJSON_CreateString(nvs_heart_packet));
        } else {
          cJSON_AddItemToObject(root, "heart_packet", cJSON_CreateString(device_mac));
        }

        if (nvs_reg_format) {
          cJSON_AddItemToObject(root, "reg_format", cJSON_CreateString(nvs_reg_format));
        } else {
          cJSON_AddItemToObject(root, "reg_format", cJSON_CreateString("hex"));
        }

        if (nvs_heart_format) {
          cJSON_AddItemToObject(root, "heart_format", cJSON_CreateString(nvs_heart_format));
        } else {
          cJSON_AddItemToObject(root, "heart_format", cJSON_CreateString("hex"));
        }

        if (nvs_heart_interval) {
          cJSON_AddItemToObject(root, "heart_interval", cJSON_CreateString(nvs_heart_interval));
        } else {
          cJSON_AddItemToObject(root, "heart_interval", cJSON_CreateString("30"));
        }

        httpd_resp_set_hdr(req, "Connection", "close");
        httpd_resp_set_type(req, "application/json");
        char *json_data = cJSON_Print(root);
        httpd_resp_send(req, json_data, strlen(json_data));
        free(json_data);
        cJSON_Delete(root);
      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_use_tcp);
      free(nvs_tcpconn);
      free(nvs_tcp_server);
      free(nvs_tcp_port);
      if (nvs_reg_packet) free(nvs_reg_packet);
      if (nvs_heart_packet) free(nvs_heart_packet);
      if (nvs_reg_format) free(nvs_reg_format);
      if (nvs_heart_format) free(nvs_heart_format);
      if (nvs_heart_interval) free(nvs_heart_interval);
    }
  }
  nvs_close(nvs_handle);
  return ESP_OK;
}



static esp_err_t get_http_info_get_handler(httpd_req_t *req) {
  esp_err_t ret = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
  size_t use_http, http_port, httpconn, http_url, http_header, http_time = 0;
  ret = nvs_get_str(nvs_handle, "use_http", NULL, &use_http);
  nvs_get_str(nvs_handle, "http_port", NULL, &http_port);
  nvs_get_str(nvs_handle, "httpconn", NULL, &httpconn);
  nvs_get_str(nvs_handle, "http_url", NULL, &http_url);
  nvs_get_str(nvs_handle, "http_header", NULL, &http_header);
  nvs_get_str(nvs_handle, "http_time", NULL, &http_time);
  switch (ret) {
  case ESP_OK:
    printf("HTTP set success");
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "use_http", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "http_port", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "httpconn", ""));
    ESP_ERROR_CHECK(
        nvs_set_str(nvs_handle, "http_url", "http://demo.sxiot.com"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "http_header", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "http_time", "5"));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'HTTP': %s\n", esp_err_to_name(ret));
  } else {
    char *nvs_use_http = malloc(use_http);
    char *nvs_http_port = malloc(http_port);
    char *nvs_httpconn = malloc(httpconn);
    char *nvs_http_url = malloc(http_url);
    char *nvs_http_header = malloc(http_header);
    char *nvs_http_time = malloc(http_time);

    if (nvs_use_http == NULL) {
      printf("Memory allocation failed\n");
    } else {
      ret = nvs_get_str(nvs_handle, "use_http", nvs_use_http, &use_http);
      nvs_get_str(nvs_handle, "http_port", nvs_http_port, &http_port);
      nvs_get_str(nvs_handle, "httpconn", nvs_httpconn, &httpconn);
      nvs_get_str(nvs_handle, "http_url", nvs_http_url, &http_url);
      nvs_get_str(nvs_handle, "http_header", nvs_http_header, &http_header);
      nvs_get_str(nvs_handle, "http_time", nvs_http_time, &http_time);

      if (ret == ESP_OK) {
        printf("Value for 'use_http' is %s\n", nvs_use_http);
        printf("Value for 'http_port' is %s\n", nvs_http_port);
        printf("Value for 'httpconn' is %s\n", nvs_httpconn);
        printf("Value for 'http_url' is %s\n", nvs_http_url);
        printf("Value for 'http_header' is %s\n", nvs_http_header);
        printf("Value for 'http_time' is %s\n", nvs_http_time);
        cJSON *root = cJSON_CreateObject();
        cJSON_AddItemToObject(root, "use_http",
                              cJSON_CreateString(nvs_use_http));
        cJSON_AddItemToObject(root, "http_port",
                              cJSON_CreateString(nvs_http_port));
        cJSON_AddItemToObject(root, "httpconn",
                              cJSON_CreateString(nvs_httpconn));
        cJSON_AddItemToObject(root, "http_url",
                              cJSON_CreateString(nvs_http_url));
        cJSON_AddItemToObject(root, "http_header",
                              cJSON_CreateString(nvs_http_header));
        cJSON_AddItemToObject(root, "http_time",
                              cJSON_CreateString(nvs_http_time));
        httpd_resp_set_hdr(req, "Connection", "close");
        httpd_resp_set_type(req, "application/json");
        char *json_data = cJSON_Print(root);
        httpd_resp_send(req, json_data, strlen(json_data));
        free(json_data);
        cJSON_Delete(root);
      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_use_http);
      free(nvs_http_port);
      free(nvs_httpconn);
      free(nvs_http_url);
      free(nvs_http_header);
      free(nvs_http_time);
    }
  }
  nvs_close(nvs_handle);
  return ESP_OK;
}

// WIFI GET Handler
static esp_err_t get_find_wifi_get_handler(httpd_req_t *req) {

  WifiValueList data = wifiSearchValue();
  ESP_LOGI(TAG, "Total APs scanned = %u", data.ap_count);
  cJSON *root = cJSON_CreateObject();

  // 检查错误状态并返回相应的错误信息
  if (data.error_code > 0) {
    switch (data.error_code) {
    case 1: // 扫描间隔过短
      ESP_LOGI(TAG, "WiFi scan refused: interval too short, need to wait %d ms",
               data.wait_time);
      cJSON_AddStringToObject(root, "error", "扫描间隔过短，请稍后再试");
      cJSON_AddNumberToObject(root, "wait_time", data.wait_time);
      break;
    case 2: // 扫描不允许
      ESP_LOGI(TAG, "WiFi scan refused: not allowed at this time");
      cJSON_AddStringToObject(root, "error",
                              "当前无法进行WiFi扫描，请稍后再试");
      cJSON_AddNumberToObject(root, "wait_time", 3000); // 默认等待5秒
      break;
    case 3: // 其他错误
    default:
      ESP_LOGI(TAG, "WiFi scan failed: other error");
      cJSON_AddStringToObject(root, "error", "WiFi扫描失败，请稍后再试");
      cJSON_AddNumberToObject(root, "wait_time", 3000); // 默认等待3秒
      break;
    }
  } else if (data.ap_count == 0) {
    // 扫描成功但未找到WiFi
    ESP_LOGI(TAG, "WiFi scan completed but no networks found");
    cJSON_AddStringToObject(root, "message", "未找到任何WiFi网络");
  } else {
    // 扫描成功，返回AP列表
    //   cJSON *wifiArray = cJSON_CreateArray();

    // 确保不会超出数组边界
    int count = (data.ap_count < DEFAULT_SCAN_LIST_SIZE)
                    ? data.ap_count
                    : DEFAULT_SCAN_LIST_SIZE;
    for (int i = 0; i < count; i++) {
      ESP_LOGI(TAG, "SSID \t\t%s", data.ap_info[i].ssid);
      ESP_LOGI(TAG, "RSSI \t\t%d", data.ap_info[i].rssi);
      ESP_LOGI(TAG, "Channel \t\t%d\n", data.ap_info[i].primary);
      // cJSON_AddStringToObject(root, "ssid", );
      cJSON_AddNumberToObject(root, (char *)data.ap_info[i].ssid,
                              data.ap_info[i].rssi);
    }
  }

  httpd_resp_set_hdr(req, "Connection", "close");
  httpd_resp_set_type(req, "application/json");
  char *json_data = cJSON_Print(root);
  httpd_resp_send(req, json_data, strlen(json_data));
  free(json_data);
  cJSON_Delete(root);

  return ESP_OK;
}

static esp_err_t get_exit_ap_get_handler(httpd_req_t *req) {
  httpd_resp_send(req, "EXIT AP", HTTPD_RESP_USE_STRLEN);
  vTaskDelay(500);
  ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
  return ESP_OK;
}

static esp_err_t get_net_set_info_get_handler(httpd_req_t *req) {

  esp_err_t ret = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));

  // 读取字符串
  // 首先获取所需的缓冲区大小
  size_t netconn, is_dhcp, static_ip, static_netmask, static_gateway, static_dns1, static_dns2, wifi_ssid,
      wifi_password = 0;
  ret = nvs_get_str(nvs_handle, "netconn", NULL, &netconn);
  nvs_get_str(nvs_handle, "is_dhcp", NULL, &is_dhcp);
  nvs_get_str(nvs_handle, "static_ip", NULL, &static_ip);
  nvs_get_str(nvs_handle, "static_netmask", NULL, &static_netmask);
  nvs_get_str(nvs_handle, "static_gateway", NULL, &static_gateway);
  nvs_get_str(nvs_handle, "static_dns1", NULL, &static_dns1);
  nvs_get_str(nvs_handle, "static_dns2", NULL, &static_dns2);
  nvs_get_str(nvs_handle, "wifi_ssid", NULL, &wifi_ssid);
  nvs_get_str(nvs_handle, "wifi_password", NULL, &wifi_password);
  switch (ret) {
  case ESP_OK:
    // printf("NET set success");
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    printf("no NET set");
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "netconn", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "is_dhcp", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "static_ip", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "static_netmask", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "static_gateway", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "static_dns1", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "static_dns2", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "wifi_ssid", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "wifi_password", ""));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'my_key': %s\n", esp_err_to_name(ret));
  } else {
    // 分配缓冲区
    char *nvs_netconn = malloc(netconn);
    char *nvs_is_dhcp = malloc(is_dhcp);
    char *nvs_static_ip = malloc(static_ip);
    char *nvs_static_netmask = malloc(static_netmask);
    char *nvs_static_gateway = malloc(static_gateway);
    char *nvs_static_dns1 = malloc(static_dns1);
    char *nvs_static_dns2 = malloc(static_dns2);
    char *nvs_wifi_ssid = malloc(wifi_ssid);
    char *nvs_wifi_password = malloc(wifi_password);
    if (nvs_netconn == NULL) {
      printf("Memory allocation failed\n");
    } else {
      // 读取字符串到分配的缓冲区
      ret = nvs_get_str(nvs_handle, "netconn", nvs_netconn, &netconn);
      nvs_get_str(nvs_handle, "is_dhcp", nvs_is_dhcp, &is_dhcp);
      nvs_get_str(nvs_handle, "static_ip", nvs_static_ip, &static_ip);
      nvs_get_str(nvs_handle, "static_netmask", nvs_static_netmask,
                  &static_netmask);
      nvs_get_str(nvs_handle, "static_gateway", nvs_static_gateway,
                  &static_gateway);
      nvs_get_str(nvs_handle, "static_dns1", nvs_static_dns1,
                  &static_dns1);
      nvs_get_str(nvs_handle, "static_dns2", nvs_static_dns2,
                  &static_dns2);
      nvs_get_str(nvs_handle, "wifi_ssid", nvs_wifi_ssid, &wifi_ssid);
      nvs_get_str(nvs_handle, "wifi_password", nvs_wifi_password,
                  &wifi_password);

      if (ret == ESP_OK) {
        cJSON *root = cJSON_CreateObject();
        cJSON_AddItemToObject(root, "netconn", cJSON_CreateString(nvs_netconn));
        cJSON_AddItemToObject(root, "is_dhcp", cJSON_CreateString(nvs_is_dhcp));
        cJSON_AddItemToObject(root, "static_ip",
                              cJSON_CreateString(nvs_static_ip));
        cJSON_AddItemToObject(root, "static_netmask",
                              cJSON_CreateString(nvs_static_netmask));
        cJSON_AddItemToObject(root, "static_gateway",
                              cJSON_CreateString(nvs_static_gateway));
        cJSON_AddItemToObject(root, "static_dns1",
                              cJSON_CreateString(nvs_static_dns1));
        cJSON_AddItemToObject(root, "static_dns2",
                              cJSON_CreateString(nvs_static_dns2));
        cJSON_AddItemToObject(root, "wifi_ssid",
                              cJSON_CreateString(nvs_wifi_ssid));
        cJSON_AddItemToObject(root, "wifi_password",
                              cJSON_CreateString(nvs_wifi_password));
        httpd_resp_set_hdr(req, "Connection", "close");
        httpd_resp_set_type(req, "application/json");
        char *json_data = cJSON_Print(root);
        httpd_resp_send(req, json_data, strlen(json_data));

        free(json_data);
        cJSON_Delete(root);

      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_netconn);
      free(nvs_is_dhcp);
      free(nvs_static_ip);
      free(nvs_static_netmask);
      free(nvs_static_gateway);
      free(nvs_static_dns1);
      free(nvs_static_dns2);
      free(nvs_wifi_ssid);
      free(nvs_wifi_password);
    }
  }

  nvs_close(nvs_handle);

  return ESP_OK;
}

static esp_err_t get_module_set_info_get_handler(httpd_req_t *req) {

  esp_err_t ret = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));

  size_t host_names, ntp_server, lgname, lgpwd = 0;

  ret = nvs_get_str(nvs_handle, "lgname", NULL, &lgname);
  nvs_get_str(nvs_handle, "lgpwd", NULL, &lgpwd);
  nvs_get_str(nvs_handle, "host_names", NULL, &host_names);
  nvs_get_str(nvs_handle, "ntp_server", NULL, &ntp_server);

  switch (ret) {
  case ESP_OK:
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "host_names", "以太网串口服务器"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "ntp_server", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "lgname", "admin"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "lgpwd", "12345678"));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'host_names': %s\n", esp_err_to_name(ret));
  } else {
    char *nvs_host_names = malloc(host_names);
    char *nvs_ntp_server = malloc(ntp_server);
    char *nvs_lgname = malloc(lgname);
    char *nvs_lgpwd = malloc(lgpwd);
    if (nvs_host_names == NULL) {
      printf("Memory allocation failed\n");
    } else {
      ret = nvs_get_str(nvs_handle, "host_names", nvs_host_names, &host_names);
      nvs_get_str(nvs_handle, "ntp_server", nvs_ntp_server, &ntp_server);
      nvs_get_str(nvs_handle, "lgname", nvs_lgname, &lgname);
      nvs_get_str(nvs_handle, "lgpwd", nvs_lgpwd, &lgpwd);

      if (ret == ESP_OK) {
        cJSON *root = cJSON_CreateObject();
        cJSON_AddItemToObject(root, "host_names",
                              cJSON_CreateString(nvs_host_names));
        cJSON_AddItemToObject(root, "ntp_server",
                              cJSON_CreateString(nvs_ntp_server));
        cJSON_AddItemToObject(root, "lgname", cJSON_CreateString(nvs_lgname));
        cJSON_AddItemToObject(root, "lgpwd", cJSON_CreateString(nvs_lgpwd));
        httpd_resp_set_hdr(req, "Connection", "close");
        httpd_resp_set_type(req, "application/json");
        char *json_data = cJSON_Print(root);
        httpd_resp_send(req, json_data, strlen(json_data));

        free(json_data);
        cJSON_Delete(root);

      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_host_names);
      free(nvs_ntp_server);
      free(nvs_lgname);
      free(nvs_lgpwd);
    }
  }

  nvs_close(nvs_handle);

  return ESP_OK;
}

static esp_err_t get_ap_set_info_get_handler(httpd_req_t *req) {

  esp_err_t ret = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
  size_t ap_name, ap_password, ap_wait_time = 0;
  ret = nvs_get_str(nvs_handle, "ap_name", NULL, &ap_name);
  nvs_get_str(nvs_handle, "ap_password", NULL, &ap_password);
  nvs_get_str(nvs_handle, "ap_wait_time", NULL, &ap_wait_time);
  switch (ret) {
  case ESP_OK:
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "ap_name", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "ap_password", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "ap_wait_time", ""));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'ap_name': %s\n", esp_err_to_name(ret));
  } else {
    // 分配缓冲区
    char *nvs_ap_name = malloc(ap_name);
    char *nvs_ap_password = malloc(ap_password);
    char *nvs_ap_wait_time = malloc(ap_wait_time);
    if (nvs_ap_name == NULL) {
      printf("Memory allocation failed\n");
    } else {
      ret = nvs_get_str(nvs_handle, "ap_name", nvs_ap_name, &ap_name);
      nvs_get_str(nvs_handle, "ap_password", nvs_ap_password, &ap_password);
      nvs_get_str(nvs_handle, "ap_wait_time", nvs_ap_wait_time, &ap_wait_time);
      if (ret == ESP_OK) {
        cJSON *root = cJSON_CreateObject();
        cJSON_AddItemToObject(root, "ap_name", cJSON_CreateString(nvs_ap_name));
        cJSON_AddItemToObject(root, "ap_password",
                              cJSON_CreateString(nvs_ap_password));
        cJSON_AddItemToObject(root, "ap_wait_time",
                              cJSON_CreateString(nvs_ap_wait_time));
        httpd_resp_set_hdr(req, "Connection", "close");
        httpd_resp_set_type(req, "application/json");
        char *json_data = cJSON_Print(root);
        httpd_resp_send(req, json_data, strlen(json_data));
        free(json_data);
        cJSON_Delete(root);
      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_ap_name);
      free(nvs_ap_password);
      free(nvs_ap_wait_time);
    }
  }

  nvs_close(nvs_handle);
  return ESP_OK;
}


// WebSocket消息发送任务
static void ws_send_task(void *pvParameters) {
  char msg_buffer[WS_MAX_MSG_LEN];
  httpd_ws_frame_t ws_pkt = {
      .type = HTTPD_WS_TYPE_TEXT, .payload = (uint8_t *)msg_buffer, .len = 0};

  while (1) {
    if (xQueueReceive(ws_msg_queue, msg_buffer, portMAX_DELAY)) {
      ws_pkt.len = strlen(msg_buffer);

      // 遍历所有客户端发送消息
      for (int i = 0; i < MAX_WS_CLIENTS; i++) {
        if (ws_clients[i].in_use) {
          esp_err_t ret = httpd_ws_send_frame_async(
              http_server, ws_clients[i].client_fd, &ws_pkt);
          if (ret != ESP_OK) {
            ESP_LOGW(TAG, "Failed to send WS message to client %d: %d", i, ret);
            // 如果发送失败，移除客户端
            ws_clients[i].in_use = false;
          }
        }
      }
    }
    // 添加小延时避免过度消耗CPU
    vTaskDelay(pdMS_TO_TICKS(10));
  }
}

// 初始化WebSocket系统
static void init_websocket(void) {
  // 创建消息队列
  ws_msg_queue = xQueueCreate(WS_QUEUE_SIZE, WS_MAX_MSG_LEN);
  if (ws_msg_queue == NULL) {
    ESP_LOGE(TAG, "Failed to create WS message queue");
    return;
  }

  // 创建WebSocket发送任务
  BaseType_t ret = xTaskCreate(ws_send_task, "ws_send_task",
                               4096, // 增加栈大小
                               NULL,
                               5, // 较高优先级
                               &ws_task_handle);
  if (ret != pdPASS) {
    ESP_LOGE(TAG, "Failed to create WS task");
    vQueueDelete(ws_msg_queue);
    ws_msg_queue = NULL;
  }
}

// WebSocket处理函数
static esp_err_t ws_handler(httpd_req_t *req) {
  if (req->method == HTTP_GET) {
    // 查找可用的客户端槽位
    int client_slot = -1;
    for (int i = 0; i < MAX_WS_CLIENTS; i++) {
      if (!ws_clients[i].in_use) {
        client_slot = i;
        break;
      }
    }

    if (client_slot >= 0) {
      ws_clients[client_slot].client_fd = httpd_req_to_sockfd(req);
      ws_clients[client_slot].in_use = true;
      ESP_LOGI(TAG, "New WS client connected, slot: %d", client_slot);
    } else {
      ESP_LOGW(TAG, "No free WS client slots");
      return ESP_FAIL;
    }
    return ESP_OK;
  }

  return ESP_OK;
}

// 发送日志到WebSocket的函数
void send_log_to_websocket(const char *log_msg) {
  // 如果日志开关关闭，直接返回
  if (!log_enabled) {
    return;
  }

  if (!ws_msg_queue) {
    return;
  }

  // 创建临时缓冲区并复制消息
  char buffer[WS_MAX_MSG_LEN];
  strncpy(buffer, log_msg, WS_MAX_MSG_LEN - 1);
  buffer[WS_MAX_MSG_LEN - 1] = '\0';

  // 使用超时时间发送到队列
  if (xQueueSend(ws_msg_queue, buffer, pdMS_TO_TICKS(100)) != pdPASS) {
    ESP_LOGW(TAG, "WS message queue full");
  }
}

// 发送串口数据到WebSocket的函数
void send_uart_to_websocket(const uint8_t *data, size_t len, bool is_tx) {
  // 串口调试数据不受日志开关控制，应该一直发送
  if (!ws_msg_queue) {
    return;
  }

  // 创建JSON对象
  cJSON *root = cJSON_CreateObject();
  if (!root) {
    ESP_LOGE(TAG, "Failed to create JSON object for UART data");
    return;
  }

  // 添加数据类型标识
  cJSON_AddStringToObject(root, "type", "uart_data");
  cJSON_AddBoolToObject(root, "is_tx", is_tx);

  // 添加时间戳
  uint64_t timestamp = esp_timer_get_time();
  cJSON_AddNumberToObject(root, "timestamp", (double)timestamp);

  // 添加数据长度信息
  cJSON_AddNumberToObject(root, "len", len);

  // 构建十六进制字符串（增加缓冲区到768字节，可处理约256字节的数据）
  char hex_str[768] = {0};
  size_t hex_pos = 0;
  size_t max_display_len = len > 255 ? 255 : len; // 限制最多显示255字节

  for (int i = 0; i < max_display_len && hex_pos < sizeof(hex_str) - 3; i++) {
    hex_pos += snprintf(hex_str + hex_pos, sizeof(hex_str) - hex_pos,
                      "%02X ", data[i]);
  }

  // 如果数据被截断，添加省略标记
  if (len > max_display_len) {
    snprintf(hex_str + hex_pos, sizeof(hex_str) - hex_pos, "... (%zu bytes total)", len);
  }

  cJSON_AddStringToObject(root, "hex", hex_str);

  // 构建ASCII字符串（增加到256字节）
  char ascii_str[256] = {0};
  size_t ascii_len = len < sizeof(ascii_str) - 1 ? len : sizeof(ascii_str) - 1;
  for (int i = 0; i < ascii_len; i++) {
    ascii_str[i] = isprint(data[i]) ? data[i] : '.';
  }
  ascii_str[ascii_len] = '\0';
  cJSON_AddStringToObject(root, "ascii", ascii_str);

  // 转换为字符串
  char *json_str = cJSON_PrintUnformatted(root);
  cJSON_Delete(root);

  if (json_str) {
    size_t json_len = strlen(json_str);

    // 检查JSON长度是否超过限制
    if (json_len >= WS_MAX_MSG_LEN) {
      ESP_LOGW(TAG, "UART data JSON too large (%zu bytes), will be truncated to %d bytes. Data len: %zu, is_tx: %d",
               json_len, WS_MAX_MSG_LEN, len, is_tx);
    }

    // 创建临时缓冲区并复制消息
    char buffer[WS_MAX_MSG_LEN];
    strncpy(buffer, json_str, WS_MAX_MSG_LEN - 1);
    buffer[WS_MAX_MSG_LEN - 1] = '\0';
    free(json_str);

    // 使用超时时间发送到队列
    if (xQueueSend(ws_msg_queue, buffer, pdMS_TO_TICKS(100)) != pdPASS) {
      ESP_LOGW(TAG, "WS message queue full, dropping %s data (len: %zu)",
               is_tx ? "TX" : "RX", len);
    } else {
      ESP_LOGD(TAG, "UART %s data sent to WS queue successfully (len: %zu)",
               is_tx ? "TX" : "RX", len);
    }
  }
}

/* 暂时不使用的HTTP日志API（已被WebSocket替代）
static esp_err_t get_log_handler(httpd_req_t *req) {
  esp_err_t ret = ESP_OK;
  char *log_content = NULL;
  char *json_data = NULL;

  // 创建JSON根对象
  cJSON *root = cJSON_CreateObject();
  if (!root) {
    ESP_LOGE(TAG, "Failed to create JSON object");
    return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR,
                               "Failed to create JSON object");
  }

  // 根据URL参数决定返回哪种日志
  char param[32] = {0};
  if (httpd_req_get_url_query_str(req, param, sizeof(param)) == ESP_OK) {
    char type[8] = {0};
    if (httpd_query_key_value(param, "type", type, sizeof(type)) == ESP_OK) {
      if (strcmp(type, "simple") == 0) {
        log_content = sx_log_get_simple_buffer();
        ESP_LOGI(TAG, "Getting simple log buffer");
      } else {
        log_content = sx_log_get_buffer();
        ESP_LOGI(TAG, "Getting full log buffer");
      }
    }
  } else {
    // 默认返回详细日志
    log_content = sx_log_get_buffer();
    ESP_LOGI(TAG, "Getting default full log buffer");
  }

  // 添加日志内容到JSON对象
  if (log_content != NULL) {
    if (!cJSON_AddStringToObject(root, "content", log_content)) {
      ESP_LOGE(TAG, "Failed to add log content to JSON");
      ret = ESP_FAIL;
      goto cleanup;
    }
    free(log_content);
    log_content = NULL;
  } else {
    if (!cJSON_AddStringToObject(root, "content", "暂无日志")) {
      ESP_LOGE(TAG, "Failed to add empty log message to JSON");
      ret = ESP_FAIL;
      goto cleanup;
    }
  }

  // 生成JSON字符串
  json_data = cJSON_Print(root);
  if (!json_data) {
    ESP_LOGE(TAG, "Failed to generate JSON string");
    ret = ESP_FAIL;
    goto cleanup;
  }

  // 设置响应类型和发送响应
  httpd_resp_set_type(req, "application/json");
  ret = httpd_resp_send(req, json_data, strlen(json_data));
  if (ret != ESP_OK) {
    ESP_LOGE(TAG, "Failed to send HTTP response: %d", ret);
  }

cleanup:
  // 清理资源
  if (log_content) {
    free(log_content);
  }
  if (json_data) {
    free(json_data);
  }
  if (root) {
    cJSON_Delete(root);
  }

  return ret;
}

static esp_err_t clear_log_handler(httpd_req_t *req) {
  sx_log_clear();

  cJSON *root = cJSON_CreateObject();
  cJSON_AddNumberToObject(root, "code", 200);

  char *json_data = cJSON_Print(root);
  httpd_resp_set_type(req, "application/json");
  httpd_resp_send(req, json_data, strlen(json_data));

  free(json_data);
  cJSON_Delete(root);
  return ESP_OK;
}
*/

// 获取日志开关状态
static esp_err_t get_log_switch_handler(httpd_req_t *req) {
  cJSON *root = cJSON_CreateObject();
  cJSON_AddNumberToObject(root, "code", 200);
  cJSON_AddBoolToObject(root, "log_enabled", log_enabled);

  char *json_data = cJSON_Print(root);
  httpd_resp_set_type(req, "application/json");
  httpd_resp_send(req, json_data, strlen(json_data));

  free(json_data);
  cJSON_Delete(root);
  return ESP_OK;
}

// 设置日志开关状态
static esp_err_t set_log_switch_handler(httpd_req_t *req) {
  char buf[128];
  int ret = 0;
  int remaining = req->content_len;

  if (remaining >= sizeof(buf)) {
    httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Content too long");
    return ESP_FAIL;
  }

  if (remaining == 0) {
    httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Empty content");
    return ESP_FAIL;
  }

  // 读取POST数据
  ret = httpd_req_recv(req, buf, remaining);
  if (ret <= 0) {
    if (ret == HTTPD_SOCK_ERR_TIMEOUT) {
      httpd_resp_send_err(req, HTTPD_408_REQ_TIMEOUT, "Request timeout");
    }
    return ESP_FAIL;
  }
  buf[ret] = '\0';

  // 解析JSON
  cJSON *json = cJSON_Parse(buf);
  if (json == NULL) {
    httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid JSON");
    return ESP_FAIL;
  }

  cJSON *enabled = cJSON_GetObjectItem(json, "log_enabled");
  if (enabled == NULL || !cJSON_IsBool(enabled)) {
    cJSON_Delete(json);
    httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Missing log_enabled field");
    return ESP_FAIL;
  }

  // 更新全局变量
  log_enabled = cJSON_IsTrue(enabled);

  // 保存到NVS
  nvs_handle_t nvs_handle;
  esp_err_t err = nvs_open("storage", NVS_READWRITE, &nvs_handle);
  if (err == ESP_OK) {
    nvs_set_u8(nvs_handle, "log_enabled", log_enabled ? 1 : 0);
    nvs_commit(nvs_handle);
    nvs_close(nvs_handle);
    ESP_LOGI(TAG, "日志开关已%s", log_enabled ? "打开" : "关闭");
  } else {
    ESP_LOGE(TAG, "保存日志开关状态失败");
  }

  cJSON_Delete(json);

  // 返回成功响应
  cJSON *response = cJSON_CreateObject();
  cJSON_AddNumberToObject(response, "code", 200);
  cJSON_AddBoolToObject(response, "log_enabled", log_enabled);

  char *json_data = cJSON_Print(response);
  httpd_resp_set_type(req, "application/json");
  httpd_resp_send(req, json_data, strlen(json_data));

  free(json_data);
  cJSON_Delete(response);
  return ESP_OK;
}

/* 登录处理函数 */
static esp_err_t web_login_handler(httpd_req_t *req) {
  char buf[1024];
  int ret, remaining = req->content_len;

  while (remaining > 0) {
    if ((ret = httpd_req_recv(req, buf, sizeof(buf))) <= 0) {
      if (ret == HTTPD_SOCK_ERR_TIMEOUT) {
        continue;
      }
      return ESP_FAIL;
    }
    remaining -= ret;
    ESP_LOGI(TAG, "%.*s", ret, buf);
  }
  printf("%s\n", buf);
  cJSON *json = cJSON_Parse(buf);
  if (json == NULL) {
    const char *error_ptr = cJSON_GetErrorPtr();
    if (error_ptr != NULL) {
      ESP_LOGE("JSON", "Error before: %s", error_ptr);
    }
    cJSON_Delete(json);
    return 0;
  }
  cJSON *username = cJSON_GetObjectItemCaseSensitive(json, "username");
  if (cJSON_IsString(username) && (username->valuestring != NULL)) {
    ESP_LOGI("JSON", "username: %s", username->valuestring);
  }
  cJSON *password = cJSON_GetObjectItemCaseSensitive(json, "password");
  if (cJSON_IsString(password) && (password->valuestring != NULL)) {
    ESP_LOGI("JSON", "password: %s", password->valuestring);
  }

  esp_err_t rets = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));

  size_t host_names, ntp_server, lgname, lgpwd = 0;

  rets = nvs_get_str(nvs_handle, "lgname", NULL, &lgname);
  nvs_get_str(nvs_handle, "lgpwd", NULL, &lgpwd);
  nvs_get_str(nvs_handle, "host_names", NULL, &host_names);
  nvs_get_str(nvs_handle, "ntp_server", NULL, &ntp_server);

  switch (rets) {
  case ESP_OK:
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "host_names", "以太网串口服务器"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "ntp_server", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "lgname", "admin"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "lgpwd", "12345678"));
    break;
  default:
    break;
  }
  if (rets != ESP_OK) {
    printf("Error getting size of 'host_names': %s\n", esp_err_to_name(rets));
  } else {
    char *nvs_host_names = malloc(host_names);
    char *nvs_ntp_server = malloc(ntp_server);
    char *nvs_lgname = malloc(lgname);
    char *nvs_lgpwd = malloc(lgpwd);
    if (nvs_host_names == NULL) {
      printf("Memory allocation failed\n");
    } else {
      rets = nvs_get_str(nvs_handle, "host_names", nvs_host_names, &host_names);
      nvs_get_str(nvs_handle, "ntp_server", nvs_ntp_server, &ntp_server);
      nvs_get_str(nvs_handle, "lgname", nvs_lgname, &lgname);
      nvs_get_str(nvs_handle, "lgpwd", nvs_lgpwd, &lgpwd);

      if (rets == ESP_OK) {
        printf("Value for 'host_names' is %s\n", nvs_host_names);
        printf("Value for 'ntp_server' is %s\n", nvs_ntp_server);
        printf("Value for 'lgname' is %s\n", nvs_lgname);
        printf("Value for 'lgpwd' is %s\n", nvs_lgpwd);
        if (strcmp(username->valuestring, nvs_lgname) == 0 &&
            strcmp(password->valuestring, nvs_lgpwd) == 0) {
          printf("login success\n");
          httpd_resp_send(req, "success", HTTPD_RESP_USE_STRLEN);
        } else {
          printf("login fail\n");
          httpd_resp_send(req, "fail", HTTPD_RESP_USE_STRLEN);
        }
      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(rets));
      }
      free(nvs_host_names);
      free(nvs_ntp_server);
      free(nvs_lgname);
      free(nvs_lgpwd);
    }
  }
  nvs_close(nvs_handle);
  cJSON_Delete(json);
  return ESP_OK;
}

static const httpd_uri_t root = {
    .uri = "/", .method = HTTP_GET, .handler = root_get_handler};

static const httpd_uri_t get_status = {
    .uri = "/status", .method = HTTP_POST, .handler = get_status_get_handler};

static const httpd_uri_t js_uri = {
    .uri = "/web.js", .method = HTTP_GET, .handler = js_get_handler};

static const httpd_uri_t css_uri = {
    .uri = "/web.css", .method = HTTP_GET, .handler = css_get_handler};

static const httpd_uri_t get_devinfo = {
    .uri = "/devinfo", .method = HTTP_GET, .handler = get_devinfo_get_handler};

static const httpd_uri_t get_sys = {
    .uri = "/sys", .method = HTTP_GET, .handler = get_sys_get_handler};

static const httpd_uri_t get_operate = {
    .uri = "/operate", .method = HTTP_GET, .handler = get_operate_get_handler};

static const httpd_uri_t get_restore = {
    .uri = "/restore", .method = HTTP_GET, .handler = get_restore_get_handler};

static const httpd_uri_t get_module_set = {.uri = "/module_set",
                                           .method = HTTP_POST,
                                           .handler =
                                               get_module_set_post_handler};

static const httpd_uri_t get_module_set_info = {
    .uri = "/module_set_info",
    .method = HTTP_GET,
    .handler = get_module_set_info_get_handler};

static const httpd_uri_t get_mqtt = {
    .uri = "/mqtt", .method = HTTP_POST, .handler = get_mqtt_post_handler};

static const httpd_uri_t get_net_set = {.uri = "/net_set",
                                        .method = HTTP_POST,
                                        .handler = get_net_set_post_handler};

static const httpd_uri_t get_net_set_info = {.uri = "/net_set_info",
                                             .method = HTTP_GET,
                                             .handler =
                                                 get_net_set_info_get_handler};

static const httpd_uri_t get_mqtt_info = {.uri = "/mqtt_info",
                                          .method = HTTP_GET,
                                          .handler = get_mqtt_info_get_handler};
static const httpd_uri_t get_tcp_info = {.uri = "/tcp_info",
                                         .method = HTTP_GET,
                                         .handler = get_tcp_info_get_handler};

static const httpd_uri_t get_http_info = {.uri = "/http_info",
                                          .method = HTTP_GET,
                                          .handler = get_http_info_get_handler};
static const httpd_uri_t get_tcp = {
    .uri = "/tcp", .method = HTTP_POST, .handler = get_tcp_post_handler};


static const httpd_uri_t get_http = {
    .uri = "/http", .method = HTTP_POST, .handler = get_http_post_handler};

static const httpd_uri_t get_update = {
    .uri = "/update", .method = HTTP_POST, .handler = get_update_post_handler};

static const httpd_uri_t get_ota = {
    .uri = "/ota", .method = HTTP_POST, .handler = get_ota_post_handler};

static const httpd_uri_t get_find_wifi = {.uri = "/find_wifi",
                                          .method = HTTP_GET,
                                          .handler = get_find_wifi_get_handler};

static const httpd_uri_t get_ap_set = {
    .uri = "/ap_set", .method = HTTP_POST, .handler = get_ap_set_post_handler};

static const httpd_uri_t get_serial_set = {.uri = "/serial_set",
                                           .method = HTTP_POST,
                                           .handler = get_serial_set_handler};

static const httpd_uri_t get_serial_ctl = {.uri = "/serial_ctl",
                                           .method = HTTP_POST,
                                           .handler = get_serial_ctl_handler};

static const httpd_uri_t get_serial_set_info = {
    .uri = "/serial_set_info",
    .method = HTTP_GET,
    .handler = get_serial_set_info_get_handler};

static const httpd_uri_t work_mode_set = {.uri = "/work_mode_set",
                                          .method = HTTP_POST,
                                          .handler = get_work_mode_set_handler};

static const httpd_uri_t work_mode_info = {.uri = "/work_mode_info",
                                           .method = HTTP_GET,
                                           .handler =
                                               get_work_mode_info_handler};

static const httpd_uri_t uart_response_uri = {.uri = "/uart_response",
                                              .method = HTTP_GET,
                                              .handler =
                                                  get_uart_response_handler,
                                              .user_ctx = NULL};

static const httpd_uri_t get_exit_ap = {
    .uri = "/exit_ap", .method = HTTP_GET, .handler = get_exit_ap_get_handler};

static const httpd_uri_t get_ap_set_info = {.uri = "/ap_set_info",
                                            .method = HTTP_GET,
                                            .handler =
                                                get_ap_set_info_get_handler};

static const httpd_uri_t log_ws = {.uri = "/ws/log",
                               .method = HTTP_GET,
                               .handler = ws_handler,
                               .user_ctx = NULL,
                               .is_websocket = true};

static const httpd_uri_t web_login = {
    .uri = "/login", .method = HTTP_POST, .handler = web_login_handler};

static const httpd_uri_t get_ota_progress = {.uri = "/ota_progress",
                                             .method = HTTP_GET,
                                             .handler =
                                                 get_ota_progress_handler,
                                             .user_ctx = NULL};

static const httpd_uri_t get_log_switch = {.uri = "/api/log_switch",
                                           .method = HTTP_GET,
                                           .handler = get_log_switch_handler,
                                           .user_ctx = NULL};

static const httpd_uri_t set_log_switch = {.uri = "/api/log_switch",
                                           .method = HTTP_POST,
                                           .handler = set_log_switch_handler,
                                           .user_ctx = NULL};

static httpd_handle_t start_webserver(void) {
  // 从NVS读取日志开关状态
  nvs_handle_t nvs_handle;
  esp_err_t err = nvs_open("storage", NVS_READONLY, &nvs_handle);
  if (err == ESP_OK) {
    uint8_t log_state = 0;
    err = nvs_get_u8(nvs_handle, "log_enabled", &log_state);
    if (err == ESP_OK) {
      log_enabled = (log_state != 0);
      ESP_LOGI(TAG, "从NVS加载日志开关状态: %s", log_enabled ? "打开" : "关闭");
    } else {
      ESP_LOGI(TAG, "NVS中未找到日志开关配置，使用默认值: 关闭");
    }
    nvs_close(nvs_handle);
  } else {
    ESP_LOGW(TAG, "无法打开NVS读取日志开关状态");
  }

  httpd_config_t config = HTTPD_DEFAULT_CONFIG();
  config.stack_size = 8192;     // 增加栈大小到8KB以避免看门狗超时（原6KB导致问题）
  config.max_open_sockets = 13; // 减少最大连接数到13以节省内存
  config.max_uri_handlers = 48;
  config.task_priority = 5;     // 使用默认优先级5，确保任务调度正常
  config.recv_wait_timeout = 10; // 增加接收超时避免阻塞（原2秒）
  config.send_wait_timeout = 10; // 增加发送超时避免阻塞（原2秒）

  config.keep_alive_enable = true;
  config.keep_alive_idle = 5; // 增加空闲时间，减少CPU占用
  config.keep_alive_interval = 3;
  config.keep_alive_count = 3;
  config.lru_purge_enable = true;
  config.enable_so_linger = true;
  config.linger_timeout = 1;

  ESP_LOGI(TAG, "正在端口 '%d' 上启动http_server，允许最大 %d 个连接",
           config.server_port, config.max_open_sockets);

  if (httpd_start(&http_server, &config) == ESP_OK) {
    ESP_LOGI(TAG, "Registering URI handlers");
    init_websocket();
    httpd_register_uri_handler(http_server, &root);
    httpd_register_uri_handler(http_server, &get_status);
    httpd_register_uri_handler(http_server, &js_uri);
    httpd_register_uri_handler(http_server, &css_uri);
    httpd_register_uri_handler(http_server, &get_devinfo);
    httpd_register_uri_handler(http_server, &get_sys);
    httpd_register_uri_handler(http_server, &get_module_set);
    httpd_register_uri_handler(http_server, &get_module_set_info);
    httpd_register_uri_handler(http_server, &get_net_set);
    httpd_register_uri_handler(http_server, &get_net_set_info);
    httpd_register_uri_handler(http_server, &get_mqtt);
    httpd_register_uri_handler(http_server, &get_mqtt_info);
    httpd_register_uri_handler(http_server, &get_tcp);
    httpd_register_uri_handler(http_server, &get_tcp_info);
    httpd_register_uri_handler(http_server, &log_ws);

    httpd_register_uri_handler(http_server, &get_http);
    httpd_register_uri_handler(http_server, &get_http_info);
    httpd_register_uri_handler(http_server, &get_operate);
    httpd_register_uri_handler(http_server, &get_restore);
    httpd_register_uri_handler(http_server, &get_update);
    httpd_register_uri_handler(http_server, &get_ota);
    httpd_register_uri_handler(http_server, &get_find_wifi);
    httpd_register_uri_handler(http_server, &get_exit_ap);
    httpd_register_uri_handler(http_server, &get_ap_set);
    httpd_register_uri_handler(http_server, &get_ap_set_info);

    httpd_register_uri_handler(http_server, &web_login);
    httpd_register_uri_handler(http_server, &get_serial_set);
    httpd_register_uri_handler(http_server, &get_serial_set_info);
    httpd_register_uri_handler(http_server, &get_serial_ctl);
    httpd_register_uri_handler(http_server, &uart_response_uri);
    httpd_register_uri_handler(http_server, &work_mode_set);
    httpd_register_uri_handler(http_server, &work_mode_info);
    httpd_register_uri_handler(http_server, &get_ota_progress);
    httpd_register_uri_handler(http_server, &get_log_switch);
    httpd_register_uri_handler(http_server, &set_log_switch);

    httpd_register_err_handler(http_server, HTTPD_404_NOT_FOUND,
                               http_404_error_handler);
  }
  return http_server;
}



void http_server_init(void) {
  // 初始化NVS互斥锁
  if (nvs_mutex == NULL) {
    nvs_mutex = xSemaphoreCreateMutex();
    if (nvs_mutex == NULL) {
      ESP_LOGE(TAG, "Failed to create NVS mutex");
    } else {
      ESP_LOGI(TAG, "NVS mutex initialized successfully");
    }
  }
  esp_log_level_set("httpd_sess", ESP_LOG_ERROR);
  // 首先初始化日志系统
  sx_log_init();
  // ESP_ERROR_CHECK(esp_netif_init());
  // ESP_ERROR_CHECK(esp_event_loop_create_default());
  // wifi_init_sta();
  wifi_init_softap();
  start_webserver();
  start_dns_server();
  // sx_log_init();
}

/*************************************************************************************/
/*                                END OF FILE */
/*************************************************************************************/
