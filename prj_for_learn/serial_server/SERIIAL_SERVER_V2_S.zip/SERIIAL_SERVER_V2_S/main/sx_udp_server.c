/*
 * @Author: Orion
 * @Date: 2024-01-23 16:08:16
 * @LastEditors: Orion
 * @LastEditTime: 2025-05-20 21:42:17
 * @FilePath: \SERIIAL_SERVER\main\sx_udp_server.c
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */

#include "esp_event.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "esp_system.h"
#include "esp_wifi.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "nvs_flash.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/param.h>
#include <unistd.h>  // 添加此头文件以解决close函数未声明的问题

#include "cJSON.h"
#include "lwip/err.h"
#include "lwip/sockets.h"
#include "lwip/sys.h"
#include "sx_async_uart.h"
#include "sx_utils.h"
#include "sx_web_server.h"  // 添加此头文件以获取网络变量声明
#include <lwip/netdb.h>


/*************************************************************************************/
/*                                START OF FILE */
/*************************************************************************************/

static const char *TAG = "UDPSERVER";
#define UDP_SERVER_PORT 37210

// 声明外部变量
extern char got_ip_addrs[16];
extern char got_ip_netmask[16];
extern char got_ip_gw[16];

TaskHandle_t xHandleUDPServerTask;
static char *global_ip = NULL;
static char *global_mask = NULL;
static char *global_gateway = NULL;
static char *global_name = NULL;
static char *global_primary_dns = NULL;
static char *global_secondary_dns = NULL;
static char *global_is_dhcp = NULL;

static void store_network_settings(const char *name, const char *ip,
                                   const char *mask, const char *gateway,
                                   const char *primary_dns, const char *secondary_dns,
                                   const char *is_dhcp) {
  if (global_name)
    free(global_name);
  if (global_ip)
    free(global_ip);
  if (global_mask)
    free(global_mask);
  if (global_gateway)
    free(global_gateway);
  if (global_primary_dns)
    free(global_primary_dns);
  if (global_secondary_dns)
    free(global_secondary_dns);
  if (global_is_dhcp)
    free(global_is_dhcp);

  global_name = strdup(name);
  global_ip = strdup(ip);
  global_mask = strdup(mask);
  global_gateway = strdup(gateway);
  global_primary_dns = strdup(primary_dns);
  global_secondary_dns = strdup(secondary_dns);
  global_is_dhcp = strdup(is_dhcp);
}

static void udp_server_task(void *pvParameters) {
  char rx_buffer[128];
  char addr_str[128];
  int addr_family = AF_INET;
  int ip_protocol = 0;
  struct sockaddr_in dest_addr;
  struct sockaddr_in source_addr;

  while (1) {
    if (addr_family == AF_INET) {
      dest_addr.sin_addr.s_addr = htonl(INADDR_ANY);
      dest_addr.sin_family = AF_INET;
      dest_addr.sin_port = htons(UDP_SERVER_PORT);
      ip_protocol = IPPROTO_IP;
    }

    int sock = socket(addr_family, SOCK_DGRAM, ip_protocol);
    if (sock < 0) {
      ESP_LOGE(TAG, "Unable to create socket: errno %d", errno);
      break;
    }
    ESP_LOGI(TAG, "Socket created");

    // 设置SO_REUSEADDR选项
    int opt = 1;
    setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    // 设置广播选项
    int broadcast = 1;
    setsockopt(sock, SOL_SOCKET, SO_BROADCAST, &broadcast, sizeof(broadcast));

    int err = bind(sock, (struct sockaddr *)&dest_addr, sizeof(dest_addr));
    if (err < 0) {
      ESP_LOGE(TAG, "Socket unable to bind: errno %d", errno);
    }
    ESP_LOGI(TAG, "Socket bound, port %d", UDP_SERVER_PORT);

    socklen_t socklen = sizeof(source_addr);

    while (1) {
      ESP_LOGI(TAG, "Waiting for data");
      int len = recvfrom(sock, rx_buffer, sizeof(rx_buffer) - 1, 0,
                         (struct sockaddr *)&source_addr, &socklen);

      // Error occurred during receiving
      if (len < 0) {
        ESP_LOGE(TAG, "recvfrom failed: errno %d", errno);
        break;
      }
      // Data received
      else {
        // Get the sender's ip address as string
        if (source_addr.sin_family == AF_INET) {
          inet_ntoa_r(((struct sockaddr_in *)&source_addr)->sin_addr, addr_str,
                      sizeof(addr_str) - 1);
        }

        rx_buffer[len] = 0; // Null-terminate whatever we received and treat like a string...
        ESP_LOGI(TAG, "Received %d bytes from %s:", len, addr_str);
        ESP_LOGI(TAG, "%s", rx_buffer);

        // 显示本地网络信息，便于调试
        ESP_LOGI(TAG, "Local IP: %s, Netmask: %s, Gateway: %s",
                 got_ip_addrs, got_ip_netmask, got_ip_gw);

        cJSON *pJsonRoot = cJSON_Parse(rx_buffer);
        if (pJsonRoot == NULL) {
          const char *error_ptr = cJSON_GetErrorPtr();
          if (error_ptr != NULL) {
            ESP_LOGE(TAG, "Error before: %s", error_ptr);
          }
          continue;
        }

        char *udpmsg = NULL;
        cJSON *device = cJSON_GetObjectItem(pJsonRoot, "device");
        if (cJSON_IsString(device) && (device->valuestring != NULL)) {
          if (strcmp(device->valuestring, "scan") == 0) {
            // 设备搜索请求，返回设备信息
            ESP_LOGI(TAG, "Received scan command from tool, sending device info");
            udpmsg = send_device_ip();
            if (udpmsg) {
              ESP_LOGI(TAG, "Device info to send: %s", udpmsg);
              // 发送响应
              int err = sendto(sock, udpmsg, strlen(udpmsg), 0,
                              (struct sockaddr *)&source_addr, sizeof(source_addr));
              if (err < 0) {
                ESP_LOGE(TAG, "Error sending response: errno %d", errno);
              } else {
                ESP_LOGI(TAG, "Response sent successfully: %d bytes", err);
              }
            } else {
              ESP_LOGE(TAG, "Failed to generate device info response");
            }
          } else if (strcmp(device->valuestring, "set") == 0) {
            // 设置网络参数
            cJSON *parm = cJSON_GetObjectItem(pJsonRoot, "parm");

            // 打印完整的参数，用于调试
            char *parm_str = cJSON_Print(parm);
            if (parm_str) {
                ESP_LOGI(TAG, "Received network settings parameters: %s", parm_str);
                free(parm_str);
            }

            cJSON *name = cJSON_GetObjectItem(parm, "name");
            cJSON *ip = cJSON_GetObjectItem(parm, "ip");
            cJSON *mask = cJSON_GetObjectItem(parm, "mask");
            cJSON *gateway = cJSON_GetObjectItem(parm, "gateway");
            cJSON *primary_dns = cJSON_GetObjectItem(parm, "primary_dns");
            cJSON *secondary_dns = cJSON_GetObjectItem(parm, "secondary_dns");
            cJSON *is_dhcp = cJSON_GetObjectItem(parm, "is_dhcp");

            // 打印各字段的值和类型
            ESP_LOGI(TAG, "name field: %s, valid: %d",
                     name ? (name->valuestring ? name->valuestring : "NULL") : "NOT FOUND",
                     (name && cJSON_IsString(name) && name->valuestring));
            ESP_LOGI(TAG, "ip field: %s, valid: %d",
                     ip ? (ip->valuestring ? ip->valuestring : "NULL") : "NOT FOUND",
                     (ip && cJSON_IsString(ip) && ip->valuestring));
            ESP_LOGI(TAG, "mask field: %s, valid: %d",
                     mask ? (mask->valuestring ? mask->valuestring : "NULL") : "NOT FOUND",
                     (mask && cJSON_IsString(mask) && mask->valuestring));
            ESP_LOGI(TAG, "gateway field: %s, valid: %d",
                     gateway ? (gateway->valuestring ? gateway->valuestring : "NULL") : "NOT FOUND",
                     (gateway && cJSON_IsString(gateway) && gateway->valuestring));
            ESP_LOGI(TAG, "primary_dns field: %s, valid: %d",
                     primary_dns ? (primary_dns->valuestring ? primary_dns->valuestring : "NULL") : "NOT FOUND",
                     (primary_dns && cJSON_IsString(primary_dns) && primary_dns->valuestring));
            ESP_LOGI(TAG, "secondary_dns field: %s, valid: %d",
                     secondary_dns ? (secondary_dns->valuestring ? secondary_dns->valuestring : "NULL") : "NOT FOUND",
                     (secondary_dns && cJSON_IsString(secondary_dns) && secondary_dns->valuestring));
            ESP_LOGI(TAG, "is_dhcp field: %s, valid: %d",
                     is_dhcp ? (is_dhcp->valuestring ? is_dhcp->valuestring : "NULL") : "NOT FOUND",
                     (is_dhcp && cJSON_IsString(is_dhcp) && is_dhcp->valuestring));

            if (cJSON_IsString(name) && cJSON_IsString(ip) &&
                cJSON_IsString(mask) && cJSON_IsString(gateway)) {

              // 设置默认DNS值
              const char *primary_dns_value = "8.8.8.8";
              const char *secondary_dns_value = "114.114.114.114";
              const char *is_dhcp_value = "2"; // 默认静态IP

              // 如果有提供DNS和IP类型值，则使用提供的值
              if (primary_dns && cJSON_IsString(primary_dns) && primary_dns->valuestring) {
                primary_dns_value = primary_dns->valuestring;
              }

              if (secondary_dns && cJSON_IsString(secondary_dns) && secondary_dns->valuestring) {
                secondary_dns_value = secondary_dns->valuestring;
              }

              if (is_dhcp && cJSON_IsString(is_dhcp) && is_dhcp->valuestring) {
                is_dhcp_value = is_dhcp->valuestring;
              }

              ESP_LOGI(TAG, "Storing network settings - Name: %s, IP: %s, Mask: %s, Gateway: %s, Primary DNS: %s, Secondary DNS: %s, IP Type: %s",
                       name->valuestring, ip->valuestring, mask->valuestring, gateway->valuestring,
                       primary_dns_value, secondary_dns_value, is_dhcp_value);

              store_network_settings(name->valuestring, ip->valuestring,
                                   mask->valuestring, gateway->valuestring,
                                   primary_dns_value, secondary_dns_value,
                                   is_dhcp_value);
              udpmsg = strdup("{\"change\":\"ok\"}");
            } else {
              ESP_LOGE(TAG, "Invalid network settings parameters");
              udpmsg = strdup("{\"change\":\"failed\"}");
            }
          }
        }

        cJSON *uname = cJSON_GetObjectItem(pJsonRoot, "username");
        cJSON *passwd = cJSON_GetObjectItem(pJsonRoot, "password");
        if (cJSON_IsString(uname) && cJSON_IsString(passwd)) {
          esp_err_t rets = nvs_init();
          nvs_handle_t nvs_handle;
          ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
          size_t lgname_len = 0, lgpwd_len = 0;
          rets = nvs_get_str(nvs_handle, "lgname", NULL, &lgname_len);
          rets = nvs_get_str(nvs_handle, "lgpwd", NULL, &lgpwd_len);
          switch (rets) {
          case ESP_OK:
            break;
          case ESP_ERR_NVS_NOT_FOUND:
            ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "lgname", "admin"));
            ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "lgpwd", "12345678"));
            break;
          default:
            ESP_LOGE(TAG, "Error getting NVS data: %s", esp_err_to_name(rets));
            break;
          }
          if (rets == ESP_OK) {
            char *nvs_lgname = malloc(lgname_len);
            char *nvs_lgpwd = malloc(lgpwd_len);
            if (nvs_lgname != NULL && nvs_lgpwd != NULL) {
              rets = nvs_get_str(nvs_handle, "lgname", nvs_lgname, &lgname_len);
              rets = nvs_get_str(nvs_handle, "lgpwd", nvs_lgpwd, &lgpwd_len);
              if (rets == ESP_OK) {
                if (strcmp(uname->valuestring, nvs_lgname) == 0 &&
                    strcmp(passwd->valuestring, nvs_lgpwd) == 0) {
                  if (udpmsg == NULL) {
                    udpmsg = strdup("{\"change\":\"ok\"}");
                  }
                  if (global_name != NULL && global_ip != NULL && global_mask != NULL &&
                      global_gateway != NULL) {
                    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "is_dhcp", global_is_dhcp ? global_is_dhcp : "2"));
                    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "host_names", global_name));
                    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "static_ip", global_ip));
                    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "static_netmask", global_mask));
                    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "static_gateway", global_gateway));

                    // 存储DNS设置
                    if (global_primary_dns) {
                      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "primary_dns", global_primary_dns));
                    }
                    if (global_secondary_dns) {
                      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "secondary_dns", global_secondary_dns));
                    }

                    int err = sendto(sock, udpmsg, strlen(udpmsg), 0,
                                   (struct sockaddr *)&source_addr, sizeof(source_addr));
                    if (err < 0) {
                      ESP_LOGE(TAG, "Error occurred during sending: errno %d", errno);
                    }
                    free(udpmsg);
                    vTaskDelay(500 / portTICK_PERIOD_MS);
                    esp_restart();
                  }
                } else {
                  if (udpmsg == NULL) {
                    udpmsg = strdup("{\"change\":\"failed\"}");
                  }
                }
              } else {
                ESP_LOGE(TAG, "Error reading NVS data: %s", esp_err_to_name(rets));
              }
              free(nvs_lgname);
              free(nvs_lgpwd);
            } else {
              ESP_LOGE(TAG, "Memory allocation failed");
            }
          } else {
            ESP_LOGE(TAG, "Error getting NVS data size: %s", esp_err_to_name(rets));
          }
          nvs_close(nvs_handle);
        }

        cJSON_Delete(pJsonRoot);

        if (udpmsg != NULL) {
          int err = sendto(sock, udpmsg, strlen(udpmsg), 0,
                         (struct sockaddr *)&source_addr, sizeof(source_addr));
          if (err < 0) {
            ESP_LOGE(TAG, "Error occurred during sending: errno %d", errno);
          }
          free(udpmsg);
        }
      }
    }

    if (sock != -1) {
      ESP_LOGE(TAG, "Shutting down socket and restarting...");
      shutdown(sock, 0);
      closesocket(sock);
    }
  }
  vTaskDelete(NULL);
}

void start_udp_server(void) {
  xTaskCreate(udp_server_task, "udp_server", 4096, (void *)AF_INET, 5, &xHandleUDPServerTask);
}

void kill_udp_server(void) {
    if (xHandleUDPServerTask != NULL) {
        vTaskDelete(xHandleUDPServerTask);
        xHandleUDPServerTask = NULL;
    }
}

/*************************************************************************************/
/*                                END OF FILE */
/*************************************************************************************/
