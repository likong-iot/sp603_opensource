#include "driver/gpio.h"
#include "driver/uart.h"
#include "esp_err.h"
#include "esp_log.h"
#include "esp_system.h"
#include "esp_timer.h"
#include "esp_task_wdt.h"
#include "freertos/FreeRTOS.h"
#include "freertos/mpu_wrappers.h"
#include "freertos/task.h"
#include "hal/uart_types.h"
#include "string.h"

#include "cJSON.h"
#include "driver/gpio.h"
#include "freertos/queue.h"
#include "freertos/ringbuf.h"
#include "nvs.h"
#include "nvs_flash.h"
#include "sx_gpio.h"
#include "sx_http_client.h"
#include "sx_mqtt_client.h"
#include "sx_tcp_client.h"
#include "sx_tcp_server.h"
#include "sx_utils.h"
#include "sx_web_server.h"
#include <stdio.h>
#include <stdlib.h>

#include "sx_async_uart.h"

// static const int RX_BUF_SIZE = 4096;
uint8_t dataArray[] = {0};
// char global_hex_data_str[256];
// uint8_t *source_data = NULL;
// int lens = 0;
// #define TXD_PIN (GPIO_NUM_1)
// #define RXD_PIN (GPIO_NUM_3)
TaskHandle_t uartTaskHandle = NULL;
// #define TXD_PIN (GPIO_NUM_15)
// #define RXD_PIN (GPIO_NUM_2)
#define TXD_PIN (GPIO_NUM_17)
#define RXD_PIN (GPIO_NUM_16)
#define TAG "ASYNCRS485"
#define BUF_SIZE (4096)
// RTS for RS485 Half-Duplex Mode manages DE/~RE
#define ECHO_TEST_RTS 2

// CTS is not used in RS485 Half-Duplex Mode
#define ECHO_TEST_CTS (UART_PIN_NO_CHANGE)

#define ECHO_READ_TOUT (3) // 3.5T * 8 = 28 ticks, TOUT=3 -> ~24..33 ticks
#define PACKET_READ_TICS (100 / portTICK_PERIOD_MS)

// char device_response[512];
uint8_t uart_response[1024] = {0};
uint8_t uart_tx_data[1024] = {0};
size_t tx_data_len = 0;
uart_timestamps_t uart_timestamps = {0};

int current_modbus_template_target = 0;
#define RING_BUFFER_SIZE 10240
void stop_rx_task();
void rx_wait();

// uint8_t uart_response[BUF_SIZE] = {0};
size_t response_len = 0;
portMUX_TYPE uart_spinlock = portMUX_INITIALIZER_UNLOCKED;
SemaphoreHandle_t uart_mutex = NULL;  // UART操作互斥锁

void uart_configure(int baudrate, uart_word_length_t data_bits,
                    uart_parity_t parity, uart_stop_bits_t stop_bits,
                    int frame_time, int frame_len) {
  ESP_LOGI(TAG, "uart_configure");
  ESP_LOGI(TAG, "baudrate: %d", baudrate);
  ESP_LOGI(TAG, "data_bits: %d", data_bits);
  ESP_LOGI(TAG, "parity: %d", parity);
  ESP_LOGI(TAG, "stop_bits: %d", stop_bits);
  ESP_LOGI(TAG, "frame_time: %d", frame_time);
  ESP_LOGI(TAG, "frame_len: %d", frame_len);
  uart_parity_t uart_parity = parity;
  uart_word_length_t uart_data_bits = data_bits;
  uart_stop_bits_t uart_stop_bits = stop_bits;
  if (parity == 0) {
    uart_parity = UART_PARITY_DISABLE;
  } else if (parity == 1) {
    uart_parity = UART_PARITY_EVEN;
  } else if (parity == 2) {
    uart_parity = UART_PARITY_ODD;
  }
  if (data_bits == 5) {
    uart_data_bits = UART_DATA_5_BITS;
  } else if (data_bits == 6) {
    uart_data_bits = UART_DATA_6_BITS;
  } else if (data_bits == 7) {
    uart_data_bits = UART_DATA_7_BITS;
  } else if (data_bits == 8) {
    uart_data_bits = UART_DATA_8_BITS;
  }
  if (stop_bits == 1) {
    uart_stop_bits = UART_STOP_BITS_1;
  } else if (stop_bits == 1.5) {
    uart_stop_bits = UART_STOP_BITS_1_5;
  } else if (stop_bits == 2) {
    uart_stop_bits = UART_STOP_BITS_2;
  }
  uart_config_t uart_config = {
      .baud_rate = baudrate,
      .data_bits = uart_data_bits,
      .parity = uart_parity,
      .stop_bits = uart_stop_bits,
      .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
      .rx_flow_ctrl_thresh = 122,
      .source_clk = UART_SCLK_DEFAULT,
  };

  // 计算超时时钟周期
  // frame_time是以毫秒为单位的帧间隔时间
  // 计算每个字符的传输时间（包括起始位、数据位、校验位、停止位）
  int bits_per_char = 1 + data_bits + stop_bits;  // 起始位(1) + 数据位 + 停止位
  if (parity != UART_PARITY_DISABLE) {
    bits_per_char += 1;  // 加上校验位
  }

  // 计算1个字符传输需要的时间（微秒）
  float char_time_us = (bits_per_char * 1000000.0) / baudrate;

  // 将frame_time（毫秒）转换为字符数
  // timeout_ticks = (frame_time_ms * 1000) / char_time_us
  int timeout_ticks = (int)((frame_time * 1000.0) / char_time_us);

  // ESP32硬件限制：UART RX超时的最大值为101字符时间
  // 限制在合理范围内（最小1，最大101）
  if (timeout_ticks < 1) {
    timeout_ticks = 1;
  }
  if (timeout_ticks > 101) {
    ESP_LOGW(TAG, "计算的timeout_ticks (%d) 超过硬件最大值 (101)，已限制为101", timeout_ticks);
    ESP_LOGW(TAG, "实际超时时间约为: %.2f ms (而非预期的 %d ms)",
             (101 * char_time_us) / 1000.0, frame_time);
    timeout_ticks = 101;
  }

  // rx_threshold 应该设置为一个合理的触发值，不是最大帧长度
  // 对于Modbus等协议，建议设置为较小值以便及时触发接收
  // ESP32 UART FIFO最大127，但实际有效阈值范围是1-120
  //
  // 修复: 使用10字节阈值，避免64/65字节数据在32/64边界处被分批接收
  // 较小的阈值能更及时触发，同时避免在特定字节数（32、64等）边界导致数据分割
  int rx_threshold = 10;

  if (rx_threshold < 1)
    rx_threshold = 1;
  if (rx_threshold > 120)
    rx_threshold = 120;

  // 设置接收缓冲区大小为2的幂次方，确保足够容纳最大帧长度
  // 缓冲区大小应该至少是最大帧长度的2倍，以避免溢出
  int rx_buffer_size = 256; // 默认256字节（适用于frame_len <= 128）
  if (frame_len > 128)
    rx_buffer_size = 512;   // 适用于frame_len: 129-256
  if (frame_len > 256)
    rx_buffer_size = 1024;  // 适用于frame_len: 257-512
  if (frame_len > 512)
    rx_buffer_size = 2048;  // 适用于frame_len: 513-1024
  if (frame_len > 1024)
    rx_buffer_size = 4096;  // 适用于frame_len: 1025-2048

  // 额外检查：如果frame_len超过2048，限制到最大值
  if (frame_len > 2048) {
    ESP_LOGW(TAG, "frame_len (%d) 超过推荐最大值(2048)，将rx_buffer限制为4096", frame_len);
    rx_buffer_size = 4096;
  }

  ESP_LOGI(TAG, "==================== UART 配置详情 ====================");
  ESP_LOGI(TAG, "波特率: %d", baudrate);
  ESP_LOGI(TAG, "数据位: %d", data_bits);
  ESP_LOGI(TAG, "校验位: %d", parity);
  ESP_LOGI(TAG, "停止位: %d", stop_bits);
  ESP_LOGI(TAG, "帧间隔时间(frame_time): %d ms", frame_time);
  ESP_LOGI(TAG, "最大帧长度(frame_len): %d bytes", frame_len);
  ESP_LOGI(TAG, "------------------------------------------------------");
  ESP_LOGI(TAG, "计算结果:");
  ESP_LOGI(TAG, "  每字符位数: %d bits", bits_per_char);
  ESP_LOGI(TAG, "  每字符传输时间: %.2f us", char_time_us);
  ESP_LOGI(TAG, "  超时时钟周期(timeout_ticks): %d 字符时间 (约%.2f ms)",
           timeout_ticks, (timeout_ticks * char_time_us) / 1000.0);
  ESP_LOGI(TAG, "  接收阈值(rx_threshold): %d bytes", rx_threshold);
  ESP_LOGI(TAG, "  接收缓冲区大小(rx_buffer): %d bytes", rx_buffer_size);
  ESP_LOGI(TAG, "======================================================");

  // 确保先删除现有的UART驱动
  uart_driver_delete(UART_NUM_2);

  // 等待一小段时间确保驱动完全释放
  vTaskDelay(pdMS_TO_TICKS(20));

  // 按照正确的顺序配置UART
  ESP_ERROR_CHECK(uart_param_config(UART_NUM_2, &uart_config));
  ESP_ERROR_CHECK(uart_set_pin(UART_NUM_2, TXD_PIN, RXD_PIN, ECHO_TEST_RTS,
                               UART_PIN_NO_CHANGE));

  esp_err_t err =
      uart_driver_install(UART_NUM_2, rx_buffer_size, 0, 0, NULL, 0);
  if (err != ESP_OK) {
    ESP_LOGE(TAG, "uart_driver_install failed with error: %d", err);
    // 如果安装失败，尝试使用最小的缓冲区大小
    rx_buffer_size = 256;
    err = uart_driver_install(UART_NUM_2, rx_buffer_size, 0, 0, NULL, 0);
    if (err != ESP_OK) {
      ESP_LOGE(TAG, "uart_driver_install retry failed");
      return;
    }
  }

  ESP_ERROR_CHECK(uart_set_mode(UART_NUM_2, UART_MODE_RS485_HALF_DUPLEX));
  ESP_ERROR_CHECK(uart_set_rx_timeout(UART_NUM_2, timeout_ticks));
  ESP_ERROR_CHECK(uart_set_rx_full_threshold(UART_NUM_2, rx_threshold));

  rx_wait();
}

void uart_init(void) {
  // 创建UART互斥锁
  if (uart_mutex == NULL) {
    uart_mutex = xSemaphoreCreateMutex();
    if (uart_mutex == NULL) {
      ESP_LOGE(TAG, "Failed to create UART mutex");
      return;
    }
  }

  esp_err_t rets = nvs_init();
  nvs_handle_t nvs_handle;

  if (nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle) != ESP_OK) {
    ESP_LOGE(TAG, "Failed to open NVS namespace");
    return;
  }

  // size_t baud_rate, data_bit, check_bit, stop_bit, frame_time, frame_len = 0;
  char *nvs_values[6] = {NULL}; // 用数组统一管理内存
  size_t sizes[6] = {0};
  const char *keys[6] = {"baud_rate", "data_bit",   "check_bit",
                         "stop_bit",  "frame_time", "frame_len"};

  // 获取所有字段的大小
  for (int i = 0; i < 6; i++) {
    rets = nvs_get_str(nvs_handle, keys[i], NULL, &sizes[i]);
    if (rets != ESP_OK && rets != ESP_ERR_NVS_NOT_FOUND) {
      ESP_LOGE(TAG, "Failed to get size for %s", keys[i]);
      nvs_close(nvs_handle);
      return;
    }
  }

  // 如果是第一次运行，设置默认值
  if (rets == ESP_ERR_NVS_NOT_FOUND) {
    ESP_LOGW(TAG, "First run, setting default values");
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "baud_rate", "9600"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "data_bit", "8"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "check_bit", "0"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "stop_bit", "0"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "frame_time", "50"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "frame_len", "512"));
    ESP_ERROR_CHECK(nvs_commit(nvs_handle));
    nvs_close(nvs_handle);
    esp_restart();
    // return;
  }

  // 分配内存并读取值
  bool allocation_failed = false;
  for (int i = 0; i < 6; i++) {
    nvs_values[i] = malloc(sizes[i]);
    if (nvs_values[i] == NULL) {
      ESP_LOGE(TAG, "Memory allocation failed for %s", keys[i]);
      allocation_failed = true;
      break;
    }

    if (nvs_get_str(nvs_handle, keys[i], nvs_values[i], &sizes[i]) != ESP_OK) {
      ESP_LOGE(TAG, "Failed to read %s", keys[i]);
      allocation_failed = true;
      break;
    }
  }

  // 如果所有值都成功读取，则配置 UART
  if (!allocation_failed) {
    int baudrate = atoi(nvs_values[0]);
    uart_word_length_t data_bits = atoi(nvs_values[1]);
    uart_parity_t parity = atoi(nvs_values[2]);
    uart_stop_bits_t stop_bits = atof(nvs_values[3]);
    int frame_time = atoi(nvs_values[4]);
    int frame_len = atoi(nvs_values[5]);

    uart_configure(baudrate, data_bits, parity, stop_bits, frame_time,
                   frame_len);
  }

  // 清理资源
  for (int i = 0; i < 6; i++) {
    if (nvs_values[i] != NULL) {
      free(nvs_values[i]);
    }
  }
  nvs_close(nvs_handle);


}
void uart_reinit(int baudrate, uart_word_length_t data_bits,
                 uart_parity_t parity, uart_stop_bits_t stop_bits,
                 int frame_time, int frame_len) {
  // 获取UART互斥锁，确保没有其他操作在使用UART
  if (uart_mutex != NULL) {
    if (xSemaphoreTake(uart_mutex, pdMS_TO_TICKS(1000)) != pdTRUE) {
      ESP_LOGE(TAG, "无法获取UART互斥锁进行重新初始化");
      return;
    }
  }

  // 确保接收任务已停止
  stop_rx_task();
  printf("Reinit UART\n");
  printf("Baudrate: %d\n", baudrate);
  printf("Data bits: %d\n", data_bits);
  printf("Parity: %d\n", parity);
  printf("Stop bits: %d\n", stop_bits);
  // 等待任务完全停止
  vTaskDelay(pdMS_TO_TICKS(10));

  // 删除旧的串口驱动
  uart_driver_delete(UART_NUM_2);

  // 重新配置串口
  uart_configure(baudrate, data_bits, parity, stop_bits, frame_time, frame_len);

  // 释放互斥锁
  if (uart_mutex != NULL) {
    xSemaphoreGive(uart_mutex);
  }
}

int sendData(char *data, size_t length) {
    // 获取UART互斥锁，防止在重新初始化期间发送数据
    if (uart_mutex != NULL) {
        if (xSemaphoreTake(uart_mutex, pdMS_TO_TICKS(100)) != pdTRUE) {
            ESP_LOGW("UART_TX", "无法获取UART互斥锁，可能正在重新初始化");
            return -1;
        }
    }

    // 🔧 添加发送前延时，避免死锁
    vTaskDelay(pdMS_TO_TICKS(2));

    // 彻底清空UART接收缓冲区，防止旧数据干扰
    size_t before_flush_size = 0;
    uart_get_buffered_data_len(UART_NUM_2, &before_flush_size);

    // 多次flush确保清除所有残留数据
    for (int i = 0; i < 3; i++) {
        uart_flush_input(UART_NUM_2);
        vTaskDelay(pdMS_TO_TICKS(1));
    }

    // 验证缓冲区已清空
    size_t after_flush_size = 0;
    if (uart_get_buffered_data_len(UART_NUM_2, &after_flush_size) == ESP_OK) {
        if (before_flush_size > 0) {
            ESP_LOGI("UART_TX", "清理缓冲区: %zu字节 -> %zu字节",
                     before_flush_size, after_flush_size);
        }

        if (after_flush_size > 0) {
            ESP_LOGW("UART_TX", "⚠️  flush失败! 缓冲区仍有%zu字节数据，强制清除",
                     after_flush_size);
            // 强制读取并丢弃
            uint8_t discard_buf[256];
            int discarded = uart_read_bytes(UART_NUM_2, discard_buf,
                                           after_flush_size > 256 ? 256 : after_flush_size,
                                           pdMS_TO_TICKS(10));
            if (discarded > 0) {
                ESP_LOGI("UART_TX", "已强制丢弃%d字节数据", discarded);
                ESP_LOG_BUFFER_HEXDUMP("UART_TX", discard_buf, discarded, ESP_LOG_WARN);
            }
        }
    }

    gpio_set_pull_mode(GPIO_NUM_4, GPIO_PULLUP_ONLY);
    uart_timestamps.tx_timestamp = esp_timer_get_time();

    int txBytes;
    // 直接将数据作为二进制数据发送，不进行字符串检查
    portENTER_CRITICAL(&uart_spinlock);
    memset(uart_tx_data, 0, sizeof(uart_tx_data));
    memcpy(uart_tx_data, data, length);
    tx_data_len = length;
    portEXIT_CRITICAL(&uart_spinlock);

    // 通过WebSocket发送数据
    send_uart_to_websocket((uint8_t *)data, length, true);

    // 直接发送二进制数据
    txBytes = uart_write_bytes(UART_NUM_2, data, length);
    ESP_LOGI("UART_TX", "Sending data to UART:");
    ESP_LOG_BUFFER_HEXDUMP("UART_TX", data, length, ESP_LOG_INFO);

    // 🔧 等待TX完成，超时设置为50毫秒以适应不同波特率
    esp_err_t err = uart_wait_tx_done(UART_NUM_2, pdMS_TO_TICKS(50));
    if (err == ESP_OK) {
        ESP_LOGI("UART_TX", "TX数据发送完成");
    } else {
        ESP_LOGW("UART_TX", "TX可能超时: %s", esp_err_to_name(err));
    }

    // RS485硬件方向切换延时（重要！）
    // 给RS485收发器足够的时间从发送模式切换到接收模式
    // 延时时间取决于硬件特性，一般1-5ms足够
    vTaskDelay(pdMS_TO_TICKS(3));

    // 切换GPIO为下拉，使RS485进入接收模式
    gpio_set_pull_mode(GPIO_NUM_4, GPIO_PULLDOWN_ONLY);

    ESP_LOGD("UART_TX", "RS485已切换到接收模式，准备接收响应");

    // 释放互斥锁
    if (uart_mutex != NULL) {
        xSemaphoreGive(uart_mutex);
    }

    return txBytes;
}

void tx_task(uint8_t data[], size_t length) {
  static const char *TX_TASK_TAG = "TX_TASK";
  ESP_LOGD(TX_TASK_TAG, "开始发送UART数据，长度: %zu", length);
  LED_DAT_ON();
  LED_DAT_OFF();
  esp_log_level_set(TX_TASK_TAG, ESP_LOG_INFO);
  sendData((char *)data, length);
  LED_DAT_ON();
  LED_DAT_OFF();
  ESP_LOGD(TX_TASK_TAG, "UART数据发送完成");
  // vTaskDelete(NULL);
}

void tx_tasks(uint8_t data[], size_t length) {
  static const char *TX_TASK_TAG = "TX_TASK";
  ESP_LOGD(TX_TASK_TAG, "开始发送UART数据（异步），长度: %zu", length);

  // 🔧 添加任务延时避免死锁和资源竞争
  vTaskDelay(pdMS_TO_TICKS(5));

    LED_DAT_ON();
  LED_DAT_OFF();
  esp_log_level_set(TX_TASK_TAG, ESP_LOG_INFO);

  // 创建数据副本以避免内存管理问题
  uint8_t *data_copy = malloc(length);
  if (data_copy == NULL) {
    ESP_LOGE(TX_TASK_TAG, "Failed to allocate memory for data copy");
    return;
  }

  memcpy(data_copy, data, length);
  sendData((char *)data_copy, length);

  // 释放数据副本
  free(data_copy);
  LED_DAT_ON();
  LED_DAT_OFF();
}

void rx_task(void *arg) {
  ESP_LOGI(TAG, "命中RX_TASK");
  static const char *RX_TASK_TAG = "RX_TASK";
  esp_log_level_set(RX_TASK_TAG, ESP_LOG_INFO);
  char work_mode[32] = {0};

  // 初始化 NVS
  esp_err_t ret = nvs_flash_init();
  if (ret == ESP_ERR_NVS_NO_FREE_PAGES ||
      ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
    ESP_ERROR_CHECK(nvs_flash_erase());
    ret = nvs_flash_init();
  }
  if (ret != ESP_OK) {
    ESP_LOGE(RX_TASK_TAG, "NVS 初始化失败: %s", esp_err_to_name(ret));
    vTaskDelete(NULL);
    return;
  }

  // 打开 storage 命名空间
  nvs_handle_t storage_handle;
  ret = nvs_open("storage", NVS_READWRITE, &storage_handle);
  if (ret != ESP_OK) {
    ESP_LOGE(RX_TASK_TAG, "无法打开 storage 命名空间: %s",
             esp_err_to_name(ret));
    vTaskDelete(NULL);
    return;
  }

  // 获取工作模式
  size_t len = sizeof(work_mode);
  ret = nvs_get_str(storage_handle, "w_mode", work_mode, &len);
  if (ret != ESP_OK) {
    ESP_LOGW(RX_TASK_TAG, "获取工作模式失败: %s", esp_err_to_name(ret));
    strncpy(work_mode, "unknown", sizeof(work_mode) - 1);
  }
  ESP_LOGI(RX_TASK_TAG, "当前工作模式: %s", work_mode);
  nvs_close(storage_handle);

  while (1) {
    uint8_t *data = NULL;
    if (uartTaskHandle != NULL && eTaskGetState(uartTaskHandle) == eDeleted) {
      break;
    }

    size_t buffered_size;
    if (uart_get_buffered_data_len(UART_NUM_2, &buffered_size) != ESP_OK) {
      // vTaskDelay(pdMS_TO_TICKS(10));
      continue;
    }

    if (buffered_size > 0) {
      // 记录开始处理时间，用于计算响应延迟
      int64_t rx_start_time = esp_timer_get_time();

      // 针对低波特率优化的智能等待策略
      // 9600bps传输时间: 65字节≈68ms, 100字节≈104ms, 256字节≈270ms
      // rx_threshold=10触发时可能只接收了部分数据

      // 第一步：等待30ms让数据到达缓冲区（激进优化：从50ms降到30ms）
      // 对于9600 bps，30ms可接收约29字节 + rx_threshold触发时的10字节 = ~39字节
      // 剩余数据通过智能等待获取
      vTaskDelay(pdMS_TO_TICKS(30));

      // 第二步：查询缓冲区大小
      uart_get_buffered_data_len(UART_NUM_2, &buffered_size);
      ESP_LOGD(RX_TASK_TAG, "初始等待后缓冲区大小: %zu字节", buffered_size);

      // 第三步：针对Modbus TCP模式的智能完整性检查
      if (strcmp(work_mode, "modbus_tcp") == 0 && buffered_size >= 3) {
        // 预读前3字节来判断完整长度
        uint8_t header[3];
        int header_len = uart_read_bytes(UART_NUM_2, header, 3, pdMS_TO_TICKS(10));

        if (header_len == 3) {
          uint8_t slave_addr = header[0];
          uint8_t function_code = header[1];
          size_t expected_total_len = 0;

          // 判断是否为有效的Modbus响应
          if (slave_addr > 0 && slave_addr <= 247) {
            // 功能码03/04：读保持寄存器/输入寄存器
            if ((function_code == 0x03 || function_code == 0x04) && !(function_code & 0x80)) {
              uint8_t byte_count = header[2];
              // 完整长度 = 地址(1) + 功能码(1) + 字节数(1) + 数据(N) + CRC(2)
              expected_total_len = 1 + 1 + 1 + byte_count + 2;
              ESP_LOGI(RX_TASK_TAG, "✓ 检测到Modbus读响应: 从站=%d, 功能码=0x%02x, 数据长度=%d字节, 预期总长度=%zu字节",
                       slave_addr, function_code, byte_count, expected_total_len);
            }
            // 功能码06/16：写单个/多个寄存器响应
            else if (function_code == 0x06 || function_code == 0x10) {
              expected_total_len = 8;  // 固定8字节
              ESP_LOGI(RX_TASK_TAG, "✓ 检测到Modbus写响应: 预期长度=8字节");
            }
            // 错误响应（最高位为1）
            else if (function_code & 0x80) {
              expected_total_len = 5;  // 固定5字节
              ESP_LOGW(RX_TASK_TAG, "⚠ 检测到Modbus错误响应: 错误码=0x%02x, 预期长度=5字节", function_code);
            }

            // 如果能确定预期长度，等待完整数据
            if (expected_total_len > 0) {
              size_t already_read = 3;  // 已经读取了3字节
              size_t remaining = expected_total_len - already_read;

              ESP_LOGI(RX_TASK_TAG, "已读取: %zu字节, 还需等待: %zu字节", already_read, remaining);

              // 等待剩余数据，最多等待100ms（激进优化：20次×5ms=100ms）
              // 对于9600 bps，剩余62字节需要约65ms传输
              size_t current_buffered = 0;
              for (int retry = 0; retry < 20; retry++) {
                uart_get_buffered_data_len(UART_NUM_2, &current_buffered);
                if (current_buffered >= remaining) {
                  ESP_LOGI(RX_TASK_TAG, "✓ 剩余数据已到达: %zu字节 (耗时约%dms)", current_buffered, retry * 5);
                  break;
                }
                ESP_LOGD(RX_TASK_TAG, "等待剩余数据: 当前=%zu, 需要=%zu", current_buffered, remaining);
                vTaskDelay(pdMS_TO_TICKS(5));  // 从10ms降到5ms，更细粒度
              }

              // 分配完整缓冲区
              data = (uint8_t *)malloc(BUF_SIZE);
              if (data == NULL) {
                ESP_LOGE(RX_TASK_TAG, "内存分配失败");
                vTaskDelay(pdMS_TO_TICKS(10));
                continue;
              }

              // 复制前3字节
              memcpy(data, header, 3);

              // 持续读取直到获取所有数据或超时（处理数据分片问题）
              // 关键：处理数据延迟到达的情况，如60字节+5字节分片
              int total_read = 3;  // 已读取header的3字节
              int remaining_to_read = remaining;
              int consecutive_empty_reads = 0;
              const int MAX_EMPTY_READS = 50;  // 连续50次无数据则放弃 (50*5ms = 250ms)

              while (total_read < (int)expected_total_len && consecutive_empty_reads < MAX_EMPTY_READS) {
                size_t current_buffered = 0;
                uart_get_buffered_data_len(UART_NUM_2, &current_buffered);

                if (current_buffered > 0) {
                  // 读取当前缓冲区中可用的数据
                  int bytes_to_read = (current_buffered < (size_t)remaining_to_read) ? current_buffered : remaining_to_read;
                  int bytes_read = uart_read_bytes(UART_NUM_2, data + total_read, bytes_to_read, pdMS_TO_TICKS(10));

                  if (bytes_read > 0) {
                    total_read += bytes_read;
                    remaining_to_read = expected_total_len - total_read;
                    consecutive_empty_reads = 0;  // 重置空读计数
                    ESP_LOGI(RX_TASK_TAG, "✓ 累计读取: %d/%zu字节 (本次+%d)", total_read, expected_total_len, bytes_read);

                    // 如果已经读完，立即退出
                    if (total_read >= (int)expected_total_len) {
                      break;
                    }
                  } else {
                    consecutive_empty_reads++;
                  }
                } else {
                  consecutive_empty_reads++;
                }

                // 如果还没读完，等待5ms后继续尝试
                if (total_read < (int)expected_total_len) {
                  vTaskDelay(pdMS_TO_TICKS(5));
                }
              }

              int rxBytes = total_read;

              if (consecutive_empty_reads >= MAX_EMPTY_READS) {
                ESP_LOGW(RX_TASK_TAG, "⚠ 等待超时，已读取: %d/%zu字节", rxBytes, expected_total_len);
              }

              // 计算响应时间
              int64_t rx_end_time = esp_timer_get_time();
              int response_time_ms = (rx_end_time - rx_start_time) / 1000;

              // 数据完整性验证 - 关键：只处理完整的数据包
              if (rxBytes < (int)expected_total_len) {
                ESP_LOGE(RX_TASK_TAG, "❌ 数据不完整，丢弃! 实际=%d, 预期=%zu (耗时%dms)",
                         rxBytes, expected_total_len, response_time_ms);
                ESP_LOG_BUFFER_HEXDUMP(RX_TASK_TAG, data, rxBytes, ESP_LOG_WARN);

                // 释放内存并跳过处理，避免发送不完整数据
                free(data);
                data = NULL;
                continue;  // 重要：跳过本次循环，不发送不完整的数据
              }

              // 数据完整，继续处理
              ESP_LOGI(RX_TASK_TAG, "✓ 接收到完整Modbus响应 (RX处理耗时: %dms)", response_time_ms);
              ESP_LOGI(RX_TASK_TAG, "工作模式: %s, 数据长度: %d字节", work_mode, rxBytes);
              ESP_LOG_BUFFER_HEXDUMP(RX_TASK_TAG, data, rxBytes, ESP_LOG_INFO);

              // 更新buffered_size以便process_data使用正确的字节数
              buffered_size = rxBytes;

              // 跳转到数据处理部分
              goto process_data;
            }
          }

          // 如果无法识别Modbus协议，可能是数据碎片，需要验证
          ESP_LOGW(RX_TASK_TAG, "❌ 无法识别Modbus协议（从站地址=%d, 功能码=0x%02x）", slave_addr, function_code);

          // 读取剩余数据以查看完整长度
          size_t current_buffered = 0;
          uart_get_buffered_data_len(UART_NUM_2, &current_buffered);
          size_t total_len = 3 + current_buffered;

          // Modbus RTU最小有效长度为5字节（错误响应），过滤掉碎片数据
          if (total_len < 5) {
            ESP_LOGE(RX_TASK_TAG, "❌ 数据太短 (%zu字节)，疑似延迟到达的CRC碎片，丢弃!", total_len);
            // 清空缓冲区并丢弃这些碎片
            if (current_buffered > 0) {
              uint8_t discard[256];
              int discarded = uart_read_bytes(UART_NUM_2, discard, current_buffered > 256 ? 256 : current_buffered, pdMS_TO_TICKS(10));
              if (discarded > 0) {
                ESP_LOG_BUFFER_HEXDUMP(RX_TASK_TAG, header, 3, ESP_LOG_ERROR);
                ESP_LOG_BUFFER_HEXDUMP(RX_TASK_TAG, discard, discarded, ESP_LOG_ERROR);
              }
            }
            continue;  // 跳过处理，避免发送碎片数据
          }

          // 长度足够，使用通用处理流程
          ESP_LOGW(RX_TASK_TAG, "数据长度足够 (%zu字节)，使用通用处理流程", total_len);
          data = (uint8_t *)malloc(BUF_SIZE);
          if (data != NULL) {
            memcpy(data, header, 3);
            int remaining_read = uart_read_bytes(UART_NUM_2, data + 3, current_buffered, pdMS_TO_TICKS(50));
            buffered_size = 3 + (remaining_read > 0 ? remaining_read : 0);
          }
        } else {
          ESP_LOGW(RX_TASK_TAG, "无法读取Modbus头部，使用通用处理");
        }
      }

      // 第四步：通用稳定性检查（非Modbus或识别失败时）
      if (data == NULL) {
        uart_get_buffered_data_len(UART_NUM_2, &buffered_size);
        int stable_count = 0;
        size_t stable_size = buffered_size;

        // 优化：缩短循环时间以减少响应延迟
        for (int i = 0; i < 10; i++) {  // 最多再等100ms（从200ms优化）
          vTaskDelay(pdMS_TO_TICKS(10));  // 从20ms降到10ms

          size_t new_size;
          if (uart_get_buffered_data_len(UART_NUM_2, &new_size) == ESP_OK) {
            if (new_size > stable_size) {
              stable_size = new_size;
              stable_count = 0;
            } else if (new_size == stable_size) {
              stable_count++;
              if (stable_count >= 3) {  // 连续3次不变（30ms），从4次优化
                break;
              }
            }
          }
        }
        buffered_size = stable_size;
      }

      // 通用数据读取（如果data还没有被智能等待分配）
      if (data == NULL) {
        ESP_LOGI(RX_TASK_TAG, "收到数据，参数如下:");
        ESP_LOGI(RX_TASK_TAG, "工作模式: %s", work_mode);
        ESP_LOGI(RX_TASK_TAG, "数据长度: %zu 字节", buffered_size);

        data = (uint8_t *)malloc(BUF_SIZE);
        if (data == NULL) {
          ESP_LOGE(RX_TASK_TAG, "内存分配失败");
          vTaskDelay(pdMS_TO_TICKS(10));
          continue;
        }

        int rxBytes = uart_read_bytes(UART_NUM_2, data, buffered_size,
                                      10 / portTICK_PERIOD_MS);

        ESP_LOG_BUFFER_HEXDUMP(RX_TASK_TAG, data, rxBytes, ESP_LOG_INFO);
        if (rxBytes <= 0) {
          ESP_LOGW(RX_TASK_TAG, "读取数据失败");
          free(data);
          data = NULL;
          vTaskDelay(pdMS_TO_TICKS(10));
          continue;
        }

        // 更新实际读取的字节数（用于后续处理）
        buffered_size = rxBytes;
      }

process_data:
      // 数据处理入口（可能来自智能等待或通用读取）
      if (data == NULL) {
        ESP_LOGE(RX_TASK_TAG, "数据指针为NULL，跳过处理");
        continue;
      }

      int rxBytes = buffered_size;  // 实际接收的字节数
      uart_timestamps.rx_timestamp = esp_timer_get_time();

      LED_DAT_ON();

      // 使用临界区保护共享资源访问
      portENTER_CRITICAL(&uart_spinlock);
      memset(uart_response, 0, sizeof(uart_response));
      memcpy(uart_response, data, rxBytes);
      response_len = rxBytes;
      portEXIT_CRITICAL(&uart_spinlock);

      // 通过WebSocket发送数据
      send_uart_to_websocket(data, rxBytes, false);

      if (strcmp(work_mode, "mqtt_tcp") == 0) {
        nvs_handle_t nvs_handle;
        char use_mqtt[8] = {0};
        char tcpconn[8] = {0};

        if (nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle) == ESP_OK) {
          size_t size = sizeof(use_mqtt);
          if (nvs_get_str(nvs_handle, "use_mqtt", use_mqtt, &size) == ESP_OK) {
            ESP_LOGI(RX_TASK_TAG, "use_mqtt: %s", use_mqtt);
            if (strcmp(use_mqtt, "1") == 0) {
              ESP_LOGI(RX_TASK_TAG, "发送MQTT数据");
              mqtt_public_send_mqtt_tcp_data(data, rxBytes);
            }

            size = sizeof(tcpconn);
            if (nvs_get_str(nvs_handle, "tcpconn", tcpconn, &size) == ESP_OK) {
              if (strcmp(tcpconn, "0") == 0) {
                tcpserver_message((char *)data, rxBytes);
              } else if (strcmp(tcpconn, "1") == 0) {
                tcpclient_message((char *)data, rxBytes);
              }
            }
          }
          nvs_close(nvs_handle);
        }
      } else if (strcmp(work_mode, "modbus_tcp") == 0) {
        nvs_handle_t nvs_handle;
        char use_mqtt[8] = {0};
        char tcpconn[8] = {0};

         if (nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle) == ESP_OK) {
                size_t size = sizeof(use_mqtt);
                if (nvs_get_str(nvs_handle, "use_mqtt", use_mqtt, &size) == ESP_OK) {
                    // 发送原始Modbus RTU响应数据给MQTT
                    if (strcmp(use_mqtt, "1") == 0) {
                        mqtt_public_send_modbus_tcp_data(data, rxBytes);
                    }

                    size = sizeof(tcpconn);
                    if (nvs_get_str(nvs_handle, "tcpconn", tcpconn, &size) == ESP_OK) {
                        if (strcmp(tcpconn, "0") == 0) {
                            // 发送Modbus RTU响应到TCP服务器，但需要移除末尾的CRC字节
                            // Modbus RTU响应格式: [从站地址][功能码][数据长度][数据...][CRC低字节][CRC高字节]
                            int rtu_data_len = rxBytes;
                            if (rxBytes >= 3) {  // 至少有从站地址、功能码和长度字节
                                // 如果数据有效且长度足够，则去除末尾的2字节CRC
                                if (rxBytes >= 3 && data[0] == 0x01 && data[1] == 0x03) {
                                    rtu_data_len = rxBytes - 2;  // 移除CRC (2字节)
                                    ESP_LOGI(RX_TASK_TAG, "转发Modbus RTU响应到TCP服务器 (已移除CRC)，数据长度: %d", rtu_data_len);
                                    tcpserver_message((char *)data, rtu_data_len);
                                } else {
                                    ESP_LOGW(RX_TASK_TAG, "无效的Modbus响应或格式不符合预期");
                                    tcpserver_message((char *)data, rxBytes);
                                }
                            } else {
                                ESP_LOGW(RX_TASK_TAG, "Modbus响应长度异常: %d", rxBytes);
                                tcpserver_message((char *)data, rxBytes);
                            }
                        } else if (strcmp(tcpconn, "1") == 0) {
                            ESP_LOGI(RX_TASK_TAG, "转发Modbus RTU响应到TCP客户端");
                            // 为TCP客户端也应该移除CRC
                            if (rxBytes >= 3 && data[0] == 0x01 && data[1] == 0x03) {
                                int rtu_data_len = rxBytes - 2;  // 移除CRC (2字节)
                                tcpclient_message((char *)data, rtu_data_len);
                            } else {
                                tcpclient_message((char *)data, rxBytes);
                            }
                        }
                    }
                }
                nvs_close(nvs_handle);
            }
      } else if (strcmp(work_mode, "modbus_rtu") == 0) {
        if (rxBytes < 2) {
          ESP_LOGW(RX_TASK_TAG, "Modbus RTU 数据长度不足");
        } else {
          uint8_t slave_addr = data[0];
          uint8_t function_code = data[1];

          ESP_LOGI(RX_TASK_TAG, "收到Modbus RTU响应 - 从机地址: %d, 功能码: %d",
                   slave_addr, function_code);
          ESP_LOGI(RX_TASK_TAG, "当前模板索引: %d",
                   current_modbus_template_target);

          if (current_modbus_template_target >= 0) {
            nvs_handle_t nvs_handle_storage;
            if (nvs_open("storage", NVS_READWRITE, &nvs_handle_storage) ==
                ESP_OK) {
              char key[32];
              char template_slave_addr[8] = {0};
              char template_function_code[8] = {0};
              char report_format[8] = {0};
              uint8_t enabled = 0;
              size_t size;

              snprintf(key, sizeof(key), "m%d_en",
                       current_modbus_template_target);
              if (nvs_get_u8(nvs_handle_storage, key, &enabled) == ESP_OK &&
                  enabled) {
                snprintf(key, sizeof(key), "m%ds_addr",
                         current_modbus_template_target);
                size = sizeof(template_slave_addr);
                if (nvs_get_str(nvs_handle_storage, key, template_slave_addr,
                                &size) == ESP_OK) {
                  snprintf(key, sizeof(key), "m%df_code",
                           current_modbus_template_target);
                  size = sizeof(template_function_code);
                  if (nvs_get_str(nvs_handle_storage, key,
                                  template_function_code, &size) == ESP_OK) {
                    ESP_LOGI(RX_TASK_TAG, "模板配置 - 从机地址: %s, 功能码: %s",
                             template_slave_addr, template_function_code);

                    if (slave_addr == atoi(template_slave_addr) &&
                        function_code == atoi(template_function_code)) {
                      ESP_LOGI(RX_TASK_TAG, "响应匹配命令 %d",
                               current_modbus_template_target + 1);

                      snprintf(key, sizeof(key), "m%dr_fmt",
                               current_modbus_template_target);
                      size = sizeof(report_format);
                      if (nvs_get_str(nvs_handle_storage, key, report_format,
                                      &size) == ESP_OK) {
                        ESP_LOGI(RX_TASK_TAG, "准备使用 %s 格式上报数据",
                                 report_format);

                        if (strcmp(report_format, "mqtt") == 0) {
                          mqtt_public_send_device_info(
                              data, rxBytes, current_modbus_template_target);
                        } else if (strcmp(report_format, "http") == 0) {
                          http_report_data(data, rxBytes,
                                           current_modbus_template_target);
                        } else if (strcmp(report_format, "tcp") == 0) {
                          nvs_handle_t nvs_handle;
                          char tcpconn[8] = {0};

                          if (nvs_open("nvs_namespace", NVS_READWRITE,
                                       &nvs_handle) == ESP_OK) {
                            size_t size = sizeof(tcpconn);
                            if (nvs_get_str(nvs_handle, "tcpconn", tcpconn,
                                            &size) == ESP_OK) {
                              if (strcmp(tcpconn, "0") == 0) {
                                // TCP服务器模式
                                tcp_server_send_device_info(
                                    data, rxBytes,
                                    current_modbus_template_target);
                              } else if (strcmp(tcpconn, "1") == 0) {
                                // TCP客户端模式
                                tcp_client_send_device_info(
                                    data, rxBytes,
                                    current_modbus_template_target);
                              }
                            }
                            nvs_close(nvs_handle);
                          }
                        }
                      }
                    } else {
                      ESP_LOGW(
                          RX_TASK_TAG,
                          "响应不匹配命令 %d - 期望从机地址: %s, 功能码: %s",
                          current_modbus_template_target + 1,
                          template_slave_addr, template_function_code);
                    }
                  }
                }
              } else {
                ESP_LOGW(RX_TASK_TAG, "模板 %d 未启用",
                         current_modbus_template_target);
              }
              nvs_close(nvs_handle_storage);
            }
          }
        }
      }
      LED_DAT_OFF();

      // 释放主数据缓冲区
      free(data);
      data = NULL;
    }

    // 最终清理
    if (data != NULL) {
      free(data);
      data = NULL;
    }
    // 优化：减少主循环延迟以提高响应速度（从10ms降到1ms）
    vTaskDelay(pdMS_TO_TICKS(1));
  }

  ESP_LOGI(RX_TASK_TAG, "接收任务退出");
  vTaskDelete(NULL);
}

void stop_rx_task() {
  if (uartTaskHandle != NULL) {
    vTaskDelete(uartTaskHandle);
    uartTaskHandle = NULL;
  }
}

// void rx_wait() {
//   xTaskCreate(rx_task, "uart_tx_task", 2048 * 2, NULL, configMAX_PRIORITIES -
//   2,
//               &uartTaskHandle);
// }
void rx_wait() {
  // 如果任务已存在，先停止并删除
  if (uartTaskHandle != NULL) {
    TaskHandle_t temp = uartTaskHandle;
    uartTaskHandle = NULL; // 先置空，防止重入
    vTaskDelete(temp);
    vTaskDelay(pdMS_TO_TICKS(50)); // 给一些时间让任务完全清理
  }

  // 创建新任务
  BaseType_t ret =
      xTaskCreate(rx_task,
                  "uart_rx_task", // 修正任务名称（原来是 uart_tx_task）
                  2048 * 2, NULL, configMAX_PRIORITIES - 2, &uartTaskHandle);

  if (ret != pdPASS) {
    ESP_LOGE("UART", "创建接收任务失败");
    uartTaskHandle = NULL;
  } else {
    ESP_LOGI("UART", "接收任务创建成功");
  }
}
