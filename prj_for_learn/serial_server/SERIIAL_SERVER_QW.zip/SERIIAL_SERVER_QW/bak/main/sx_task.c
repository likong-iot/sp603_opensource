/*
 * @Author: Orion
 * @Date: 2024-02-03 11:29:54
 * @LastEditors: Orion
 * @LastEditTime: 2025-01-10 14:47:30
 * @FilePath: \SERIIAL_SERVER\main\sx_task.c
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */

#include "driver/gpio.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "esp_wifi.h"
#include "nvs.h"
#include "nvs_flash.h"
#include "sx_gpio.h"
#include "sx_http_client.h"
#include "sx_utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*************************************************************************************/
/*                                START OF FILE */
/*************************************************************************************/

void led_task(void *param) {
  while (1) {
    gpio_set_level(LED_DAT, 0);
    // gpio_set_level(LED0, 0);
    vTaskDelay(1000 / portTICK_PERIOD_MS);
    gpio_set_level(LED_DAT, 1);
    // gpio_set_level(LED0, 1);
    vTaskDelay(1000 / portTICK_PERIOD_MS);
  }
  vTaskDelete(NULL);
}

void key_task(void *param) {
    while (1) {
        if (gpio_get_level(KEY) == 0) {  // 按键按下
            vTaskDelay(100 / portTICK_PERIOD_MS);  // 消抖
            if ((gpio_get_level(KEY) == 0) && (KeyState == 0)) {
                KeyState = 1;
                // LED指示灯切换状态
                if (LED_DAT_STATE == 0) {
                    LED_DAT_ON();
                } else {
                    LED_DAT_OFF();
                }

                // 等待按键释放或超时
                int press_time = 0;
                while (gpio_get_level(KEY) == 0 && press_time < 300) {
                    vTaskDelay(10 / portTICK_PERIOD_MS);
                    press_time++;
                }

                if (press_time >= 300) {  // 长按超过3秒
                    printf("RESET ALL!\n");
                    ESP_ERROR_CHECK(nvs_flash_erase());
                    vTaskDelay(1000 / portTICK_PERIOD_MS);
                    esp_restart();
                } else if (gpio_get_level(KEY) == 1) {  // 短按后释放
                    printf("RESTART!\n");
                    vTaskDelay(1000 / portTICK_PERIOD_MS);
                    esp_restart();
                }
            }
        } else {
            KeyState = 0;
        }
        vTaskDelay(10 / portTICK_PERIOD_MS);
    }
    vTaskDelete(NULL);
}

void i2cRead(void *arg) {

  while (1) {
    // init_bmx();
    printf("=================================================\r\n");

    printf("=================================================\r\n");
    // bme280_getdata();
    vTaskDelay(1000 / portTICK_PERIOD_MS);
  }
  vTaskDelete(NULL);
}

void free_task(void *param) {
  // uint8_t pcWriteBuffer[500];
  while (1) {
    printf("=================================================\r\n");
    printf("\r\nremaining memory = %zu,minimum memory = %zu\r\n",
           xPortGetFreeHeapSize(), xPortGetMinimumEverFreeHeapSize());
    vTaskDelay(5000);
    // 获取自系统启动以来的时间（单位：微秒）
    int64_t time_since_boot = esp_timer_get_time();

    // 转换为天、小时、分钟
    int days = time_since_boot / (1000000LL * 60 * 60 * 24);
    int hours =
        (time_since_boot % (1000000LL * 60 * 60 * 24)) / (1000000LL * 60 * 60);
    int minutes = (time_since_boot % (1000000LL * 60 * 60)) / (1000000LL * 60);

    // 打印结果
    if (days > 0) {
      printf("Time since boot: %d days, %d hours, %d minutes\n", days, hours,
             minutes);
    } else if (hours > 0) {
      printf("Time since boot: %d hours, %d minutes\n", hours, minutes);
    } else {
      printf("Time since boot: %d minutes\n", minutes);
    }
    esp_reset_reason_t reason = esp_reset_reason();
    printf("Reset reason: %s\n", reset_reason_to_string(reason));
    printf("=================================================\r\n");
  }
  vTaskDelete(NULL);
}

void close_ap_task(void *pvParameter) {
  // 等待五分钟
  vTaskDelay(30 * 60 * 1000 / portTICK_PERIOD_MS);
  // vTaskDelay(5000);
  printf("close success\n");
  ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));

  // 关闭AP模式，保持STA连接
  // esp_wifi_set_mode(WIFI_MODE_STA);

  // 删除这个任务
  vTaskDelete(NULL);
}

/*************************************************************************************/
/*                                END OF FILE */
/*************************************************************************************/
