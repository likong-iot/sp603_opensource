/*
 * @Author: Orion
 * @Date: 2024-01-23 16:08:36
 * @LastEditors: Orion
 * @LastEditTime: 2024-10-18 11:31:53
 * @FilePath: \SERIIAL_SERVER\main\sx_tcp_server.c
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */

#include "cJSON.h"
#include "esp_event.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "esp_system.h"
#include "esp_wifi.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "lwip/err.h"
#include "lwip/sockets.h"
#include "lwip/sys.h"
#include "nvs_flash.h"
#include <lwip/netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/param.h>

// #include "sx_async_uart.h"
#include "sx_utils.h"

#define KEEPALIVE_IDLE 5
#define KEEPALIVE_INTERVAL 5
#define KEEPALIVE_COUNT 3
int global_sock = -1;

int tcp_client_count = 0;

static const char *TAG = "TCPSERVER";

/*************************************************************************************/
/*                                START OF FILE */
/*************************************************************************************/

static void do_retransmit(const int sock) {
  int len;
  char rx_buffer[512];
  do {
    len = recv(sock, rx_buffer, sizeof(rx_buffer) - 1, 0);
    if (len < 0) {
      ESP_LOGE(TAG, "Error occurred during receiving: errno %d", errno);
    } else if (len == 0) {
      ESP_LOGW(TAG, "Connection closed");
    } else {
      rx_buffer[len] = 0;
      ESP_LOGI(TAG, "!!!Received tcp %d bytes: %s", len, rx_buffer);
      // tx_task((uint8_t *)rx_buffer, len);
      printf("!!!Received tcp %d bytes: %s\n", len, rx_buffer);
    }
  } while (len > 0);
}

void tcpserver_message(char *message,int rxBytes) {
  if (global_sock != -1) {
    int to_write = rxBytes;
    while (to_write > 0) {
      int written = send(global_sock, message, to_write, 0);
      if (written < 0) {
        ESP_LOGE(TAG, "Error occurred during sending: errno %d", errno);
        return;
      }
      to_write -= written;
    }
  } else {
    ESP_LOGE(TAG, "No active socket to send message");
  }
}

static void tcp_server_task(void *pvParameters) {
  char addr_str[128];
  int addr_family = (int)pvParameters;
  int ip_protocol = 0;
  int keepAlive = 1;
  int keepIdle = KEEPALIVE_IDLE;
  int keepInterval = KEEPALIVE_INTERVAL;
  int keepCount = KEEPALIVE_COUNT;
  struct sockaddr_storage dest_addr;

  esp_err_t ret = nvs_flash_init();
  if (ret == ESP_ERR_NVS_NO_FREE_PAGES ||
      ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
    ESP_ERROR_CHECK(nvs_flash_erase());
    ret = nvs_flash_init();
  }
  ESP_ERROR_CHECK(ret);

  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));

  size_t use_tcp, tcpconn, tcp_server, tcp_port;
  ret = nvs_get_str(nvs_handle, "use_tcp", NULL, &use_tcp);
  nvs_get_str(nvs_handle, "tcpconn", NULL, &tcpconn);
  nvs_get_str(nvs_handle, "tcp_server", NULL, &tcp_server);
  nvs_get_str(nvs_handle, "tcp_port", NULL, &tcp_port);
  if (ret != ESP_OK) {
    printf("Error getting size of 'my_key': %s\n", esp_err_to_name(ret));
  } else {
    char *nvs_use_tcp = malloc(use_tcp);
    char *nvs_tcpconn = malloc(tcpconn);
    char *nvs_tcp_server = malloc(tcp_server);
    char *nvs_tcp_port = malloc(tcp_port);

    if (nvs_use_tcp == NULL || nvs_tcpconn == NULL || nvs_tcp_server == NULL ||
        nvs_tcp_port == NULL) {
      printf("Memory allocation failed\n");
      free(nvs_use_tcp);
      free(nvs_tcpconn);
      free(nvs_tcp_server);
      free(nvs_tcp_port);
    } else {
      ret = nvs_get_str(nvs_handle, "use_tcp", nvs_use_tcp, &use_tcp);
      nvs_get_str(nvs_handle, "tcpconn", nvs_tcpconn, &tcpconn);
      nvs_get_str(nvs_handle, "tcp_server", nvs_tcp_server, &tcp_server);
      nvs_get_str(nvs_handle, "tcp_port", nvs_tcp_port, &tcp_port);
      if (ret == ESP_OK) {
        if (addr_family == AF_INET) {
          struct sockaddr_in *dest_addr_ip4 = (struct sockaddr_in *)&dest_addr;
          dest_addr_ip4->sin_addr.s_addr = htonl(INADDR_ANY);
          dest_addr_ip4->sin_family = AF_INET;
          dest_addr_ip4->sin_port = htons(atoi(nvs_tcp_port));
          ip_protocol = IPPROTO_IP;
        }
        ESP_LOGI(TAG, "Socket bound, port %d", atoi(nvs_tcp_port));
      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_use_tcp);
      free(nvs_tcpconn);
      free(nvs_tcp_server);
      free(nvs_tcp_port);
    }
  }
  nvs_close(nvs_handle);

  int listen_sock = socket(addr_family, SOCK_STREAM, ip_protocol);
  if (listen_sock < 0) {
    ESP_LOGE(TAG, "Unable to create socket: errno %d", errno);
    vTaskDelete(NULL);
    return;
  }

  int opt = 1;
  setsockopt(listen_sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
  if (addr_family == AF_INET6) {
    setsockopt(listen_sock, IPPROTO_IPV6, IPV6_V6ONLY, &opt, sizeof(opt));
  }

  ESP_LOGI(TAG, "Socket created");

  int err = bind(listen_sock, (struct sockaddr *)&dest_addr, sizeof(dest_addr));
  if (err != 0) {
    ESP_LOGE(TAG, "Socket unable to bind: errno %d", errno);
    ESP_LOGE(TAG, "IPPROTO: %d", addr_family);
    goto CLEAN_UP;
  }

  err = listen(listen_sock, 1);
  if (err != 0) {
    ESP_LOGE(TAG, "Error occurred during listen: errno %d", errno);
    goto CLEAN_UP;
  }

  while (1) {
    ESP_LOGI(TAG, "Socket listening");
    struct sockaddr_storage source_addr;
    socklen_t addr_len = sizeof(source_addr);
    int sock = accept(listen_sock, (struct sockaddr *)&source_addr, &addr_len);
    if (sock < 0) {
      ESP_LOGE(TAG, "Unable to accept connection: errno %d", errno);
      break;
    }

    global_sock = sock;
    tcp_client_count++; // 客户端连接数量加1
    ESP_LOGI(TAG, "Client connected, current client count: %d",
             tcp_client_count);
    setsockopt(sock, SOL_SOCKET, SO_KEEPALIVE, &keepAlive, sizeof(int));
    setsockopt(sock, IPPROTO_TCP, TCP_KEEPIDLE, &keepIdle, sizeof(int));
    setsockopt(sock, IPPROTO_TCP, TCP_KEEPINTVL, &keepInterval, sizeof(int));
    setsockopt(sock, IPPROTO_TCP, TCP_KEEPCNT, &keepCount, sizeof(int));

    if (source_addr.ss_family == PF_INET) {
      inet_ntoa_r(((struct sockaddr_in *)&source_addr)->sin_addr, addr_str,
                  sizeof(addr_str) - 1);
    }
    ESP_LOGI(TAG, "Socket accepted ip address: %s", addr_str);

    do_retransmit(sock);

    shutdown(sock, 0);
    close(sock);
    tcp_client_count--; // 客户端断开连接，数量减1
    ESP_LOGI(TAG, "Client disconnected, current client count: %d",
             tcp_client_count);
  }

CLEAN_UP:
  close(listen_sock);
  vTaskDelete(NULL);
}

void start_tcp_server(void) {
  xTaskCreate(tcp_server_task, "tcp_server", 4096, (void *)AF_INET, 5, NULL);
}

/*************************************************************************************/
/*                                END OF FILE */
/*************************************************************************************/
