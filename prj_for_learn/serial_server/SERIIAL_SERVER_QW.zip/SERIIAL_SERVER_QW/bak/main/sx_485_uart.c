/*
 * @Author: Orion
 * @Date: 2024-10-24 17:00:21
 * @LastEditors: Orion
 * @LastEditTime: 2025-02-24 15:11:04
 * @Description:
 *
 */
#include "sx_485_uart.h"
#include "cJSON.h"
#include "driver/gpio.h"
#include "driver/uart.h"
#include "esp_log.h"
#include "esp_system.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "hal/gpio_types.h"
#include "nvs.h"
#include "nvs_flash.h"
#include "string.h"
#include "sx_gpio.h"
#include "sx_mqtt_client.h"
#include "sx_utils.h"
#include <stdio.h>
#include <stdlib.h>

#include "sx_485_http.h"
#include "sx_4g_uart.h"
#include "sx_log.h"
static const int RX_BUF_SIZE = 1024;
static const char *TAG = "SX_485_UART";

// 添加一个结构体来保存当前的发送目标
typedef struct {
  char targets[10][32]; // 最多10个目标，每个名称最长32字符
  int target_count;
} current_targets_t;

static current_targets_t current_targets = {0};

uart_stats_t uart_stats = {0};

// 添加HTTP目标结构体和管理数组
typedef struct {
  char name[32];
  char url[128];
} http_target_t;

#define MAX_HTTP_TARGETS 10
static http_target_t http_targets[MAX_HTTP_TARGETS];
static int http_target_count = 0;

TaskHandle_t uart485TaskHandle = NULL;
static TaskHandle_t uart_loop_task_handle = NULL;

void rx_485_task();
void stop_rx_485_task();

static const char *get_com_type_from_config(const cJSON *json_data) {
  if (!json_data)
    return "485"; // 默认返回485

  cJSON *params = cJSON_GetObjectItem(json_data, "params");
  if (params && cJSON_IsArray(params)) {
    cJSON *param = cJSON_GetArrayItem(params, 0);
    if (param) {
      cJSON *com_type = cJSON_GetObjectItem(param, "com_type");
      if (com_type && cJSON_IsString(com_type)) {
        return com_type->valuestring;
      }
    }
  }
  return "485"; // 如果未找到配置，默认返回485
}

void configure_485_uart(int baudrate, uart_word_length_t data_bits,
                        uart_parity_t parity, uart_stop_bits_t stop_bits,
                        int frame_time, int frame_len) {
  // 设置默认值
  if (baudrate <= 0)
    baudrate = 9600;
  if (data_bits <= 0)
    data_bits = UART_DATA_8_BITS;
  if (stop_bits <= 0)
    stop_bits = UART_STOP_BITS_1;
  // 获取当前配置
  cJSON *json_data = load_config_from_nvs();
  const char *com_type = get_com_type_from_config(json_data);

  // 根据com_type选择对应的引脚
  gpio_num_t txd_pin = strcmp(com_type, "232") == 0 ? TXD_PIN_232 : TXD_PIN_485;
  gpio_num_t rxd_pin = strcmp(com_type, "232") == 0 ? RXD_PIN_232 : RXD_PIN_485;

  // 设置校验位
  uart_parity_t uart_parity = parity;
  if (parity == 0) {
    uart_parity = UART_PARITY_DISABLE;
  } else if (parity == 1) {
    uart_parity = UART_PARITY_EVEN;
  } else if (parity == 2) {
    uart_parity = UART_PARITY_ODD;
  }

  // 设置数据位
  uart_word_length_t uart_data_bits = data_bits;
  if (data_bits == 5) {
    uart_data_bits = UART_DATA_5_BITS;
  } else if (data_bits == 6) {
    uart_data_bits = UART_DATA_6_BITS;
  } else if (data_bits == 7) {
    uart_data_bits = UART_DATA_7_BITS;
  } else if (data_bits == 8) {
    uart_data_bits = UART_DATA_8_BITS;
  }

  // 设置停止位
  uart_stop_bits_t uart_stop_bits = stop_bits;
  if (stop_bits == 1) {
    uart_stop_bits = UART_STOP_BITS_1;
  } else if (stop_bits == 1.5) {
    uart_stop_bits = UART_STOP_BITS_1_5;
  } else if (stop_bits == 2) {
    uart_stop_bits = UART_STOP_BITS_2;
  }

  // 配置UART参数
  uart_config_t uart_config = {
      .baud_rate = baudrate,
      .data_bits = uart_data_bits,
      .parity = uart_parity,
      .stop_bits = uart_stop_bits,
      .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
      .rx_flow_ctrl_thresh = 122,
      .source_clk = UART_SCLK_DEFAULT,
  };

  // 检查 UART 驱动是否已经安装
  if (!uart_is_driver_installed(UART_NUM_2)) {
    uart_driver_install(UART_NUM_2, RX_BUF_SIZE * 2, 0, 0, NULL, 0);
  }

  // 配置UART参数和引脚
  uart_param_config(UART_NUM_2, &uart_config);
  uart_set_pin(UART_NUM_2, txd_pin, rxd_pin, UART_PIN_NO_CHANGE,
               UART_PIN_NO_CHANGE);

  // 根据com_type设置UART模式
  if (strcmp(com_type, "232") == 0) {
    uart_set_mode(UART_NUM_2, UART_MODE_UART);
  } else {
    uart_set_mode(UART_NUM_2, UART_MODE_RS485_HALF_DUPLEX);
  }

  // 设置接收超时
  uart_set_rx_timeout(UART_NUM_2, ECHO_READ_TOUT);

  // 清理JSON资源
  if (json_data) {
    cJSON_Delete(json_data);
  }
}

// 定义全局统计数组
target_stats_t target_stats[MAX_TARGETS] = {0};
int target_stats_count = 0;

// 更新目标统计信息
void update_target_stats(const char *name, bool is_success, size_t bytes,
                         bool is_recv) {
  // 查找或创建目标统计记录
  int target_idx = -1;
  for (int i = 0; i < target_stats_count; i++) {
    if (strcmp(target_stats[i].name, name) == 0) {
      target_idx = i;
      break;
    }
  }

  if (target_idx == -1 && target_stats_count < MAX_TARGETS) {
    target_idx = target_stats_count++;
    strncpy(target_stats[target_idx].name, name,
            sizeof(target_stats[0].name) - 1);
  }

  if (target_idx != -1) {
    if (is_recv) {
      target_stats[target_idx].recv_frame++;
      target_stats[target_idx].recv_byte += bytes;
    } else {
      if (is_success) {
        target_stats[target_idx].send_frame_success++;
        target_stats[target_idx].send_byte_success += bytes;
      } else {
        target_stats[target_idx].send_frame_failed++;
        target_stats[target_idx].send_byte_failed += bytes;
      }
    }
  }
}

// 添加HTTP目标
bool add_http_target(const char *name, const char *url) {
  if (http_target_count >= MAX_HTTP_TARGETS) {
    ESP_LOGE(TAG, "已达到最大HTTP目标数量");
    return false;
  }

  // 检查是否存在重复
  for (int i = 0; i < http_target_count; i++) {
    if (strcmp(http_targets[i].name, name) == 0) {
      // 更新现有目标的URL
      strncpy(http_targets[i].url, url, sizeof(http_targets[i].url) - 1);
      return true;
    }
  }

  // 添加新目标
  strncpy(http_targets[http_target_count].name, name,
          sizeof(http_targets[0].name) - 1);
  strncpy(http_targets[http_target_count].url, url,
          sizeof(http_targets[0].url) - 1);
  http_target_count++;
  return true;
}

// 根据名称获取HTTP目标URL
const char *get_http_target_url(const char *name) {
  for (int i = 0; i < http_target_count; i++) {
    if (strcmp(http_targets[i].name, name) == 0) {
      return http_targets[i].url;
    }
  }
  return NULL;
}

// 清除所有HTTP目标
void clear_http_targets(void) { http_target_count = 0; }

esp_err_t http_send_data_to_target(const char *target_name,
                                   const char *hex_data) {
  const char *url = get_http_target_url(target_name);
  if (url == NULL) {
    ESP_LOGE(TAG, "未找到目标: %s", target_name);
    update_target_stats(target_name, false, strlen(hex_data) / 2,
                        false); // 使用实际字节数
    return ESP_FAIL;
  }
  esp_err_t result = http_send_data(url, hex_data, target_name);
  update_target_stats(target_name, result == ESP_OK, strlen(hex_data) / 2,
                      false); // 使用实际字节数
  return result;
}

// 向所有HTTP目标发送
void http_send_data_to_all_targets(const char *hex_data) {
  for (int i = 0; i < http_target_count; i++) {
    esp_err_t err =
        http_send_data(http_targets[i].url, hex_data, http_targets[i].name);
    if (err != ESP_OK) {
      ESP_LOGE(TAG, "发送到目标 %s 失败: %s", http_targets[i].name,
               esp_err_to_name(err));
      sx_log_write_simple("【 网关-HTTP 】 发送到目标 %s 失败: %s",
                          http_targets[i].name, esp_err_to_name(err));
    }
  }
}

void init_485_uart(void) {
  esp_err_t rets = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
  size_t baud_rate, data_bit, check_bit, stop_bit, frame_time, frame_len = 0;
  rets = nvs_get_str(nvs_handle, "baud_rate", NULL, &baud_rate);
  nvs_get_str(nvs_handle, "data_bit", NULL, &data_bit);
  nvs_get_str(nvs_handle, "check_bit", NULL, &check_bit);
  nvs_get_str(nvs_handle, "stop_bit", NULL, &stop_bit);
  nvs_get_str(nvs_handle, "frame_time", NULL, &frame_time);
  nvs_get_str(nvs_handle, "frame_len", NULL, &frame_len);

  switch (rets) {
  case ESP_OK:
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "baud_rate", "4800"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "data_bit", "8"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "check_bit", "0"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "stop_bit", "1"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "frame_time", "50"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "frame_len", "512"));
    break;
  default:
    break;
  }

  if (rets != ESP_OK) {
    printf("Error getting size of 'SERIAL': %s\n", esp_err_to_name(rets));
  } else {
    char *nvs_baud_rate = malloc(baud_rate);
    char *nvs_data_bit = malloc(data_bit);
    char *nvs_check_bit = malloc(check_bit);
    char *nvs_stop_bit = malloc(stop_bit);
    char *nvs_frame_time = malloc(frame_time);
    char *nvs_frame_len = malloc(frame_len);

    if (nvs_baud_rate == NULL || nvs_data_bit == NULL ||
        nvs_check_bit == NULL || nvs_stop_bit == NULL ||
        nvs_frame_time == NULL || nvs_frame_len == NULL) {
      printf("Memory allocation failed\n");
      free(nvs_baud_rate);
      free(nvs_data_bit);
      free(nvs_check_bit);
      free(nvs_stop_bit);
      free(nvs_frame_time);
      free(nvs_frame_len);
    } else {
      rets = nvs_get_str(nvs_handle, "baud_rate", nvs_baud_rate, &baud_rate);
      nvs_get_str(nvs_handle, "data_bit", nvs_data_bit, &data_bit);
      nvs_get_str(nvs_handle, "check_bit", nvs_check_bit, &check_bit);
      nvs_get_str(nvs_handle, "stop_bit", nvs_stop_bit, &stop_bit);
      nvs_get_str(nvs_handle, "frame_time", nvs_frame_time, &frame_time);
      nvs_get_str(nvs_handle, "frame_len", nvs_frame_len, &frame_len);

      if (rets == ESP_OK) {
        int baudrate = atoi(nvs_baud_rate);
        uart_word_length_t uart_data_bits = atoi(nvs_data_bit);
        uart_parity_t uart_parity = atoi(nvs_check_bit);
        uart_stop_bits_t uart_stop_bits = atof(nvs_stop_bit);
        int frame_time = atoi(nvs_frame_time);
        int frame_len = atoi(nvs_frame_len);

        configure_485_uart(baudrate, uart_data_bits, uart_parity,
                           uart_stop_bits, frame_time, frame_len);
      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(rets));
      }

      free(nvs_baud_rate);
      free(nvs_data_bit);
      free(nvs_check_bit);
      free(nvs_stop_bit);
      free(nvs_frame_time);
      free(nvs_frame_len);
    }
  }

  nvs_close(nvs_handle);
}

void reinit_485_uart(int baudrate, uart_word_length_t data_bits,
                     uart_parity_t parity, uart_stop_bits_t stop_bits,
                     int frame_time, int frame_len) {
  // stop_rx_485_task();
  printf("Reinit UART\n");
  printf("Baudrate: %d\n", baudrate);
  printf("Data bits: %d\n", data_bits);
  printf("Parity: %d\n", parity);
  printf("Stop bits: %d\n", stop_bits);
  // 确保释放之前的资源
  // uart_driver_delete(UART_NUM_2);

  // 重新配置 UART
  configure_485_uart(baudrate, data_bits, parity, stop_bits, frame_time,
                     frame_len);
}

void parse_com_settings(const char *com_str, int *baudrate,
                        uart_parity_t *parity, uart_word_length_t *data_bits,
                        uart_stop_bits_t *stop_bits) {
  int baud;
  char p;
  int data, stop;

  // 解析COM字符串
  if (sscanf(com_str, "%d/%c/%d/%d", &baud, &p, &data, &stop) != 4) {
    ESP_LOGE(TAG, "COM参数解析失败: %s", com_str);
    return;
  }

  ESP_LOGI(TAG, "解析COM参数: 波特率=%d, 校验位=%c, 数据位=%d, 停止位=%d", baud,
           p, data, stop);

  *baudrate = baud;

  // 解析校验位
  switch (p) {
  case 'n':
  case 'N':
    *parity = UART_PARITY_DISABLE;
    break;
  case 'e':
  case 'E':
    *parity = UART_PARITY_EVEN;
    break;
  case 'o':
  case 'O':
    *parity = UART_PARITY_ODD;
    break;
  default:
    ESP_LOGW(TAG, "未知的校验位设置: %c, 使用默认值NONE", p);
    *parity = UART_PARITY_DISABLE;
  }

  // 解析数据位 - 使用正确的枚举值
  switch (data) {
  case 5:
    *data_bits = 5; // UART_DATA_5_BITS
    break;
  case 6:
    *data_bits = 6; // UART_DATA_6_BITS
    break;
  case 7:
    *data_bits = 7; // UART_DATA_7_BITS
    break;
  case 8:
    *data_bits = 8; // UART_DATA_8_BITS
    break;
  default:
    ESP_LOGW(TAG, "未知的数据位设置: %d, 用默认值8位", data);
    *data_bits = 8; // UART_DATA_8_BITS
  }

  // 解析停止位
  switch (stop) {
  case 1:
    *stop_bits = UART_STOP_BITS_1;
    break;
  case 2:
    *stop_bits = UART_STOP_BITS_2;
    break;
  default:
    ESP_LOGW(TAG, "未知的停止位设置: %d, 使用默认值1位", stop);
    *stop_bits = UART_STOP_BITS_1;
  }

  ESP_LOGI(TAG, "COM参数解析结果: 波特率=%d, 校验位=%d, 数据位=%d, 停止位=%d",
           *baudrate, *parity, *data_bits, *stop_bits);
}

int send_485_data(char *data, size_t length) {
  const int txBytes = uart_write_bytes(UART_NUM_2, data, length);

  // 创建临时缓冲区来存储十六进制字符串
  char hex_str[length * 3 + 1]; // 每个字节需要2个字符+1个空格，最后加1个结束符
  hex_str[0] = '\0';

  // 将二进制数据转换为十六进制字符串
  for (size_t i = 0; i < length; i++) {
    char temp[4];
    snprintf(temp, sizeof(temp), "%02X ", (unsigned char)data[i]);
    strcat(hex_str, temp);
  }

  // 移除最后一个空格
  if (length > 0) {
    hex_str[strlen(hex_str) - 1] = '\0';
  }

  sx_log_write_simple("【 网关-串口 】 发送: [%s] , 字节长度: %d", hex_str,
                      length);

  if (txBytes > 0) {
    uart_stats.send_frame_success++;
    uart_stats.send_byte_success += txBytes;
  }

  blink_rx_tx_led();
  uart_wait_tx_done(UART_NUM_2, 100);

  return txBytes;
}

// 添加设置目标的函数
void set_current_targets(const char **targets, int count) {
  current_targets.target_count = 0;
  if (targets && count > 0) {
    int max_targets =
        sizeof(current_targets.targets) / sizeof(current_targets.targets[0]);
    current_targets.target_count = (count > max_targets) ? max_targets : count;
    for (int i = 0; i < current_targets.target_count; i++) {
      strncpy(current_targets.targets[i], targets[i],
              sizeof(current_targets.targets[0]) - 1);
      current_targets.targets[i][sizeof(current_targets.targets[0]) - 1] = '\0';
    }
  }
}

// 清除当前目标
void clear_current_targets(void) { current_targets.target_count = 0; }

// 修改发送函数，添加目标设置功能
void tx_485_task(uint8_t data[], size_t length) {
  static const char *TX_TASK_TAG = "TX_485_TASK";
  esp_log_level_set(TX_TASK_TAG, ESP_LOG_INFO);
  blink_rx_tx_led();
  send_485_data((char *)data, length);
  ESP_LOGI(TX_TASK_TAG, "数据已发送，等待响应");
}

// 新增一个带targets的发送函数
void tx_485_task_with_targets(uint8_t data[], size_t length,
                              const char **targets, int target_count) {
  // 设置当前的目标
  set_current_targets(targets, target_count);

  // 发送
  tx_485_task(data, length);
}

// 添加全局变量用于跟踪多命令响应
typedef struct {
  char *buffer;           // 存储拼接的响应数据
  size_t buffer_len;      // 当前缓冲区长度
  int expected_responses; // 预期的响应数量
  int received_responses; // 已接收的响应数量
} response_buffer_t;

static response_buffer_t g_response_buffer = {0};

// 初始化响应缓冲区
static void init_response_buffer(int expected_responses) {
  if (g_response_buffer.buffer) {
    free(g_response_buffer.buffer);
  }
  g_response_buffer.buffer = malloc(1024); // 初始分配1KB
  g_response_buffer.buffer_len = 0;
  g_response_buffer.expected_responses = expected_responses;
  g_response_buffer.received_responses = 0;
  if (g_response_buffer.buffer) {
    g_response_buffer.buffer[0] = '\0';
  }
}

// 清理响应缓冲区
static void cleanup_response_buffer(void) {
  if (g_response_buffer.buffer) {
    free(g_response_buffer.buffer);
    g_response_buffer.buffer = NULL;
  }
  g_response_buffer.buffer_len = 0;
  g_response_buffer.expected_responses = 0;
  g_response_buffer.received_responses = 0;
}

static int last_baudrate = 0;
static uart_parity_t last_parity = UART_PARITY_DISABLE;
static uart_word_length_t last_data_bits = UART_DATA_8_BITS;
static uart_stop_bits_t last_stop_bits = UART_STOP_BITS_1;

static void uart_loop_task(void *arg) {
  cJSON *json_data = (cJSON *)arg;
  static const char *LOOP_TASK_TAG = "UART_LOOP_TASK";
  esp_log_level_set(LOOP_TASK_TAG, ESP_LOG_INFO);

  if (!json_data) {
    ESP_LOGE(LOOP_TASK_TAG, "Invalid JSON data");
    vTaskDelete(NULL);
    return;
  }

  // 提前获取并缓存循环所需的值
  int loop_interval = 0;
  int points_interval = 0;
  int global_baudrate = 0;
  uart_parity_t global_parity = UART_PARITY_DISABLE;
  uart_word_length_t global_data_bits = UART_DATA_8_BITS;
  uart_stop_bits_t global_stop_bits = UART_STOP_BITS_1;

  // 从params数组获取全局配置
  cJSON *params = cJSON_GetObjectItem(json_data, "params");
  if (params && cJSON_IsArray(params)) {
    cJSON *param = cJSON_GetArrayItem(params, 0);
    if (param) {
      cJSON *loop = cJSON_GetObjectItem(param, "loop");
      if (loop && cJSON_IsNumber(loop)) {
        loop_interval = loop->valueint;
      }

      cJSON *interval = cJSON_GetObjectItem(param, "inteval");
      if (interval && cJSON_IsNumber(interval)) {
        points_interval = interval->valueint;
      }

      cJSON *com_type = cJSON_GetObjectItem(param, "com_type");
      cJSON *com = cJSON_GetObjectItem(param, "com");
      if (com_type && cJSON_IsString(com_type) &&
          strcmp(com_type->valuestring, "485") == 0 && com &&
          cJSON_IsString(com)) {
        parse_com_settings(com->valuestring, &global_baudrate, &global_parity,
                           &global_data_bits, &global_stop_bits);
      }
    }
  }

  ESP_LOGI(LOOP_TASK_TAG, "循环任务启动: 循环间隔=%d ms, 点间隔=%d ms",
           loop_interval, points_interval);

  while (1) {
    // 记录循环开始时间
    int64_t start_time = esp_timer_get_time();

    cJSON *points = cJSON_GetObjectItem(json_data, "points");
    if (points && cJSON_IsArray(points)) {
      int point_count = cJSON_GetArraySize(points);
      ESP_LOGI(LOOP_TASK_TAG, "开始处理 %d 个点", point_count);

      for (int i = 0; i < point_count; i++) {
        cJSON *point = cJSON_GetArrayItem(points, i);
        if (!point)
          continue;

        // 处理点级别的串口配置
        int baudrate = global_baudrate;
        uart_parity_t parity = global_parity;
        uart_word_length_t data_bits = global_data_bits;
        uart_stop_bits_t stop_bits = global_stop_bits;

        cJSON *point_com = cJSON_GetObjectItem(point, "com");
        if (point_com && cJSON_IsString(point_com)) {
          ESP_LOGI(LOOP_TASK_TAG, "应用点级别COM设置: %s",
                   point_com->valuestring);
          parse_com_settings(point_com->valuestring, &baudrate, &parity,
                             &data_bits, &stop_bits);
        }

        // 仅在参数变化时重新初始化UART
        if (baudrate != last_baudrate || parity != last_parity ||
            data_bits != last_data_bits || stop_bits != last_stop_bits) {
          reinit_485_uart(baudrate, data_bits, parity, stop_bits, 50, 512);
          last_baudrate = baudrate;
          last_parity = parity;
          last_data_bits = data_bits;
          last_stop_bits = stop_bits;
        }

        // 处理命令
        cJSON *cmds = cJSON_GetObjectItem(point, "cmds");
        if (cmds && cJSON_IsArray(cmds)) {
          int cmd_count = cJSON_GetArraySize(cmds);
          init_response_buffer(cmd_count);

          // 获取point级别的命令间隔时间
          int cmd_interval = 1000; // 默认命令间隔1秒
          cJSON *p_interval = cJSON_GetObjectItem(point, "inteval");
          if (p_interval && cJSON_IsNumber(p_interval)) {
            cmd_interval = p_interval->valueint;
          }

          // 处理目标
          cJSON *point_targets = cJSON_GetObjectItem(point, "targets");
          if (point_targets && cJSON_IsArray(point_targets)) {
            int target_count = cJSON_GetArraySize(point_targets);
            const char **target_list = malloc(sizeof(char *) * target_count);

            if (target_list) {
              ESP_LOGI(LOOP_TASK_TAG, "使用点级别目标列表，共 %d 个目标",
                       target_count);

              for (int k = 0; k < target_count; k++) {
                cJSON *target = cJSON_GetArrayItem(point_targets, k);
                if (cJSON_IsString(target)) {
                  target_list[k] = target->valuestring;
                  ESP_LOGI(LOOP_TASK_TAG, "目标 %d: %s", k + 1, target_list[k]);
                }
              }

              // 处理每个命令
              cJSON *cmd;
              int cmd_index = 0;
              cJSON_ArrayForEach(cmd, cmds) {
                if (!cJSON_IsString(cmd))
                  continue;

                // 解析并发送命令
                size_t length = strlen(cmd->valuestring) / 2;
                uint8_t *data = malloc(length);
                if (!data) {
                  ESP_LOGE(LOOP_TASK_TAG, "命令数据内存分配失败");
                  continue;
                }

                // 转换十六进制字符串到字节数组
                for (size_t j = 0; j < length; j++) {
                  sscanf(&cmd->valuestring[j * 2], "%2hhx", &data[j]);
                }
                ESP_LOGI(LOOP_TASK_TAG, "发送命令: %s", cmd->valuestring);

                tx_485_task_with_targets(data, length, target_list,
                                         target_count);
                free(data);

                // 命令间延时
                cmd_index++;
                if (cmd_index < cmd_count) {
                  ESP_LOGI(LOOP_TASK_TAG, "等待命令间隔: %d ms", cmd_interval);
                  vTaskDelay(pdMS_TO_TICKS(cmd_interval));
                }

                // 检查任务状态
                if (uart_loop_task_handle == NULL) {
                  ESP_LOGI(LOOP_TASK_TAG,
                           "Task stop requested during command execution");
                  free(target_list);
                  cJSON_Delete(json_data);
                  vTaskDelete(NULL);
                  return;
                }
              }
              free(target_list);
            }
          } else {
            // 使用全局目标
            cJSON *global_targets = cJSON_GetObjectItem(json_data, "targets");
            if (global_targets && cJSON_IsArray(global_targets)) {
              int target_count = cJSON_GetArraySize(global_targets);
              const char **target_list = malloc(sizeof(char *) * target_count);

              if (target_list) {
                int valid_target_count = 0;
                ESP_LOGI(LOOP_TASK_TAG, "使用全局目标列表");

                cJSON *target;
                cJSON_ArrayForEach(target, global_targets) {
                  cJSON *name = cJSON_GetObjectItem(target, "name");
                  if (name && cJSON_IsString(name)) {
                    target_list[valid_target_count] = name->valuestring;
                    ESP_LOGI(LOOP_TASK_TAG, "全局目标 %d: %s",
                             valid_target_count + 1,
                             target_list[valid_target_count]);
                    valid_target_count++;
                  }
                }

                // 处理每个命令
                cJSON *cmd;
                int cmd_index = 0;
                cJSON_ArrayForEach(cmd, cmds) {
                  if (!cJSON_IsString(cmd))
                    continue;

                  size_t length = strlen(cmd->valuestring) / 2;
                  uint8_t *data = malloc(length);
                  if (!data) {
                    ESP_LOGE(LOOP_TASK_TAG, "命令数据内存分配失败");
                    continue;
                  }

                  for (size_t j = 0; j < length; j++) {
                    sscanf(&cmd->valuestring[j * 2], "%2hhx", &data[j]);
                  }
                  ESP_LOGI(LOOP_TASK_TAG, "发送命令: %s", cmd->valuestring);

                  if (valid_target_count > 0) {
                    tx_485_task_with_targets(data, length, target_list,
                                             valid_target_count);
                  } else {
                    tx_485_task(data, length);
                  }
                  free(data);

                  // 命令间延时
                  cmd_index++;
                  if (cmd_index < cmd_count) {
                    ESP_LOGI(LOOP_TASK_TAG, "等待命令间隔: %d ms",
                             cmd_interval);
                    vTaskDelay(pdMS_TO_TICKS(cmd_interval));
                  }

                  if (uart_loop_task_handle == NULL) {
                    ESP_LOGI(LOOP_TASK_TAG, "Task stop requested");
                    free(target_list);
                    cJSON_Delete(json_data);
                    vTaskDelete(NULL);
                    return;
                  }
                }
                free(target_list);
              }
            } else {
              // 没有目标配置，使用默认发送
              cJSON *cmd;
              int cmd_index = 0;
              cJSON_ArrayForEach(cmd, cmds) {
                if (!cJSON_IsString(cmd))
                  continue;

                size_t length = strlen(cmd->valuestring) / 2;
                uint8_t *data = malloc(length);
                if (!data) {
                  ESP_LOGE(LOOP_TASK_TAG, "命令数据内存分配失败");
                  continue;
                }

                for (size_t j = 0; j < length; j++) {
                  sscanf(&cmd->valuestring[j * 2], "%2hhx", &data[j]);
                }
                ESP_LOGI(LOOP_TASK_TAG, "发送命令: %s", cmd->valuestring);

                tx_485_task(data, length);
                free(data);

                // 命令间延时
                cmd_index++;
                if (cmd_index < cmd_count) {
                  ESP_LOGI(LOOP_TASK_TAG, "等待命令间隔: %d ms", cmd_interval);
                  vTaskDelay(pdMS_TO_TICKS(cmd_interval));
                }

                if (uart_loop_task_handle == NULL) {
                  ESP_LOGI(LOOP_TASK_TAG, "Task stop requested");
                  cJSON_Delete(json_data);
                  vTaskDelete(NULL);
                  return;
                }
              }
            }
          }
        }

        // point间延时
        if (i < point_count - 1) {
          ESP_LOGI(LOOP_TASK_TAG, "等待点间隔: %d ms", points_interval);
          vTaskDelay(pdMS_TO_TICKS(points_interval));
        }
      }
    }

    // 计算实际执行时间并调整延时
    int64_t end_time = esp_timer_get_time();
    int64_t elapsed_time = (end_time - start_time) / 1000; // 转换为毫秒
    int64_t delay_time = loop_interval - elapsed_time;
    if (delay_time > 0) {
      ESP_LOGI(LOOP_TASK_TAG, "完成一轮循环，等待下一轮: %lld ms", delay_time);
      vTaskDelay(pdMS_TO_TICKS(delay_time));
    }

    // 检查任务状态
    if (uart_loop_task_handle == NULL) {
      ESP_LOGI(LOOP_TASK_TAG, "Task stop requested after points processing");
      break;
    }
  }

  // 清理资源
  cJSON_Delete(json_data);
  ESP_LOGI(LOOP_TASK_TAG, "Task cleanup complete");
  vTaskDelete(NULL);
}

void stop_uart_loop_task(void) {
  if (uart_loop_task_handle != NULL) {
    vTaskDelete(uart_loop_task_handle);
    uart_loop_task_handle = NULL;
  }
}

void start_uart_loop_task(const cJSON *json_data) {
  cJSON *saved_config = NULL; // 添加声明

  if (json_data == NULL) {
    // 尝试从NVS加载配置
    saved_config = load_config_from_nvs();
    if (saved_config == NULL) {
      ESP_LOGE(TAG, "无效的JSON数据且无法从NVS加载配置");
      return;
    }
    json_data = saved_config;
  }

  ESP_LOGE(TAG, "进入LOOP");

  // 停止现有任务
  stop_uart_loop_task();

  // 创建JSON副本
  cJSON *json_copy = cJSON_Duplicate(json_data, 1);
  if (json_copy == NULL) {
    ESP_LOGE(TAG, "JSON复制失败");
    if (saved_config != NULL) {
      cJSON_Delete(saved_config); // 清理从NVS加载的JSON
    }
    return;
  }

  // 检查并启动rx_485_task任务（如果尚未启动）
  if (uart485TaskHandle == NULL) {
    rx_485_task();
  }

  BaseType_t ret = xTaskCreate(uart_loop_task, "uart_loop_task",
                               8192, // 增加栈大小
                               (void *)json_copy, 5, &uart_loop_task_handle);
  if (ret != pdPASS) {
    ESP_LOGE(TAG, "任务创建失败");
    cJSON_Delete(json_copy);
    uart_loop_task_handle = NULL;
  }

  // 如果是从NVS加载的配置，需要清理
  if (saved_config != NULL) {
    cJSON_Delete(saved_config);
  }
}

// 获取目标的URL
const char *get_target_url_by_name(const cJSON *json_data,
                                   const char *target_name) {
  cJSON *targets = cJSON_GetObjectItem(json_data, "targets");
  if (targets && cJSON_IsArray(targets)) {
    cJSON *target;
    cJSON_ArrayForEach(target, targets) {
      cJSON *name = cJSON_GetObjectItem(target, "name");
      cJSON *url = cJSON_GetObjectItem(target, "url");
      if (name && url && cJSON_IsString(name) && cJSON_IsString(url)) {
        if (strcmp(name->valuestring, target_name) == 0) {
          return url->valuestring;
        }
      }
    }
  }
  return NULL;
}

// 辅助函数发送到指定目标
static void send_data_to_target(const char *target_name, const char *target_url,
                                const char *data, cJSON *json_data) {
  static const char *RX_TASK_TAG = "RX_485_TASK";
  ESP_LOGI(RX_TASK_TAG, "发送到目标: %s, URL: %s", target_name, target_url);
  if (is_http_target(target_url)) {
    ESP_LOGI(RX_TASK_TAG, "发送到HTTP目标: %s", target_name);
    esp_err_t err = http_send_data_to_target(target_name, data);
    if (err != ESP_OK) {
      ESP_LOGE(RX_TASK_TAG, "HTTP发送失败: %s", esp_err_to_name(err));
    }
  } else {
    ESP_LOGI(RX_TASK_TAG, "发送到MQTT目标: %s", target_name);
    mqtt_send_message_by_name(target_name, data, strlen(data));
  }
}

// 发送到所有配置的目标
static void send_data_to_all_targets(const char *data, cJSON *json_data) {
  static const char *RX_TASK_TAG = "RX_485_TASK";
  cJSON *targets = cJSON_GetObjectItem(json_data, "targets");
  if (!targets || !cJSON_IsArray(targets)) {
    ESP_LOGE(RX_TASK_TAG, "配置中未找到targets数组");
    return;
  }

  cJSON *target;
  cJSON_ArrayForEach(target, targets) {
    cJSON *name = cJSON_GetObjectItem(target, "name");
    cJSON *url = cJSON_GetObjectItem(target, "url");
    if (name && url && cJSON_IsString(name) && cJSON_IsString(url)) {
      send_data_to_target(name->valuestring, url->valuestring, data, json_data);
    }
  }
}

static void rx_485_receive(void *arg) {
  static const char *RX_TASK_TAG = "RX_485_TASK";
  esp_log_level_set(RX_TASK_TAG, ESP_LOG_INFO);
  uint8_t *data = (uint8_t *)malloc(RX_BUF_SIZE + 1);
  char *hex_str = (char *)malloc(RX_BUF_SIZE * 2 + 1);

  // 从 NVS 加载配置
  cJSON *json_data = load_config_from_nvs();
  if (json_data == NULL) {
    ESP_LOGE(RX_TASK_TAG, "无法从 NVS 加载配置");
    free(data);
    free(hex_str);
    vTaskDelete(NULL);
    return;
  }

  // 读取 netconn 值
  nvs_handle_t nvs_handle;
  size_t netconn_size = 0;
  char *nvs_netconn = NULL;
  if (nvs_open("nvs_namespace", NVS_READONLY, &nvs_handle) == ESP_OK) {
    if (nvs_get_str(nvs_handle, "netconn", NULL, &netconn_size) == ESP_OK) {
      nvs_netconn = malloc(netconn_size);
      if (nvs_netconn) {
        nvs_get_str(nvs_handle, "netconn", nvs_netconn, &netconn_size);
      }
    }
    nvs_close(nvs_handle);
  }

  while (1) {
    if (data == NULL || hex_str == NULL) {
      ESP_LOGE(RX_TASK_TAG, "内存分配失败");
      free(data);
      free(hex_str);
      if (json_data) {
        cJSON_Delete(json_data);
      }
      if (nvs_netconn) {
        free(nvs_netconn);
      }
      vTaskDelete(NULL);
      return;
    }

    if (uart485TaskHandle == NULL) {
      break;
    }

    const int rxBytes = uart_read_bytes(UART_NUM_2, data, RX_BUF_SIZE,
                                        100 / portTICK_PERIOD_MS);
    if (rxBytes > 0) {
      uart_stats.recv_frame_success++;
      uart_stats.recv_byte_success += rxBytes;
      // if (current_targets.target_count > 0) {
      //   for (int i = 0; i < current_targets.target_count; i++) {
      //     update_target_stats(current_targets.targets[i], true, rxBytes,
      //     true);
      //   }
      // }

      blink_rx_tx_led();
      data[rxBytes] = 0;
      ESP_LOGI(RX_TASK_TAG, "Read %d bytes", rxBytes);
      // ESP_LOG_BUFFER_HEXDUMP(RX_TASK_TAG, data, rxBytes, ESP_LOG_INFO);

      // 将接收到的数据转换为十六进制字符串，字节间添加空格
      memset(hex_str, 0, RX_BUF_SIZE * 2 + 1);
      // hex_str[0] = '['; // 添加开始的方括号
      // int pos = 1;
      // for (int i = 0; i < rxBytes; i++) {
      //     if (i > 0) {
      //         hex_str[pos++] = ' '; // 在字节之间添加空格
      //     }
      //     sprintf(hex_str + pos, "%02X", data[i]);
      //     pos += 2;
      // }
      // hex_str[pos++] = ']'; // 添加结束的方括号
      // hex_str[pos] = '\0';  // 确保字符串正确终止
      for (int i = 0; i < rxBytes; i++) {
        sprintf(hex_str + (i * 2), "%02X", data[i]);
      }

      sx_log_write_simple("【 串口-网关 】收到: %s，字节长度：%d ", hex_str,
                          rxBytes);

      if (g_response_buffer.expected_responses > 0) {
        // 处理多响应模式
        if (g_response_buffer.buffer_len + strlen(hex_str) + 1 < 1024) {
          if (g_response_buffer.buffer_len > 0) {
            strcat(g_response_buffer.buffer, "");
            g_response_buffer.buffer_len++;
          }
          strcat(g_response_buffer.buffer, hex_str);
          g_response_buffer.buffer_len += strlen(hex_str);
        }

        g_response_buffer.received_responses++;

        if (g_response_buffer.received_responses >=
            g_response_buffer.expected_responses) {
          if (current_targets.target_count > 0) {
            if (nvs_netconn && atoi(nvs_netconn) == 3) {
              // 4G模式处理
              for (int i = 0; i < current_targets.target_count; i++) {
                const char *target_name = current_targets.targets[i];
                const char *target_url =
                    get_target_url_by_name(json_data, target_name);

                if (target_url) {
                  cJSON *response = cJSON_CreateObject();
                  cJSON_AddStringToObject(response, "target", target_name);
                  cJSON_AddStringToObject(response, "target_url", target_url);
                  cJSON_AddStringToObject(response, "data",
                                          g_response_buffer.buffer);

                  char *json_str = cJSON_PrintUnformatted(response);
                  if (json_str) {
                    ESP_LOGI(RX_TASK_TAG, "发送4G数据: target=%s, url=%s",
                             target_name, target_url);
                    send4gData(RX_TASK_TAG, json_str);
                    free(json_str);
                  }
                  cJSON_Delete(response);
                } else {
                  ESP_LOGE(RX_TASK_TAG, "未找到目标URL: %s", target_name);
                }
              }
            } else {
              // 发送到指定的目标
              for (int i = 0; i < current_targets.target_count; i++) {
                const char *target_name = current_targets.targets[i];
                const char *target_url =
                    get_target_url_by_name(json_data, target_name);
                if (target_url) {
                  send_data_to_target(target_name, target_url,
                                      g_response_buffer.buffer, json_data);
                }
              }
            }
          } else {
            // 发送到所有目标
            ESP_LOGI(RX_TASK_TAG, "没有指定targets，发送到所有目标");
            send_data_to_all_targets(g_response_buffer.buffer, json_data);
          }
          cleanup_response_buffer();
        }
      } else {
        // 处理单响应模式
        if (current_targets.target_count > 0) {
          if (nvs_netconn && atoi(nvs_netconn) == 3) {
            // 4G模式处理
            for (int i = 0; i < current_targets.target_count; i++) {
              const char *target_name = current_targets.targets[i];
              const char *target_url =
                  get_target_url_by_name(json_data, target_name);

              if (target_url) {
                cJSON *response = cJSON_CreateObject();
                cJSON_AddStringToObject(response, "target", target_name);
                cJSON_AddStringToObject(response, "target_url", target_url);
                cJSON_AddStringToObject(response, "data", hex_str);

                char *json_str = cJSON_PrintUnformatted(response);
                if (json_str) {
                  ESP_LOGI(RX_TASK_TAG, "发送4G数据: target=%s, url=%s",
                           target_name, target_url);
                  send4gData(RX_TASK_TAG, json_str);
                  free(json_str);
                }
                cJSON_Delete(response);
              } else {
                ESP_LOGE(RX_TASK_TAG, "未找到目标URL: %s", target_name);
              }
            }
          } else {
            // 发送到指定的目标
            for (int i = 0; i < current_targets.target_count; i++) {
              const char *target_name = current_targets.targets[i];
              const char *target_url =
                  get_target_url_by_name(json_data, target_name);
              if (target_url) {
                send_data_to_target(target_name, target_url, hex_str,
                                    json_data);
              }
            }
          }
        } else {
          // 发送到所有目标
          ESP_LOGI(RX_TASK_TAG, "没有指定targets，发送到所有目标");
          send_data_to_all_targets(hex_str, json_data);
        }
      }
    }
  }

  // 清理资源
  cleanup_response_buffer();
  free(hex_str);
  free(data);
  if (nvs_netconn) {
    free(nvs_netconn);
  }
  if (json_data) {
    cJSON_Delete(json_data);
  }
  ESP_LOGI(RX_TASK_TAG, "RX任务结束");
  vTaskDelete(NULL);
}

void stop_rx_485_task() {
  if (uart485TaskHandle != NULL) {
    vTaskDelete(uart485TaskHandle);
    uart485TaskHandle = NULL;
  }
}

void rx_485_task() {
  if (uart485TaskHandle != NULL) {
    vTaskDelete(uart485TaskHandle);
    uart485TaskHandle = NULL;
  }
  ESP_LOGE("RX_485_TASK", "命中RX任务");

  xTaskCreate(rx_485_receive, "rx_485_task", 8192, NULL,
              configMAX_PRIORITIES - 2, &uart485TaskHandle);
}
