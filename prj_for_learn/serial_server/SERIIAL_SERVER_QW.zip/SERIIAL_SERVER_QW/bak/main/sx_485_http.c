
#include "cJSON.h"
#include "esp_event.h"
#include "esp_http_client.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "esp_system.h"
#include "esp_timer.h"
#include "esp_tls.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "math.h"
#include "nvs.h"
#include "nvs_flash.h"
#include "sx_utils.h"

#include "sx_gpio.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/param.h>
#include "sx_log.h"
#define MAX_HTTP_RECV_BUFFER 1024
#define MAX_HTTP_OUTPUT_BUFFER 2048
static const char *TAG = "HTTP_485";

// HTTP事件处理函数
esp_err_t _http_event_handlers(esp_http_client_event_t *evt) {
  switch (evt->event_id) {
  case HTTP_EVENT_ERROR:
    ESP_LOGE(TAG, "HTTP_EVENT_ERROR");
    break;
  case HTTP_EVENT_ON_CONNECTED:
    ESP_LOGI(TAG, "HTTP_EVENT_ON_CONNECTED");
    break;
  case HTTP_EVENT_HEADERS_SENT:
    ESP_LOGI(TAG, "HTTP_EVENT_HEADERS_SENT");
    break;
  case HTTP_EVENT_ON_HEADER:
    ESP_LOGI(TAG, "HTTP_EVENT_ON_HEADER, key=%s, value=%s", evt->header_key,
             evt->header_value);
    break;
  case HTTP_EVENT_ON_DATA:
    if (!esp_http_client_is_chunked_response(evt->client)) {
      ESP_LOGI(TAG, "HTTP_EVENT_ON_DATA, len=%d", evt->data_len);
    }
    break;
  case HTTP_EVENT_ON_FINISH:
    ESP_LOGI(TAG, "HTTP_EVENT_ON_FINISH");
    break;
  case HTTP_EVENT_DISCONNECTED:
    ESP_LOGI(TAG, "HTTP_EVENT_DISCONNECTED");
    break;
  default:
    break;
  }
  return ESP_OK;
}

esp_err_t http_send_data(const char *url, const char *hex_data, const char *target_name) {
    static const char *TAG = "HTTP_CLIENT";

    // 将十六进制字符串转换为二进制数据
    size_t data_len = strlen(hex_data) / 2;
    uint8_t *binary_data = malloc(data_len);
    if (binary_data == NULL) {
        ESP_LOGE(TAG, "内存分配失败");
        return ESP_FAIL;
    }

    // 转换为二进制数据
    for (size_t i = 0; i < data_len; i++) {
        sscanf(&hex_data[i * 2], "%2hhx", &binary_data[i]);
    }

    esp_http_client_config_t config = {
        .url = url,
        .method = HTTP_METHOD_POST,
        .event_handler = _http_event_handlers,
        .timeout_ms = 5000,
        .disable_auto_redirect = true,
    };

    esp_http_client_handle_t client = esp_http_client_init(&config);
    if (client == NULL) {
        ESP_LOGE(TAG, "HTTP client init failed");
        free(binary_data);
        return ESP_FAIL;
    }

    esp_http_client_set_header(client, "Content-Type", "application/octet-stream");

    esp_err_t err = esp_http_client_set_post_field(client, (const char *)binary_data, data_len);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Failed to set post field: %s", esp_err_to_name(err));
        free(binary_data);
        esp_http_client_cleanup(client);
        return err;
    } else {
        ESP_LOGI(TAG, "HTTP POST request data (HEX):");
        for(size_t i = 0; i < data_len; i++) {
            printf("%02X ", binary_data[i]);
        }
        printf("\n");
        blink_net_led();
    }

    // 执行HTTP请求
    err = esp_http_client_perform(client);
    if (err == ESP_OK) {
        int status_code = esp_http_client_get_status_code(client);
        ESP_LOGI(TAG, "HTTP POST Status = %d", status_code);

        // 创建带空格的十六进制字符串
        char *formatted_hex = malloc(strlen(hex_data) + 1); // 保持原始长度，最后加结束符
        if (formatted_hex != NULL) {
            // 直接复制原始字符串，保持原有格式
            memcpy(formatted_hex, hex_data, strlen(hex_data));
            formatted_hex[strlen(hex_data)] = '\0';

            sx_log_write_simple("【网关-HTTP】(%s) 发送: [%s], 字节长度: %d",
                              target_name, formatted_hex, data_len);

            free(formatted_hex);
        } else {
            sx_log_write_simple("【网关-HTTP】(%s) 发送: [%s], 字节长度: %d",
                              target_name, hex_data, data_len);
        }
    } else {
        ESP_LOGE(TAG, "HTTP POST request failed: %s", esp_err_to_name(err));
        sx_log_write_simple("【网关-HTTP】(%s) 发送失败: %s",
                          target_name, esp_err_to_name(err));
    }

    // 清理资源
    free(binary_data);
    esp_http_client_cleanup(client);
    return err;
}

// 判断目标类型的辅助函数
bool is_http_target(const char *url) { return strncmp(url, "http://", 7) == 0; }
