/*
 * @Author: Orion
 * @Date: 2024-02-20 15:58:29
 * @LastEditors: Orion
 * @LastEditTime: 2025-01-11 11:14:57
 * @FilePath: \SERIIAL_SERVER_P\main\sx_init_wifi.c
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */

#include "esp_err.h"
#include "esp_event.h"
#include "esp_log.h"
#include "esp_system.h"
#include "esp_wifi.h"
#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"
#include "freertos/task.h"
#include "nvs_flash.h"
#include "sx_http_client.h"
#include "sx_udp_server.h"
#include "sx_web_server.h"
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sx_utils.h>
#include "sx_gpio.h"

// #define EXAMPLE_WIFI_SSID "Xiaomi_LIKONG"
// #define EXAMPLE_WIFI_PASS "GY18392501558"
#define EXAMPLE_MAXIMUM_RETRY 86400

#ifdef CONFIG_EXAMPLE_STATIC_DNS_AUTO
#define EXAMPLE_MAIN_DNS_SERVER EXAMPLE_STATIC_GW_ADDR
#define EXAMPLE_BACKUP_DNS_SERVER "0.0.0.0"
#else
#define EXAMPLE_MAIN_DNS_SERVER "8.8.8.8"
#define EXAMPLE_BACKUP_DNS_SERVER "114.114.114.114"
#endif
#ifdef CONFIG_EXAMPLE_STATIC_DNS_RESOLVE_TEST
#define EXAMPLE_RESOLVE_DOMAIN CONFIG_EXAMPLE_STATIC_RESOLVE_DOMAIN
#endif

static EventGroupHandle_t s_wifi_event_group;

#define WIFI_CONNECTED_BIT BIT0
#define WIFI_FAIL_BIT BIT1

static const char *TAG = "static_ip";

static int s_retry_num = 0;

typedef struct {
  char ssid[32];
  char password[64];
} wifi_credentials_t;

int is_netif_initialized = 0;
/*************************************************************************************/
/*                                START OF FILE */
/*************************************************************************************/

static esp_err_t example_set_dns_server(esp_netif_t *netif, uint32_t addr,
                                        esp_netif_dns_type_t type) {
  if (addr && (addr != IPADDR_NONE)) {
    esp_netif_dns_info_t dns;
    dns.ip.u_addr.ip4.addr = addr;
    dns.ip.type = IPADDR_TYPE_V4;
    ESP_ERROR_CHECK(esp_netif_set_dns_info(netif, type, &dns));
  }
  return ESP_OK;
}

static void example_set_static_ip(esp_netif_t *netif) {
  esp_err_t ret = nvs_flash_init();
  if (ret == ESP_ERR_NVS_NO_FREE_PAGES ||
      ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
    ESP_ERROR_CHECK(nvs_flash_erase());
    ret = nvs_flash_init();
  }
  ESP_ERROR_CHECK(ret);
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
  size_t netconn, is_dhcp, static_ip, static_netmask, static_gateway, static_dns1, static_dns2, wifi_ssid,
      wifi_password = 0;
  ret = nvs_get_str(nvs_handle, "netconn", NULL, &netconn);
  nvs_get_str(nvs_handle, "is_dhcp", NULL, &is_dhcp);
  nvs_get_str(nvs_handle, "static_ip", NULL, &static_ip);
  nvs_get_str(nvs_handle, "static_netmask", NULL, &static_netmask);
  nvs_get_str(nvs_handle, "static_gateway", NULL, &static_gateway);
  nvs_get_str(nvs_handle, "static_dns1", NULL, &static_dns1);
  nvs_get_str(nvs_handle, "static_dns2", NULL, &static_dns2);
  nvs_get_str(nvs_handle, "wifi_ssid", NULL, &wifi_ssid);
  nvs_get_str(nvs_handle, "wifi_password", NULL, &wifi_password);
  switch (ret) {
  case ESP_OK:
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "netconn", "1"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "is_dhcp", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "static_ip", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "static_netmask", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "static_gateway", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "wifi_ssid", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "wifi_password", ""));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'netconn': %s\n", esp_err_to_name(ret));
  } else {
    char *nvs_netconn = malloc(netconn);
    char *nvs_is_dhcp = malloc(is_dhcp);
    char *nvs_static_ip = malloc(static_ip);
    char *nvs_static_netmask = malloc(static_netmask);
    char *nvs_static_gateway = malloc(static_gateway);
    char *nvs_static_dns1 = malloc(static_dns1);
    char *nvs_static_dns2 = malloc(static_dns2);
    char *nvs_wifi_ssid = malloc(wifi_ssid);
    char *nvs_wifi_password = malloc(wifi_password);
    if (nvs_netconn == NULL) {
      printf("Memory allocation failed\n");
    } else {
      ret = nvs_get_str(nvs_handle, "netconn", nvs_netconn, &netconn);
      nvs_get_str(nvs_handle, "is_dhcp", nvs_is_dhcp, &is_dhcp);
      nvs_get_str(nvs_handle, "static_ip", nvs_static_ip, &static_ip);
      nvs_get_str(nvs_handle, "static_netmask", nvs_static_netmask,
                  &static_netmask);
      nvs_get_str(nvs_handle, "static_dns1", nvs_static_dns1, &static_dns1);
      nvs_get_str(nvs_handle, "static_dns2", nvs_static_dns2, &static_dns2);
      nvs_get_str(nvs_handle, "static_gateway", nvs_static_gateway,
                  &static_gateway);
      nvs_get_str(nvs_handle, "wifi_ssid", nvs_wifi_ssid, &wifi_ssid);
      nvs_get_str(nvs_handle, "wifi_password", nvs_wifi_password,
                  &wifi_password);
      if (ret == ESP_OK) {
        if (atoi(nvs_is_dhcp) == 2) {
          if (strlen(nvs_wifi_ssid) == 0 || strlen(nvs_wifi_password) == 0) {
            printf("wifi_ssid or wifi_password is empty\n");
            return;
          }
          if (esp_netif_dhcpc_stop(netif) != ESP_OK) {
            ESP_LOGE(TAG, "Failed to stop dhcp client");
            return;
          }
          esp_netif_ip_info_t ip;
          memset(&ip, 0, sizeof(esp_netif_ip_info_t));
          ip.ip.addr = ipaddr_addr(nvs_static_ip);
          ip.netmask.addr = ipaddr_addr(nvs_static_netmask);
          ip.gw.addr = ipaddr_addr(nvs_static_gateway);
          if (esp_netif_set_ip_info(netif, &ip) != ESP_OK) {
            ESP_LOGE(TAG, "Failed to set ip info");
            return;
          }
          ESP_LOGD(TAG, "Success to set static ip: %s, netmask: %s, gw: %s",
                   got_ip_addrs, got_ip_netmask, got_ip_gw);
          ESP_ERROR_CHECK(example_set_dns_server(
              netif, ipaddr_addr(nvs_static_dns1), ESP_NETIF_DNS_MAIN));
          ESP_ERROR_CHECK(example_set_dns_server(
              netif, ipaddr_addr(nvs_static_dns2), ESP_NETIF_DNS_BACKUP));
        } else {
          printf("sta dhcp start\n");
        }
      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_netconn);
      free(nvs_is_dhcp);
      free(nvs_static_ip);
      free(nvs_static_netmask);
      free(nvs_static_gateway);
      free(nvs_static_dns1);
      free(nvs_static_dns2);
      free(nvs_wifi_ssid);
      free(nvs_wifi_password);
    }
  }

  nvs_close(nvs_handle);
}

static void event_handler(void *arg, esp_event_base_t event_base,
                          int32_t event_id, void *event_data) {
  esp_err_t ret = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
  size_t wifi_flag = 0;
  ret = nvs_get_str(nvs_handle, "wifi_flag", NULL, &wifi_flag);
  switch (ret) {
  case ESP_OK:
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "wifi_flag", "0"));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'UDP': %s\n", esp_err_to_name(ret));
  } else {
    char *nvs_wifi_flag = malloc(wifi_flag);
    if (nvs_wifi_flag == NULL) {
      printf("nvs_wifi_flag Memory allocation failed\n");
    } else {
      ret = nvs_get_str(nvs_handle, "wifi_flag", nvs_wifi_flag, &wifi_flag);
      if (ret == ESP_OK) {

        if (atoi(nvs_wifi_flag) == 1) {
          if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_START) {
            esp_wifi_connect();
          } else if (event_base == WIFI_EVENT &&
                     event_id == WIFI_EVENT_STA_CONNECTED) {
            example_set_static_ip(arg);
          } else if (event_base == WIFI_EVENT &&
                     event_id == WIFI_EVENT_STA_DISCONNECTED) {
            kill_udp_server();
            turn_on_gpio(LEDWIFI,0);

            ESP_LOGI(TAG, "connect to the AP fail");
          } else if (event_base == IP_EVENT &&
                     event_id == IP_EVENT_STA_GOT_IP) {
            if (atoi(nvs_wifi_flag) == 1) {
              ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "wifi_flag", "0"));
              esp_restart();
            }
            ip_event_got_ip_t *event = (ip_event_got_ip_t *)event_data;
            ESP_LOGI(TAG, "static ip:" IPSTR, IP2STR(&event->ip_info.ip));
            s_retry_num = 0;
            inet_ntoa_r(event->ip_info.ip, got_ip_addrs, 16);
            inet_ntoa_r(event->ip_info.netmask, got_ip_netmask, 16);
            inet_ntoa_r(event->ip_info.gw, got_ip_gw, 16);
            // ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "wifi_flag", "0"));
            xEventGroupSetBits(s_wifi_event_group, WIFI_CONNECTED_BIT);
            turn_on_gpio(LEDWIFI,1);
            protocol_select();
            start_udp_server();
          }
        } else {
          if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_START) {
            esp_wifi_connect();
          } else if (event_base == WIFI_EVENT &&
                     event_id == WIFI_EVENT_STA_CONNECTED) {
            example_set_static_ip(arg);
          } else if (event_base == WIFI_EVENT &&
                     event_id == WIFI_EVENT_STA_DISCONNECTED) {
            kill_udp_server();
            turn_on_gpio(LEDWIFI,0);
            if (s_retry_num < EXAMPLE_MAXIMUM_RETRY) {
              vTaskDelay(pdMS_TO_TICKS(100));
              esp_wifi_connect(); // 重连导致打不开AP
              s_retry_num++;
              ESP_LOGI(TAG, "retry to connect to the AP to %d", s_retry_num);
            } else {
              xEventGroupSetBits(s_wifi_event_group, WIFI_FAIL_BIT);
            }
            ESP_LOGI(TAG, "connect to the AP fail");
          } else if (event_base == IP_EVENT &&
                     event_id == IP_EVENT_STA_GOT_IP) {
            ip_event_got_ip_t *event = (ip_event_got_ip_t *)event_data;
            ESP_LOGI(TAG, "static ip:" IPSTR, IP2STR(&event->ip_info.ip));
            s_retry_num = 0;
            inet_ntoa_r(event->ip_info.ip, got_ip_addrs, 16);
            inet_ntoa_r(event->ip_info.netmask, got_ip_netmask, 16);
            inet_ntoa_r(event->ip_info.gw, got_ip_gw, 16);

            xEventGroupSetBits(s_wifi_event_group, WIFI_CONNECTED_BIT);
            ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "wifi_flag", "0"));
            turn_on_gpio(LEDWIFI,1);
            protocol_select();
            start_udp_server();
          }
        }

      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_wifi_flag);
    }
  }
  nvs_close(nvs_handle);
}

void wifi_init_sta(const char *w_ssid, const char *w_passwd) {
  printf(
      "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("w_ssid: %s\n", w_ssid);
  printf("w_passwd: %s\n", w_passwd);
  s_wifi_event_group = xEventGroupCreate();
  ESP_ERROR_CHECK(esp_netif_init());
  esp_netif_t *sta_netif = esp_netif_create_default_wifi_sta();
  assert(sta_netif);
  wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
  esp_err_t wifi_ret = esp_wifi_init(&cfg);
  if (wifi_ret) {
    printf("Init0");
  }

  esp_event_handler_instance_t instance_any_id;
  esp_event_handler_instance_t instance_got_ip;
  ESP_ERROR_CHECK(esp_event_handler_instance_register(
      WIFI_EVENT, ESP_EVENT_ANY_ID, &event_handler, sta_netif,
      &instance_any_id));
  ESP_ERROR_CHECK(esp_event_handler_instance_register(
      IP_EVENT, IP_EVENT_STA_GOT_IP, &event_handler, sta_netif,
      &instance_got_ip));
  wifi_config_t wifi_config = {0};
  strncpy((char *)wifi_config.sta.ssid, w_ssid,
          sizeof(wifi_config.sta.ssid) - 1);
  strncpy((char *)wifi_config.sta.password, w_passwd,
          sizeof(wifi_config.sta.password) - 1);
  wifi_config.sta.threshold.authmode = WIFI_AUTH_WPA_WPA2_PSK;
    printf(
      "===============================================\n");
  ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
  ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wifi_config));
  ESP_ERROR_CHECK(esp_wifi_start());
  ESP_LOGI(TAG, "wifi_init_sta finished.");
  EventBits_t bits = xEventGroupWaitBits(s_wifi_event_group,
                                         WIFI_CONNECTED_BIT | WIFI_FAIL_BIT,
                                         pdFALSE, pdFALSE, portMAX_DELAY);
  if (bits & WIFI_CONNECTED_BIT) {
    ESP_LOGI(TAG, "connected to ap SSID:%s password:%s", w_ssid, w_passwd);
  } else if (bits & WIFI_FAIL_BIT) {
    ESP_LOGI(TAG, "Failed to connect to SSID:%s, password:%s", w_ssid,
             w_passwd);
  } else {
    ESP_LOGE(TAG, "UNEXPECTED EVENT");
  }
}

static void wifi_task(void *pvParameters) {
  wifi_credentials_t *wifi_credentials = (wifi_credentials_t *)pvParameters;
  wifi_init_sta(wifi_credentials->ssid, wifi_credentials->password);
  vTaskDelete(NULL);
}

void start_wifi_task(const char *ssid, const char *password) {
  wifi_credentials_t *wifi_credentials = malloc(sizeof(wifi_credentials_t));
  if (wifi_credentials == NULL) {
    ESP_LOGE(TAG, "Failed to allocate memory for WiFi credentials");
    return;
  }
  strncpy(wifi_credentials->ssid, ssid, sizeof(wifi_credentials->ssid) - 1);
  strncpy(wifi_credentials->password, password,
          sizeof(wifi_credentials->password) - 1);

  xTaskCreate(wifi_task, "wifi_task", 4096, wifi_credentials, 6, NULL);
}

/*************************************************************************************/
/*                                END OF FILE */
/*************************************************************************************/
