/*
 * @Author: Orion
 * @Date: 2024-01-23 15:51:37
 * @LastEditors: Orion
 * @LastEditTime: 2025-03-06 16:55:37
 * @FilePath: \SERIIAL_SERVER\main\sx_main.c
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */

#include "driver/i2c.h"
#include "esp_eth.h"
#include "esp_event.h"
#include "esp_log.h"
#include "esp_mac.h"
#include "esp_netif.h"
#include "esp_timer.h"
#include "esp_tls.h"
#include "esp_wifi.h"
#include "ethernet_init.h"
#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"
#include "freertos/task.h"
#include "lwip/inet.h"
#include "lwip/priv/tcp_priv.h"
#include "lwip/sockets.h"
#include "lwip/sys.h"
#include "nvs.h"
#include "nvs_flash.h"
#include "sdkconfig.h"
#include "sx_4g_uart.h"
// #include "sx_async_uart.h"
#include "sx_485_uart.h"
#include "sx_gpio.h"
#include "sx_http_client.h"
#include "sx_init_eth.h"
#include "sx_init_wifi.h"
#include "sx_task.h"
#include "sx_udp_server.h"
#include "sx_utils.h"
#include "sx_web_server.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *TAG = "ETH-TH";

/*************************************************************************************/
/*                                START OF FILE */
/*************************************************************************************/

/** Event handler for IP_EVENT_ETH_GOT_IP */
/** Event handler for IP_EVENT_ETH_GOT_IP */
static void got_ip_event_handler(void *arg, esp_event_base_t event_base,
                                 int32_t event_id, void *event_data) {
  ip_event_got_ip_t *event = (ip_event_got_ip_t *)event_data;
  const esp_netif_ip_info_t *ip_infos = &event->ip_info;

  ESP_LOGI(TAG, "Ethernet Got IP Address");
  ESP_LOGI(TAG, "~~~~~~~~~~~");
  ESP_LOGI(TAG, "ETHIP:" IPSTR, IP2STR(&ip_infos->ip));
  ESP_LOGI(TAG, "ETHMASK:" IPSTR, IP2STR(&ip_infos->netmask));
  ESP_LOGI(TAG, "ETHGW:" IPSTR, IP2STR(&ip_infos->gw));
  ESP_LOGI(TAG, "~~~~~~~~~~~");

  inet_ntoa_r(ip_infos->ip, got_ip_addrs, 16);
  inet_ntoa_r(ip_infos->netmask, got_ip_netmask, 16);
  inet_ntoa_r(ip_infos->gw, got_ip_gw, 16);
  if (event_id == IP_EVENT_ETH_LOST_IP) {
    ESP_LOGI(TAG, "Ethernet IP_EVENT_ETH_LOST_IP");
    vTaskDelay(pdMS_TO_TICKS(100));
    turn_on_gpio(LEDLAN, 0);
    vTaskDelay(pdMS_TO_TICKS(100));
    turn_on_gpio(LEDLAN, 0);
    eth_disconnect();
    kill_udp_server();
  }
  if (event_id == IP_EVENT_ETH_GOT_IP) {
    // turn_on_gpio(6,1);
    vTaskDelay(pdMS_TO_TICKS(100));
    turn_on_gpio(LEDLAN, 1);
    vTaskDelay(pdMS_TO_TICKS(100));
    turn_on_gpio(LEDLAN, 1);

    start_udp_server();
    printf("Ethernet got ip and conn\n");
    protocol_select();
  }
}

bool check_nvs_key(nvs_handle_t nvs_handle, const char *key) {
  size_t required_size;
  return nvs_get_str(nvs_handle, key, NULL, &required_size) ==
         ESP_ERR_NVS_NOT_FOUND;
}

void print_sockets(void) {
  struct netconn *conn;
  int socket_count = 0;
  struct tcp_pcb *pcb;
  pcb = tcp_active_pcbs;

  while (pcb != NULL) {
    ESP_LOGI(TAG, "Active socket found: local port %d, remote port %d",
             pcb->local_port, pcb->remote_port);
    socket_count++;
    pcb = pcb->next;
  }

  ESP_LOGI(TAG, "Total active sockets: %d", socket_count);
}

void app_main(void) {
  init_gpio();
  if (gpio_get_level(KEY) == 0) {
    vTaskDelay(100 / portTICK_PERIOD_MS);
    if ((gpio_get_level(KEY) == 0) && (KeyState == 0)) {
      KeyState = 1;

      for (int i = 0; i < 200; i++) {
        vTaskDelay(10 / portTICK_PERIOD_MS);
        if (gpio_get_level(KEY) == 1) {
          break;
        }
      }
      if (gpio_get_level(KEY) == 0) {
        printf("RESET ALL!\n");
        // esp_wifi_restore();
        LED_DAT_ON();
        vTaskDelay(100 / portTICK_PERIOD_MS);
        LED_DAT_OFF();
        vTaskDelay(100 / portTICK_PERIOD_MS);
        LED_DAT_ON();
        vTaskDelay(100 / portTICK_PERIOD_MS);
        LED_DAT_OFF();
        vTaskDelay(100 / portTICK_PERIOD_MS);
        LED_DAT_ON();
        vTaskDelay(100 / portTICK_PERIOD_MS);
        LED_DAT_OFF();
        vTaskDelay(100 / portTICK_PERIOD_MS);
        LED_DAT_ON();
        vTaskDelay(100 / portTICK_PERIOD_MS);
        LED_DAT_OFF();
        vTaskDelay(100 / portTICK_PERIOD_MS);
        LED_DAT_ON();
        vTaskDelay(100 / portTICK_PERIOD_MS);
        LED_DAT_OFF();
        ESP_ERROR_CHECK(nvs_flash_erase());
        vTaskDelay(300 / portTICK_PERIOD_MS);
        esp_restart();
      }
    }
  } else {
    KeyState = 0;
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    uint8_t sta_mac[6] = {0};
    uint8_t eth_mac[6] = {0};
    char d_sta_mac[24];
    char p_mac[48];
    char s_mac[48];
    char c_mac[48];
    esp_read_mac(sta_mac, ESP_MAC_WIFI_STA);
    esp_read_mac(eth_mac, ESP_MAC_ETH);

    sprintf(d_sta_mac, "%02X%02X%02X%02X%02X%02X", sta_mac[0], sta_mac[1],
            sta_mac[2], sta_mac[3], sta_mac[4], sta_mac[5]);
    sprintf(p_mac, "/config/%s_%02X%02X%02X%02X%02X%02X", CLIENT_HEAD,
            sta_mac[0], sta_mac[1], sta_mac[2], sta_mac[3], sta_mac[4],
            sta_mac[5]); // publish
    sprintf(s_mac, "/status/%s_%02X%02X%02X%02X%02X%02X", CLIENT_HEAD,
            sta_mac[0], sta_mac[1], sta_mac[2], sta_mac[3], sta_mac[4],
            sta_mac[5]); // subscribe
    // sprintf(c_mac, "%02x%02x%02x%02x%02x%02x_%s", sta_mac[0], sta_mac[1],
    //         sta_mac[2], sta_mac[3], sta_mac[4], sta_mac[5], VERSION);
    sprintf(c_mac, "%s_%02X%02X%02X%02X%02X%02X", CLIENT_HEAD, sta_mac[0],
            sta_mac[1], sta_mac[2], sta_mac[3], sta_mac[4], sta_mac[5]);

    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES ||
        ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
      ESP_ERROR_CHECK(nvs_flash_erase());
      ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);

    nvs_handle_t nvs_handle;
    ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));

    size_t netconn, is_dhcp, static_ip, static_netmask, static_gateway,
        static_dns1, static_dns2, wifi_ssid, wifi_password;
    size_t ap_name, ap_password, ap_wait_time, use_mqtt, mqtt_type, mqtt_server,
        mqtt_port;
    size_t mqtt_username, mqtt_password, mqtt_clientid, mqtt_sub_topic,
        mqtt_pub_topic, qos, retain, mqtt_send;
    size_t mqtt_time, use_http, http_port, httpconn, http_url, http_header,
        http_time, host_names;
    size_t ntp_server, lgname, lgpwd, use_tcp, tcpconn;
    size_t tcp_server, tcp_port, tcp_send, tcp_time;
    bool nvs_not_found = false;
    if (nvs_get_str(nvs_handle, "netconn", NULL, &netconn) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "is_dhcp", NULL, &is_dhcp) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "static_ip", NULL, &static_ip) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "static_netmask", NULL, &static_netmask) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "static_gateway", NULL, &static_gateway) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "static_dns1", NULL, &static_dns1) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "static_dns2", NULL, &static_dns2) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "wifi_ssid", NULL, &wifi_ssid) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "wifi_password", NULL, &wifi_password) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "ap_name", NULL, &ap_name) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "ap_password", NULL, &ap_password) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "ap_wait_time", NULL, &ap_wait_time) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "use_mqtt", NULL, &use_mqtt) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "mqtt_type", NULL, &mqtt_type) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "mqtt_server", NULL, &mqtt_server) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "mqtt_port", NULL, &mqtt_port) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "mqtt_username", NULL, &mqtt_username) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "mqtt_password", NULL, &mqtt_password) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "mqtt_clientid", NULL, &mqtt_clientid) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "mqtt_sub_topic", NULL, &mqtt_sub_topic) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "mqtt_pub_topic", NULL, &mqtt_pub_topic) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "qos", NULL, &qos) == ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "retain", NULL, &retain) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "mqtt_send", NULL, &mqtt_send) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "mqtt_time", NULL, &mqtt_time) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "use_http", NULL, &use_http) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "http_port", NULL, &http_port) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "httpconn", NULL, &httpconn) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "http_url", NULL, &http_url) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "http_header", NULL, &http_header) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "http_time", NULL, &http_time) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "host_names", NULL, &host_names) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "ntp_server", NULL, &ntp_server) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "lgname", NULL, &lgname) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "lgpwd", NULL, &lgpwd) == ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;

    if (nvs_get_str(nvs_handle, "use_tcp", NULL, &use_tcp) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "tcpconn", NULL, &tcpconn) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "tcp_server", NULL, &tcp_server) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "tcp_port", NULL, &tcp_port) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "tcp_send", NULL, &tcp_send) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;
    if (nvs_get_str(nvs_handle, "tcp_time", NULL, &tcp_time) ==
        ESP_ERR_NVS_NOT_FOUND)
      nvs_not_found = true;

    if (nvs_not_found) {
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "netconn", "3"));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "is_dhcp", "1"));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "static_ip", ""));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "static_netmask", ""));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "static_gateway", ""));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "static_dns1", "8.8.8.8"));
      ESP_ERROR_CHECK(
          nvs_set_str(nvs_handle, "static_dns2", "114.114.114.114"));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "wifi_ssid", ""));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "wifi_password", ""));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "ap_name", ""));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "ap_password", ""));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "ap_wait_time", "5"));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "use_mqtt", "1"));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_type", "0"));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_server", "47.116.122.204"));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_port", "1883"));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_username", "public"));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_password", "Aa123456"));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_clientid", c_mac));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_sub_topic", s_mac));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_pub_topic", p_mac));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "qos", "2"));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "retain", "0"));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_send", "0"));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_time", "5"));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "use_http", "0"));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "http_port", "5000"));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "httpconn", "1"));
      ESP_ERROR_CHECK(
          nvs_set_str(nvs_handle, "http_url", "http://demo.sxiot.com"));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "http_header", ""));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "http_time", "5"));
      ESP_ERROR_CHECK(
          nvs_set_str(nvs_handle, "host_names", "千瓦科技 --物小能G1"));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "ntp_server", ""));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "lgname", "wuxiaoneng"));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "lgpwd", "4006303060"));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "use_tcp", "1"));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "tcpconn", "0"));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "tcp_server", "192.168.1.100"));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "tcp_port", "8888"));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "tcp_send", "0"));
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "tcp_time", "5"));
    }

    char *nvs_netconn = malloc(netconn);
    char *nvs_is_dhcp = malloc(is_dhcp);
    char *nvs_static_ip = malloc(static_ip);
    char *nvs_static_netmask = malloc(static_netmask);
    char *nvs_static_gateway = malloc(static_gateway);
    char *nvs_static_dns1 = malloc(static_dns1);
    char *nvs_static_dns2 = malloc(static_dns2);
    char *nvs_wifi_ssid = malloc(wifi_ssid);
    char *nvs_wifi_password = malloc(wifi_password);
    if (nvs_netconn == NULL) {
      printf("Memory allocation failed\n");
      esp_restart();
    } else {
      ret = nvs_get_str(nvs_handle, "netconn", nvs_netconn, &netconn);
      nvs_get_str(nvs_handle, "is_dhcp", nvs_is_dhcp, &is_dhcp);
      nvs_get_str(nvs_handle, "static_ip", nvs_static_ip, &static_ip);
      nvs_get_str(nvs_handle, "static_netmask", nvs_static_netmask,
                  &static_netmask);
      nvs_get_str(nvs_handle, "static_gateway", nvs_static_gateway,
                  &static_gateway);
      nvs_get_str(nvs_handle, "static_dns1", nvs_static_dns1, &static_dns1);
      nvs_get_str(nvs_handle, "static_dns2", nvs_static_dns2, &static_dns2);
      nvs_get_str(nvs_handle, "wifi_ssid", nvs_wifi_ssid, &wifi_ssid);
      nvs_get_str(nvs_handle, "wifi_password", nvs_wifi_password,
                  &wifi_password);

      if (ret == ESP_OK) {
        ESP_LOGI(TAG, "4G触发");
        turn_on_gpio(RESET4G, 0);
        vTaskDelay(500 / portTICK_PERIOD_MS);
        // turn_on_gpio(RESET4G, 1);
        turn_on_gpio(POW4G, 1);
        vTaskDelay(500 / portTICK_PERIOD_MS);
        turn_on_gpio(POW4G, 1);
        ESP_LOGI(TAG, "4G触发");
        if (atoi(nvs_netconn) == 2) {
          // wifi_init_sta(nvs_wifi_ssid, nvs_wifi_password);
          start_wifi_task(nvs_wifi_ssid, nvs_wifi_password);
        } else if (atoi(nvs_netconn) == 3) {
          start_4g_task();

          protocol_select();
        } else {
          uint8_t eth_port_cnt = 0;
          esp_eth_handle_t *eth_handles;
          esp_err_t ret = example_eth_init(&eth_handles, &eth_port_cnt);
          if (ret == ESP_OK) {
            if (eth_port_cnt == 1) {
              esp_netif_config_t cfg = ESP_NETIF_DEFAULT_ETH();
              esp_netif_t *eth_netif = esp_netif_new(&cfg);

              if (strcmp(nvs_static_ip, "") == 0 ||
                  strcmp(nvs_static_netmask, "") == 0 ||
                  strcmp(nvs_static_gateway, "") == 0 ||
                  strcmp(nvs_static_dns1, "") == 0 ||
                  strcmp(nvs_static_dns2, "") == 0 ||
                  strcmp(nvs_is_dhcp, "1") == 0) {
                ESP_ERROR_CHECK(esp_netif_attach(
                    eth_netif, esp_eth_new_netif_glue(eth_handles[0])));
              } else {
                ESP_ERROR_CHECK(esp_netif_dhcpc_stop(eth_netif));
                esp_netif_ip_info_t info_t;
                memset(&info_t, 0, sizeof(esp_netif_ip_info_t));
                info_t.ip.addr = esp_ip4addr_aton((const char *)nvs_static_ip);
                info_t.netmask.addr =
                    esp_ip4addr_aton((const char *)nvs_static_netmask);
                info_t.gw.addr =
                    esp_ip4addr_aton((const char *)nvs_static_gateway);
                ESP_ERROR_CHECK(esp_netif_set_ip_info(eth_netif, &info_t));

                // 配置DNS1
                esp_netif_dns_info_t dns1_info = {0};
                dns1_info.ip.u_addr.ip4.addr =
                    esp_ip4addr_aton((const char *)nvs_static_dns1);
                ESP_ERROR_CHECK(esp_netif_set_dns_info(
                    eth_netif, ESP_NETIF_DNS_MAIN, &dns1_info));

                // 配置DNS2
                esp_netif_dns_info_t dns2_info = {0};
                dns2_info.ip.u_addr.ip4.addr =
                    esp_ip4addr_aton((const char *)nvs_static_dns2);
                ESP_ERROR_CHECK(esp_netif_set_dns_info(
                    eth_netif, ESP_NETIF_DNS_BACKUP, &dns2_info));

                ESP_ERROR_CHECK(esp_netif_attach(
                    eth_netif, esp_eth_new_netif_glue(eth_handles[0])));
              }
            } else {
              esp_netif_inherent_config_t esp_netif_config =
                  ESP_NETIF_INHERENT_DEFAULT_ETH();
              esp_netif_config_t cfg_spi = {.base = &esp_netif_config,
                                            .stack =
                                                ESP_NETIF_NETSTACK_DEFAULT_ETH};
              char if_key_str[10];
              char if_desc_str[10];
              char num_str[3];
              for (int i = 0; i < eth_port_cnt; i++) {
                itoa(i, num_str, 10);
                strcat(strcpy(if_key_str, "ETH_"), num_str);
                strcat(strcpy(if_desc_str, "eth"), num_str);
                esp_netif_config.if_key = if_key_str;
                esp_netif_config.if_desc = if_desc_str;
                esp_netif_config.route_prio -= i * 5;
                esp_netif_t *eth_netif = esp_netif_new(&cfg_spi);
                ESP_ERROR_CHECK(esp_netif_attach(
                    eth_netif, esp_eth_new_netif_glue(eth_handles[i])));
              }
            }
            ESP_ERROR_CHECK(esp_event_handler_register(
                ETH_EVENT, ESP_EVENT_ANY_ID, &eth_event_handler, NULL));
            ESP_ERROR_CHECK(esp_event_handler_register(
                IP_EVENT, IP_EVENT_ETH_GOT_IP, &got_ip_event_handler, NULL));
            for (int i = 0; i < eth_port_cnt; i++) {
              ESP_ERROR_CHECK(esp_eth_start(eth_handles[i]));
            }
          } else {
            printf("eth init failed\n");
          }
        }

      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_netconn);
      free(nvs_is_dhcp);
      free(nvs_static_ip);
      free(nvs_static_netmask);
      free(nvs_static_gateway);
      free(nvs_static_dns1);
      free(nvs_static_dns2);
      free(nvs_wifi_ssid);
      free(nvs_wifi_password);
    }

    nvs_close(nvs_handle);
    // uart_init();
    init_485_uart();
    simple_task();

    http_server_init();

    // while (1) {
    //   printf("+++++++++++++++++++++++++++++++++++++++++++++++++++ \n");
    //   print_sockets();
    //   printf("+++++++++++++++++++++++++++++++++++++++++++++++++++ \n");
    //   vTaskDelay(pdMS_TO_TICKS(10000)); // 每10秒统计一次
    // }
  }
}

/*************************************************************************************/
/*                                END OF FILE */
/*************************************************************************************/
