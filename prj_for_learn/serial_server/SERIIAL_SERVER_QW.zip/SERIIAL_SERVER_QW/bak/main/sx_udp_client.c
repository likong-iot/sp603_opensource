/*
 * @Author: Orion
 * @Date: 2024-01-23 16:08:04
 * @LastEditors: Orion
 * @LastEditTime: 2025-01-17 15:46:20
 * @FilePath: \SERIIAL_SERVER\main\sx_udp_client.c
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */

#include "cJSON.h"
#include "esp_event.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "esp_system.h"
#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"
#include "freertos/task.h"
#include "lwip/err.h"
#include "lwip/sockets.h"
#include "lwip/sys.h"
#include "nvs_flash.h"
#include "sx_utils.h"
#include <lwip/netdb.h>
#include <string.h>
#include <sys/param.h>

#define HOST_IP_ADDR "192.168.31.33"

#define PORT 45678

static const char *TAG = "UDPCLIENT";
static const char *payload = "Message from ESP32 ";

/*************************************************************************************/
/*                                START OF FILE */
/*************************************************************************************/

static void udp_client_task(void *pvParameters) {
  char rx_buffer[128];
  char host_ip[32];
  int addr_family = 0;
  int ip_protocol = 0;
  int udp_client_port = 0;

  esp_err_t ret = nvs_flash_init();
  if (ret == ESP_ERR_NVS_NO_FREE_PAGES ||
      ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
    ESP_ERROR_CHECK(nvs_flash_erase());
    ret = nvs_flash_init();
  }
  ESP_ERROR_CHECK(ret);
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
  size_t use_udp, udpconn, udp_server, udp_port = 0;
  ret = nvs_get_str(nvs_handle, "use_udp", NULL, &use_udp);
  nvs_get_str(nvs_handle, "udpconn", NULL, &udpconn);
  nvs_get_str(nvs_handle, "udp_server", NULL, &udp_server);
  nvs_get_str(nvs_handle, "udp_port", NULL, &udp_port);
  if (ret != ESP_OK) {
    printf("Error getting size of 'my_key': %s\n", esp_err_to_name(ret));
  } else {
    char *nvs_use_udp = malloc(use_udp);
    char *nvs_udpconn = malloc(udpconn);
    char *nvs_udp_server = malloc(udp_server);
    char *nvs_udp_port = malloc(udp_port);

    if (nvs_udp_port == NULL) {
      printf("Memory allocation failed\n");
    } else {
      ret = nvs_get_str(nvs_handle, "use_udp", nvs_use_udp, &use_udp);
      nvs_get_str(nvs_handle, "udpconn", nvs_udpconn, &udpconn);
      nvs_get_str(nvs_handle, "udp_server", nvs_udp_server, &udp_server);
      nvs_get_str(nvs_handle, "udp_port", nvs_udp_port, &udp_port);
      if (ret == ESP_OK) {
        printf("Value for 'use_udp' is %s\n", nvs_use_udp);
        printf("Value for 'udpconn' is %s\n", nvs_udpconn);
        printf("Value for 'udp_server' is %s\n", nvs_udp_server);
        printf("Value for 'udp_port' is %s\n", nvs_udp_port);

        strcpy(host_ip, nvs_udp_server);
        udp_client_port = atoi(nvs_udp_port);
        // ESP_LOGI(TAG, "Socket created, sending to %s:%d", host_ip,
        //          udp_client_port);
      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_use_udp); // 释放缓冲区
      free(nvs_udpconn);
      free(nvs_udp_server);
      free(nvs_udp_port);
    }
  }
  nvs_close(nvs_handle);

  while (1) {
    struct sockaddr_in dest_addr;
    dest_addr.sin_addr.s_addr = inet_addr(host_ip);
    dest_addr.sin_family = AF_INET;
    dest_addr.sin_port = htons(udp_client_port);
    addr_family = AF_INET;
    ip_protocol = IPPROTO_IP;

    int sock = socket(addr_family, SOCK_DGRAM, ip_protocol);
    if (sock < 0) {
      ESP_LOGE(TAG, "Unable to create socket: errno %d", errno);
      break;
    }

    struct timeval timeout;
    timeout.tv_sec = 10;
    timeout.tv_usec = 0;
    setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof timeout);

    while (1) {

      int err = sendto(sock, payload, strlen(payload), 0,
                       (struct sockaddr *)&dest_addr, sizeof(dest_addr));
      if (err < 0) {
        ESP_LOGE(TAG, "Error occurred during sending: errno %d", errno);
        break;
      }
      ESP_LOGI(TAG, "Message sent");

      struct sockaddr_storage source_addr;
      socklen_t socklen = sizeof(source_addr);
      int len = recvfrom(sock, rx_buffer, sizeof(rx_buffer) - 1, 0,
                         (struct sockaddr *)&source_addr, &socklen);

      if (len < 0) {
        // ESP_LOGE(TAG, "recvfrom failed: errno %d", errno);
        break;
      }

      else {
        char *udpmsg = NULL;
        rx_buffer[len] = 0;
        ESP_LOGI(TAG, "Received %d bytes from %s:", len, host_ip);
        ESP_LOGI(TAG, "%s", rx_buffer);

        if (strncmp(rx_buffer, "OK: ", 4) == 0) {
          ESP_LOGI(TAG, "Received expected message, reconnecting");
          break;
        }
        cJSON *pJsonRoot = cJSON_Parse(rx_buffer);

        if (pJsonRoot == NULL) {
          const char *error_ptr = cJSON_GetErrorPtr();
          if (error_ptr != NULL) {
            fprintf(stderr, "Error before: %s\n", error_ptr);
          }
          cJSON_Delete(pJsonRoot);
          return;
        }
        // 获取并打印 "id" 字段
        cJSON *id = cJSON_GetObjectItemCaseSensitive(pJsonRoot, "messageid");
        if (cJSON_IsString(id)) {
          printf("id: %s\n", id->valuestring);
          strcpy(messageid, id->valuestring);
          printf("messageid: %s\n", messageid);
        }

        // 获取 "param" 对象
        cJSON *param = cJSON_GetObjectItemCaseSensitive(pJsonRoot, "param");
        cJSON *require = cJSON_GetObjectItemCaseSensitive(param, "require");
        if (cJSON_IsObject(param)) {
          // 获取并打印 "type" 字段
          cJSON *type = cJSON_GetObjectItemCaseSensitive(param, "type");
          if (cJSON_IsString(type) && (type->valuestring != NULL)) {
            if (strcmp(type->valuestring, "data") == 0) {
              uint8_t *data = NULL;
              int idx = 0;

              if (strchr(require->valuestring, ' ') != NULL) {
                char *token = strtok(require->valuestring, " ");
                while (token != NULL) {
                  data = realloc(data, (idx + 1) * sizeof(uint8_t));
                  sscanf(token, "%hhx", &data[idx]);
                  idx++;
                  token = strtok(NULL, " ");
                }
              } else {
                for (int i = 0; i < strlen(require->valuestring); i += 2) {
                  data = realloc(data, (idx + 1) * sizeof(uint8_t));
                  sscanf(&require->valuestring[i], "%2hhx", &data[idx]);
                  idx++;
                }
              }
              printf("type: %s\n", type->valuestring);
              udpmsg = send_device_info(data, idx);
              printf("tcpmsg: %s\n", udpmsg);
            }
          } else {
            udpmsg = send_device_info_err();
          }
          int err = sendto(sock, udpmsg, strlen(udpmsg), 0,
                           (struct sockaddr *)&dest_addr, sizeof(dest_addr));

          if (err < 0) {
            ESP_LOGE(TAG, "Error occurred during sending: errno %d", errno);
            break;
          }
        }
        free(udpmsg);
        cJSON_Delete(pJsonRoot); // 释放cJSON_Parse()分配出来的内存空间
      }

      // vTaskDelay(2000 / portTICK_PERIOD_MS);
    }

    if (sock != -1) {
      ESP_LOGE(TAG, "Shutting down socket and restarting...");
      shutdown(sock, 0);
      close(sock);
    }
  }
  vTaskDelete(NULL);
}

void start_udp_client(void) {

  xTaskCreate(udp_client_task, "udp_client", 4096, NULL, 5, NULL);
}

/*************************************************************************************/
/*                                END OF FILE */
/*************************************************************************************/
