/*
 * @Author: Orion
 * @Date: 2024-09-13 11:45:12
 * @LastEditors: Orion
 * @LastEditTime: 2025-03-12 19:03:34
 * @Description:
 *
 */
#include "sx_4g_uart.h"
#include "driver/gpio.h"
#include "driver/uart.h"
#include "esp_http_client.h"
#include "esp_log.h"
#include "esp_system.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "nvs.h"
#include "nvs_flash.h"
#include "string.h"
#include "sx_485_uart.h"
#include "sx_gpio.h"
#include "sx_log.h"
#include "sx_mqtt_client.h"
#include "sx_time.h"
#include "sx_utils.h"
#include "sx_web_server.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static const int RX_BUF_SIZE = 4096;

char g_ccid[32] = {0};
char g_cgsn[32] = {0};
char g_4gip[32] = {0};
char g_csq[32] = {0};

void init4g(void) {
  const uart_config_t uart_config = {
      .baud_rate = 115200,
      .data_bits = UART_DATA_8_BITS,
      .parity = UART_PARITY_DISABLE,
      .stop_bits = UART_STOP_BITS_1,
      .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
      .source_clk = UART_SCLK_DEFAULT,
  };
  uart_driver_install(UART_NUM_1, RX_BUF_SIZE * 2, 0, 0, NULL, 0);
  uart_param_config(UART_NUM_1, &uart_config);
  uart_set_pin(UART_NUM_1, TXD_PIN_4G, RXD_PIN_4G, UART_PIN_NO_CHANGE,
               UART_PIN_NO_CHANGE);
}

#define FIRMWARE_BUFFER_SIZE 2048
#define MAX_FIRMWARE_SIZE (2048 * 2048)

// Base64编码表
static const char base64_chars[] =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

// Base64编码实现
char *base64_encode(const uint8_t *data, size_t length, size_t *out_length) {
  *out_length = 4 * ((length + 2) / 3);
  char *encoded = (char *)malloc(*out_length + 1);
  if (encoded == NULL)
    return NULL;

  size_t i = 0, j = 0;
  size_t remaining = length;

  while (remaining >= 3) {
    encoded[j++] = base64_chars[data[i] >> 2];
    encoded[j++] = base64_chars[((data[i] & 0x03) << 4) | (data[i + 1] >> 4)];
    encoded[j++] =
        base64_chars[((data[i + 1] & 0x0f) << 2) | (data[i + 2] >> 6)];
    encoded[j++] = base64_chars[data[i + 2] & 0x3f];
    remaining -= 3;
    i += 3;
  }

  if (remaining > 0) {
    encoded[j++] = base64_chars[data[i] >> 2];
    if (remaining == 1) {
      encoded[j++] = base64_chars[(data[i] & 0x03) << 4];
      encoded[j++] = '=';
    } else {
      encoded[j++] = base64_chars[((data[i] & 0x03) << 4) | (data[i + 1] >> 4)];
      encoded[j++] = base64_chars[(data[i + 1] & 0x0f) << 2];
    }
    encoded[j++] = '=';
  }

  encoded[*out_length] = '\0';
  return encoded;
}

// 下载并更新4G模块固件
esp_err_t download_and_update_4g(const char *url) {
  sx_log_write_simple("【 4G-升级 】开始下载固件: %s", url);
  esp_http_client_config_t config = {
      .url = url,
      .timeout_ms = 5000,
  };

  esp_http_client_handle_t client = esp_http_client_init(&config);
  if (client == NULL) {
    ESP_LOGE("4G_FOTA", "Failed to initialize HTTP client");
    sx_log_write_simple("【 4G-升级 】初始化HTTP客户端失败");
    return ESP_FAIL;
  }

  esp_err_t err = esp_http_client_open(client, 0);
  if (err != ESP_OK) {
    ESP_LOGE("4G_FOTA", "Failed to open HTTP connection: %s",
             esp_err_to_name(err));
    sx_log_write_simple("【 4G-升级 】初始化HTTP客户端失败: %s",
                        esp_err_to_name(err));
    esp_http_client_cleanup(client);
    return err;
  }

  int content_length = esp_http_client_fetch_headers(client);
  if (content_length < 0) {
    ESP_LOGE("4G_FOTA", "Failed to get content length");
    sx_log_write_simple("【 4G-升级 】获取内容长度失败");
    esp_http_client_cleanup(client);
    return ESP_FAIL;
  }

  if (content_length > MAX_FIRMWARE_SIZE) {
    ESP_LOGE("4G_FOTA", "Firmware size too large: %d", content_length);
    sx_log_write_simple("【 4G-升级 】固件大小太大: %d", content_length);
    esp_http_client_cleanup(client);
    return ESP_ERR_INVALID_SIZE;
  }

  // 发送FOTA开始命令
  cJSON *start_cmd = cJSON_CreateObject();
  cJSON_AddStringToObject(start_cmd, "type", "fota");
  cJSON_AddStringToObject(start_cmd, "action", "start");
  cJSON_AddNumberToObject(start_cmd, "size", content_length);

  char *start_str = cJSON_PrintUnformatted(start_cmd);
  if (start_str) {
    char *cmd_with_newline = malloc(strlen(start_str) + 3);
    if (cmd_with_newline) {
      sprintf(cmd_with_newline, "%s\r\n", start_str);
      send4gData("4G_FOTA", cmd_with_newline);
      free(cmd_with_newline);
    }
    free(start_str);
  }
  cJSON_Delete(start_cmd);

  vTaskDelay(1000 / portTICK_PERIOD_MS);

  // 开始传输固件数据
  uint8_t *buffer = malloc(FIRMWARE_BUFFER_SIZE);
  if (buffer == NULL) {
    ESP_LOGE("4G_FOTA", "Failed to allocate memory for firmware buffer");
    sx_log_write_simple("【 4G-升级 】分配固件缓冲区失败");
    esp_http_client_cleanup(client);
    return ESP_ERR_NO_MEM;
  }

  int total_bytes_read = 0;
  bool success = true;

  // 发送固件数据
  while (success) {
    int data_read =
        esp_http_client_read(client, (char *)buffer, FIRMWARE_BUFFER_SIZE);
    if (data_read < 0) {
      ESP_LOGE("4G_FOTA", "Error reading data");
      sx_log_write_simple("【 4G-升级 】读取数据失败");
      success = false;
      break;
    } else if (data_read == 0) {
      break; // 传输完成
    }

    // 发送块
    cJSON *data_cmd = cJSON_CreateObject();
    cJSON_AddStringToObject(data_cmd, "type", "fota");
    cJSON_AddStringToObject(data_cmd, "action", "data");
    cJSON_AddNumberToObject(data_cmd, "offset", total_bytes_read);

    // Base64编码固件数据
    size_t encoded_len = 0;
    char *encoded_data = base64_encode(buffer, data_read, &encoded_len);
    if (encoded_data) {
      cJSON_AddStringToObject(data_cmd, "data", encoded_data);
      char *data_str = cJSON_PrintUnformatted(data_cmd);
      if (data_str) {
        char *cmd_with_newline = malloc(strlen(data_str) + 3);
        if (cmd_with_newline) {
          sprintf(cmd_with_newline, "%s\r\n", data_str);
          send4gData("4G_FOTA", cmd_with_newline);
          free(cmd_with_newline);
        }
        free(data_str);
      }
      free(encoded_data);
    }
    cJSON_Delete(data_cmd);

    vTaskDelay(100 / portTICK_PERIOD_MS);

    total_bytes_read += data_read;
    sx_log_write_simple("【 4G-升级 】已下载 %d/%d 字节", total_bytes_read,
                        content_length);
  }

  free(buffer);
  esp_http_client_cleanup(client);

  if (!success) {
    return ESP_FAIL;
  }

  // 发送升级完成命令
  cJSON *end_cmd = cJSON_CreateObject();
  cJSON_AddStringToObject(end_cmd, "type", "fota");
  cJSON_AddStringToObject(end_cmd, "action", "end");

  char *end_str = cJSON_PrintUnformatted(end_cmd);
  if (end_str) {
    char *cmd_with_newline = malloc(strlen(end_str) + 3);
    if (cmd_with_newline) {
      sprintf(cmd_with_newline, "%s\r\n", end_str);
      send4gData("4G_FOTA", cmd_with_newline);
      free(cmd_with_newline);
    }
    free(end_str);
  }
  cJSON_Delete(end_cmd);

  sx_log_write_simple("【 4G-升级 】4G模块固件更新完成");
  return ESP_OK;
}
int send4gData(const char *logName, const char *data) {
  const int len = strlen(data);
  const int txBytes = uart_write_bytes(UART_NUM_1, data, len);
  sx_log_write_simple("【 4G-串口 】写入 %d 字节", txBytes);
  return txBytes;
}

void tx_4g_task(void *arg) {
  static const char *TX_TASK_TAG = "4G_TX_TASK";

  while (1) {
    send4gData(TX_TASK_TAG, "{\"type\":\"info\"}");
    vTaskDelay(5000 / portTICK_PERIOD_MS);
  }
  // vTaskDelete(NULL);
}
void parse_and_store_data(const char *data) {
  // sx_log_write_simple("【 4G-串口 】收到: %s", data);

  // 解析JSON数据
  cJSON *json = cJSON_Parse(data);
  if (!json) {
    sx_log_write_simple("【 4G-串口 】JSON解析失败");
    return;
  }

  // 检查消息类型
  cJSON *type = cJSON_GetObjectItem(json, "type");

  // 如果没有type字段或者是设备信息JSON，直接处理设备信息
  if (!type || !cJSON_IsString(type)) {
    // 提取ICCID
    cJSON *iccid = cJSON_GetObjectItem(json, "iccid");
    if (cJSON_IsString(iccid) && (iccid->valuestring != NULL)) {
      strncpy(g_ccid, iccid->valuestring, sizeof(g_ccid) - 1);
      g_ccid[sizeof(g_ccid) - 1] = '\0';
      ESP_LOGI("4G_RX_TASK", "ICCID: %s", g_ccid);
      sx_log_write_simple("【 4G-串口 】ICCID: %s", g_ccid);
    }

    // 提取IMEI
    cJSON *imei = cJSON_GetObjectItem(json, "imei");
    if (cJSON_IsString(imei) && (imei->valuestring != NULL)) {
      strncpy(g_cgsn, imei->valuestring, sizeof(g_cgsn) - 1);
      g_cgsn[sizeof(g_cgsn) - 1] = '\0';
      ESP_LOGI("4G_RX_TASK", "IMEI: %s", g_cgsn);
      sx_log_write_simple("【 4G-串口 】IMEI: %s", g_cgsn);
    }

    // 提取IP
    cJSON *ip = cJSON_GetObjectItem(json, "ip");
    if (cJSON_IsString(ip) && (ip->valuestring != NULL)) {
      strncpy(g_4gip, ip->valuestring, sizeof(g_4gip) - 1);
      g_4gip[sizeof(g_4gip) - 1] = '\0';
      ESP_LOGI("4G_RX_TASK", "IP: %s", g_4gip);
      sx_log_write_simple("【 4G-串口 】IP: %s", g_4gip);
    }

    // 提取timestamp
    cJSON *timestamp = cJSON_GetObjectItem(json, "timestamp");
    if (cJSON_IsString(timestamp) && timestamp->valuestring != NULL) {
      strncpy(strftime_buf, timestamp->valuestring, sizeof(strftime_buf) - 1);
      strftime_buf[sizeof(strftime_buf) - 1] = '\0';
      ESP_LOGI("4G_RX_TASK", "当前时间: %s", strftime_buf);
      // sx_log_write_simple("【 4G-串口 】当前时间: %s", strftime_buf);
    }

    // 提取CSQ
    cJSON *csq = cJSON_GetObjectItem(json, "csq");
    if (cJSON_IsNumber(csq)) {
      snprintf(g_csq, sizeof(g_csq), "%d", csq->valueint);
      ESP_LOGI("4G_RX_TASK", "CSQ: %s", g_csq);
      sx_log_write_simple("【 4G-串口 】CSQ: %s", g_csq);
      turn_on_gpio(LED4G, 1);
    }

    // 处理统计信息
    cJSON *stat = cJSON_GetObjectItem(json, "stat");
    if (stat) {
      cJSON *targets = cJSON_GetObjectItem(stat, "targets");
      if (targets && cJSON_IsArray(targets)) {
        int target_count = cJSON_GetArraySize(targets);

        // 遍历每个目标的统计信息
        for (int i = 0; i < target_count; i++) {
          cJSON *target = cJSON_GetArrayItem(targets, i);
          if (target) {
            cJSON *name = cJSON_GetObjectItem(target, "name");
            if (name && cJSON_IsString(name)) {
              // 更新目标统计信息
              target_stats_t *stats = NULL;

              // 查找现有统计信息或创建新的
              for (int j = 0; j < target_stats_count; j++) {
                if (strcmp(target_stats[j].name, name->valuestring) == 0) {
                  stats = &target_stats[j];
                  break;
                }
              }

              // 如果没找到，创建新的统计记录
              if (!stats && target_stats_count < MAX_TARGETS) {
                stats = &target_stats[target_stats_count++];
                strncpy(stats->name, name->valuestring,
                        sizeof(stats->name) - 1);
              }

              if (stats) {
                // 更新统计数据
                stats->send_frame_success =
                    cJSON_GetObjectItem(target, "send_frame_success")->valueint;
                stats->send_byte_success =
                    cJSON_GetObjectItem(target, "send_byte_success")->valueint;
                stats->send_frame_failed =
                    cJSON_GetObjectItem(target, "send_frame_failed")->valueint;
                stats->send_byte_failed =
                    cJSON_GetObjectItem(target, "send_byte_failed")->valueint;
                stats->recv_frame =
                    cJSON_GetObjectItem(target, "recv_frame")->valueint;
                stats->recv_byte =
                    cJSON_GetObjectItem(target, "recv_byte")->valueint;
              }
            }
          }
        }
      }
    }


  } else {
    // 处理特定类型的消息
    if (strcmp(type->valuestring, "get_config") == 0) {
      // 使用load_config_from_nvs获取配置
      cJSON *config_json = load_config_from_nvs();
      if (config_json != NULL) {
        // 创建响应对象
        cJSON *response = cJSON_CreateObject();
        cJSON_AddStringToObject(response, "type", "config_response");
        cJSON_AddItemToObject(response, "config", config_json);

        // 添加主MQTT配置
        nvs_handle_t nvs_handle;
        esp_err_t err = nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle);
        if (err == ESP_OK) {
          size_t mqtt_username, mqtt_password, mqtt_server, mqtt_port,
              mqtt_clientid, mqtt_sub_topic, mqtt_pub_topic, qos, retain = 0;

          // 获取所有MQTT配置参数的大小
          nvs_get_str(nvs_handle, "mqtt_username", NULL, &mqtt_username);
          nvs_get_str(nvs_handle, "mqtt_password", NULL, &mqtt_password);
          nvs_get_str(nvs_handle, "mqtt_server", NULL, &mqtt_server);
          nvs_get_str(nvs_handle, "mqtt_port", NULL, &mqtt_port);
          nvs_get_str(nvs_handle, "mqtt_clientid", NULL, &mqtt_clientid);
          nvs_get_str(nvs_handle, "mqtt_sub_topic", NULL, &mqtt_sub_topic);
          nvs_get_str(nvs_handle, "mqtt_pub_topic", NULL, &mqtt_pub_topic);
          nvs_get_str(nvs_handle, "qos", NULL, &qos);
          nvs_get_str(nvs_handle, "retain", NULL, &retain);

          // 分配内存并获取值
          char *nvs_mqtt_username = malloc(mqtt_username);
          char *nvs_mqtt_password = malloc(mqtt_password);
          char *nvs_mqtt_server = malloc(mqtt_server);
          char *nvs_mqtt_port = malloc(mqtt_port);
          char *nvs_mqtt_clientid = malloc(mqtt_clientid);
          char *nvs_mqtt_sub_topic = malloc(mqtt_sub_topic);
          char *nvs_mqtt_pub_topic = malloc(mqtt_pub_topic);
          char *nvs_qos = malloc(qos);
          char *nvs_retain = malloc(retain);

          if (nvs_mqtt_server != NULL) {
            nvs_get_str(nvs_handle, "mqtt_username", nvs_mqtt_username,
                        &mqtt_username);
            nvs_get_str(nvs_handle, "mqtt_password", nvs_mqtt_password,
                        &mqtt_password);
            nvs_get_str(nvs_handle, "mqtt_server", nvs_mqtt_server,
                        &mqtt_server);
            nvs_get_str(nvs_handle, "mqtt_port", nvs_mqtt_port, &mqtt_port);
            nvs_get_str(nvs_handle, "mqtt_clientid", nvs_mqtt_clientid,
                        &mqtt_clientid);
            nvs_get_str(nvs_handle, "mqtt_sub_topic", nvs_mqtt_sub_topic,
                        &mqtt_sub_topic);
            nvs_get_str(nvs_handle, "mqtt_pub_topic", nvs_mqtt_pub_topic,
                        &mqtt_pub_topic);
            nvs_get_str(nvs_handle, "qos", nvs_qos, &qos);
            nvs_get_str(nvs_handle, "retain", nvs_retain, &retain);

            // 创建主MQTT配置对象
            cJSON *mqtt_config = cJSON_CreateObject();
            if (mqtt_config != NULL) {
              // 构建完整的URL
              char mqtt_url[256];
              snprintf(mqtt_url, sizeof(mqtt_url), "mqtt://%s:%s@%s",
                       nvs_mqtt_username, nvs_mqtt_password, nvs_mqtt_server);

              cJSON_AddStringToObject(mqtt_config, "type", "mqtt");
              cJSON_AddStringToObject(mqtt_config, "url", mqtt_url);
              cJSON_AddNumberToObject(mqtt_config, "port", atoi(nvs_mqtt_port));
              cJSON_AddStringToObject(mqtt_config, "clientid",
                                      nvs_mqtt_clientid);
              cJSON_AddStringToObject(mqtt_config, "sub_topic",
                                      nvs_mqtt_sub_topic);
              cJSON_AddStringToObject(mqtt_config, "pub_topic",
                                      nvs_mqtt_pub_topic);
              cJSON_AddNumberToObject(mqtt_config, "qos", atoi(nvs_qos));
              cJSON_AddNumberToObject(mqtt_config, "retain", atoi(nvs_retain));

              // 将主MQTT配置添加到配置响应中
              cJSON_AddItemToObject(response, "mqtt", mqtt_config);
            }
          }

          // 释放内存
          free(nvs_mqtt_username);
          free(nvs_mqtt_password);
          free(nvs_mqtt_server);
          free(nvs_mqtt_port);
          free(nvs_mqtt_clientid);
          free(nvs_mqtt_sub_topic);
          free(nvs_mqtt_pub_topic);
          free(nvs_qos);
          free(nvs_retain);
          nvs_close(nvs_handle);
        }

        // 转换为字符串并发送
        char *response_str = cJSON_PrintUnformatted(response);
        if (response_str) {
          char *final_response = malloc(strlen(response_str) + 3);
          if (final_response) {
            sprintf(final_response, "%s\r\n", response_str);
            send4gData("4G_RX_TASK", final_response);
            ESP_LOGI("4G_RX_TASK", "发送配置响应: %s", final_response);
            free(final_response);
          }
          free(response_str);
        }
        cJSON_Delete(response);
      } else {
        // 如果没有找到配置，发送空配置响应
        const char *empty_response =
            "{\"type\":\"config_response\",\"config\":{}}\r\n";
        send4gData("4G_RX_TASK", empty_response);
        ESP_LOGI("4G_RX_TASK", "未找到配置，发送空配置响应");
      }
    } else if (strcmp(type->valuestring, "mqtt_message") == 0) {

      cJSON *payload = cJSON_GetObjectItem(json, "payload");
      if (payload && cJSON_IsString(payload)) {
        cJSON *payload_json = cJSON_Parse(payload->valuestring);
        sx_log_write_simple("【 4G-MQTT 】收到消息: %s", payload->valuestring);

        if (payload_json) {
          cJSON *payload_type = cJSON_GetObjectItem(payload_json, "action");
          if (payload_type && cJSON_IsString(payload_type)) {
            if (strcmp(payload_type->valuestring, "info") == 0) {
              ESP_LOGI("4G_RX_TASK", "收到info类型消息，发送设备信息");
              char *info = device_basic_info();

              if (info) {
                // 创建一个新的JSON对象，添加status字段
                cJSON *info_json = cJSON_Parse(info);
                if (info_json) {
                  cJSON_AddStringToObject(info_json, "action", "info");
                  char *new_info = cJSON_PrintUnformatted(info_json);
                  if (new_info) {
                    char *final_info = malloc(strlen(new_info) + 3);
                    if (final_info) {
                      sprintf(final_info, "%s\r\n", new_info);
                      send4gData("4G_RX_TASK", final_info);
                      free(final_info);
                    }
                    free(new_info);
                  }
                  cJSON_Delete(info_json);
                }
                free(info);
              }
            } else if (strcmp(payload_type->valuestring, "restart") == 0) {
              ESP_LOGI("4G_RX_TASK", "收到重启命令，设备即将重启...");
              vTaskDelay(200 / portTICK_PERIOD_MS);
              esp_restart();
            } else if (strcmp(payload_type->valuestring, "reset") == 0) {
              ESP_LOGI("4G_RX_TASK", "收到重置命令");
              reset_device_config();
            } else if (strcmp(payload_type->valuestring, "set") == 0) {
              ESP_LOGI("4G_RX_TASK", "收到set类型消息,开始轮询任务1");
              handle_set_message(payload_json);
              char *info = device_basic_info();

              if (info) {
                // 创建一个新的JSON对象，添加status字段
                cJSON *info_json = cJSON_Parse(info);
                if (info_json) {
                  cJSON_AddStringToObject(info_json, "action", "report_info");
                  char *new_info = cJSON_PrintUnformatted(info_json);
                  if (new_info) {
                    char *final_info = malloc(strlen(new_info) + 3);
                    if (final_info) {
                      sprintf(final_info, "%s\r\n", new_info);
                      send4gData("4G_RX_TASK", final_info);
                      free(final_info);
                    }
                    free(new_info);
                  }
                  cJSON_Delete(info_json);
                }
                free(info);
              }
            }
          }
          cJSON_Delete(payload_json);
        }
      }
    } else if (strcmp(type->valuestring, "set") == 0) {
      ESP_LOGI("4G_RX_TASK", "收到set类型消息,开始轮询任务2");
      handle_set_message(json);
      char *info = device_basic_info();

      if (info) {
        // 创建一个新的JSON对象，添加status字段
        cJSON *info_json = cJSON_Parse(info);
        if (info_json) {
          cJSON_AddStringToObject(info_json, "action", "report_info");
          char *new_info = cJSON_PrintUnformatted(info_json);
          if (new_info) {
            char *final_info = malloc(strlen(new_info) + 3);
            if (final_info) {
              sprintf(final_info, "%s\r\n", new_info);
              send4gData("4G_RX_TASK", final_info);
              free(final_info);
            }
            free(new_info);
          }
          cJSON_Delete(info_json);
        }
        free(info);
      }
    } else if (strcmp(type->valuestring, "target") == 0) {
      cJSON *target = cJSON_GetObjectItem(json, "target");
      cJSON *data_obj = cJSON_GetObjectItem(json, "data");
      cJSON *target_url = cJSON_GetObjectItem(json, "target_url");

      if (target && data_obj && target_url && cJSON_IsString(target) &&
          cJSON_IsString(data_obj) && cJSON_IsString(target_url)) {
        // 创建转发消息JSON
        cJSON *forward_msg = cJSON_CreateObject();
        cJSON_AddStringToObject(forward_msg, "type", "target");
        cJSON_AddStringToObject(forward_msg, "target", target->valuestring);
        cJSON_AddStringToObject(forward_msg, "target_url",
                                target_url->valuestring);
        cJSON_AddStringToObject(forward_msg, "data", data_obj->valuestring);

        char *msg_str = cJSON_PrintUnformatted(forward_msg);
        if (msg_str) {
          // 添加换行符
          char *cmd_with_newline = malloc(strlen(msg_str) + 3);
          if (cmd_with_newline) {
            sprintf(cmd_with_newline, "%s\r\n", msg_str);
            sx_log_write_simple("【 4G-MQTT 】发送到目标 (%s): %s",
                                target->valuestring, data_obj->valuestring);

            ESP_LOGI("4G_RX_TASK", "发送485响应到MQTT: %s", cmd_with_newline);
            send4gData("4G_RX_TASK", cmd_with_newline);
            free(cmd_with_newline);
          }
          free(msg_str);
        }
        cJSON_Delete(forward_msg);
      }
    } else if (strcmp(type->valuestring, "mqtt_cmd") == 0) {
      // 处理MQTT命令
      static const char *SEND_4G_CMD = "SEND_4G_CMD";
      cJSON *payload = cJSON_GetObjectItem(json, "payload");
      cJSON *target = cJSON_GetObjectItem(json, "target");

      if (payload && cJSON_IsString(payload) && target &&
          cJSON_IsString(target)) {
        // 将payload转换为十六进制字符串
        size_t length = strlen(payload->valuestring) / 2;
        uint8_t *data = malloc(length);
        if (data) {
          for (size_t i = 0; i < length; i++) {
            sscanf(&payload->valuestring[i * 2], "%2hhx", &data[i]);
          }
          ESP_LOGI(SEND_4G_CMD, "SEND_4G_CMD ->发送命令: %s",
                   payload->valuestring);

          // 发送到485串口
          tx_485_task(data, length);
          free(data);
          ESP_LOGI("4G_RX_TASK", "发送485命令到目标: %s", target->valuestring);
        } else {
          ESP_LOGE("4G_RX_TASK", "内存分配失败");
        }
      } else {
        ESP_LOGE("4G_RX_TASK", "MQTT命令格式不完整");
      }
    }
  }

  cJSON_Delete(json);
}
void rx_4g_task(void *arg) {
  static const char *RX_TASK_TAG = "4G_RX_TASK";
  esp_log_level_set(RX_TASK_TAG, ESP_LOG_INFO);
  uint8_t *data = (uint8_t *)malloc(RX_BUF_SIZE + 1);
  while (1) {
    const int rxBytes = uart_read_bytes(UART_NUM_1, data, RX_BUF_SIZE,
                                        100 / portTICK_PERIOD_MS);
    if (rxBytes > 0) {
      data[rxBytes] = 0;
      ESP_LOGI(RX_TASK_TAG, "Read %d bytes: '%s'", rxBytes, data);

      // 检查是否是JSON数据
      bool is_json = (data[0] == '{' && strchr((char *)data, '}') != NULL);

      if (is_json) {
        // JSON数据直接发送到WebSocket
        char log_buffer[1024];
        snprintf(log_buffer, sizeof(log_buffer), "[4G-JSON] %.*s", rxBytes > 900 ? 900 : rxBytes, (char *)data);
        send_log_to_websocket(log_buffer);

        // 同时写入到ESP32的日志系统 (仅记录前100个字符，避免日志过长)
        sx_log_write_simple("【 4G-JSON 】%.*s%s",
                           rxBytes > 100 ? 100 : rxBytes,
                           (char *)data,
                           rxBytes > 100 ? "..." : "");

        // 如果是JSON数据，解析并存储
        parse_and_store_data((const char *)data);
      } else {
        // 非JSON数据，检查是否是新的日志格式 "4G: 时间戳 标签 消息"
        if (strstr((char *)data, "4G:") != NULL) {
          // 直接发送到WebSocket，不添加额外前缀
          send_log_to_websocket((char *)data);

          // 同时写入到ESP32的日志系统 (仅记录前100个字符，避免日志过长)
          sx_log_write_simple("【 4G-日志 】%.*s%s",
                             rxBytes > 100 ? 100 : rxBytes,
                             (char *)data,
                             rxBytes > 100 ? "..." : "");
        } else {
          // 旧格式日志或其他数据，添加前缀
          char log_buffer[1024];
          snprintf(log_buffer, sizeof(log_buffer), "[4G-LOG] %.*s", rxBytes > 900 ? 900 : rxBytes, (char *)data);
          send_log_to_websocket(log_buffer);

          // 同时写入到ESP32的日志系统 (仅记录前100个字符，避免日志过长)
          sx_log_write_simple("【 4G-日志 】%.*s%s",
                             rxBytes > 100 ? 100 : rxBytes,
                             (char *)data,
                             rxBytes > 100 ? "..." : "");
        }
      }
    }
  }
  free(data);
}

void start_4g_task(void) {
  sx_log_write_simple("【 4G-系统 】开始初始化4G模块");
  turn_on_gpio(RESET4G, 0);
  vTaskDelay(1000 / portTICK_PERIOD_MS);
  printf("+0====================+\n");
  turn_on_gpio(RESET4G, 1);
  turn_on_gpio(POW4G, 1);
  vTaskDelay(1000 / portTICK_PERIOD_MS);
  turn_on_gpio(POW4G, 0);
  vTaskDelay(1000 / portTICK_PERIOD_MS);
  printf("+1====================+\n");
  turn_on_gpio(POW4G, 0);
  printf("+2====================+\n");
  init4g();
  sx_log_write_simple("【 4G-系统 】4G模块初始化完成");
  xTaskCreate(rx_4g_task, "rx_4g_task", 8192, NULL, configMAX_PRIORITIES - 1,
              NULL);
  xTaskCreate(tx_4g_task, "tx_4g_task", 8192, NULL, configMAX_PRIORITIES - 2,
              NULL);
}
