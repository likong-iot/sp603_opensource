
#include "driver/gpio.h"
#include "driver/uart.h"
#include "esp_err.h"
#include "esp_log.h"
#include "esp_system.h"
#include "freertos/FreeRTOS.h"
#include "freertos/mpu_wrappers.h"
#include "freertos/task.h"
#include "hal/uart_types.h"
#include "string.h"

#include "cJSON.h"
#include "driver/gpio.h"
#include "freertos/queue.h"
#include "freertos/ringbuf.h"
#include "nvs.h"
#include "nvs_flash.h"
#include "sx_gpio.h"
#include "sx_log.h"
#include "sx_mqtt_client.h"
#include "sx_tcp_client.h"
#include "sx_tcp_server.h"
#include "sx_utils.h"
#include <stdio.h>
#include <stdlib.h>

// #include "sx_async_uart.h"

// static const int RX_BUF_SIZE = 4096;
uint8_t dataArray[] = {0};
// char global_hex_data_str[256];
// uint8_t *source_data = NULL;
// int lens = 0;
// #define TXD_PIN (GPIO_NUM_1)
// #define RXD_PIN (GPIO_NUM_3)
TaskHandle_t uartTaskHandle = NULL;
#define TXD_PIN (GPIO_NUM_2)
#define RXD_PIN (GPIO_NUM_15)
#define TAG "RS485"
#define BUF_SIZE (512)
// RTS for RS485 Half-Duplex Mode manages DE/~RE
#define ECHO_TEST_RTS 2

// CTS is not used in RS485 Half-Duplex Mode
#define ECHO_TEST_CTS (UART_PIN_NO_CHANGE)

#define ECHO_READ_TOUT (3) // 3.5T * 8 = 28 ticks, TOUT=3 -> ~24..33 ticks
#define PACKET_READ_TICS (100 / portTICK_PERIOD_MS)

// char device_response[512];
uint8_t uart_response[512];

#define RING_BUFFER_SIZE 8192
void stop_rx_task();
void rx_wait();

void uart_configure(int baudrate, uart_word_length_t data_bits,
                    uart_parity_t parity, uart_stop_bits_t stop_bits,
                    int frame_time, int frame_len) {
  uart_parity_t uart_parity = parity;
  uart_word_length_t uart_data_bits = data_bits;
  uart_stop_bits_t uart_stop_bits = stop_bits;
  if (parity == 0) {
    uart_parity = UART_PARITY_DISABLE;
  } else if (parity == 1) {
    uart_parity = UART_PARITY_EVEN;
  } else if (parity == 2) {
    uart_parity = UART_PARITY_ODD;
  }
  if (data_bits == 5) {
    uart_data_bits = UART_DATA_5_BITS;
  } else if (data_bits == 6) {
    uart_data_bits = UART_DATA_6_BITS;
  } else if (data_bits == 7) {
    uart_data_bits = UART_DATA_7_BITS;
  } else if (data_bits == 8) {
    uart_data_bits = UART_DATA_8_BITS;
  }
  if (stop_bits == 1) {
    uart_stop_bits = UART_STOP_BITS_1;
  } else if (stop_bits == 1.5) {
    uart_stop_bits = UART_STOP_BITS_1_5;
  } else if (stop_bits == 2) {
    uart_stop_bits = UART_STOP_BITS_2;
  }
  // uart_config_t uart_config = {
  //     .baud_rate = baudrate,
  //     .data_bits = uart_data_bits,
  //     .parity = uart_parity,
  //     .stop_bits = uart_stop_bits,
  //     .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
  //     .rx_flow_ctrl_thresh = 122,
  //     .source_clk = UART_SCLK_DEFAULT,
  // };

  const uart_config_t uart_config = {
      .baud_rate = 4800,
      .data_bits = UART_DATA_8_BITS,
      .parity = UART_PARITY_DISABLE,
      .stop_bits = UART_STOP_BITS_1,
      .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
      .source_clk = UART_SCLK_DEFAULT,
  };

  uart_driver_install(UART_NUM_2, BUF_SIZE * 2, 0, 0, NULL, 0);
  uart_param_config(UART_NUM_2, &uart_config);
  uart_set_pin(UART_NUM_2, TXD_PIN, RXD_PIN, ECHO_TEST_RTS, UART_PIN_NO_CHANGE);
  ESP_ERROR_CHECK(uart_set_mode(UART_NUM_2, UART_MODE_RS485_HALF_DUPLEX));
  ESP_ERROR_CHECK(uart_set_rx_timeout(UART_NUM_2, ECHO_READ_TOUT));
  // ESP_ERROR_CHECK(uart_set_rx_full_threshold(UART_NUM_2, frame_len));

  rx_wait();
}

void uart_init(void) {
  esp_err_t rets = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
  size_t baud_rate, data_bit, check_bit, stop_bit, frame_time, frame_len = 0;
  rets = nvs_get_str(nvs_handle, "baud_rate", NULL, &baud_rate);
  nvs_get_str(nvs_handle, "data_bit", NULL, &data_bit);
  nvs_get_str(nvs_handle, "check_bit", NULL, &check_bit);
  nvs_get_str(nvs_handle, "stop_bit", NULL, &stop_bit);
  nvs_get_str(nvs_handle, "frame_time", NULL, &frame_time);
  nvs_get_str(nvs_handle, "frame_len", NULL, &frame_len);

  switch (rets) {
  case ESP_OK:
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "baud_rate", "4800"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "data_bit", "8"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "check_bit", "0"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "stop_bit", "1"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "frame_time", "50"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "frame_len", "512"));
    break;
  default:
    break;
  }

  if (rets != ESP_OK) {
    printf("Error getting size of 'SERIAL': %s\n", esp_err_to_name(rets));
  } else {
    char *nvs_baud_rate = malloc(baud_rate);
    char *nvs_data_bit = malloc(data_bit);
    char *nvs_check_bit = malloc(check_bit);
    char *nvs_stop_bit = malloc(stop_bit);
    char *nvs_frame_time = malloc(frame_time);
    char *nvs_frame_len = malloc(frame_len);

    if (nvs_baud_rate == NULL) {
      printf("Memory allocation failed\n");
    } else {
      rets = nvs_get_str(nvs_handle, "baud_rate", nvs_baud_rate, &baud_rate);
      nvs_get_str(nvs_handle, "data_bit", nvs_data_bit, &data_bit);
      nvs_get_str(nvs_handle, "check_bit", nvs_check_bit, &check_bit);
      nvs_get_str(nvs_handle, "stop_bit", nvs_stop_bit, &stop_bit);
      nvs_get_str(nvs_handle, "frame_time", nvs_frame_time, &frame_time);
      nvs_get_str(nvs_handle, "frame_len", nvs_frame_len, &frame_len);

      if (rets == ESP_OK) {
        int baudrate = atoi(nvs_baud_rate);
        uart_word_length_t uart_data_bits = atoi(nvs_data_bit);
        uart_parity_t uart_parity = atoi(nvs_check_bit);
        uart_stop_bits_t uart_stop_bits = atof(nvs_stop_bit);
        int frame_time = atoi(nvs_frame_time);
        int frame_len = atoi(nvs_frame_len);

        uart_configure(baudrate, uart_data_bits, uart_parity, uart_stop_bits,
                       frame_time, frame_len);
      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(rets));
      }

      free(nvs_baud_rate);
      free(nvs_data_bit);
      free(nvs_check_bit);
      free(nvs_stop_bit);
      free(nvs_frame_time);
      free(nvs_frame_len);
    }
  }

  nvs_close(nvs_handle);
}

void uart_reinit(int baudrate, uart_word_length_t data_bits,
                 uart_parity_t parity, uart_stop_bits_t stop_bits,
                 int frame_time, int frame_len) {
  stop_rx_task();
  printf("Reinit UART\n");
  printf("Baudrate: %d\n", baudrate);
  printf("Data bits: %d\n", data_bits);
  printf("Parity: %d\n", parity);
  printf("Stop bits: %d\n", stop_bits);

  uart_driver_delete(UART_NUM_2);
  uart_configure(baudrate, data_bits, parity, stop_bits, frame_time, frame_len);
  // rx_wait();
}

// static int echo_send(const int port, const char* str, uint8_t length)
// {
//     int ret = uart_write_bytes(port, str, length);
//     if (ret != length) {
//         ESP_LOGE(TAG, "Send data critical failure.");
//         abort();
//     }
//     return ret;
// }

// int sendData(char *data, size_t length) {
//   // uart_flush(UART_NUM_2);
//   gpio_set_pull_mode(GPIO_NUM_4, GPIO_PULLUP_ONLY);

//   int txBytes = echo_send(UART_NUM_2, data, length);
//   esp_err_t err = uart_wait_tx_done(UART_NUM_2, 200 / portTICK_PERIOD_MS);
//   if (err == ESP_OK) {
//     gpio_set_pull_mode(GPIO_NUM_4, GPIO_PULLDOWN_ONLY);
//   } else {
//     gpio_set_pull_mode(GPIO_NUM_4, GPIO_PULLUP_ONLY);
//   }
//   return txBytes;
// }

static void echo_send(const int port, const char *str, uint8_t length) {
  if (uart_write_bytes(port, str, length) != length) {
    abort();
  }
}

int sendData(char *data, size_t length) {
  const int txBytes = uart_write_bytes(UART_NUM_2, data, length);
  sx_log_write_simple("[ 网关-串口 ] %.*s\n", length, data);

  // printf("txBytes-> %d\n", txBytes);
  uart_wait_tx_done(UART_NUM_2, 100);
  return txBytes;
}

void tx_task(uint8_t data[], size_t length) {
  static const char *TX_TASK_TAG = "TX_TASK";
  printf("TX_TASK\n");
  LED_DAT_ON();
  LED_DAT_OFF();
  esp_log_level_set(TX_TASK_TAG, ESP_LOG_INFO);
  // printf("111111111111111111111111\n");
  sendData((char *)data, length);
  // printf("222222222222222222222222\n");
  LED_DAT_ON();
  LED_DAT_OFF();
  // vTaskDelete(NULL);
}

void tx_tasks(uint8_t data[], size_t length) {
  static const char *TX_TASK_TAG = "TX_TASK";
  printf("TX_TASK\n");
  LED_DAT_ON();
  LED_DAT_OFF();
  esp_log_level_set(TX_TASK_TAG, ESP_LOG_INFO);
  sendData((char *)data, length);
  LED_DAT_ON();
  LED_DAT_OFF();
  // vTaskDelete(NULL);
}

static void rx_task(void *arg) {
  static const char *RX_TASK_TAG = "RX_TASK";
  esp_log_level_set(RX_TASK_TAG, ESP_LOG_INFO);
  int u_mqtt, u_tcp, u_tcpconn = 0;
  // uint8_t *data = (uint8_t *)malloc(RX_BUF_SIZE + 1);
  uint8_t *data = (uint8_t *)malloc(BUF_SIZE);
  esp_err_t ret = nvs_flash_init();
  if (ret == ESP_ERR_NVS_NO_FREE_PAGES ||
      ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
    ESP_ERROR_CHECK(nvs_flash_erase());
    ret = nvs_flash_init();
  }
  ESP_ERROR_CHECK(ret);
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
  size_t use_mqtt, use_tcp, tcpconn = 0;
  ret = nvs_get_str(nvs_handle, "use_mqtt", NULL, &use_mqtt);
  nvs_get_str(nvs_handle, "use_tcp", NULL, &use_tcp);
  nvs_get_str(nvs_handle, "tcpconn", NULL, &tcpconn);
  switch (ret) {
  case ESP_OK:
    printf("MQTT set success");
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    printf("no MQTT set");
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "use_mqtt", "1"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_type", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_server", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_port", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_username", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_password", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_clientid", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_sub_topic", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_pub_topic", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "qos", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "retain", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_send", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_time", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqttconn", ""));
    break;
  default:
    break;
  }
  char *nvs_use_mqtt = malloc(use_mqtt);
  char *nvs_use_tcp = malloc(use_tcp);
  char *nvs_tcpconn = malloc(tcpconn);
  nvs_get_str(nvs_handle, "use_mqtt", nvs_use_mqtt, &use_mqtt);
  nvs_get_str(nvs_handle, "use_tcp", nvs_use_tcp, &use_tcp);
  nvs_get_str(nvs_handle, "tcpconn", nvs_tcpconn, &tcpconn);
  u_mqtt = 1;
  u_tcp = 0;
  u_tcpconn = 0;
  free(nvs_use_mqtt);
  free(nvs_use_tcp);
  free(nvs_tcpconn);
  nvs_close(nvs_handle);
  while (1) {
    if (uartTaskHandle != NULL && eTaskGetState(uartTaskHandle) == eDeleted) {
      break;
    }
    size_t buffered_size;
    uart_get_buffered_data_len(UART_NUM_2, &buffered_size);
    if (buffered_size < 8192) {

      const int rxBytes =
          uart_read_bytes(UART_NUM_2, data, BUF_SIZE, PACKET_READ_TICS);
      if (rxBytes > 0) {
        LED_DAT_ON();
        LED_DAT_OFF();
        data[rxBytes] = 0;
        ESP_LOGI(RX_TASK_TAG, "Read %d bytes: '%s'", rxBytes, data);
        sx_log_write_simple("[ 串口-网关] %.*s\n", rxBytes, data);
        printf("===============\n");
        ESP_LOG_BUFFER_HEXDUMP(RX_TASK_TAG, data, rxBytes, ESP_LOG_INFO);
        ESP_LOG_BUFFER_CHAR(RX_TASK_TAG, data, rxBytes);
        // mqtt_send_message_by_name("mqtt1", (char *)data, rxBytes);
        if (u_mqtt == 1) {
          printf("uuuu_mqtt-> %d\n", u_mqtt);
          // mqtt_public_send_device_info(data, rxBytes);
        }
        if (u_tcp == 1) {
          printf("uuuu_tcpconn-> %d\n", u_tcpconn);
          if (u_tcpconn == 0) {

            tcpserver_message((char *)data, rxBytes);
          }
          if (u_tcpconn == 1) {
            tcpclient_message((char *)data, rxBytes);
          }
        }
        for (int i = 0; i < rxBytes; i++) {
          uart_response[i] = data[i];
        }
        LED_DAT_ON();
        LED_DAT_OFF();
      }
      // uart_flush(UART_NUM_2);
    } else {
      // while (buffered_size >= 8192) {
      //   vTaskDelay(10 / portTICK_PERIOD_MS);
      //   uart_get_buffered_data_len(UART_NUM_2, &buffered_size);
      // }
      uart_wait_tx_done(UART_NUM_2, 10);
    }
  }
  free(data);
  vTaskDelete(NULL);
}

void stop_rx_task() {
  if (uartTaskHandle != NULL) {
    vTaskDelete(uartTaskHandle);
    uartTaskHandle = NULL;
  }
}

void rx_wait() {
  xTaskCreate(rx_task, "uart_tx_task", 2048 * 2, NULL, configMAX_PRIORITIES - 2,
              &uartTaskHandle);
}
