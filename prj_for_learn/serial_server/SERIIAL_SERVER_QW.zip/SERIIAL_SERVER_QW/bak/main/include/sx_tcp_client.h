/*
 * @Author: Orion
 * @Date: 2024-01-11 11:20:48
 * @LastEditors: Orion
 * @LastEditTime: 2024-07-02 01:08:48
 * @FilePath: \SERIIAL_SERVER\main\include\sx_tcp_client.h
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */

#pragma once

#ifdef __cplusplus
extern "C" {
#endif
void start_tcp_client(void);
void tcpclient_message(char *message,int rxBytes);
extern int global_client_sock;
extern int global_tcp_server;
#ifdef __cplusplus
}
#endif
