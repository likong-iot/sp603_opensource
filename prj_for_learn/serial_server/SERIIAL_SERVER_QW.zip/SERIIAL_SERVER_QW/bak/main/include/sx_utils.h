/*
 * @Author: Orion
 * @Date: 2024-01-11 11:21:24
 * @LastEditors: Orion
 * @LastEditTime: 2024-11-14 17:14:10
 * @FilePath: \SERIIAL_SERVER\main\include\sx_utils.h
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */

#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#include "esp_system.h"
void urlDecode(char *src, char *dest);
void save_form_data(const char *query);
char *reset_reason_to_string(esp_reset_reason_t reason);
esp_err_t nvs_init();
void save_to_nvs(const char *json_string);
double pressure_to_altitude(double pressure);

extern char messageid[48];

char *send_device_info(uint8_t *u_data, int idx);
char *send_device_info_err(void);
char *send_device_ip(void);

esp_err_t nvs_reset_clear();
void protocol_select();
void eth_disconnect();
void simple_task();
char *device_basic_info(void);
#ifdef __cplusplus
}
#endif
