




#pragma once

#ifdef __cplusplus
extern "C" {
#endif
#include <esp_err.h>
#include <stdbool.h>
esp_err_t http_send_data(const char *url, const char *hex_data, const char *target_name);
bool is_http_target(const char *url);
#ifdef __cplusplus
}
#endif
