/*
 * @Author: Orion
 * @Date: 2024-10-24 17:02:36
 * @LastEditors: Orion
 * @LastEditTime: 2025-01-08 17:19:12
 * @Description:
 *
 */

#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#include "cJSON.h"
#include "driver/uart.h"

void tx_485_task(uint8_t data[], size_t length);
int send_485_data(char *data, size_t length);
void init_485_uart(void);

void reinit_485_uart(int baudrate, uart_word_length_t data_bits,
                     uart_parity_t parity, uart_stop_bits_t stop_bits,
                     int frame_time, int frame_len);

// 命令配置结构体
typedef struct {
  uint8_t *data;
  size_t length;
  char **targets;
  int target_count;
} cmd_config_t;

// 点配置结构体
typedef struct {
  char *com;          // COM配置字符串
  cmd_config_t *cmds; // 命令数组
  int cmd_count;      // 命令数量
  int interval;       // 点间隔时间
} point_config_t;

// 全局配置结构体
typedef struct {
  char *global_com;       // 全局COM配置
  int loop_interval;      // 循环间隔时间
  int global_interval;    // 全局点间隔时间
  point_config_t *points; // 点配置数组
  int point_count;        // 点数量
} uart_loop_config_t;

typedef struct {
    uint32_t send_frame_success;
    uint32_t send_byte_success;
    uint32_t recv_frame_success;
    uint32_t recv_byte_success;
} uart_stats_t;


typedef struct {
    char name[32];
    uint32_t send_frame_success;
    uint32_t send_byte_success;
    uint32_t send_frame_failed;
    uint32_t send_byte_failed;
    uint32_t recv_frame;
    uint32_t recv_byte;
} target_stats_t;

#define MAX_TARGETS 10
extern target_stats_t target_stats[MAX_TARGETS];
extern int target_stats_count;
extern uart_stats_t uart_stats;
// 添加统计函数声明
void update_target_stats(const char *name, bool is_success, size_t bytes, bool is_recv);

void start_uart_loop_task(const cJSON *json_data);
void stop_uart_loop_task(void);
void parse_com_settings(const char *com_str, int *baudrate,
                        uart_parity_t *parity, uart_word_length_t *data_bits,
                        uart_stop_bits_t *stop_bits);
void tx_485_task_with_targets(uint8_t data[], size_t length,
                              const char **targets, int target_count);
bool add_http_target(const char *name, const char *url);
void clear_http_targets(void);
void rx_485_task();
void set_current_targets(const char **targets, int count);
extern TaskHandle_t uart485TaskHandle;

#define TXD_PIN_485 (GPIO_NUM_2)
#define RXD_PIN_485 (GPIO_NUM_15)
#define TXD_PIN_232 (GPIO_NUM_4)
#define RXD_PIN_232 (GPIO_NUM_35)
#define ECHO_TEST_RTS 2
#define ECHO_TEST_CTS (UART_PIN_NO_CHANGE)
#define ECHO_READ_TOUT (3)

#ifdef __cplusplus
}
#endif
