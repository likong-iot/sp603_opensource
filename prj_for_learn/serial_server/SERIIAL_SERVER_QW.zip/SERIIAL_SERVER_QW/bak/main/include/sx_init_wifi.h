/*
 * @Author: Orion
 * @Date: 2024-01-11 11:20:16
 * @LastEditors: Orion
 * @LastEditTime: 2024-09-03 14:34:03
 * @FilePath: \SERIIAL_SERVER\main\include\sx_init_wifi.h
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */

#pragma once

#ifdef __cplusplus
extern "C" {
#endif

void wifi_init_sta(const char *w_ssid, const char *w_passwd);
void start_wifi_task(const char *ssid, const char *password);
extern int is_netif_initialized;
#ifdef __cplusplus
}
#endif
