/*
 * @Author: Orion
 * @Date: 2024-01-18 14:06:11
 * @LastEditors: Orion
 * @LastEditTime: 2024-09-03 14:02:47
 * @FilePath: \SERIIAL_SERVER\main\include\sx_udp_server.h
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */

#pragma once

#ifdef __cplusplus
extern "C" {
#endif
void start_udp_server(void);
void kill_udp_server(void);
#ifdef __cplusplus
}
#endif
