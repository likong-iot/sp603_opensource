/*
 * @Author: Orion
 * @Date: 2024-01-18 14:06:39
 * @LastEditors: Orion
 * @LastEditTime: 2024-05-08 15:36:28
 * @FilePath: \SERIIAL_SERVER\main\include\sx_udp_client.h
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */

#pragma once

#ifdef __cplusplus
extern "C" {
#endif
void start_udp_client(void);
#ifdef __cplusplus
}
#endif
