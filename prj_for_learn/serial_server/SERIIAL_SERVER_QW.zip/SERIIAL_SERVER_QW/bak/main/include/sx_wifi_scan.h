

#pragma once

#ifdef __cplusplus
extern "C" {
#endif
#include "esp_wifi.h"

#define DEFAULT_SCAN_LIST_SIZE 10

typedef struct {
  uint16_t ap_count;
  wifi_ap_record_t ap_info[DEFAULT_SCAN_LIST_SIZE];
} WifiValueList;

WifiValueList wifiSearchValue();
#ifdef __cplusplus
}
#endif
