/*
 * @Author: Orion
 * @Date: 2024-05-08 16:08:44
 * @LastEditors: Orion
 * @LastEditTime: 2024-07-01 18:42:47
 * @FilePath: \SERIIAL_SERVER_P\main\include\sx_async_uart.h
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */

#pragma once

#ifdef __cplusplus
extern "C" {
#endif
#include "hal/uart_types.h"
#include "freertos/FreeRTOS.h"
#include "freertos/mpu_wrappers.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
// #include <stdint.h>
void uart_init(void);
// char *tx_task(uint8_t data[], size_t length);
void tx_task(uint8_t data[], size_t length);
void tx_tasks(uint8_t data[], size_t length);
// void tcp_tx_task(char *data, size_t length);
int sendData(char *data, size_t length);
// void rx_task(void *arg);
extern uint8_t dataArray[];
void uart_reinit(int baudrate, uart_word_length_t data_bits,
                 uart_parity_t parity, uart_stop_bits_t stop_bits,int frame_time,int frame_len);
// void rx_task(void *arg);
void rx_wait();
void stop_rx_task();
// extern char device_response[256];
extern uint8_t uart_response[512];
extern char *hex_data_str;
extern SemaphoreHandle_t xSemaphore;

#ifdef __cplusplus
}
#endif
