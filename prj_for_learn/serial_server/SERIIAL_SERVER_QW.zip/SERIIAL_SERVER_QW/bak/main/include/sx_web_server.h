/*
 * @Author: Orion
 * @Date: 2024-01-23 16:10:01
 * @LastEditors: Orion
 * @LastEditTime: 2025-02-26 22:21:37
 * @FilePath: \SERIIAL_SERVER\main\include\sx_web_server.h
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */

#pragma once

#ifdef __cplusplus
extern "C" {
#endif
#include <stdint.h>
extern char dIp[20];
extern char dNetmask[20];
extern char dGateway[20];
extern uint8_t mac_addr[6];
extern char device_mac[30];
extern char th[20];
extern char device_mac_end[20];
extern char got_ip_addrs[16];
extern char got_ip_netmask[16];
extern char got_ip_gw[16];
extern int httpreason;
extern char device_sta_mac[24];
extern char device_eth_mac[24];
void http_server_init(void);
void send_log_to_websocket(const char* log_msg);
// #define VERSION "1.0.7-release"
#define VERSION "SDK:1.0.1_HW:1.0.0"
#define DEVICE_TYPE "WXNG1"
#define CLIENT_HEAD "WXNG1"
#ifdef __cplusplus
}
#endif
