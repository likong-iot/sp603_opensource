/*
 * @Author: Orion
 * @Date: 2024-05-07 16:29:37
 * @LastEditors: Orion
 * @LastEditTime: 2024-05-07 16:29:42
 * @FilePath: \SERIIAL_SERVER\main\include\sx_time.h
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */
#pragma once

#ifdef __cplusplus
extern "C" {
#endif

void http_get_current_time_task(void *pvParameters);

extern char strftime_buf[64];

#ifdef __cplusplus
}
#endif
