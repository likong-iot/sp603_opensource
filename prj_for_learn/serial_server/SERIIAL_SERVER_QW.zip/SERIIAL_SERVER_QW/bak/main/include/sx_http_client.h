/*
 * @Author: Orion
 * @Date: 2024-01-11 11:19:54
 * @LastEditors: Orion
 * @LastEditTime: 2024-05-08 15:37:35
 * @FilePath: \SERIIAL_SERVER\main\include\sx_http_client.h
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */

#pragma once

#ifdef __cplusplus
extern "C" {
#endif
void http_test_task(void *pvParameters);

#ifdef __cplusplus
}
#endif
