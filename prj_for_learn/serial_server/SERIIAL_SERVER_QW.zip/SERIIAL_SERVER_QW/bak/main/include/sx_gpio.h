/*
 * @Author: Orion
 * @Date: 2024-02-03 11:26:54
 * @LastEditors: Orion
 * @LastEditTime: 2025-01-11 13:38:03
 * @FilePath: \SERIIAL_SERVER\main\include\sx_gpio.h
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */

#pragma once

#ifdef __cplusplus
extern "C" {
#endif
#include <stdint.h>
// #define LED GPIO_NUM_4
// #define LED0 GPIO_NUM_13
#define KEY GPIO_NUM_34
#define LED_LAN GPIO_NUM_14
#define LED_WIFI GPIO_NUM_13
#define LED_DAT GPIO_NUM_15


#define SCK_GPIO_PIN GPIO_NUM_14 // 移位寄存器时钟线引脚 (SHCP)
#define RCK_GPIO_PIN GPIO_NUM_12 // 存储寄存器时钟线引脚 (STCP)
#define SDA_GPIO_PIN GPIO_NUM_13 // 数据引脚 (DS)

// 74HC595 GPIO DEFINE
#define RESET4G 0
#define POW4G 1
#define LED4G 6
#define LEDNET 3
#define LEDWIFI 2
#define LED485 5
#define LEDLAN 4
// #define LED4G_2 2
// #define LEDWIFI 3
// #define LED4G_3 4
// #define LED485 5
// #define LED4G_1 6
// #define LEDLAN 7
// #define RESET4G 0
// #define POW4G 1
// #define LED4G 2
// #define LEDNET 3
// #define LEDWIFI 4
// #define LED485 5
// #define LEDLAN 6



extern uint16_t KeyState, LED_LAN_STATE, LED_WIFI_STATE, LED_DAT_STATE;

void LED_LAN_ON();
void LED_LAN_OFF();
void LED_WIFI_ON();
void LED_WIFI_OFF();
void LED_DAT_ON();
void LED_DAT_OFF();
void init_gpio();
void turn_on_gpio(uint8_t led_index, uint8_t state);
void shift_register_init();
void blink_rx_tx_led();
void blink_net_led();
#ifdef __cplusplus
}
#endif
