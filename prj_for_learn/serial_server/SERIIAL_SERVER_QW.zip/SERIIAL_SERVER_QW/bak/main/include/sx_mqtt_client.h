/*
 * @Author: Orion
 * @Date: 2024-01-11 11:20:29
 * @LastEditors: Orion
 * @LastEditTime: 2025-01-03 15:10:51
 * @FilePath: \SERIIAL_SERVER\main\include\sx_mqtt_client.h
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */
#pragma once

// #include <vadefs.h>
#ifdef __cplusplus
extern "C" {
#endif
#include <stdint.h>
#include <esp_err.h>
#include <stdbool.h>
#include "cJSON.h"
#include "mqtt_client.h"
void mqtt_app_start(void);
int aiot_platform_publish_topic(const char *topic, const char *data, int len,
                                int qos, int retain);
// void mqtt_public_send_device_info(uint8_t *u_data, int idx);

void mqtt_public_send_device_info(void);

// 获取已连接的MQTT目标数量
int get_mqtt_target_count(void);
// char* get_target_url(const char* target_name);

// 获取指定索引的MQTT目标名称
const char* get_mqtt_target_name(int index);

int mqtt_send_message_by_name(const char* name, const char* message,int rxBytes);
extern char *mqtt_data_buffer;
cJSON *load_config_from_nvs(void);
esp_err_t save_config_to_nvs(const cJSON *json_data);
void handle_set_message(cJSON *json_data);
void reset_device_config(void);
void mqtt_public_send_device_info(void);
int mqtt_4g_publish(const char *topic, const char *data, int qos);


typedef struct {
    char name[32];
    char url[128];
    char clientid[32];
    char pub_topic[100];
    char sub_topic[100];
    esp_mqtt_client_handle_t client;
} mqtt_target_t;

#define MAX_MQTT_TARGETS 10

extern mqtt_target_t mqtt_targets[MAX_MQTT_TARGETS];
extern int mqtt_target_count;
#ifdef __cplusplus
}
#endif
