/*
 * @Author: Orion
 * @Date: 2024-01-23 16:08:51
 * @LastEditors: Orion
 * @LastEditTime: 2025-03-07 15:02:51
 * @FilePath: \SERIIAL_SERVER_P\main\sx_utils.c
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */

#include "cJSON.h"
#include "esp_log.h"
#include "esp_system.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"
#include "freertos/task.h"
#include "math.h"
#include "nvs.h"
#include "nvs_flash.h"
#include "sx_485_uart.h"
#include "sx_gpio.h"
#include "sx_http_client.h"
#include "sx_mqtt_client.h"
#include "sx_task.h"
#include "sx_tcp_client.h"
#include "sx_tcp_server.h"
#include "sx_time.h"
#include "sx_udp_client.h"

// #include "sx_async_uart.h"
#include "sx_udp_server.h"
#include "sx_web_server.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

TaskHandle_t xHandleTask1, xHandleTask2, xHandleTask3 = NULL;
char messageid[48] = {0};

/*************************************************************************************/
/*                                START OF FILE */
/*************************************************************************************/

// 函数用于将十六进制字符转换为对应的十进制数
int hexCharToInt(char c) {
  if (c >= '0' && c <= '9') {
    return c - '0';
  }
  if (c >= 'A' && c <= 'F') {
    return c - 'A' + 10;
  }
  if (c >= 'a' && c <= 'f') {
    return c - 'a' + 10;
  }
  return 0;
}

// URL 解码函数
void urlDecode(char *src, char *dest) {
  char *pSrc = src;
  char *pDest = dest;

  while (*pSrc) {
    if (*pSrc == '%') {
      if (pSrc[1] && pSrc[2]) {
        *pDest++ = hexCharToInt(pSrc[1]) * 16 + hexCharToInt(pSrc[2]);
        pSrc += 3;
      }
    } else if (*pSrc == '+') { // 处理空格（空格有时被编码为+）
      *pDest++ = ' ';
      pSrc++;
    } else {
      *pDest++ = *pSrc++;
    }
  }

  *pDest = '\0';
}

void save_form_data(const char *query) {

  esp_err_t err = nvs_flash_init();
  if (err == ESP_ERR_NVS_NO_FREE_PAGES ||
      err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
    ESP_ERROR_CHECK(nvs_flash_erase());
    err = nvs_flash_init();
  }
  ESP_ERROR_CHECK(err);
  // 打开NVS命名空间
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
  char *params = strdup(query); // 为了不修改原字符串
  char *param;

  // 按 & 分割字符串
  param = strtok(params, "&");
  while (param != NULL) {
    // 找到键和值的分隔符 '='
    char *delimiter = strchr(param, '=');
    if (delimiter != NULL) {
      // 分割键和值
      *delimiter = '\0';
      char *key = param;
      char *value = delimiter + 1;
      // 打印键和值
      printf("Key: %s, Value: %s\n", key, value);
      ESP_ERROR_CHECK(nvs_set_str(nvs_handle, key, value));
    }
    // 继续获取下一个参数
    param = strtok(NULL, "&");
    ESP_ERROR_CHECK(nvs_commit(nvs_handle));
  }

  nvs_close(nvs_handle);

  free(params); // 释放复制的字符串
}

char *reset_reason_to_string(esp_reset_reason_t reason) {
  switch (reason) {
  case ESP_RST_UNKNOWN:
    return "Unknown";
  case ESP_RST_POWERON:
    return "Power-on reset";
  case ESP_RST_EXT:
    return "External reset";
  case ESP_RST_SW:
    return "Software reset";
  case ESP_RST_PANIC:
    return "Exception/panic reset";
  case ESP_RST_INT_WDT:
    return "Watchdog reset";
  case ESP_RST_TASK_WDT:
    return "Task watchdog reset";
  case ESP_RST_WDT:
    return "Other watchdog reset";
  case ESP_RST_DEEPSLEEP:
    return "Exited deep sleep";
  case ESP_RST_BROWNOUT:
    return "Brownout reset";
  case ESP_RST_SDIO:
    return "SDIO reset";
  default:
    return "Unknown";
  }
}

uint16_t ModbusCRC16(uint8_t *data, uint16_t length) {
  uint16_t crc = 0xFFFF;
  for (int pos = 0; pos < length; pos++) {
    crc ^= (uint16_t)data[pos];    // XOR byte into least sig. byte of crc
    for (int i = 8; i != 0; i--) { // Loop over each bit
      if ((crc & 0x0001) != 0) {   // If the LSB is set
        crc >>= 1;                 // Shift right and XOR 0xA001
        crc ^= 0xA001;
      } else       // Else LSB is not set
        crc >>= 1; // Just shift right
    }
  }
  return crc;
}

// 初始化 NVS
esp_err_t nvs_init() {
  esp_err_t ret = nvs_flash_init();
  if (ret == ESP_ERR_NVS_NO_FREE_PAGES ||
      ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
    ESP_ERROR_CHECK(nvs_flash_erase());
    ret = nvs_flash_init();
  }
  return ret;
}

void save_to_nvs(const char *json_string) {
  nvs_handle_t nvs_handle;
  esp_err_t err;
  // 打开 NVS
  err = nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle);
  if (err != ESP_OK) {
    printf("Error (%s) opening NVS handle!\n", esp_err_to_name(err));
    return;
  } else {
    printf("Opened NVS handle\n");
  }

  // 解析 JSON
  cJSON *json = cJSON_Parse(json_string);
  if (json == NULL) {
    const char *error_ptr = cJSON_GetErrorPtr();
    if (error_ptr != NULL) {
      fprintf(stderr, "Error before: %s\n", error_ptr);
    }
    nvs_close(nvs_handle);
    // free(json);
    cJSON_Delete(json);
    return;
  }

  // 遍历 JSON 对象
  cJSON *current_element = NULL;
  cJSON_ArrayForEach(current_element, json) {
    if (cJSON_IsString(current_element) &&
        (current_element->valuestring != NULL)) {
      // 保存字符串
      err = nvs_set_str(nvs_handle, current_element->string,
                        current_element->valuestring);
      if (err != ESP_OK) {
        printf("Failed to write %s to NVS\n", current_element->string);
      }
    } else if (cJSON_IsNumber(current_element)) {
      // 保存整数
      err = nvs_set_i32(nvs_handle, current_element->string,
                        current_element->valueint);
      if (err != ESP_OK) {
        printf("Failed to write %s to NVS\n", current_element->string);
      }
    }
  }

  // 提交写入操作
  err = nvs_commit(nvs_handle);
  if (err != ESP_OK) {
    printf("Failed to commit changes!\n");
  }

  // 清理
  cJSON_Delete(current_element);
  cJSON_Delete(json);

  nvs_close(nvs_handle);
}

// 发送设备信息
char *device_basic_info(void) {
  cJSON *root = cJSON_CreateObject();
  uint64_t time_since_boot = esp_timer_get_time();
  uint64_t time_in_s = time_since_boot / 1000000;

  // 从 VERSION 字符串中解析软件版本和硬件版本
  char *version_str = strdup(VERSION);
  char *sdk_ver = NULL;
  char *hw_ver = NULL;

  // 查找 "SDK:" 和 "HW:" 的位置
  char *sdk_pos = strstr(version_str, "SDK:");
  char *hw_pos = strstr(version_str, "HW:");

  if (sdk_pos && hw_pos) {
    sdk_pos += 4; // 跳过 "SDK:"
    hw_pos += 3;  // 跳过 "HW:"

    // 提取软件版本
    char *underscore = strchr(sdk_pos, '_');
    if (underscore) {
      *underscore = '\0';
      sdk_ver = strdup(sdk_pos);
    }

    // 提取硬件版本
    hw_ver = strdup(hw_pos);
  }

  // 添加 "sys" 对象
  cJSON *sys = cJSON_CreateObject();
  cJSON_AddStringToObject(sys, "model", DEVICE_TYPE);

  // 从NVS读取last_config时间
  nvs_handle_t nvs_handle;
  esp_err_t ret = nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle);
  if (ret == ESP_OK) {
    size_t md5_size = 0;
    ret = nvs_get_str(nvs_handle, "config_md5", NULL, &md5_size);
    if (ret == ESP_OK && md5_size > 0) {
      char *config_md5 = malloc(md5_size);
      if (config_md5) {
        if (nvs_get_str(nvs_handle, "config_md5", config_md5, &md5_size) ==
            ESP_OK) {
          cJSON_AddStringToObject(sys, "config_md5", config_md5);
        }
        free(config_md5);
      }
    } else {
      cJSON_AddStringToObject(sys, "config_md5",
                              ""); // 如果没有保存过配置，返回空字符串
    }
    size_t last_config_size = 0;
    ret = nvs_get_str(nvs_handle, "last_config", NULL, &last_config_size);
    if (ret == ESP_OK && last_config_size > 0) {
      char *last_config = malloc(last_config_size);
      if (last_config) {
        if (nvs_get_str(nvs_handle, "last_config", last_config,
                        &last_config_size) == ESP_OK) {
          cJSON_AddStringToObject(sys, "last_config", last_config);
        }
        free(last_config);
      }
    } else {
      cJSON_AddStringToObject(sys, "last_config", "");
    }
  }

  cJSON_AddStringToObject(sys, "hard_ver", hw_ver ? hw_ver : "1.0.0");
  cJSON_AddStringToObject(sys, "soft_ver", sdk_ver ? sdk_ver : "1.0.0");
  cJSON_AddNumberToObject(sys, "runtime", time_in_s);
  cJSON_AddItemToObject(root, "sys", sys);

  // 清理内存
  free(version_str);
  if (sdk_ver)
    free(sdk_ver);
  if (hw_ver)
    free(hw_ver);

  // 添加 "net" 对象
  cJSON *net = cJSON_CreateObject();

  // 从NVS读取网络配置
  if (ret == ESP_OK) {
    size_t netconn, wifi_ssid, is_dhcp, static_dns1, static_dns2 = 0;
    ret = nvs_get_str(nvs_handle, "netconn", NULL, &netconn);
    nvs_get_str(nvs_handle, "is_dhcp", NULL, &is_dhcp);
    nvs_get_str(nvs_handle, "wifi_ssid", NULL, &wifi_ssid);
    nvs_get_str(nvs_handle, "static_dns1", NULL, &static_dns1);
    nvs_get_str(nvs_handle, "static_dns2", NULL, &static_dns2);

    char *nvs_netconn = malloc(netconn);
    char *nvs_wifi_ssid = malloc(wifi_ssid);
    char *nvs_is_dhcp = malloc(is_dhcp);
    char *nvs_static_dns1 = malloc(static_dns1);
    char *nvs_static_dns2 = malloc(static_dns2);

    if (nvs_netconn && nvs_wifi_ssid && nvs_is_dhcp && nvs_static_dns1 &&
        nvs_static_dns2) {
      nvs_get_str(nvs_handle, "netconn", nvs_netconn, &netconn);
      nvs_get_str(nvs_handle, "wifi_ssid", nvs_wifi_ssid, &wifi_ssid);
      nvs_get_str(nvs_handle, "is_dhcp", nvs_is_dhcp, &is_dhcp);
      nvs_get_str(nvs_handle, "static_dns1", nvs_static_dns1, &static_dns1);
      nvs_get_str(nvs_handle, "static_dns2", nvs_static_dns2, &static_dns2);

      // 根据网络类型设置相应的值
      if (atoi(nvs_netconn) == 2) {
        cJSON_AddStringToObject(net, "type", "wifi");
        cJSON_AddStringToObject(net, "ssid", nvs_wifi_ssid);
      } else if (atoi(nvs_netconn) == 3) {
        cJSON_AddStringToObject(net, "type", "4g");
        cJSON_AddStringToObject(net, "lon", "---");
        cJSON_AddStringToObject(net, "lat", "---");
      } else {
        cJSON_AddStringToObject(net, "type", "eth");
        cJSON_AddStringToObject(net, "ssid", "---");
      }

      cJSON_AddStringToObject(net, "eth_mac", device_eth_mac);
      cJSON_AddStringToObject(net, "sta_mac", device_sta_mac);
      cJSON_AddStringToObject(net, "ip", got_ip_addrs);
      cJSON_AddStringToObject(net, "nm", got_ip_netmask);
      cJSON_AddStringToObject(net, "gw", got_ip_gw);
      cJSON_AddNumberToObject(net, "dhcp", atoi(nvs_is_dhcp) == 2 ? 0 : 1);
      if (atoi(nvs_is_dhcp) == 1) {
        cJSON_AddStringToObject(net, "dns1", "---");
        cJSON_AddStringToObject(net, "dns2", "---");
      } else {
        cJSON_AddStringToObject(net, "dns1", nvs_static_dns1);
        cJSON_AddStringToObject(net, "dns2", nvs_static_dns2);
      }
      free(nvs_netconn);
      free(nvs_wifi_ssid);
      free(nvs_is_dhcp);
      free(nvs_static_dns1);
      free(nvs_static_dns2);
    }
  } else { // 没有NVS配置的情况，使用默认值
    // 默认使用以太网
    cJSON_AddStringToObject(net, "type", "eth");
    cJSON_AddStringToObject(net, "ssid", "---");
    cJSON_AddStringToObject(net, "eth_mac", device_eth_mac);
    cJSON_AddStringToObject(net, "sta_mac", device_sta_mac);
    cJSON_AddStringToObject(net, "ip", got_ip_addrs);
    cJSON_AddStringToObject(net, "nm", got_ip_netmask);
    cJSON_AddStringToObject(net, "gw", got_ip_gw);
    cJSON_AddNumberToObject(net, "dhcp", 1); // 默认DHCP
    cJSON_AddStringToObject(net, "dns1", "---");
    cJSON_AddStringToObject(net, "dns2", "---");
  }

  // 添加网络相关信息
  cJSON_AddItemToObject(root, "net", net);

  // 添加 "stat" 对象
  cJSON *stat = cJSON_CreateObject();
  cJSON *com_stat = cJSON_CreateObject();
  cJSON_AddNumberToObject(com_stat, "send_frame_success",
                          uart_stats.send_frame_success);
  cJSON_AddNumberToObject(com_stat, "send_byte_success",
                          uart_stats.send_byte_success);
  cJSON_AddNumberToObject(com_stat, "recv_frame_success",
                          uart_stats.recv_frame_success);
  cJSON_AddNumberToObject(com_stat, "recv_byte_success",
                          uart_stats.recv_byte_success);
  cJSON_AddItemToObject(stat, "com", com_stat);

  // 添加目标统计信息
  cJSON *targets_stat = cJSON_CreateArray();
  for (int i = 0; i < target_stats_count; i++) {
    cJSON *target = cJSON_CreateObject();
    cJSON_AddStringToObject(target, "name", target_stats[i].name);
    cJSON_AddNumberToObject(target, "send_frame_success",
                            target_stats[i].send_frame_success);
    cJSON_AddNumberToObject(target, "send_byte_success",
                            target_stats[i].send_byte_success);
    cJSON_AddNumberToObject(target, "send_frame_failed",
                            target_stats[i].send_frame_failed);
    cJSON_AddNumberToObject(target, "send_byte_failed",
                            target_stats[i].send_byte_failed);
    cJSON_AddNumberToObject(target, "recv_frame", target_stats[i].recv_frame);
    cJSON_AddNumberToObject(target, "recv_byte", target_stats[i].recv_byte);
    cJSON_AddItemToArray(targets_stat, target);
  }

  cJSON_AddItemToObject(stat, "targets", targets_stat);
  cJSON_AddItemToObject(root, "stat", stat);

  // 添加 "set" 对象
  cJSON *set = cJSON_CreateObject();
  cJSON *saved_config = load_config_from_nvs();
  if (saved_config) {
    // 添加 params 数组
    cJSON *params = cJSON_GetObjectItem(saved_config, "params");
    if (params) {
      cJSON_AddItemToObject(set, "params", cJSON_Duplicate(params, 1));
    } else {
      cJSON *empty_params = cJSON_CreateArray();
      cJSON_AddItemToArray(empty_params, cJSON_CreateObject());
      cJSON_AddItemToObject(set, "params", empty_params);
    }

    // 添加 targets 数组
    cJSON *targets = cJSON_GetObjectItem(saved_config, "targets");
    if (targets) {
      cJSON_AddItemToObject(set, "targets", cJSON_Duplicate(targets, 1));
    }

    // 添加 points 数组
    cJSON *points = cJSON_GetObjectItem(saved_config, "points");
    if (points) {
      cJSON_AddItemToObject(set, "points", cJSON_Duplicate(points, 1));
    }

    cJSON_Delete(saved_config);
  }
  cJSON_AddItemToObject(root, "set", set);

  nvs_close(nvs_handle);

  // 生成最终的 JSON 字符串
  char *jsonString = cJSON_Print(root);
  char *result = strdup(jsonString);
  free(jsonString);
  cJSON_Delete(root);
  return result;
}


char *send_device_info(uint8_t *u_data, int idx) {
  // 创建根对象
  cJSON *root = cJSON_CreateObject();
  // 添加基础键值对
  // cJSON_AddStringToObject(root, "messageid", messageid);
  cJSON_AddNumberToObject(root, "code", 200);
  cJSON_AddStringToObject(root, "type", DEVICE_TYPE);

  uint64_t time_since_boot = esp_timer_get_time();
  uint64_t time_in_s = time_since_boot / 1000000;
  // 添加 "data" 对象
  cJSON *data = cJSON_CreateObject();
  cJSON *net = cJSON_CreateObject();
  cJSON *sys = cJSON_CreateObject();
  cJSON *protocol = cJSON_CreateObject();
  cJSON *serial = cJSON_CreateObject();

  // char *response = tx_task(u_data, idx);
  // char *response = "";
  // tx_task(u_data, idx);
  // cJSON_AddStringToObject(root, "resopnse", device_response);

  cJSON_AddItemToObject(root, "data", data);
  // free(response);

  esp_err_t ret = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
  size_t use_mqtt, use_tcp, use_udp, use_http, tcpconn, udpconn, netconn,
      wifi_ssid, is_dhcp, baud_rate, data_bit, check_bit, stop_bit = 0;
  ret = nvs_get_str(nvs_handle, "netconn", NULL, &netconn);
  nvs_get_str(nvs_handle, "is_dhcp", NULL, &is_dhcp);
  nvs_get_str(nvs_handle, "use_mqtt", NULL, &use_mqtt);
  nvs_get_str(nvs_handle, "use_tcp", NULL, &use_tcp);
  nvs_get_str(nvs_handle, "use_udp", NULL, &use_udp);
  nvs_get_str(nvs_handle, "use_http", NULL, &use_http);
  nvs_get_str(nvs_handle, "tcpconn", NULL, &tcpconn);
  nvs_get_str(nvs_handle, "udpconn", NULL, &udpconn);
  nvs_get_str(nvs_handle, "wifi_ssid", NULL, &wifi_ssid);
  nvs_get_str(nvs_handle, "baud_rate", NULL, &baud_rate);
  nvs_get_str(nvs_handle, "data_bit", NULL, &data_bit);
  nvs_get_str(nvs_handle, "check_bit", NULL, &check_bit);
  nvs_get_str(nvs_handle, "stop_bit", NULL, &stop_bit);
  switch (ret) {
  case ESP_OK:
    printf("protocol set success");
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "use_mqtt", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "use_tcp", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "use_udp", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "use_http", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "tcpconn", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "udpconn", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "netconn", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "wifi_ssid", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "is_dhcp", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "baud_rate", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "data_bit", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "check_bit", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "stop_bit", ""));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'my_key': %s\n", esp_err_to_name(ret));
  } else {
    char *nvs_use_mqtt = malloc(use_mqtt);
    char *nvs_use_tcp = malloc(use_tcp);
    char *nvs_use_udp = malloc(use_udp);
    char *nvs_use_http = malloc(use_http);
    char *nvs_tcpconn = malloc(tcpconn);
    char *nvs_udpconn = malloc(udpconn);
    char *nvs_netconn = malloc(netconn);
    char *nvs_wifi_ssid = malloc(wifi_ssid);
    char *nvs_is_dhcp = malloc(is_dhcp);
    char *nvs_baud_rate = malloc(baud_rate);
    char *nvs_data_bit = malloc(data_bit);
    char *nvs_check_bit = malloc(check_bit);
    char *nvs_stop_bit = malloc(stop_bit);

    if (nvs_netconn == NULL) {
      printf("Memory allocation failed\n");
    } else {
      ret = nvs_get_str(nvs_handle, "netconn", nvs_netconn, &netconn);
      nvs_get_str(nvs_handle, "use_mqtt", nvs_use_mqtt, &use_mqtt);
      nvs_get_str(nvs_handle, "use_tcp", nvs_use_tcp, &use_tcp);
      nvs_get_str(nvs_handle, "use_udp", nvs_use_udp, &use_udp);
      nvs_get_str(nvs_handle, "use_http", nvs_use_http, &use_http);
      nvs_get_str(nvs_handle, "tcpconn", nvs_tcpconn, &tcpconn);
      nvs_get_str(nvs_handle, "udpconn", nvs_udpconn, &udpconn);
      nvs_get_str(nvs_handle, "wifi_ssid", nvs_wifi_ssid, &wifi_ssid);
      nvs_get_str(nvs_handle, "is_dhcp", nvs_is_dhcp, &is_dhcp);
      nvs_get_str(nvs_handle, "baud_rate", nvs_baud_rate, &baud_rate);
      nvs_get_str(nvs_handle, "data_bit", nvs_data_bit, &data_bit);
      nvs_get_str(nvs_handle, "check_bit", nvs_check_bit, &check_bit);
      nvs_get_str(nvs_handle, "stop_bit", nvs_stop_bit, &stop_bit);

      if (ret == ESP_OK) {
        // 添加 "net" 对象
        cJSON_AddNumberToObject(serial, "baud_rate", atoi(nvs_baud_rate));
        cJSON_AddNumberToObject(serial, "data_bit", atoi(nvs_data_bit));

        cJSON_AddNumberToObject(serial, "stop_bit", atof(nvs_stop_bit));
        cJSON_AddStringToObject(serial, "check_bit", nvs_check_bit);
        cJSON_AddItemToObject(root, "serial", serial);

        if (atoi(nvs_netconn) == 2) {
          cJSON_AddStringToObject(net, "connmethed", "wifi");
          cJSON_AddStringToObject(net, "ssid", nvs_wifi_ssid);
          if (atoi(nvs_is_dhcp) == 2) {
            cJSON_AddNumberToObject(net, "dhcp", 0);
          } else {
            cJSON_AddNumberToObject(net, "dhcp", 1);
          }
        } else {
          cJSON_AddStringToObject(net, "connmethed", "eth");
          cJSON_AddStringToObject(net, "ssid", "---");
          cJSON_AddNumberToObject(net, "dhcp", 1);
        }
        cJSON_AddStringToObject(net, "ip", got_ip_addrs);
        cJSON_AddItemToObject(root, "net", net);

        // 添加 "sys" 对象

        cJSON_AddStringToObject(sys, "version", VERSION);

        cJSON_AddNumberToObject(sys, "runtime", time_in_s);
        cJSON_AddStringToObject(sys, "eth_mac", device_eth_mac);
        cJSON_AddStringToObject(sys, "sta_mac", device_sta_mac);
        cJSON_AddItemToObject(root, "sys", sys);

        // 添加 "protocol" 对象

        cJSON_AddNumberToObject(protocol, "mqtt", atoi(nvs_use_mqtt));
        cJSON_AddNumberToObject(protocol, "http", atoi(nvs_use_http));
        if (atoi(nvs_use_tcp) == 1) {
          if (atoi(nvs_tcpconn) == 0) {
            cJSON_AddNumberToObject(protocol, "tcpserver", 1);
            cJSON_AddNumberToObject(protocol, "tcpclient", 0);
          } else {
            cJSON_AddNumberToObject(protocol, "tcpserver", 0);
            cJSON_AddNumberToObject(protocol, "tcpclient", 1);
          }
        } else {
          cJSON_AddNumberToObject(protocol, "tcpserver", 0);
          cJSON_AddNumberToObject(protocol, "tcpclient", 0);
        }
        if (atoi(nvs_use_udp) == 1) {
          if (atoi(nvs_udpconn) == 0) {
            cJSON_AddNumberToObject(protocol, "udpserver", 1);
            cJSON_AddNumberToObject(protocol, "udpclient", 0);
          } else {
            cJSON_AddNumberToObject(protocol, "udpserver", 0);
            cJSON_AddNumberToObject(protocol, "udpclient", 1);
          }
        } else {
          cJSON_AddNumberToObject(protocol, "udpserver", 0);
          cJSON_AddNumberToObject(protocol, "udpclient", 0);
        }
        cJSON_AddItemToObject(root, "protocol", protocol);
      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }

      free(nvs_use_mqtt);
      free(nvs_use_tcp);
      free(nvs_use_udp);
      free(nvs_use_http);
      free(nvs_tcpconn);
      free(nvs_udpconn);
      free(nvs_netconn);
      free(nvs_wifi_ssid);
      free(nvs_is_dhcp);
      free(nvs_baud_rate);
      free(nvs_data_bit);
      free(nvs_check_bit);
      free(nvs_stop_bit);
    }
  }
  nvs_close(nvs_handle);
  char *jsonString = cJSON_Print(root);
  char *result = strdup(jsonString);
  free(jsonString);
  cJSON_Delete(root);
  return result;
}

char *send_device_ip(void) {
  char *jsonString = NULL;
  esp_err_t ret = nvs_flash_init();
  if (ret == ESP_ERR_NVS_NO_FREE_PAGES ||
      ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
    ESP_ERROR_CHECK(nvs_flash_erase());
    ret = nvs_flash_init();
  }
  ESP_ERROR_CHECK(ret);
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
  size_t host_names = 0;
  ret = nvs_get_str(nvs_handle, "host_names", NULL, &host_names);
  if (ret != ESP_OK) {
    printf("Error getting size of 'my_key': %s\n", esp_err_to_name(ret));
  } else {
    char *nvs_host_names = malloc(host_names);
    if (nvs_host_names == NULL) {
      printf("Memory allocation failed\n");
    } else {
      ret = nvs_get_str(nvs_handle, "host_names", nvs_host_names, &host_names);
      if (ret == ESP_OK) {
        cJSON *root = cJSON_CreateObject();
        cJSON_AddStringToObject(root, "type", DEVICE_TYPE);
        cJSON_AddStringToObject(root, "name", nvs_host_names);
        cJSON_AddStringToObject(root, "mac", device_eth_mac);
        cJSON_AddStringToObject(root, "ip", got_ip_addrs);
        cJSON_AddStringToObject(root, "netmask", got_ip_netmask);
        cJSON_AddStringToObject(root, "gateway", got_ip_gw);
        cJSON_AddStringToObject(root, "eth_mac", device_eth_mac);
        cJSON_AddStringToObject(root, "sta_mac", device_sta_mac);
        cJSON_AddStringToObject(root, "version", VERSION);
        jsonString = cJSON_Print(root);
        cJSON_Delete(root);

      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_host_names);
    }
  }
  nvs_close(nvs_handle);

  return jsonString;
}

char *send_device_info_err(void) {
  cJSON *root = cJSON_CreateObject();
  // cJSON_AddStringToObject(root, "messageid", messageid);
  cJSON_AddNumberToObject(root, "code", 204);
  cJSON_AddStringToObject(root, "msg", "type not found");
  char *jsonString = cJSON_Print(root);
  cJSON_Delete(root);
  return jsonString;
}

// 函数用于重置并清除所有NVS存储
esp_err_t nvs_reset_clear() {
  const char *TAG = "nvs_reset_clear";
  esp_err_t err;
  err = nvs_flash_init();
  if (err == ESP_ERR_NVS_NO_FREE_PAGES ||
      err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
    ESP_LOGI(TAG, "Erasing NVS flash");
    err = nvs_flash_erase();
    if (err != ESP_OK) {
      ESP_LOGE(TAG, "NVS flash erase failed: %s", esp_err_to_name(err));
      return err;
    }
    err = nvs_flash_init();
  }
  if (err != ESP_OK) {
    ESP_LOGE(TAG, "NVS flash init failed: %s", esp_err_to_name(err));
    return err;
  }
  ESP_LOGI(TAG, "NVS flash reset and cleared");
  return ESP_OK;
}

void protocol_select() {
  // if (xHandleTask3 == NULL) {
  //   xTaskCreate(&led_task, "led_task", 10096, NULL, 0, &xHandleTask3);
  // }


  xTaskCreate(&http_get_current_time_task, "http_get_current_time_task", 8192,
              NULL, 5, NULL);

  // udp_multicast();
  // get_current_time();
  printf("%s", strftime_buf);

  esp_err_t ret = nvs_flash_init();
  if (ret == ESP_ERR_NVS_NO_FREE_PAGES ||
      ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
    ESP_ERROR_CHECK(nvs_flash_erase());
    ret = nvs_flash_init();
  }
  ESP_ERROR_CHECK(ret);
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
  size_t use_mqtt, mqtt_type;
  ret = nvs_get_str(nvs_handle, "use_mqtt", NULL, &use_mqtt);
  nvs_get_str(nvs_handle, "mqtt_type", NULL, &mqtt_type);
  switch (ret) {
  case ESP_OK:
    printf("HTTP set success");
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    printf("no HTTP set");
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "use_mqtt", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_type", ""));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'my_key': %s\n", esp_err_to_name(ret));
  } else {
    char *nvs_use_mqtt = malloc(use_mqtt);
    char *nvs_mqtt_type = malloc(mqtt_type);
    ret = nvs_get_str(nvs_handle, "use_mqtt", nvs_use_mqtt, &use_mqtt);
    nvs_get_str(nvs_handle, "mqtt_type", nvs_mqtt_type, &mqtt_type);
    if (ret == ESP_OK) {
      printf("Value for 'use_mqtt' is %s\n", nvs_use_mqtt);
      printf("Value for 'mqtt_type' is %s\n", nvs_mqtt_type);
      if (atoi(nvs_use_mqtt) == 1) {
        if (atoi(nvs_mqtt_type) == 0) {
          mqtt_app_start();
        }
        if (atoi(nvs_mqtt_type) == 1) {
          // mqtt_app_start();
          printf("TODO MQTT5 PROTOCOL\n");
        }
      } else {
        printf("NOT SET MQTT PROTOCOL\n");
      }
    }
    free(nvs_use_mqtt);
    free(nvs_mqtt_type);
  }

  start_udp_server();
  // size_t use_udp, udpconn;
  // ret = nvs_get_str(nvs_handle, "use_udp", NULL, &use_udp);
  // nvs_get_str(nvs_handle, "udpconn", NULL, &udpconn);
  // switch (ret) {
  // case ESP_OK:
  //   printf("HTTP set success");
  //   break;
  // case ESP_ERR_NVS_NOT_FOUND:
  //   printf("no HTTP set");
  //   ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "use_udp", ""));
  //   ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "udpconn", ""));
  //   break;
  // default:
  //   break;
  // }
  // if (ret != ESP_OK) {
  //   printf("Error getting size of 'UDP': %s\n", esp_err_to_name(ret));
  // } else {
  //   char *nvs_use_udp = malloc(use_udp);
  //   char *nvs_udpconn = malloc(udpconn);
  //   ret = nvs_get_str(nvs_handle, "use_udp", nvs_use_udp, &use_udp);
  //   nvs_get_str(nvs_handle, "udpconn", nvs_udpconn, &udpconn);
  //   if (ret == ESP_OK) {
  //     printf("Value for 'use_udp' is %s\n", nvs_use_udp);
  //     printf("Value for 'udpconn' is %s\n", nvs_udpconn);
  //     if (atoi(nvs_use_udp) == 1) {
  //       if (atoi(nvs_udpconn) == 0) {
  //         printf("!!!!!!!!!!!!!!!!!!!!!==============================");
  //         start_udp_server();
  //       }
  //       if (atoi(nvs_udpconn) == 1) {
  //         printf("=============================================");
  //         start_udp_client();
  //       }
  //     } else {
  //       printf("NOT SET MQTT PROTOCOL\n");
  //     }
  //   }
  //   free(nvs_use_udp);
  //   free(nvs_udpconn);
  // }
  size_t use_tcp, tcpconn, tcp_server, tcp_port;
  ret = nvs_get_str(nvs_handle, "use_tcp", NULL, &use_tcp);
  nvs_get_str(nvs_handle, "tcpconn", NULL, &tcpconn);
  nvs_get_str(nvs_handle, "tcp_server", NULL, &tcp_server);
  nvs_get_str(nvs_handle, "tcp_port", NULL, &tcp_port);
  switch (ret) {
  case ESP_OK:
    printf("TCP set success");
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    printf("no TCP set");
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "use_tcp", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "tcpconn", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "tcp_server", "192.168.1.100"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "tcp_port", "8888"));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'my_key': %s\n", esp_err_to_name(ret));
  } else {
    // 分配缓冲区
    char *nvs_use_tcp = malloc(use_tcp);
    char *nvs_tcpconn = malloc(tcpconn);
    char *nvs_tcp_server = malloc(tcp_server);
    char *nvs_tcp_port = malloc(tcp_port);
    if (nvs_tcp_server == NULL) {
      printf("Memory allocation failed\n");
    } else {
      // 读取字符串到分配的缓冲区
      ret = nvs_get_str(nvs_handle, "use_tcp", nvs_use_tcp, &use_tcp);
      nvs_get_str(nvs_handle, "tcpconn", nvs_tcpconn, &tcpconn);
      nvs_get_str(nvs_handle, "tcp_server", nvs_tcp_server, &tcp_server);
      nvs_get_str(nvs_handle, "tcp_port", nvs_tcp_port, &tcp_port);
      if (ret == ESP_OK) {
        if (atoi(nvs_use_tcp) == 1) {
          if (atoi(nvs_tcpconn) == 0) {
            start_tcp_server();
          }
          if (atoi(nvs_tcpconn) == 1) {
            start_tcp_client();
          }
        } else {
          printf("NOT SET TCP PROTOCOL\n");
        }
      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_use_tcp); // 释放缓冲区
      free(nvs_tcpconn);
      free(nvs_tcp_server);
      free(nvs_tcp_port);
    }
  }

  size_t use_http, http_port, httpconn, http_url, http_header, http_time = 0;
  ret = nvs_get_str(nvs_handle, "use_http", NULL, &use_http);
  nvs_get_str(nvs_handle, "http_port", NULL, &http_port);
  nvs_get_str(nvs_handle, "httpconn", NULL, &httpconn);
  nvs_get_str(nvs_handle, "http_url", NULL, &http_url);
  nvs_get_str(nvs_handle, "http_header", NULL, &http_header);
  nvs_get_str(nvs_handle, "http_time", NULL, &http_time);
  switch (ret) {
  case ESP_OK:
    printf("HTTP set success");
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    printf("no HTTP set");
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "use_http", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "http_port", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "httpconn", ""));
    ESP_ERROR_CHECK(
        nvs_set_str(nvs_handle, "http_url", "http://demo.sxiot.com"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "http_header", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "http_time", ""));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'HTTP': %s\n", esp_err_to_name(ret));
  } else {
    char *nvs_use_http = malloc(use_http);
    char *nvs_http_port = malloc(http_port);
    char *nvs_httpconn = malloc(httpconn);
    char *nvs_http_url = malloc(http_url);
    char *nvs_http_header = malloc(http_header);
    char *nvs_http_time = malloc(http_time);

    if (nvs_use_http == NULL) {
      printf("Memory allocation failed\n");
    } else {
      ret = nvs_get_str(nvs_handle, "use_http", nvs_use_http, &use_http);
      nvs_get_str(nvs_handle, "http_port", nvs_http_port, &http_port);
      nvs_get_str(nvs_handle, "httpconn", nvs_httpconn, &httpconn);
      nvs_get_str(nvs_handle, "http_url", nvs_http_url, &http_url);
      nvs_get_str(nvs_handle, "http_header", nvs_http_header, &http_header);
      nvs_get_str(nvs_handle, "http_time", nvs_http_time, &http_time);

      if (ret == ESP_OK) {
        printf("Value for 'use_http' is %s\n", nvs_use_http);
        printf("Value for 'http_port' is %s\n", nvs_http_port);
        printf("Value for 'httpconn' is %s\n", nvs_httpconn);
        printf("Value for 'http_url' is %s\n", nvs_http_url);
        printf("Value for 'http_header' is %s\n", nvs_http_header);
        printf("Value for 'http_time' is %s\n", nvs_http_time);

        if (atoi(nvs_use_http) == 1) {
          xTaskCreate(&http_test_task, "http_test_task", 8192, NULL, 5, NULL);
        } else {
          printf("NOT SET HTTP PROTOCOL\n");
        }

      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_use_http);
      free(nvs_http_port);
      free(nvs_httpconn);
      free(nvs_http_url);
      free(nvs_http_header);
      free(nvs_http_time);
    }
  }

  nvs_close(nvs_handle);
}

void eth_disconnect() {

  printf("eth disconnect\n");
  //   gpio_set_level(LED, 0);
  if (xHandleTask3 != NULL) {
    vTaskDelete(xHandleTask3);
    xHandleTask3 = NULL;
  }
}

void simple_task() {

  // xTaskCreate(&i2cRead, "i2cRead", 10096, NULL, 0, NULL);

  xTaskCreate(free_task, (char *)"free_task", 2048, NULL, 1, NULL);
  xTaskCreate(&key_task, "key_task", 2048, NULL, 0, NULL);
  // xTaskCreate(close_ap_task, "close_ap_task", 2048, NULL, 5, NULL);
  // xTaskCreate(rx_task, "uart_tx_task", 1024 * 2, NULL, configMAX_PRIORITIES -
  // 2,
  //             NULL);
  // rx_wait();
}

/*************************************************************************************/
/*                                END OF FILE */
/*************************************************************************************/
