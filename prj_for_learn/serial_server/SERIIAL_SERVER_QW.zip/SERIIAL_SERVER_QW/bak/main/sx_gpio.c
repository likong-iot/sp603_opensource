/*
 * @Author: Orion
 * @Date: 2024-02-03 11:29:35
 * @LastEditors: Orion
 * @LastEditTime: 2024-11-26 13:59:02
 * @FilePath: \SERIIAL_SERVER_P\main\sx_gpio.c
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */

#include "sx_gpio.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"
#include "freertos/task.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

uint16_t KeyState = 0, LED_LAN_STATE = 0, LED_WIFI_STATE = 0, LED_DAT_STATE = 0;

/*************************************************************************************/
/*                                START OF FILE */
/*************************************************************************************/

void LED_LAN_ON() {
  gpio_set_level(LED_LAN, 0);
  vTaskDelay(10 / portTICK_PERIOD_MS);
  // gpio_set_level(KEY, 1);
  LED_LAN_STATE = 1;
}
void LED_LAN_OFF() {
  gpio_set_level(LED_LAN, 1);
  vTaskDelay(10 / portTICK_PERIOD_MS);
  // gpio_set_level(KEY, 0);
  LED_LAN_STATE = 0;
}

void LED_WIFI_ON() {
  gpio_set_level(LED_WIFI, 0);
  vTaskDelay(10 / portTICK_PERIOD_MS);
  // gpio_set_level(KEY, 1);
  LED_WIFI_STATE = 1;
}
void LED_WIFI_OFF() {
  gpio_set_level(LED_WIFI, 1);
  vTaskDelay(10 / portTICK_PERIOD_MS);
  // gpio_set_level(KEY, 0);
  LED_WIFI_STATE = 0;
}

void LED_DAT_ON() {
  gpio_set_level(LED_DAT, 0);
  vTaskDelay(10 / portTICK_PERIOD_MS);
  // gpio_set_level(KEY, 1);
  LED_DAT_STATE = 1;
}

void LED_DAT_OFF() {
  gpio_set_level(LED_DAT, 1);
  vTaskDelay(10 / portTICK_PERIOD_MS);
  // gpio_set_level(KEY, 0);
  LED_DAT_STATE = 0;
}

// void Send_595_1(unsigned char dat)
// {
// 	unsigned char i;
// 	for(i=0; i<8; i++)
// 	{
// 		dat <<= 1;
// 		P1_HC595_SER   = CY;
// 		P1_HC595_SRCLK = 1;
// 		P1_HC595_SRCLK = 0;
// 	}
// }

#define SCK_GPIO_PIN GPIO_NUM_14 // 移位寄存器时钟线引脚 (SHCP)
#define RCK_GPIO_PIN GPIO_NUM_12 // 存储寄存器时钟线引脚 (STCP)
#define SDA_GPIO_PIN GPIO_NUM_13 // 数据引脚 (DS)

typedef struct {
  uint8_t state; // 存储 LED 状态，8 位
} ShiftRegister;

ShiftRegister sr; // 提出的 ShiftRegister 实例

// 初始化 GPIO 引脚
void init_shift_register() {
  gpio_reset_pin(SCK_GPIO_PIN);
  gpio_reset_pin(RCK_GPIO_PIN);
  gpio_reset_pin(SDA_GPIO_PIN);

  gpio_set_direction(SCK_GPIO_PIN, GPIO_MODE_OUTPUT);
  gpio_set_direction(RCK_GPIO_PIN, GPIO_MODE_OUTPUT);
  gpio_set_direction(SDA_GPIO_PIN, GPIO_MODE_OUTPUT);

  // 初始化引脚电平
  gpio_set_level(SCK_GPIO_PIN, 0);
  gpio_set_level(RCK_GPIO_PIN, 0);
  gpio_set_level(SDA_GPIO_PIN, 0);
}

// 向 74HC595 发送一位数据
void shift_bit(uint8_t bit_value) {
  gpio_set_level(SDA_GPIO_PIN, bit_value);
  // 发送到移位寄存器
  gpio_set_level(SCK_GPIO_PIN, 1); // 产生一个时钟脉冲
  gpio_set_level(SCK_GPIO_PIN, 0);
}

// 将所有 8 位数据推送到 74HC595
void shift_byte(uint8_t data) {
  for (int i = 7; i >= 0; i--) {
    shift_bit((data >> i) & 0x01);
  }
  // 将数据锁存到输出寄存器
  gpio_set_level(RCK_GPIO_PIN, 1); // 存储寄存器时钟
  gpio_set_level(RCK_GPIO_PIN, 0);
}

// 初始化移位寄存器并设置初始状态
void shift_register_init() {
  sr.state = 0xFC; // 初始化为熄灭所有 LED
  init_shift_register();
  shift_byte(sr.state);
}

// 控制指定 LED 的点亮或熄灭
void turn_on_gpio(uint8_t led_index, uint8_t state) {
  if (led_index < 8) {
    if (state) {
      sr.state &= ~(1 << led_index); // 点亮 LED: 清除对应位为 0
    } else {
      sr.state |= (1 << led_index); // 熄灭 LED: 设置对应位为 1
    }
    shift_byte(sr.state);
  }
}

void blink_rx_tx_led(){
  turn_on_gpio(LED485, 1);
  vTaskDelay(100 / portTICK_PERIOD_MS);
  turn_on_gpio(LED485, 0);
}

void blink_net_led(){
  turn_on_gpio(LEDNET, 1);
  vTaskDelay(100 / portTICK_PERIOD_MS);
  turn_on_gpio(LEDNET, 0);
}

void init_gpio() {

  shift_register_init(); // Init shift register


  gpio_reset_pin(KEY);
  gpio_set_direction(KEY, GPIO_MODE_INPUT);
  gpio_set_pull_mode(KEY, GPIO_PULLUP_ONLY);
  gpio_config_t led_lan_conf = {
      .pin_bit_mask = (1ULL << LED_LAN),
      .mode = GPIO_MODE_OUTPUT,
  };
  gpio_config(&led_lan_conf);

  gpio_config_t led_wifi_conf = {
      .pin_bit_mask = (1ULL << LED_WIFI),
      .mode = GPIO_MODE_OUTPUT,
  };
  gpio_config(&led_wifi_conf);
  gpio_config_t led_data_conf = {
      .pin_bit_mask = (1ULL << LED_DAT),
      .mode = GPIO_MODE_OUTPUT,
  };
  gpio_config(&led_data_conf);

  esp_log_level_set("httpd_uri", ESP_LOG_ERROR);
  esp_log_level_set("httpd_txrx", ESP_LOG_ERROR);
  esp_log_level_set("httpd_parse", ESP_LOG_ERROR);
  esp_log_level_set("wifi", ESP_LOG_ERROR);

  // 设置 GPIO 为高电平（LED 保持常亮）
  gpio_set_level(LED_LAN, 1); // LED0灭
  gpio_set_level(LED_WIFI, 1);
  gpio_set_level(LED_DAT, 1);
}

/*************************************************************************************/
/*                                END OF FILE */
/*************************************************************************************/
