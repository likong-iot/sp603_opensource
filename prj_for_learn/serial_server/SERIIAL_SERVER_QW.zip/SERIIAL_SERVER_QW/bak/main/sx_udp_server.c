/*
 * @Author: Orion
 * @Date: 2024-01-23 16:08:16
 * @LastEditors: Orion
 * @LastEditTime: 2024-09-03 14:47:05
 * @FilePath: \SERIIAL_SERVER\main\sx_udp_server.c
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */

#include "esp_event.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "esp_system.h"
#include "esp_wifi.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "nvs_flash.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/param.h>

#include "cJSON.h"
#include "driver/gpio.h"
#include "lwip/err.h"
#include "lwip/sockets.h"
#include "lwip/sys.h"
#include "sx_gpio.h"
#include "sx_http_ota.h"
#include "sx_utils.h"
#include <lwip/netdb.h>

/*************************************************************************************/
/*                                START OF FILE */
/*************************************************************************************/

static const char *TAG = "UDPSERVER";
#define UDP_SERVER_PORT 37210

TaskHandle_t xHandleUDPServerTask;
int udp_server_sock = -1; // 新增全局变量保存套接字
static char *global_ip = NULL;
static char *global_mask = NULL;
static char *global_gateway = NULL;
static char *global_name = NULL;

static void store_network_settings(const char *name, const char *ip,
                                   const char *mask, const char *gateway) {
  if (global_name)
    free(global_name);
  if (global_ip)
    free(global_ip);
  if (global_mask)
    free(global_mask);
  if (global_gateway)
    free(global_gateway);

  global_name = strdup(name);
  global_ip = strdup(ip);
  global_mask = strdup(mask);
  global_gateway = strdup(gateway);
}

static void udp_server_task(void *pvParameters) {
  char rx_buffer[256];
  char addr_str[256];
  int addr_family = (int)pvParameters;
  int ip_protocol = 0;
  struct sockaddr_in6 dest_addr;

  if (addr_family == AF_INET) {
    struct sockaddr_in *dest_addr_ip4 = (struct sockaddr_in *)&dest_addr;
    dest_addr_ip4->sin_addr.s_addr = htonl(INADDR_ANY);
    dest_addr_ip4->sin_family = AF_INET;
    dest_addr_ip4->sin_port = htons(UDP_SERVER_PORT);
    ESP_LOGI(TAG, "Socket bound, port %d", UDP_SERVER_PORT);
    ip_protocol = IPPROTO_IP;
  }

  while (1) {
    udp_server_sock = socket(addr_family, SOCK_DGRAM, ip_protocol);
    if (udp_server_sock < 0) {
      ESP_LOGE(TAG, "Unable to create socket: errno %d", errno);
      break;
    }
    ESP_LOGI(TAG, "Socket created");
    struct timeval timeout;
    timeout.tv_sec = 10;
    timeout.tv_usec = 0;
    setsockopt(udp_server_sock, SOL_SOCKET, SO_RCVTIMEO, &timeout,
               sizeof(timeout));

    int err =
        bind(udp_server_sock, (struct sockaddr *)&dest_addr, sizeof(dest_addr));
    if (err < 0) {
      ESP_LOGE(TAG, "Socket unable to bind: errno %d", errno);
      shutdown(udp_server_sock, 0);
      close(udp_server_sock);
      vTaskDelay(1000 / portTICK_PERIOD_MS);
      continue;
    }
    ESP_LOGI(TAG, "Socket bound, port %d", UDP_SERVER_PORT);
    struct sockaddr_storage source_addr;
    socklen_t socklen = sizeof(source_addr);

    while (1) {
      ESP_LOGI(TAG, "Waiting for data");
      int len = recvfrom(udp_server_sock, rx_buffer, sizeof(rx_buffer) - 1, 0,
                         (struct sockaddr *)&source_addr, &socklen);
      if (len < 0) {
        ESP_LOGE(TAG, "recvfrom failed: errno %d", errno);
        shutdown(udp_server_sock, 0);
        close(udp_server_sock);
        udp_server_sock = -1;
        break;
      } else {
        if (source_addr.ss_family == PF_INET) {
          inet_ntoa_r(((struct sockaddr_in *)&source_addr)->sin_addr, addr_str,
                      sizeof(addr_str) - 1);
        } else if (source_addr.ss_family == PF_INET6) {
          inet6_ntoa_r(((struct sockaddr_in6 *)&source_addr)->sin6_addr,
                       addr_str, sizeof(addr_str) - 1);
        }
        rx_buffer[len] = 0;
        ESP_LOGI(TAG, "Received %d bytes from %s:", len, addr_str);
        ESP_LOGI(TAG, "%s", rx_buffer);
        cJSON *pJsonRoot = cJSON_Parse(rx_buffer);
        if (pJsonRoot == NULL) {
          const char *error_ptr = cJSON_GetErrorPtr();
          if (error_ptr != NULL) {
            fprintf(stderr, "Error before: %s\n", error_ptr);
          }
          cJSON_Delete(pJsonRoot);
          break;
        }
        char *udpmsg = NULL;
        cJSON *device = cJSON_GetObjectItem(pJsonRoot, "device");
        cJSON *parm = cJSON_GetObjectItem(pJsonRoot, "parm");
        cJSON *name = cJSON_GetObjectItem(parm, "name");
        cJSON *ip = cJSON_GetObjectItem(parm, "ip");
        cJSON *mask = cJSON_GetObjectItem(parm, "mask");
        cJSON *gateway = cJSON_GetObjectItem(parm, "gateway");

        if (cJSON_IsString(device) && (device->valuestring != NULL)) {
          if (strcmp(device->valuestring, "scan") == 0) {
            udpmsg = send_device_ip();
          } else if (strcmp(device->valuestring, "set") == 0) {
            if (cJSON_IsString(name) && cJSON_IsString(ip) &&
                cJSON_IsString(mask) && cJSON_IsString(gateway)) {
              printf("Name: %s, IP: %s, Mask: %s, Gateway: %s\n",
                     name->valuestring, ip->valuestring, mask->valuestring,
                     gateway->valuestring);
              store_network_settings(name->valuestring, ip->valuestring,
                                     mask->valuestring, gateway->valuestring);
              udpmsg = strdup("{\"change\":\"ok\"}");
            }
          } else if (strcmp(device->valuestring, "exec") == 0) {
            if (cJSON_IsString(parm) && (parm->valuestring != NULL)) {
              if (strcmp(parm->valuestring, "device_info") == 0) {
                gpio_set_level(LED_DAT, 0);
                vTaskDelay(100 / portTICK_PERIOD_MS);
                gpio_set_level(LED_DAT, 1);
                vTaskDelay(100 / portTICK_PERIOD_MS);
                gpio_set_level(LED_DAT, 0);
                vTaskDelay(100 / portTICK_PERIOD_MS);
                gpio_set_level(LED_DAT, 1);
                vTaskDelay(100 / portTICK_PERIOD_MS);
                gpio_set_level(LED_DAT, 0);
                vTaskDelay(100 / portTICK_PERIOD_MS);
                gpio_set_level(LED_DAT, 1);
                // udpmsg = send_device_info();
              }
            }
            if (cJSON_IsString(parm) && (parm->valuestring != NULL)) {
              const char *parm_value = parm->valuestring;
              const char *ota_prefix = "ota[";
              if (strncmp(parm_value, ota_prefix, strlen(ota_prefix)) == 0) {
                const char *url_start = parm_value + strlen(ota_prefix);
                const char *url_end = strchr(url_start, ']');
                if (url_end != NULL) {
                  size_t url_length = url_end - url_start;
                  char url[256];
                  strncpy(url, url_start, url_length);
                  url[url_length] = '\0';
                  printf(
                      "OTA URL: %s\n",
                      url); // ota[http://47.101.140.34:8080/ETH_TH_1.0.9.bin]
                  udpmsg = "正在升级中,请稍后重新搜索设备!";
                  err = sendto(udp_server_sock, udpmsg, strlen(udpmsg), 0,
                               (struct sockaddr *)&source_addr,
                               sizeof(source_addr));
                  simple_ota_task(url);

                } else {
                  printf("Invalid OTA URL format\n");
                }
              }
            }
          } else {
            udpmsg = strdup("{\"change\":\"failed\"}");
          }
        }

        cJSON *uname = cJSON_GetObjectItem(pJsonRoot, "username");
        cJSON *passwd = cJSON_GetObjectItem(pJsonRoot, "password");

        if (cJSON_IsString(uname) && (uname->valuestring != NULL)) {
          printf("Username: %s\n", uname->valuestring);
        } else {
          printf("Username is not valid\n");
        }

        if (cJSON_IsString(passwd) && (passwd->valuestring != NULL)) {
          printf("Password: %s\n", passwd->valuestring);
        } else {
          printf("Password is not valid\n");
        }
        esp_err_t rets = nvs_init();
        nvs_handle_t nvs_handle;
        ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
        size_t lgname_len = 0, lgpwd_len = 0;
        rets = nvs_get_str(nvs_handle, "lgname", NULL, &lgname_len);
        rets = nvs_get_str(nvs_handle, "lgpwd", NULL, &lgpwd_len);
        switch (rets) {
        case ESP_OK:
          break;
        case ESP_ERR_NVS_NOT_FOUND:
          ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "lgname", "admin"));
          ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "lgpwd", "12345678"));
          break;
        default:
          printf("Error getting NVS data: %s\n", esp_err_to_name(rets));
          break;
        }

        if (rets == ESP_OK) {
          char *nvs_lgname = malloc(lgname_len);
          char *nvs_lgpwd = malloc(lgpwd_len);
          if (nvs_lgname != NULL && nvs_lgpwd != NULL) {
            rets = nvs_get_str(nvs_handle, "lgname", nvs_lgname, &lgname_len);
            rets = nvs_get_str(nvs_handle, "lgpwd", nvs_lgpwd, &lgpwd_len);
            if (rets == ESP_OK) {
              if (cJSON_IsString(uname) && cJSON_IsString(passwd) &&
                  strcmp(uname->valuestring, nvs_lgname) == 0 &&
                  strcmp(passwd->valuestring, nvs_lgpwd) == 0) {
                printf("Login success\n");
                if (udpmsg == NULL) {
                  udpmsg = strdup("{\"change\":\"ok\"}");
                }
                printf("Username: %s, Password: %s\n", uname->valuestring,
                       passwd->valuestring);
                printf("Name: %s, IP: %s, Mask: %s, Gateway: %s\n", global_name,
                       global_ip, global_mask, global_gateway);
                ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "is_dhcp", "2"));
                ESP_ERROR_CHECK(
                    nvs_set_str(nvs_handle, "host_names", global_name));
                ESP_ERROR_CHECK(
                    nvs_set_str(nvs_handle, "static_ip", global_ip));
                ESP_ERROR_CHECK(
                    nvs_set_str(nvs_handle, "static_netmask", global_mask));
                ESP_ERROR_CHECK(
                    nvs_set_str(nvs_handle, "static_gateway", global_gateway));
                if (udpmsg != NULL) {
                  err = sendto(udp_server_sock, udpmsg, strlen(udpmsg), 0,
                               (struct sockaddr *)&source_addr,
                               sizeof(source_addr));
                  if (err < 0) {
                    ESP_LOGE(TAG, "Error occurred during sending: errno %d",
                             errno);
                  }
                  free(udpmsg);
                  udpmsg = NULL;
                }
                vTaskDelay(500 / portTICK_PERIOD_MS);
                esp_restart();

              } else {
                printf("Login failed: Username or password incorrect\n");
                if (udpmsg == NULL) {
                  udpmsg = strdup("{\"change\":\"failed\"}");
                }
              }
            } else {
              printf("Error reading NVS data: %s\n", esp_err_to_name(rets));
            }

            free(nvs_lgname);
            free(nvs_lgpwd);
          } else {
            printf("Memory allocation failed\n");
          }
        } else {
          printf("Error getting NVS data size: %s\n", esp_err_to_name(rets));
        }

        nvs_close(nvs_handle);
        cJSON_Delete(pJsonRoot);

        int err = sendto(udp_server_sock, udpmsg, strlen(udpmsg), 0,
                         (struct sockaddr *)&source_addr, sizeof(source_addr));
        if (err < 0) {
          ESP_LOGE(TAG, "Error occurred during sending: errno %d", errno);
          break;
        }
      }
    }
    if (udp_server_sock != -1) {
      ESP_LOGE(TAG, "Shutting down socket and restarting...");
      shutdown(udp_server_sock, 0);
      close(udp_server_sock);
      udp_server_sock = -1;
    }
  }
  vTaskDelete(NULL);
}

void start_udp_server(void) {
  if (xHandleUDPServerTask == NULL) {
    printf("START UDP SERVER!!\n");
    xTaskCreate(udp_server_task, "udp_server", 4096, (void *)AF_INET, 5,
                &xHandleUDPServerTask);
  }
}

void kill_udp_server(void) {
  if (xHandleUDPServerTask != NULL) {
    printf("KILL UDP SERVER!!\n");
    if (udp_server_sock != -1) {
      shutdown(udp_server_sock, 0);
      close(udp_server_sock);
      udp_server_sock = -1;
    }
    vTaskDelete(xHandleUDPServerTask);
    xHandleUDPServerTask = NULL;
  }
}

/*************************************************************************************/
/*                                END OF FILE */
/*************************************************************************************/