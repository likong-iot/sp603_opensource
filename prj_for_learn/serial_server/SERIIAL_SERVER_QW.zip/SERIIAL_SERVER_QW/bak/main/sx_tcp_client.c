/*
 * @Author: Orion
 * @Date: 2024-01-23 16:08:26
 * @LastEditors: Orion
 * @LastEditTime: 2024-10-18 11:32:25
 * @FilePath: \SERIIAL_SERVER\main\sx_tcp_client.c
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */

#include "cJSON.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"
#include "freertos/task.h"
#include "nvs.h"
#include "nvs_flash.h"
#include "sdkconfig.h"
// #include "sx_async_uart.h"
#include "sx_utils.h"
#include <arpa/inet.h>
#include <errno.h>
#include <netdb.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

static const char *TAG = "TCPCLIENT";
TaskHandle_t xHandleTaskTCPClient = NULL;
int global_client_sock = -1;

bool tcp_server_conn = false;
int global_tcp_server = 0;
/*************************************************************************************/
/*                                START OF FILE */
/*************************************************************************************/

void tcpclient_message(char *message,int rxBytes) {
  // printf("12312312312312312312312321333333333333333: %s\n", message);
  if (global_client_sock != -1) {
    int to_write = rxBytes;
    while (to_write > 0) {
      int written = send(global_client_sock, message, to_write, 0);
      if (written < 0) {
        ESP_LOGE(TAG, "Error occurred during sending: errno %d", errno);
        return;
      }
      to_write -= written;
    }
  } else {
    ESP_LOGE(TAG, "No active socket to send message");
  }
}

void tcp_client(void *pvParameters) {
  char rx_buffer[256];
  int addr_family = 0;
  int ip_protocol = 0;
  int port = 0;
  char ip[32];
  esp_err_t ret = nvs_flash_init();
  if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
    ESP_ERROR_CHECK(nvs_flash_erase());
    ret = nvs_flash_init();
  }
  ESP_ERROR_CHECK(ret);

  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));

  size_t use_tcp, tcpconn, tcp_server, tcp_port;
  ret = nvs_get_str(nvs_handle, "use_tcp", NULL, &use_tcp);
  nvs_get_str(nvs_handle, "tcpconn", NULL, &tcpconn);
  nvs_get_str(nvs_handle, "tcp_server", NULL, &tcp_server);
  nvs_get_str(nvs_handle, "tcp_port", NULL, &tcp_port);
  if (ret != ESP_OK) {
    printf("Error getting size of 'my_key': %s\n", esp_err_to_name(ret));
  } else {
    char *nvs_use_tcp = malloc(use_tcp);
    char *nvs_tcpconn = malloc(tcpconn);
    char *nvs_tcp_server = malloc(tcp_server);
    char *nvs_tcp_port = malloc(tcp_port);

    if (nvs_use_tcp == NULL || nvs_tcpconn == NULL || nvs_tcp_server == NULL || nvs_tcp_port == NULL) {
      printf("Memory allocation failed\n");
      free(nvs_use_tcp);
      free(nvs_tcpconn);
      free(nvs_tcp_server);
      free(nvs_tcp_port);
    } else {
      ret = nvs_get_str(nvs_handle, "use_tcp", nvs_use_tcp, &use_tcp);
      nvs_get_str(nvs_handle, "tcpconn", nvs_tcpconn, &tcpconn);
      nvs_get_str(nvs_handle, "tcp_server", nvs_tcp_server, &tcp_server);
      nvs_get_str(nvs_handle, "tcp_port", nvs_tcp_port, &tcp_port);
      if (ret == ESP_OK) {
        strncpy(ip, nvs_tcp_server, sizeof(ip));
        ip[sizeof(ip) - 1] = '\0';
        port = atoi(nvs_tcp_port);
        printf("Copied string: %s\n", ip);
        printf("Copied port: %d\n", port);
      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_use_tcp);
      free(nvs_tcpconn);
      free(nvs_tcp_server);
      free(nvs_tcp_port);
    }
  }
  nvs_close(nvs_handle);

  struct sockaddr_in dest_addr;
  inet_pton(AF_INET, ip, &dest_addr.sin_addr);
  dest_addr.sin_family = AF_INET;
  dest_addr.sin_port = htons(port);
  addr_family = AF_INET;
  ip_protocol = IPPROTO_IP;

  while (1) {
    int sock = socket(addr_family, SOCK_STREAM, ip_protocol);
    global_client_sock = sock;
    if (sock < 0) {
      ESP_LOGE(TAG, "Unable to create socket: errno %d", errno);
      vTaskDelay(1000 / portTICK_PERIOD_MS);
      continue;
    }
    ESP_LOGI(TAG, "Socket created, connecting to %s:%d", ip, port);

    int err = connect(sock, (struct sockaddr *)&dest_addr, sizeof(dest_addr));
    if (err != 0) {
      ESP_LOGE(TAG, "Socket unable to connect: errno %d", errno);
      close(sock);
      global_client_sock = -1;
      tcp_server_conn=false;
      global_tcp_server=0;
      vTaskDelay(1000 / portTICK_PERIOD_MS);
      continue;
    } else {
      ESP_LOGI(TAG, "Successfully connected");
      tcp_server_conn=true;
      global_tcp_server=1;
    }

    while (tcp_server_conn) {
      int len = recv(sock, rx_buffer, sizeof(rx_buffer) - 1, 0);
      if (len < 0) {
        ESP_LOGE(TAG, "recv failed: errno %d", errno);
        close(sock);
        global_client_sock = -1;
        tcp_server_conn=false;
        global_tcp_server=0;
        break;
      } else if (len == 0) {
        ESP_LOGW(TAG, "Connection closed");
        close(sock);
        global_client_sock = -1;
        tcp_server_conn=false;
        global_tcp_server=0;
        break;
      } else {
        rx_buffer[len] = 0;
        ESP_LOGI(TAG, "Received %d bytes from %s:", len, ip);
        ESP_LOGI(TAG, "%s", rx_buffer);
        // tx_task((uint8_t *)rx_buffer, len);
      }
    }

    vTaskDelay(1000 / portTICK_PERIOD_MS);
  }
  vTaskDelete(NULL);
}


void start_tcp_client(void) {
  if (xHandleTaskTCPClient == NULL) {
    xTaskCreate(&tcp_client, "tcp_client", 4096, NULL, 5,
                &xHandleTaskTCPClient);
  }
}

/*************************************************************************************/
/*                                END OF FILE */
/*************************************************************************************/
