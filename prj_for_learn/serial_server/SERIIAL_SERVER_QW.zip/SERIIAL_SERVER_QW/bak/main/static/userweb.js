

let hasRestarted = false;

// Basic info API

const basicInfoElementIds = ['host_name', 'uptime', 'net_mode', 'eth_mac', 'eth_ip', 'sta_mac', 'sta_ip', 'is_dhcps', 'g_ccid', 'g_cgsn', 'g_4gip'];
const basicInfoElements = basicInfoElementIds.reduce((obj, id) => ({ ...obj, [id]: document.getElementById(id) }), {});

async function updateBasicInfo() {
    try {
        const response = await fetch('/devinfo');
        if (!response.ok) {
            console.error('Failed to fetch data. Status:', response.status);
            return;
        }
        const data = await response.json();
        basicInfoElements.host_name.textContent = data.host_names || '物小能G1';
        basicInfoElements.uptime.textContent = data.uptime || '---';
        basicInfoElements.eth_mac.textContent = data.device_eth_mac || '---';
        basicInfoElements.eth_ip.textContent = data.eth_ip || '---';
        basicInfoElements.sta_mac.textContent = data.device_sta_mac || '---';
        basicInfoElements.is_dhcps.textContent = data.is_dhcp == 2 ? 'STATIC(静态IP)' : 'DHCP(动态IP)';
        basicInfoElements.net_mode.textContent =
            data.netconn == 2 ? 'WIFI(无线连接)' :
                data.netconn == 3 ? '4G' :
                    '以太网(有线连接)';

        basicInfoElements.sta_ip.textContent = data.sta_ip;
        // 更新4G相关信息和MQTT状态
        if (data.netconn == 3 && data.g_4gip && data.uptime) {
            basicInfoElements.g_4gip.textContent = data.g_4gip;
            basicInfoElements.g_ccid.textContent = data.g_ccid || '---';
            basicInfoElements.g_cgsn.textContent = data.g_cgsn || '---';
            // 如果是4G模式且有IP和时间,设置MQTT状态为已连接
            const mqttconnected = document.getElementById('mqttconnected');
            if (mqttconnected) {
                mqttconnected.textContent = "已连接";
                mqttconnected.style.color = "#5cb85c";
            }
        } else {
            basicInfoElements.g_4gip.textContent = '---';
            basicInfoElements.g_ccid.textContent = '---';
            basicInfoElements.g_cgsn.textContent = '---';
        }

    } catch (error) {
        console.error('Failed to fetch data:', error);
    }
}


updateBasicInfo();
setInterval(updateBasicInfo, 5000);

let selectedTarget = 'uart';

function createTabs() {
    fetch('/targets')
        .then(response => response.json())
        .then(data => {
            const tabsContainer = document.getElementById('tabsContainer');
            tabsContainer.innerHTML = '';

            data.targets.forEach(target => {
                const button = document.createElement('button');
                button.textContent = target.name === 'uart' ? '串口' : target.name;
                button.className = 'tab-button';
                button.style.cssText = `
                    background-color: transparent;
                    border: none;
                    padding: 10px 16px;
                    cursor: pointer;
                    font-size: 14px;
                    outline: none;
                    margin-left: 10px;
                `;

                if (target.name === selectedTarget) {
                    button.style.borderBottom = '2px solid #009ee1';
                    button.style.color = '#009ee1';
                }

                button.addEventListener('mouseover', () => {
                    if (target.name !== selectedTarget) {
                        button.style.backgroundColor = '#f0f0f0';
                    }
                });

                button.addEventListener('mouseout', () => {
                    if (target.name !== selectedTarget) {
                        button.style.backgroundColor = 'transparent';
                    }
                });

                button.addEventListener('click', () => {
                    selectedTarget = target.name;
                    highlightActiveTab(tabsContainer, button);
                    updateStatistics();
                });

                tabsContainer.appendChild(button);
            });
        })
        .catch(err => {
            console.error('获取 targets 失败:', err);
        });
}
function highlightActiveTab(container, activeButton) {
    Array.from(container.children).forEach(button => {
        button.style.borderBottom = 'none';
        button.style.color = '#333';
        button.style.backgroundColor = 'transparent';
    });

    activeButton.style.borderBottom = '2px solid #009ee1';
    // activeButton.style.color = '#009ee1';
}


function updateStatistics() {
    fetch('/statistics')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.text();
        })
        .then(text => {
            try {
                return JSON.parse(text);
            } catch (e) {
                console.error('Failed to parse JSON:', text);
                throw e;
            }
        })
        .then(data => {
            const send_frames = document.getElementById('send_frames');
            const send_bytes = document.getElementById('send_bytes');
            const failed_frames = document.getElementById('failed_frames');
            const failed_bytes = document.getElementById('failed_bytes');
            const recv_frames = document.getElementById('recv_frames');
            const recv_bytes = document.getElementById('recv_bytes');
            const failedStatsRow1 = document.getElementById('failed_stats_row1');
            const failedStatsRow2 = document.getElementById('failed_stats_row2');

            if (!send_frames || !send_bytes || !recv_frames || !recv_bytes) {
                console.error('Required elements not found');
                return;
            }

            if (selectedTarget === 'uart') {
                const stats = data.uart || {
                    send_frame_success: 0,
                    send_byte_success: 0,
                    recv_frame_success: 0,
                    recv_byte_success: 0
                };

                document.querySelector('[data-translate="send_frames"]').textContent = '发送成功帧数';
                document.querySelector('[data-translate="send_bytes"]').textContent = '发送成功字节数';
                document.querySelector('[data-translate="recv_frames"]').textContent = '接收成功帧数';
                document.querySelector('[data-translate="recv_bytes"]').textContent = '接收成功字节数';

                send_frames.textContent = `：${stats.send_frame_success}`;
                send_bytes.textContent = `：${stats.send_byte_success}`;
                recv_frames.textContent = `：${stats.recv_frame_success}`;
                recv_bytes.textContent = `：${stats.recv_byte_success}`;

                failedStatsRow1.style.display = 'none';
                failedStatsRow2.style.display = 'none';
            } else {
                // 为非 uart target 设置默认值
                const stats = (data.targets && data.targets[selectedTarget]) || {
                    send_frame_success: 0,
                    send_byte_success: 0,
                    send_frame_failed: 0,
                    send_byte_failed: 0,
                    recv_frame: 0,
                    recv_byte: 0
                };

                document.querySelector('[data-translate="send_frames"]').textContent = '发送成功帧数';
                document.querySelector('[data-translate="send_bytes"]').textContent = '发送成功字节数';
                document.querySelector('[data-translate="recv_frames"]').textContent = '接收帧数';
                document.querySelector('[data-translate="recv_bytes"]').textContent = '接收字节数';

                send_frames.textContent = `：${stats.send_frame_success}`;
                send_bytes.textContent = `：${stats.send_byte_success}`;
                recv_frames.textContent = `：${stats.recv_frame}`;
                recv_bytes.textContent = `：${stats.recv_byte}`;
                failed_frames.textContent = `：${stats.send_frame_failed}`;
                failed_bytes.textContent = `：${stats.send_byte_failed}`;

                failedStatsRow1.style.display = 'block';
                failedStatsRow2.style.display = 'block';
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
}

createTabs();
updateStatistics();

setInterval(updateStatistics, 2000);

// Post Get basic function

async function postData(url = '', data = {}) {
    const response = await fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Connection': 'close'  // 禁用Keep-Alive
        },
        body: JSON.stringify(data)
    });
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    return response.json();
}

async function fetchData(url = '') {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    return response.json();
}


// Net config API

window.onload = () => autoDHCP(document.getElementById('is_dhcp'));

function autoDHCP(element) {
    element.classList.toggle('on');
    element.classList.toggle('off');
    document.getElementById('is_dhcp').value = element.classList.contains('on') ? '2' : '1';
    ['static_ip', 'static_netmask', 'static_gateway', 'static_dns1', 'static_dns2'].forEach(id => {
        if (element.classList.contains('on')) {
            document.getElementById(id).removeAttribute('disabled');
        } else {
            document.getElementById(id).setAttribute('disabled', true);
        }
    });
}

// 添加一个对象来存储静态IP配置
let staticIPConfig = {
    static_ip: '',
    static_netmask: '',
    static_gateway: '',
    static_dns1: '',
    static_dns2: ''
};

function changeNetSelect(id) {
    [...document.getElementsByClassName('network-btn')].forEach(btn => btn.style.background = '#898989a1');
    document.getElementById(id).style.background = '#009ee1';
    document.getElementById('selectedNetwork').value = (id === 'ethernet') ? 1 : (id === 'wifi') ? 2 : 3;
    ['wifi_ssid_div', 'wifi_password_div', 'wifisearch', 'scanList'].forEach(el =>
        document.getElementById(el).style.display = (id === 'ethernet' || id === 'sim4g') ? 'none' : 'flex'
    );

    const is4GSelected = id === 'sim4g';
    const staticIPFields = ['static_ip', 'static_netmask', 'static_gateway', 'static_dns1', 'static_dns2'];

    if (is4GSelected) {
        // 保存当前静态IP配置和开关状态
        const staticIpSwitch = document.getElementById('static_ip_switch');
        staticIPConfig.switchState = staticIpSwitch.classList.contains('on');

        staticIPFields.forEach(field => {
            staticIPConfig[field] = document.getElementById(field).value;
        });

        // 隐藏静态IP相关元素
        [...staticIPFields, 'static_ip_switch'].forEach(field => {
            const div = document.getElementById(field + '_div');
            if (div) div.style.display = 'none';
        });

        // 如果静态IP开关是打开的，关闭它
        if (!staticIpSwitch.classList.contains('off')) {
            autoDHCP(staticIpSwitch);
        }
    } else {
        // 显示静态IP相关元素
        [...staticIPFields, 'static_ip_switch'].forEach(field => {
            const div = document.getElementById(field + '_div');
            if (div) div.style.display = 'flex';
        });

        // 恢复之前保存的静态IP配置
        staticIPFields.forEach(field => {
            if (staticIPConfig[field]) {
                document.getElementById(field).value = staticIPConfig[field];
            }
        });

        // 恢复开关状态
        if (staticIPConfig.switchState) {
            const staticIpSwitch = document.getElementById('static_ip_switch');
            if (staticIpSwitch.classList.contains('off')) {
                autoDHCP(staticIpSwitch);
            }
        }
    }
}

document.getElementById("net_set").addEventListener("submit", event => event.preventDefault());

function validateIP(ip) {
    const ipPattern = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    return ipPattern.test(ip);
}

async function netsetSubmit() {
    let isValid = true;
    const fields = [];
    const selectedNetwork = document.getElementById('selectedNetwork').value;
    const isDHCP = document.getElementById('is_dhcp').value;
    if ((selectedNetwork == '1' && isDHCP == '2') || (selectedNetwork == '2' && isDHCP == '2')) {
        fields.push({
            id: 'static_ip',
            errMsg: 'IP地址格式不正确',
            validate: validateIP
        }, {
            id: 'static_netmask',
            errMsg: '子网掩码格式不正确',
            validate: validateIP
        }, {
            id: 'static_gateway',
            errMsg: '网关格式不正确',
            validate: validateIP
        }, {
            id: 'static_dns1',
            errMsg: 'DNS1格式不正确',
            validate: validateIP
        }, {
            id: 'static_dns2',
            errMsg: 'DNS2格式不正确',
            validate: validateIP
        });
    }
    if (selectedNetwork == '2') {
        const ssid = document.getElementById('wifi_ssid').value;
        const password = document.getElementById('wifi_password').value;
        if (!ssid) {
            document.getElementById('wifi_ssid').nextElementSibling.textContent = 'WiFi名称不能为空';
            isValid = false;
        }
        if (!password || password.length < 8) {
            document.getElementById('wifi_password').nextElementSibling.textContent = 'WiFi密码不能为空且最少8位';
            isValid = false;
        }
    }

    for (const field of fields) {
        const input = document.getElementById(field.id);
        const errText = input.nextElementSibling;
        const value = input.value.trim();

        if (!value) {
            errText.textContent = field.errMsg;
            isValid = false;
        } else if (field.validate && !field.validate(value)) {
            errText.textContent = field.errMsg;
            isValid = false;
        } else {
            errText.textContent = '';
        }
    }
    if (!isValid) {
        return;
    }
    const formData = new FormData(document.getElementById('net_set'));
    const data = Object.fromEntries(formData);
    try {
        await postData('/net_set', data);
        document.getElementById('netSetButton').textContent = "设置成功";
        if (!hasRestarted) {
            const deviceRestart = document.getElementById('deviceRestart');
            if (deviceRestart) {
                showSvg('deviceRestart', 6000);
                hasRestarted = true;
            }
        }
    } catch (error) {
        console.error('Error fetching data. Status:', error);
        document.getElementById('netSetButton').textContent = '设置失败';
    }
    setTimeout(() => document.getElementById('netSetButton').textContent = '设置', 2000);
}

document.getElementById('netSetButton').addEventListener('click', netsetSubmit);


async function netsetfetchData() {
    try {
        const responseData = await fetchData('/net_set_info');
        if (!responseData) {
            console.error('No data returned from /net_set_info');
            return;
        }
        // 保存初始静态IP配置
        ['static_ip', 'static_netmask', 'static_gateway', 'static_dns1', 'static_dns2'].forEach(id => {
            document.getElementById(id).value = responseData[id];
            staticIPConfig[id] = responseData[id];  // 保存到staticIPConfig
        });

        if (responseData.netconn == 1 || responseData.netconn == 0) {
            document.getElementById('ethernet').click();
        }
        if (responseData.netconn == 2) {
            document.getElementById('wifi').click();
            ['wifi_ssid', 'wifi_password'].forEach(id => document.getElementById(id).value = responseData[id]);
        }
        if (responseData.netconn == 3) {
            document.getElementById('sim4g').click();
        }
        const static_ip_switch = document.getElementById('static_ip_switch');
        static_ip_switch.classList.toggle('off', responseData.is_dhcp == 1);
        static_ip_switch.classList.toggle('on', responseData.is_dhcp == 2);
        ['static_ip', 'static_netmask', 'static_gateway', 'static_dns1', 'static_dns2'].forEach(id => {
            if (responseData.is_dhcp == 1) {
                document.getElementById(id).setAttribute('disabled', true);
            } else {
                document.getElementById(id).removeAttribute('disabled');
            }
        });
    } catch (error) {
        console.error('Failed to fetch data. Status:', error);
    }
}

netsetfetchData();


// Search wifi API

function clickwifi(element) {
    document.getElementById('wifi_ssid').value = element.value;
    [...document.querySelectorAll('#wifitable .addwifi')].forEach(row => row.style.backgroundColor = '');
    element.parentNode.parentNode.parentNode.style.backgroundColor = '#004ba93d';
}

document.getElementById('wifisearch').addEventListener('click', async () => {
    document.getElementById('wifisearch').textContent = '搜索中';
    try {
        const data = await fetchData('/find_wifi');
        document.getElementById('scanList').style.display = 'flex';
        [...document.getElementsByClassName('addwifi')].forEach(tr => tr.remove());
        for (const key in data) {
            const tr = document.createElement("tr");
            tr.setAttribute('class', 'addwifi');
            let td = document.createElement("td");
            td.innerHTML = `<label class='bui-radios-label'><input type='radio' name='wifi'  onclick='clickwifi(this)' value='${key}'/><i class='bui-radios'></i> ${key}</label>`;
            tr.appendChild(td);
            td = document.createElement("td");
            td.innerHTML = `${data[key]}dBm `;
            tr.appendChild(td);
            document.getElementById('clusss').parentNode.insertBefore(tr, document.getElementById('clusss'));
        }
        setTimeout(() => document.getElementById('wifisearch').textContent = '搜索', 200);
    } catch (error) {
        console.error('Error fetching data. Status:', error);
    }
});



// System data API

const systemElements = {
    version: document.getElementById('version'),
    free_heap_size: document.getElementById('free_heap_size'),
    min_ever_free_heap_size: document.getElementById('min_ever_free_heap_size'),
    time_since_boot: document.getElementById('time_since_boot'),
    res_reason: document.getElementById('res_reason')
};

function formatTime(microseconds) {
    const totalSeconds = Math.floor(microseconds / 1000000);
    const days = Math.floor(totalSeconds / (24 * 3600));
    const hours = Math.floor((totalSeconds % (24 * 3600)) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    return `${days > 0 ? days + " day " : ""}${hours > 0 ? hours + " hour " : ""}${minutes > 0 ? minutes + " minute " : ""}${seconds > 0 ? seconds + " second" : ""}`.trim();
}

async function sysfetchData() {
    try {
        const responseData = await fetchData('/sys');
        systemElements.version.textContent = responseData.version;
        systemElements.free_heap_size.textContent = (responseData.free_heap_size).toFixed(2) + " KB ";
        systemElements.min_ever_free_heap_size.textContent = (responseData.min_ever_free_heap_size).toFixed(2) + " KB ";
        systemElements.time_since_boot.textContent = formatTime(responseData.time_since_boot);
        systemElements.res_reason.textContent = responseData.res_reason;
    } catch (error) {
        console.error('Failed to fetch data. Status:', error);
        Object.values(systemElements).forEach(element => element.textContent = "---");
    }
}


setInterval(sysfetchData, 5000);
sysfetchData();

// Module set API

document.getElementById("module_set").addEventListener("submit", event => event.preventDefault());

async function modulesetSubmit() {
    const formData = new FormData(document.getElementById('module_set'));
    const data = Object.fromEntries(formData);
    try {
        await postData('/module_set', data);
        document.getElementById('moduleSetButton').textContent = "设置成功";
    } catch (error) {
        console.error('Error fetching data. Status:', error);
        document.getElementById('moduleSetButton').textContent = '设置失败';
    }
    setTimeout(() => document.getElementById('moduleSetButton').textContent = '设置', 2000);
}

document.getElementById('moduleSetButton').addEventListener('click', modulesetSubmit);

async function modulesetfetchData() {
    try {
        const responseData = await fetchData('/module_set_info');
        ['host_names', 'lgname', 'lgpwd'].forEach(id => document.getElementById(id).value = responseData[id]);
        document.getElementById('moduleSetButton').textContent = responseData.host_names != "物小能G1" ? '设置' : '设置';
    } catch (error) {
        console.error('Failed to fetch data. Status:', error);
    }
}

modulesetfetchData();





// Opreate API

const observer = new MutationObserver(mutations => {
    mutations.forEach(mutation => {
        if (mutation.type === 'childList') {
            const deviceRestart = document.getElementById('deviceRestart');

            if (deviceRestart && deviceRestart.style.display !== 'none') {
                handleDeviceRestart();
            }

        }
    });
});

const config = { attributes: true, childList: true, subtree: true };
observer.observe(document.body, config);

async function handleDeviceRestart() {
    document.getElementById('cancelRestart').addEventListener('click', () => {
        deviceRestart.style.display = 'none';
        hasRestarted = false;
    });
    document.getElementById('restart').addEventListener('click', async () => {
        deviceRestart.style.display = 'none';
        hasRestarted = false;
        try {
            await fetchData('/operate');
            displaySuccessMessage('重启中，请稍后...');
            setTimeout(() => location.reload(), 5000);
        } catch (error) {
            console.error('Error:', error);
        }
    });
}



function displaySuccessMessage(message) {
    let svg = document.getElementById('successMessage');
    svg.style.display = 'flex';
    document.getElementById('msgValue').textContent = message;
    const clone = svg.cloneNode(true);
    svg.parentNode.replaceChild(clone, svg);
    svg = clone;
    setTimeout(() => svg.style.display = 'none', 1200);
}



// System banner tree

window.onload = function () {
    // Password visibility toggle
    const passwordFields = [
        { input: 'lgpwd', openEye: 'eyeOpen', closedEye: 'eyeClosed' },
        { input: 'mqtt_password', openEye: 'mqtteyeOpen', closedEye: 'mqtteyeClosed' },
        { input: 'wifi_password', openEye: 'wifieyeOpen', closedEye: 'wifieyeClosed' }
    ];

    function togglePasswordVisibility(input, openEye, closedEye) {
        input.type = input.type === 'password' ? 'text' : 'password';
        openEye.style.display = input.type === 'password' ? 'none' : 'block';
        closedEye.style.display = input.type === 'password' ? 'block' : 'none';
    }

    passwordFields.forEach(field => {
        const input = document.getElementById(field.input);
        const openEye = document.getElementById(field.openEye);
        const closedEye = document.getElementById(field.closedEye);
        openEye.addEventListener('click', () => togglePasswordVisibility(input, openEye, closedEye));
        closedEye.addEventListener('click', () => togglePasswordVisibility(input, openEye, closedEye));
    });

    // Form validation
    var otaUrlInput = document.getElementById('ota_url');
    var otaSubmitButton = document.getElementById('otaSubmitButton');
    otaUrlInput.addEventListener('input', function () {
        if (otaUrlInput.value) {
            otaSubmitButton.disabled = false;
        } else {
            otaSubmitButton.disabled = true;
        }
    });
    var hostNamesInput = document.getElementById('host_names');
    var lgnameInput = document.getElementById('lgname');
    var lgpwdInput = document.getElementById('lgpwd');
    var moduleSetButton = document.getElementById('moduleSetButton');
    function checkInput() {
        if (hostNamesInput.value && lgnameInput.value && lgpwdInput.value) {
            moduleSetButton.disabled = false;
        } else {
            moduleSetButton.disabled = true;
        }
    }
    hostNamesInput.addEventListener('input', checkInput);
    lgnameInput.addEventListener('input', checkInput);
    lgpwdInput.addEventListener('input', checkInput);
    checkInput();
};

function toggleClass(elementId, ...classNames) {
    var element = document.getElementById(elementId);
    classNames.forEach(function (className) {
        element.classList.toggle(className);
    });
}

function switchView(activeViewId, activeLinkId, mainClass, mainTitleText, isMobile) {
    var viewIds = ['infoView', 'configurationView', 'sysView', 'advancedView', 'netView'];
    var linkIds = ['basicInfo', 'configurationDashbord', 'sysConfig', 'advancedSet', 'netConfig', 'basicInfo_m', 'configurationDashbord_m', 'sysConfig_m', 'advancedSet_m', 'netConfig_m'];
    var main = document.getElementById("main");
    var mainTitle = document.getElementById("mainTitle");

    viewIds.forEach(function (id) {
        var view = document.getElementById(id);
        if (view) {
            view.style.display = (id === activeViewId) ? 'block' : 'none';
        }
    });

    linkIds.forEach(function (id) {
        var link = document.getElementById(id);
        if (link) { // Ensure the link element exists
            if (id === activeLinkId || id === activeLinkId + '_m') {
                link.classList.add('router-link-exact-active', 'router-link-active', 'active');
                toggleClass("nav-top", "nav-off", "nav-on");
                toggleClass("app-icon", "icondaohang", "iconchahao");
                toggleClass("nav-lists", "nav-on");
                toggleClass("version-div", "nav-on");
            } else {
                link.classList.remove('router-link-exact-active', 'router-link-active', 'active');
            }
        }
    });

    if (main) {
        main.className = mainClass;
    }

    if (mainTitle) {
        mainTitle.textContent = mainTitleText;
    }
}

function addEventListenerToElement(elementId, viewId, linkId, mainClass, mainTitle, isMobile) {
    var element = document.getElementById(elementId);
    if (element) { // Ensure element exists
        element.addEventListener("click", function () {
            switchView(viewId, linkId, mainClass, mainTitle, isMobile);
            if (isMobile) {
                setTimeout(function () {
                    toggleClass("nav-top", "nav-off", "nav-on");
                    toggleClass("app-icon", "icondaohang", "iconchahao");
                    toggleClass("nav-lists", "nav-on");
                    toggleClass("version-div", "nav-on");
                }, 100);
            }
        });
    }
}

document.getElementById("app-icon-btn").addEventListener("click", function () {
    toggleClass("nav-top", "nav-off", "nav-on");
    toggleClass("app-icon", "icondaohang", "iconchahao");
    toggleClass("nav-lists", "nav-on");
    toggleClass("version-div", "nav-on");
});

function showSvg(svgId, duration) {
    var svg = document.getElementById(svgId);
    svg.style.display = 'flex';
    var clone = svg.cloneNode(true);
    svg.parentNode.replaceChild(clone, svg);
    svg = clone;
    setTimeout(function () {
        svg.style.display = 'none';
    }, duration);
}


document.getElementById("restartButton").addEventListener("click", function () {
    showSvg('deviceRestart', 6000);
    hasRestarted = false;
});



// i18n.js
const translations = {
    en: {
        basic_info: "Basic Information",
        sensor_info: "Sensor Information",
        device_name: "Device Name",
        current_time: "Current Time",
        net_mode: "Network Mode",
        eth_mac: "Ethernet MAC",
        eth_ip: "Ethernet IP Address",
        wifi_mac: "WiFi MAC",
        wifi_ip: "WiFi IP Address",
        ip_acquisition: "IP Acquisition Method",
        sensor_dashboard: "Sensor Dashboard",
        network_settings: "Network Settings",
        network_mode_selection: "Network Mode Selection",
        ethernet: "Ethernet",
        wifi: "WiFi",
        static_ip: "Static IP",
        wifi_name: "WiFi Name",
        wifi_password: "WiFi Password",
        scan_list: "Scan List",
        signal_strength: "Signal Strength",
        ip_address: "IP Address",
        subnet_mask: "Subnet Mask",
        gateway: "Gateway",
        search: "Search",
        submit: "Submit",
        mqttSettings: "MQTT Settings",
        mqttsubmit: "Submit",
        mqttenable: "Enable",
        mqttServerAddress: "Server Address",
        mqttServerPort: "Server Port",
        mqttUsername: "Username",
        mqttPassword: "Password",
        mqttClientID: "Client ID",
        subscribeTopic: "Subscribe Topic",
        publishTopic: "Publish Topic",
        qos: "QoS",
        retain: "Retain",
        timedReport: "Timed Report",
        mqttIntervalTime: "Interval Time",
        mqttConnectionStatus: "Connection Status",
        mqttnConnected: "Connected",
        tcpSettings: "TCP Settings",
        tcpSubmit: "Submit",
        tcpUse: "Enable",
        tcpProtocolType: "Protocol Type",
        tcpServer: "TCP Server",
        tcpClient: "TCP Client",
        tcpIntervalTime: "Interval Time",
        tcpAddress: "Server Address",
        tcpPort: "Server Port",
        tcpConn: "Connection Status",
        tcpnConn: "Connected",
        httpSettings: "HTTP/HTTPS Settings",
        requestType: "Request Type",
        http: "HTTP",
        https: "HTTPS",
        post: "POST",
        get: "GET",
        deviceTitle: "Serial Device Server",
        deviceBasicInfo: "Basic Information",
        deviceConfigurationDashbord: "Configuration Dashboard",
        deviceProtocolConfig: "Protocol Management",
        deviceWiFiConfig: "Network Management",
        deviceAdvancedSet: "Advanced Settings",
        deviceSysConfig: "System Management",
        lkWEB: "LK-WEB",
        ztList: "Configuration Dashboard",
        deviceHDvalue: "Hardware Parameters",
        sysVeren: "System Version",
        deviceFreeHeap: "Available Heap Memory",
        deviceMinHeap: "Minimum Available Heap Size",
        deviceRunTime: "System Uptime",
        deviceResReason: "Last Restart Reason",
        loginSet: "Login Settings",
        loginSubmit: "Set",
        deviceName: "Device Name",
        deviceUname: "Username",
        devicePwd: "Login Password",
        deviceOTA: "OTA Firmware Upgrade",
        otaSubmit: "Upgrade",
        otaURL: "OTA URL",
        deviceRestart: "Restart Device",
        isrestart: "Restart",
        deviceReset: "Reset Device",
        isreset: "Reset",
        isdreset: "Restart Device",
        isqreset: "Are you sure you want to restart?",
        dcancel: "Cancel",
        dreq: "Confirm",
        isdres: "Reset Device",
        isqres: "Are you sure you want to reset? The device will be reset after confirmation.",
        scancel: "Cancel",
        sreq: "Confirm",
        opsuccess: "Operation Successful",
        setopsuccess: "Settings Updated Successfully",
        valueCompensate: "Parameter Compensation",
        vcSubmit: "Set",
        httpConn: "HTTP/HTTPS Settings",
        httpSet: "Settings",
        httpIsUse: "Enable",
        httpWay: "Request Method",
        http_time: "Interval Time",
        second: "Second",
        thpsensor: 'Sensor'
    },
    zh: {
        basic_info: "设备状态",
        sensor_info: "传感器信息",
        device_name: "设备名称",
        current_time: "当前时间",
        net_mode: "网络模式",
        eth_mac: "以太网MAC",
        eth_ip: "以太网IP地址",
        wifi_mac: "WiFi MAC",
        wifi_ip: "WiFi IP地址",
        ip_acquisition: "IP获取方式",
        sensor_dashboard: "传感器仪表",
        network_settings: "网络设置",
        network_mode_selection: "网络模式选择",
        ethernet: "以太网",
        wifi: "WiFi",
        static_ip: "静态IP",
        wifi_name: "WIFI名称",
        wifi_password: "WIFI密码",
        scan_list: "扫描列表",
        signal_strength: "信号强度",
        ip_address: "IP地址",
        subnet_mask: "子网掩码",
        gateway: "网关",
        search: "搜索",
        submit: "设置",
        mqttSettings: "MQTT设置",
        mqttsubmit: "设置",
        mqttenable: "是否启用",
        mqttServerAddress: "服务器地址",
        mqttServerPort: "服务器端口",
        mqttUsername: "用户名",
        mqttPassword: "密码",
        mqttClientID: "ClientID",
        subscribeTopic: "订阅主题",
        publishTopic: "发布主题",
        qos: "QOS",
        retain: "保留(Retain)",
        timedReport: "定时上报",
        mqttIntervalTime: "间隔时间",
        mqttConnectionStatus: "连接状态",
        mqttnConnected: "未连接",
        tcpSettings: "TCP设置",
        tcpSubmit: "设置",
        tcpUse: "是否启用",
        tcpProtocolType: "协议类型",
        tcpServer: "TCPServer",
        tcpClient: "TCPClient",
        tcpIntervalTime: "间隔时间",
        tcpAddress: "服务器地址",
        tcpPort: "服务器端口",
        tcpConn: "连接状态",
        tcpnConn: "未连接",
        httpSettings: "HTTP/HTTPS设置",
        requestType: "请求方式",
        http: "HTTP",
        https: "HTTPS",
        post: "POST",
        get: "GET",
        deviceTitle: "物小能G1",
        deviceBasicInfo: "基本信息",
        deviceConfigurationDashbord: "组态仪表",
        deviceProtocolConfig: "协议管理",
        deviceWiFiConfig: "网络管理",
        deviceAdvancedSet: "高级设置",
        deviceSysConfig: "系统管理",
        lkWEB: "立控官网",
        ztList: "组态仪表",
        deviceHDvalue: "硬件参数",
        sysVeren: "系统版本",
        deviceFreeHeap: "系统可用堆内存",
        deviceMinHeap: "最小可用堆大小",
        deviceRunTime: "系统运行时间",
        deviceResReason: "上一次重启原因",
        loginSet: "登录设置",
        loginSubmit: "设置",
        deviceName: "设备名称",
        deviceUname: "用户名",
        devicePwd: "登录密码",
        deviceOTA: "OTA固件升级",
        otaSubmit: "升级",
        otaURL: "OTA地址",
        deviceRestart: "重启设备",
        isrestart: "重启",
        deviceReset: "恢复出厂参数",
        isreset: "重置",
        isdreset: "重启设备",
        isqreset: "是否确定重启？",
        dcancel: "取消",
        dreq: "确认",
        isdres: "恢复出厂参数",
        isqres: "是否确定重置？确认后设备将被重置",
        scancel: "取消",
        sreq: "确认",
        opsuccess: "操作成功",
        setopsuccess: "设置参数成功",
        valueCompensate: "参数补偿",
        vcSubmit: "设置",
        httpConn: "HTTP/HTTPS设置",
        httpSet: "设置",
        httpIsUse: "是否启用",
        httpWay: "请求方式",
        http_time: "间隔时间",
        second: "秒",
        thpsensor: "传感器"
    }
};


let currentLang = 'zh';


function setLanguage(lang) {
    document.querySelectorAll("[data-translate]").forEach(el => {
        const key = el.getAttribute("data-translate");
        if (translations[lang][key]) {
            el.textContent = translations[lang][key];
        }
    });

    // Clear existing event listeners before rebinding
    ['basicInfo', 'basicInfo_m', 'configurationDashbord', 'configurationDashbord_m',
        'advancedSet', 'advancedSet_m', 'sysConfig', 'sysConfig_m',
        'protocolConfig', 'protocolConfig_m', 'netConfig', 'netConfig_m'].forEach(id => {
            var el = document.getElementById(id);
            if (el) {
                el.replaceWith(el.cloneNode(true)); // Clear event listeners
            }
        });

    // Rebind event listeners based on language
    if (lang === 'zh') {
        addEventListenerToElement("basicInfo", 'infoView', 'basicInfo', 'base-info', '基本信息', false);
        addEventListenerToElement("basicInfo_m", 'infoView', 'basicInfo', 'base-info', '基本信息', true);
        addEventListenerToElement("configurationDashbord", 'configurationView', 'configurationDashbord', 'base-info', '组态仪表', false);
        addEventListenerToElement("configurationDashbord_m", 'configurationView', 'configurationDashbord', 'base-info', '组态仪表', true);
        addEventListenerToElement("advancedSet", 'advancedView', 'advancedSet', 'security', '高级设置', false);
        addEventListenerToElement("advancedSet_m", 'advancedView', 'advancedSet', 'security', '高级设置', true);
        addEventListenerToElement("sysConfig", 'sysView', 'sysConfig', 'security', '系统管理', false);
        addEventListenerToElement("sysConfig_m", 'sysView', 'sysConfig', 'security', '系统管理', true);
        addEventListenerToElement("netConfig", 'netView', 'netConfig', 'base-info', '网络管理', false);
        addEventListenerToElement("netConfig_m", 'netView', 'netConfig', 'base-info', '网络管理', true);
    } else if (lang === 'en') {
        addEventListenerToElement("basicInfo", 'infoView', 'basicInfo', 'base-info', 'Basic Information', false);
        addEventListenerToElement("basicInfo_m", 'infoView', 'basicInfo', 'base-info', 'Basic Information', true);
        addEventListenerToElement("configurationDashbord", 'configurationView', 'configurationDashbord', 'base-info', 'Configuration Dashboard', false);
        addEventListenerToElement("configurationDashbord_m", 'configurationView', 'configurationDashbord', 'base-info', 'Configuration Dashboard', true);
        addEventListenerToElement("advancedSet", 'advancedView', 'advancedSet', 'security', 'Advanced Settings', false);
        addEventListenerToElement("advancedSet_m", 'advancedView', 'advancedSet', 'security', 'Advanced Settings', true);
        addEventListenerToElement("sysConfig", 'sysView', 'sysConfig', 'security', 'System Management', false);
        addEventListenerToElement("sysConfig_m", 'sysView', 'sysConfig', 'security', 'System Management', true);
        addEventListenerToElement("netConfig", 'netView', 'netConfig', 'base-info', 'Network Management', false);
        addEventListenerToElement("netConfig_m", 'netView', 'netConfig', 'base-info', 'Network Management', true);
    }

    currentLang = lang;
}

// Initial language setup
setLanguage(currentLang);
