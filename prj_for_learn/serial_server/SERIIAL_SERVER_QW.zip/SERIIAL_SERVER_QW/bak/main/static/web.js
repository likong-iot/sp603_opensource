

let hasRestarted = false;

// Basic info API

const basicInfoElementIds = ['host_name', 'uptime', 'net_mode', 'eth_mac', 'eth_ip', 'sta_mac', 'sta_ip', 'is_dhcps', 'g_ccid', 'g_cgsn', 'g_4gip'];
const basicInfoElements = basicInfoElementIds.reduce((obj, id) => ({ ...obj, [id]: document.getElementById(id) }), {});

async function updateBasicInfo() {
    try {
        const response = await fetch('/devinfo');
        if (!response.ok) {
            console.error('Failed to fetch data. Status:', response.status);
            return;
        }
        const data = await response.json();
        basicInfoElements.host_name.textContent = data.host_names || '物小能G1';
        basicInfoElements.uptime.textContent = data.uptime || '---';
        basicInfoElements.eth_mac.textContent = data.device_eth_mac || '---';
        basicInfoElements.eth_ip.textContent = data.eth_ip || '---';
        basicInfoElements.sta_mac.textContent = data.device_sta_mac || '---';
        basicInfoElements.is_dhcps.textContent = data.is_dhcp == 2 ? 'STATIC(静态IP)' : 'DHCP(动态IP)';
        basicInfoElements.net_mode.textContent =
            data.netconn == 2 ? 'WIFI(无线连接)' :
                data.netconn == 3 ? '4G' :
                    '以太网(有线连接)';

        basicInfoElements.sta_ip.textContent = data.sta_ip;
        // 更新4G相关信息和MQTT状态
        if (data.netconn == 3 && data.g_4gip && data.uptime) {
            basicInfoElements.g_4gip.textContent = data.g_4gip;
            basicInfoElements.g_ccid.textContent = data.g_ccid || '---';
            basicInfoElements.g_cgsn.textContent = data.g_cgsn || '---';
            // 如果是4G模式且有IP和时间,设置MQTT状态为已连接
            const mqttconnected = document.getElementById('mqttconnected');
            if (mqttconnected) {
                mqttconnected.textContent = "已连接";
                mqttconnected.style.color = "#5cb85c";
            }
        } else {
            basicInfoElements.g_4gip.textContent = '---';
            basicInfoElements.g_ccid.textContent = '---';
            basicInfoElements.g_cgsn.textContent = '---';
        }

    } catch (error) {
        console.error('Failed to fetch data:', error);
    }
}


updateBasicInfo();
setInterval(updateBasicInfo, 5000);


let selectedTarget = 'uart';

function createTabs() {
    fetch('/targets')
        .then(response => response.json())
        .then(data => {
            const tabsContainer = document.getElementById('tabsContainer');
            tabsContainer.innerHTML = '';

            data.targets.forEach(target => {
                const button = document.createElement('button');
                button.textContent = target.name === 'uart' ? '串口' : target.name;
                button.className = 'tab-button';
                button.style.cssText = `
                    background-color: transparent;
                    border: none;
                    padding: 10px 16px;
                    cursor: pointer;
                    font-size: 14px;
                    outline: none;
                    margin-left: 10px;
                `;

                if (target.name === selectedTarget) {
                    button.style.borderBottom = '2px solid #009ee1';
                    button.style.color = '#009ee1';
                }

                button.addEventListener('mouseover', () => {
                    if (target.name !== selectedTarget) {
                        button.style.backgroundColor = '#f0f0f0';
                    }
                });

                button.addEventListener('mouseout', () => {
                    if (target.name !== selectedTarget) {
                        button.style.backgroundColor = 'transparent';
                    }
                });

                button.addEventListener('click', () => {
                    selectedTarget = target.name;
                    highlightActiveTab(tabsContainer, button);
                    updateStatistics();
                });

                tabsContainer.appendChild(button);
            });
        })
        .catch(err => {
            console.error('获取 targets 失败:', err);
        });
}
function highlightActiveTab(container, activeButton) {
    Array.from(container.children).forEach(button => {
        button.style.borderBottom = 'none';
        button.style.color = '#333';
        button.style.backgroundColor = 'transparent';
    });

    activeButton.style.borderBottom = '2px solid #009ee1';
    // activeButton.style.color = '#009ee1';
}


function updateStatistics() {
    fetch('/statistics')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.text();
        })
        .then(text => {
            try {
                return JSON.parse(text);
            } catch (e) {
                console.error('Failed to parse JSON:', text);
                throw e;
            }
        })
        .then(data => {
            const send_frames = document.getElementById('send_frames');
            const send_bytes = document.getElementById('send_bytes');
            const failed_frames = document.getElementById('failed_frames');
            const failed_bytes = document.getElementById('failed_bytes');
            const recv_frames = document.getElementById('recv_frames');
            const recv_bytes = document.getElementById('recv_bytes');
            const failedStatsRow1 = document.getElementById('failed_stats_row1');
            const failedStatsRow2 = document.getElementById('failed_stats_row2');

            if (!send_frames || !send_bytes || !recv_frames || !recv_bytes) {
                console.error('Required elements not found');
                return;
            }

            if (selectedTarget === 'uart') {
                const stats = data.uart || {
                    send_frame_success: 0,
                    send_byte_success: 0,
                    recv_frame_success: 0,
                    recv_byte_success: 0
                };

                document.querySelector('[data-translate="send_frames"]').textContent = '发送成功帧数';
                document.querySelector('[data-translate="send_bytes"]').textContent = '发送成功字节数';
                document.querySelector('[data-translate="recv_frames"]').textContent = '接收成功帧数';
                document.querySelector('[data-translate="recv_bytes"]').textContent = '接收成功字节数';

                send_frames.textContent = `：${stats.send_frame_success}`;
                send_bytes.textContent = `：${stats.send_byte_success}`;
                recv_frames.textContent = `：${stats.recv_frame_success}`;
                recv_bytes.textContent = `：${stats.recv_byte_success}`;

                failedStatsRow1.style.display = 'none';
                failedStatsRow2.style.display = 'none';
            } else {
                // 为非 uart target 设置默认值
                const stats = (data.targets && data.targets[selectedTarget]) || {
                    send_frame_success: 0,
                    send_byte_success: 0,
                    send_frame_failed: 0,
                    send_byte_failed: 0,
                    recv_frame: 0,
                    recv_byte: 0
                };

                document.querySelector('[data-translate="send_frames"]').textContent = '发送成功帧数';
                document.querySelector('[data-translate="send_bytes"]').textContent = '发送成功字节数';
                document.querySelector('[data-translate="recv_frames"]').textContent = '接收帧数';
                document.querySelector('[data-translate="recv_bytes"]').textContent = '接收字节数';

                send_frames.textContent = `：${stats.send_frame_success}`;
                send_bytes.textContent = `：${stats.send_byte_success}`;
                recv_frames.textContent = `：${stats.recv_frame}`;
                recv_bytes.textContent = `：${stats.recv_byte}`;
                failed_frames.textContent = `：${stats.send_frame_failed}`;
                failed_bytes.textContent = `：${stats.send_byte_failed}`;

                failedStatsRow1.style.display = 'block';
                failedStatsRow2.style.display = 'block';
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
}

createTabs();
updateStatistics();

setInterval(updateStatistics, 2000);

// Post Get basic function

async function postData(url = '', data = {}) {
    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Connection': 'close'  // 禁用Keep-Alive
            },
            body: JSON.stringify(data)
        });

        // 先获取响应文本
        const text = await response.text();
        console.log('Response text:', text); // 调试输出

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        // 尝试解析JSON
        try {
            return JSON.parse(text);
        } catch (e) {
            console.error('Invalid JSON response:', text);
            throw new Error('Invalid JSON response');
        }
    } catch (error) {
        console.error('Request failed:', error);
        throw error;
    }
}

async function fetchData(url = '') {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    return response.json();
}


// Net config API

window.onload = () => autoDHCP(document.getElementById('is_dhcp'));

function autoDHCP(element) {
    element.classList.toggle('on');
    element.classList.toggle('off');
    document.getElementById('is_dhcp').value = element.classList.contains('on') ? '2' : '1';
    ['static_ip', 'static_netmask', 'static_gateway', 'static_dns1', 'static_dns2'].forEach(id => {
        if (element.classList.contains('on')) {
            document.getElementById(id).removeAttribute('disabled');
        } else {
            document.getElementById(id).setAttribute('disabled', true);
        }
    });
}

// 添加一个对象来存储静态IP配置
let staticIPConfig = {
    static_ip: '',
    static_netmask: '',
    static_gateway: '',
    static_dns1: '',
    static_dns2: ''
};

function changeNetSelect(id) {
    [...document.getElementsByClassName('network-btn')].forEach(btn => btn.style.background = '#898989a1');
    document.getElementById(id).style.background = '#009ee1';
    document.getElementById('selectedNetwork').value = (id === 'ethernet') ? 1 : (id === 'wifi') ? 2 : 3;
    ['wifi_ssid_div', 'wifi_password_div', 'wifisearch', 'scanList'].forEach(el =>
        document.getElementById(el).style.display = (id === 'ethernet' || id === 'sim4g') ? 'none' : 'flex'
    );

    const is4GSelected = id === 'sim4g';
    const staticIPFields = ['static_ip', 'static_netmask', 'static_gateway', 'static_dns1', 'static_dns2'];

    if (is4GSelected) {
        // 保存当前静态IP配置和开关状态
        const staticIpSwitch = document.getElementById('static_ip_switch');
        staticIPConfig.switchState = staticIpSwitch.classList.contains('on');

        staticIPFields.forEach(field => {
            staticIPConfig[field] = document.getElementById(field).value;
        });

        // 隐藏静态IP相关元素
        [...staticIPFields, 'static_ip_switch'].forEach(field => {
            const div = document.getElementById(field + '_div');
            if (div) div.style.display = 'none';
        });

        // 如果静态IP开关是打开的，关闭它
        if (!staticIpSwitch.classList.contains('off')) {
            autoDHCP(staticIpSwitch);
        }
    } else {
        // 显示静态IP相关元素
        [...staticIPFields, 'static_ip_switch'].forEach(field => {
            const div = document.getElementById(field + '_div');
            if (div) div.style.display = 'flex';
        });

        // 恢复之前保存的静态IP配置
        staticIPFields.forEach(field => {
            if (staticIPConfig[field]) {
                document.getElementById(field).value = staticIPConfig[field];
            }
        });

        // 恢复开关状态
        if (staticIPConfig.switchState) {
            const staticIpSwitch = document.getElementById('static_ip_switch');
            if (staticIpSwitch.classList.contains('off')) {
                autoDHCP(staticIpSwitch);
            }
        }
    }
}

document.getElementById("net_set").addEventListener("submit", event => event.preventDefault());

function validateIP(ip) {
    const ipPattern = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    return ipPattern.test(ip);
}

async function netsetSubmit() {
    let isValid = true;
    const fields = [];
    const selectedNetwork = document.getElementById('selectedNetwork').value;
    const isDHCP = document.getElementById('is_dhcp').value;
    if ((selectedNetwork == '1' && isDHCP == '2') || (selectedNetwork == '2' && isDHCP == '2')) {
        fields.push({
            id: 'static_ip',
            errMsg: 'IP地址格式不正确',
            validate: validateIP
        }, {
            id: 'static_netmask',
            errMsg: '子网掩码格式不正确',
            validate: validateIP
        }, {
            id: 'static_gateway',
            errMsg: '网关格式不正确',
            validate: validateIP
        }, {
            id: 'static_dns1',
            errMsg: 'DNS1格式不正确',
            validate: validateIP
        }, {
            id: 'static_dns2',
            errMsg: 'DNS2格式不正确',
            validate: validateIP
        }

        );

    }
    if (selectedNetwork == '2') {
        const ssid = document.getElementById('wifi_ssid').value;
        const password = document.getElementById('wifi_password').value;
        if (!ssid) {
            document.getElementById('wifi_ssid').nextElementSibling.textContent = 'WiFi名称不能为空';
            isValid = false;
        }
        if (!password || password.length < 8) {
            document.getElementById('wifi_password').nextElementSibling.textContent = 'WiFi密码不能为空且最少8位';
            isValid = false;
        }
    }

    for (const field of fields) {
        const input = document.getElementById(field.id);
        const errText = input.nextElementSibling;
        const value = input.value.trim();

        if (!value) {
            errText.textContent = field.errMsg;
            isValid = false;
        } else if (field.validate && !field.validate(value)) {
            errText.textContent = field.errMsg;
            isValid = false;
        } else {
            errText.textContent = '';
        }
    }
    if (!isValid) {
        return;
    }
    const formData = new FormData(document.getElementById('net_set'));
    const data = Object.fromEntries(formData);
    try {
        await postData('/net_set', data);
        document.getElementById('netSetButton').textContent = "设置成功";
        if (!hasRestarted) {
            const deviceRestart = document.getElementById('deviceRestart');
            if (deviceRestart) {
                showSvg('deviceRestart', 6000);
                hasRestarted = true;
            }
        }
    } catch (error) {
        console.error('Error fetching data. Status:', error);
        document.getElementById('netSetButton').textContent = '设置失败';
    }
    setTimeout(() => document.getElementById('netSetButton').textContent = '设置', 2000);
}

document.getElementById('netSetButton').addEventListener('click', netsetSubmit);


async function netsetfetchData() {
    try {
        const responseData = await fetchData('/net_set_info');
        if (!responseData) {
            console.error('No data returned from /net_set_info');
            return;
        }
        // 保存初始静态IP配置
        ['static_ip', 'static_netmask', 'static_gateway', 'static_dns1', 'static_dns2'].forEach(id => {
            document.getElementById(id).value = responseData[id];
            staticIPConfig[id] = responseData[id];  // 保存到staticIPConfig
        });

        if (responseData.netconn == 1 || responseData.netconn == 0) {
            document.getElementById('ethernet').click();
        }
        if (responseData.netconn == 2) {
            document.getElementById('wifi').click();
            ['wifi_ssid', 'wifi_password'].forEach(id => document.getElementById(id).value = responseData[id]);
        }
        if (responseData.netconn == 3) {
            document.getElementById('sim4g').click();
        }
        const static_ip_switch = document.getElementById('static_ip_switch');
        static_ip_switch.classList.toggle('off', responseData.is_dhcp == 1);
        static_ip_switch.classList.toggle('on', responseData.is_dhcp == 2);
        ['static_ip', 'static_netmask', 'static_gateway', 'static_dns1', 'static_dns2'].forEach(id => {
            if (responseData.is_dhcp == 1) {
                document.getElementById(id).setAttribute('disabled', true);
            } else {
                document.getElementById(id).removeAttribute('disabled');
            }
        });
    } catch (error) {
        console.error('Failed to fetch data. Status:', error);
    }
}


netsetfetchData();


// Search wifi API

function clickwifi(element) {
    document.getElementById('wifi_ssid').value = element.value;
    [...document.querySelectorAll('#wifitable .addwifi')].forEach(row => row.style.backgroundColor = '');
    element.parentNode.parentNode.parentNode.style.backgroundColor = '#004ba93d';
}

document.getElementById('wifisearch').addEventListener('click', async () => {
    document.getElementById('wifisearch').textContent = '搜索中';
    try {
        const data = await fetchData('/find_wifi');
        document.getElementById('scanList').style.display = 'flex';
        [...document.getElementsByClassName('addwifi')].forEach(tr => tr.remove());
        for (const key in data) {
            const tr = document.createElement("tr");
            tr.setAttribute('class', 'addwifi');
            let td = document.createElement("td");
            td.innerHTML = `<label class='bui-radios-label'><input type='radio' name='wifi'  onclick='clickwifi(this)' value='${key}'/><i class='bui-radios'></i> ${key}</label>`;
            tr.appendChild(td);
            td = document.createElement("td");
            td.innerHTML = `${data[key]}dBm `;
            tr.appendChild(td);
            document.getElementById('clusss').parentNode.insertBefore(tr, document.getElementById('clusss'));
        }
        setTimeout(() => document.getElementById('wifisearch').textContent = '搜索', 200);
    } catch (error) {
        console.error('Error fetching data. Status:', error);
    }
});


// MQTT config API

const useMqttStates = document.getElementById('useMqttState');
const mqttInputs = document.querySelectorAll('.mqtt-input');
const mqttButtons = document.querySelectorAll('.mqtt-btn');

function toggleInputs() {
    const isDisabled = useMqttState.value == '0';
    mqttInputs.forEach(input => input.disabled = isDisabled);
    mqttButtons.forEach(button => button.disabled = isDisabled);
}

toggleInputs();
useMqttStates.addEventListener('change', toggleInputs);

function toggleMqttSwitch(element) {
    element.classList.toggle('on');
    element.classList.toggle('off');
    document.getElementById('useMqttState').value = element.classList.contains('on') ? '1' : '0';
    toggleInputs();
}

function toggleMqttRetain(element) {
    element.classList.toggle('on');
    element.classList.toggle('off');
    document.getElementById('useMqttRetain').value = element.classList.contains('on') ? '1' : '0';
    toggleInputs();
}

function toggleMqttSend(element) {
    element.classList.toggle('on');
    element.classList.toggle('off');
    document.getElementById('useMqttSend').value = element.classList.contains('on') ? '1' : '0';
    toggleInputs();
}


function changeQosSelect(id) {
    var buttons = document.getElementsByClassName('qos-btn');
    Array.from(buttons).forEach(button => button.style.background = '#898989a1');
    document.getElementById('qos' + id).style.background = '#009ee1';
    document.getElementById('selectedQos').value = id;
}

document.getElementById("mqttDataForm").addEventListener("submit", event => event.preventDefault());

function isValidIPorDomain(value) {
    const ipPattern = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    const domainPattern = /^(?!-)(?:[a-zA-Z0-9-]{0,62}[a-zA-Z0-9]\.)+[a-zA-Z]{2,}$/;
    return ipPattern.test(value) || domainPattern.test(value);
}
function validateIntervalTime(value) {
    const intervalTime = parseInt(value, 10);
    return !isNaN(intervalTime) && intervalTime > 2;
}

async function mqttSubmit() {
    const fields = [
        { id: 'mqtt_server', errMsg: '请输入合法的服务器地址', validate: value => isValidIPorDomain(value) },
        { id: 'mqtt_port', errMsg: '请输入100-65535范围内的端口', isNumeric: true, validate: value => value >= 100 && value <= 65535 },
        { id: 'mqtt_clientid', errMsg: '请输入ClientID' },
        { id: 'mqtt_sub_topic', errMsg: '请输入订阅主题' },
        { id: 'mqtt_pub_topic', errMsg: '请输入发布主题' }
    ];

    // const mqttSendEnabled = document.getElementById('useMqttSend').value === '1';
    // if (mqttSendEnabled) {
    //     fields.push({
    //         id: 'mqtt_time',
    //         errMsg: '请输入间隔时间，且必须大于2秒',
    //         validate: validateIntervalTime
    //     });
    // }

    let isValid = true;
    let mqttSubTopic = '';
    let mqttPubTopic = '';

    for (const field of fields) {
        const input = document.getElementById(field.id);
        const errText = input.nextElementSibling;
        const value = input.value.trim();

        if (!value) {
            errText.textContent = field.errMsg;
            isValid = false;
        } else if (field.isNumeric && isNaN(value)) {
            errText.textContent = '请输入数字';
            isValid = false;
        } else if (field.validate && !field.validate(value)) {
            errText.textContent = field.errMsg;
            isValid = false;
        } else {
            errText.textContent = '';
        }

        if (field.id === 'mqtt_sub_topic') mqttSubTopic = value;
        if (field.id === 'mqtt_pub_topic') mqttPubTopic = value;
    }

    if (mqttSubTopic && mqttPubTopic && mqttSubTopic === mqttPubTopic) {
        document.getElementById('mqtt_sub_topic').nextElementSibling.textContent = '订阅主题和发布主题不能相同';
        document.getElementById('mqtt_pub_topic').nextElementSibling.textContent = '订阅主题和发布主题不能相同';
        isValid = false;
    }

    if (!isValid) {
        return; // 如果有错误，不进行提交
    }


    const formData = new FormData(document.getElementById('mqttDataForm'));
    const data = Object.fromEntries(formData);
    try {
        await postData('/mqtt', data);
        document.getElementById('mqttSubmitButton').textContent = "设置成功";
        if (!hasRestarted) {  // 检查是否已经发送了重启命令
            const deviceRestart = document.getElementById('deviceRestart');
            if (deviceRestart) {
                showSvg('deviceRestart', 6000);
                hasRestarted = true;  // 标记重启命令已经发送
            }
        }
    } catch (error) {
        console.error('Error fetching data. Status:', error);
        document.getElementById('mqttSubmitButton').textContent = '设置失败';
    }
    setTimeout(() => document.getElementById('mqttSubmitButton').textContent = '设置', 2000);
}

document.getElementById('mqttSubmitButton').addEventListener('click', mqttSubmit);

async function mqttfetchData() {
    try {
        const responseData = await fetchData('/mqtt_info');
        const mqttInputs = document.querySelectorAll('.mqtt-input');
        const mqttButtons = document.querySelectorAll('.mqtt-btn');
        const mqttconnected = document.getElementById('mqttconnected');
        document.getElementById('use_mqtt').className = responseData.use_mqtt == 1 ? "switch-btn switch-btn on" : "switch-btn switch-btn off";
        mqttInputs.forEach(input => input.disabled = responseData.use_mqtt == 0);
        mqttButtons.forEach(button => button.disabled = responseData.use_mqtt == 0);
        document.getElementById(`qos${responseData.qos}`).click();
        ['mqtt_server', 'mqtt_port', 'mqtt_username', 'mqtt_password', 'mqtt_clientid', 'mqtt_sub_topic', 'mqtt_pub_topic'].forEach(id => {
            document.getElementById(id).value = responseData[id];
        });
        document.getElementById('useMqttState').value = responseData.use_mqtt;
        document.getElementById('useMqttType').value = responseData.mqtt_type;
        document.getElementById('useMqttRetain').value = responseData.retain;
        document.getElementById('selectRetain').className = responseData.retain == 1 ? "switch-btn switch-btn on" : "switch-btn switch-btn off";

        mqttconnected.textContent = responseData.mqttconn == "1" && responseData.use_mqtt == 1 ? "已连接" : "未连接";
        mqttconnected.style.color = responseData.mqttconn == "1" && responseData.use_mqtt == 1 ? "#5cb85c" : "#d9534f";
        // document.getElementById('useMqttSend').value = responseData.mqtt_send;
        // document.getElementById('selectSend').className = responseData.mqtt_send == 1 ? "switch-btn switch-btn on" : "switch-btn switch-btn off";
    } catch (error) {
        console.error('Failed to fetch data. Status:', error);
    }
}

mqttfetchData();


// TCP config API

// document.addEventListener('DOMContentLoaded', () => {
//     const useTCPState = document.getElementById('useTCPState');
//     const tcpInputs = document.querySelectorAll('.tcp-input');
//     const tcpButtons = document.querySelectorAll('.tcp-btn');
//     const tcpSubmitButton = document.getElementById('tcpSubmitButton');
//     const tcpDataForm = document.getElementById('tcpDataForm');

//     function toggleInputs(isDisabled) {
//         tcpInputs.forEach(input => input.disabled = isDisabled);
//         tcpButtons.forEach(button => button.disabled = isDisabled);
//     }

//     function tcptoggleInputs() {
//         toggleInputs(useTCPState.value === '0');
//     }

//     useTCPState.addEventListener('change', tcptoggleInputs);
//     tcptoggleInputs();

//     window.toggleTCPSwitch = function (element) {
//         element.classList.toggle('on');
//         element.classList.toggle('off');
//         useTCPState.value = element.classList.contains('on') ? '1' : '0';
//         tcptoggleInputs();
//     };

//     window.toggleTcpSend = function (element) {
//         element.classList.toggle('on');
//         element.classList.toggle('off');
//         document.getElementById('useTcpSend').value = element.classList.contains('on') ? '1' : '0';
//     };

//     window.changeTCPSelect = function (id) {
//         tcpButtons.forEach(button => button.style.background = '#898989a1');
//         document.getElementById(id).style.background = '#009ee1';
//         document.getElementById('selectedTCP').value = id === 'tcpServer' ? '0' : '1';

//         const tcpServerAddress = document.getElementById('tcpServerAddress');
//         tcpServerAddress.style.display = id === 'tcpServer' ? 'none' : 'flex';
//     };

//     tcpDataForm.addEventListener('submit', event => event.preventDefault());

//     async function tcpSubmit() {
//         const fields = [
//             { id: 'tcp_server', errMsg: '请输入合法的服务器地址', validate: value => isValidIPorDomain(value) },
//             { id: 'tcp_port', errMsg: '请输入100-65535范围内的端口', isNumeric: true, validate: value => value >= 100 && value <= 65535 }
//         ];

//         const tcpSendEnabled = document.getElementById('useTcpSend').value === '1';
//         if (tcpSendEnabled) {
//             fields.push({
//                 id: 'tcp_time',
//                 errMsg: '请输入间隔时间，且必须大于2秒',
//                 validate: validateIntervalTime
//             });
//         }

//         let isValid = true;

//         for (const field of fields) {
//             const input = document.getElementById(field.id);
//             const errText = input.nextElementSibling;
//             const value = input.value.trim();

//             if (!value) {
//                 errText.textContent = field.errMsg;
//                 isValid = false;
//             } else if (field.isNumeric && isNaN(value)) {
//                 errText.textContent = '请输入数字';
//                 isValid = false;
//             } else if (field.validate && !field.validate(value)) {
//                 errText.textContent = field.errMsg;
//                 isValid = false;
//             } else {
//                 errText.textContent = '';
//             }
//         }

//         if (!isValid) {
//             return; // 如果有错误，不进行提交
//         }

//         const formData = new FormData(document.getElementById('tcpDataForm'));
//         const data = Object.fromEntries(formData);
//         try {
//             await postData('/tcp', data);
//             document.getElementById('tcpSubmitButton').textContent = "设置成功";
//             if (!hasRestarted) {  // 检查是否已经发送了重启命令
//                 const deviceRestart = document.getElementById('deviceRestart');
//                 if (deviceRestart) {
//                     showSvg('deviceRestart', 6000);
//                     hasRestarted = true;  // 标记重启命令已经发送
//                 }
//             }
//         } catch (error) {
//             console.error('Error fetching data. Status:', error);
//             document.getElementById('tcpSubmitButton').textContent = '设置失败';
//         }
//         setTimeout(() => document.getElementById('tcpSubmitButton').textContent = '设置', 2000);
//     }

//     tcpSubmitButton.addEventListener('click', tcpSubmit);

//     async function tcpfetchData() {
//         const apiUrl = '/tcp_info';

//         try {
//             const response = await fetch(apiUrl);
//             if (!response.ok) throw new Error(`Failed to fetch data. Status: ${response.status}`);

//             const responseData = await response.json();

//             document.getElementById('tcp_server').value = responseData.tcp_server;
//             document.getElementById('tcp_port').value = responseData.tcp_port;
//             document.getElementById('tcp_time').value = responseData.tcp_time;
//             document.getElementById('useTcpSend').value = responseData.tcp_send;
//             document.getElementById('tselectSend').className = responseData.tcp_send == 1 ? "switch-btn switch-btn on" : "switch-btn switch-btn off";
//             if (responseData.use_tcp == 0) {
//                 document.getElementById('use_tcp_server').className = "switch-btn tcp-switch-btn off";
//                 useTCPState.value = '0';
//                 toggleInputs(true);
//             } else {
//                 document.getElementById('use_tcp_server').className = "switch-btn tcp-switch-btn on";
//                 useTCPState.value = '1';
//                 toggleInputs(false);
//             }
//             if (responseData.tcpconn == 0) {
//                 document.getElementById('tcpServer').click();
//                 const tcpConnected = document.getElementById('tcpconnected');
//                 tcpConnected.textContent = responseData.tcp_client_count > 0
//                     ? `当前有${responseData.tcp_client_count}个客户端连接`
//                     : '没有设备连接';
//                 tcpConnected.style.color = responseData.tcp_client_count > 0 ? "#5cb85c" : "#d9534f";
//             } else {
//                 document.getElementById('tcpClient').click();
//                 const tcpConnected = document.getElementById('tcpconnected');
//                 tcpConnected.textContent = responseData.tcp_server_conn == 1 ? '已连接' : '未连接';
//                 tcpConnected.style.color = responseData.tcp_server_conn == 1 ? "#5cb85c" : "#d9534f";
//             }

//         } catch (error) {
//             console.error('Failed to fetch data:', error);
//         }
//     }
//     tcpfetchData();
// });


// HTTP config API

// document.addEventListener('DOMContentLoaded', () => {
//     const useHTTPState = document.getElementById('useHTTPState');
//     const httpInputs = document.querySelectorAll('.http-input');
//     const httpButtons = document.querySelectorAll('.http-btn');
//     const httpSubmitButton = document.getElementById('httpSubmitButton');
//     const httpDataForm = document.getElementById('httpDataForm');

//     function toggleInputs(isDisabled) {
//         httpInputs.forEach(input => input.disabled = isDisabled);
//         httpButtons.forEach(button => button.disabled = isDisabled);
//     }

//     function httptoggleInputs() {
//         toggleInputs(useHTTPState.value === '0');
//     }

//     useHTTPState.addEventListener('change', httptoggleInputs);
//     httptoggleInputs();

//     window.toggleHTTPSwitch = function (element) {
//         element.classList.toggle('on');
//         element.classList.toggle('off');
//         useHTTPState.value = element.classList.contains('on') ? '1' : '0';
//         httptoggleInputs();
//     }

//     window.changeHTTPSelect = function (id) {
//         httpButtons.forEach(button => button.style.background = '#898989a1');
//         if (id === 'http_post') {
//             document.getElementById('http_post').style.background = '#009ee1';
//         }
//         document.getElementById('selectedHTTP').value = '1';
//     }

//     httpDataForm.addEventListener('submit', event => event.preventDefault());

//     async function httpSubmit() {
//         const fields = [
//             { id: 'http_url', errMsg: '请输入有效的HTTP URI，格式如：https://likong-iot.com:8080', validate: validateHttpUri },
//             { id: 'http_time', errMsg: '请输入间隔时间，且必须大于2秒', validate: validateIntervalTime },
//         ];

//         for (const field of fields) {
//             const input = document.getElementById(field.id);
//             const errText = input.nextElementSibling;
//             if (!input.value.trim()) {
//                 errText.textContent = field.errMsg;
//                 return;
//             } else if (field.validate && !field.validate(input.value)) {
//                 errText.textContent = field.errMsg;
//                 return;
//             } else {
//                 errText.textContent = '';
//             }
//         }

//         const backendApiUrl = '/http';
//         const formData = new FormData(httpDataForm);
//         formData.set('use_http', useHTTPState.value);
//         const json = JSON.stringify(Object.fromEntries(formData.entries()));
//         try {
//             const response = await fetch(backendApiUrl, {
//                 method: 'POST',
//                 headers: {
//                     'Content-Type': 'application/json',
//                     'Connection': 'close'  // 禁用Keep-Alive
//                 },
//                 body: json
//             });

//             const data = await response.json();
//             httpSubmitButton.textContent = data.code === 200 ? '设置成功' : '设置失败';
//             if (data.code === 200) {
//                 if (!hasRestarted) {
//                     const deviceRestart = document.getElementById('deviceRestart');
//                     if (deviceRestart) {
//                         showSvg('deviceRestart', 6000);
//                         hasRestarted = true;
//                     }
//                 }
//             }
//             setTimeout(() => {
//                 httpSubmitButton.textContent = '设置';
//             }, 2000);
//         } catch (error) {
//             console.error('Error submitting data:', error);
//         }
//     }

//     httpSubmitButton.addEventListener('click', httpSubmit);

//     async function httpfetchData() {
//         const apiUrl = '/http_info';

//         try {
//             const response = await fetch(apiUrl);
//             if (!response.ok) throw new Error(`Failed to fetch data. Status: ${response.status}`);
//             const responseData = await response.json();
//             if (responseData.use_http == 0) {
//                 document.getElementById('use_http').className = "switch-btn http-switch-btn off";
//                 useHTTPState.value = '0';
//                 toggleInputs(true);
//             } else {
//                 document.getElementById('use_http').className = "switch-btn http-switch-btn on";
//                 useHTTPState.value = '1';
//                 toggleInputs(false);
//             }
//             document.getElementById('http_url').value = responseData.http_url || '';
//             document.getElementById('http_time').value = responseData.http_time || '';
//             document.getElementById('http_post').style.background = '#009ee1';

//         } catch (error) {
//             console.error('Failed to fetch data:', error);
//         }
//     }
//     httpfetchData();
// });

// function validateHttpUri(value) {
//     const httpPattern = /^(https?:\/\/)((\d{1,3}\.){3}\d{1,3}|([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,})(:\d{1,5})?(\/.*)?$/;
//     return httpPattern.test(value);
// }


// System data API

const systemElements = {
    version: document.getElementById('version'),
    free_heap_size: document.getElementById('free_heap_size'),
    min_ever_free_heap_size: document.getElementById('min_ever_free_heap_size'),
    time_since_boot: document.getElementById('time_since_boot'),
    res_reason: document.getElementById('res_reason')
};

function formatTime(microseconds) {
    const totalSeconds = Math.floor(microseconds / 1000000);
    const days = Math.floor(totalSeconds / (24 * 3600));
    const hours = Math.floor((totalSeconds % (24 * 3600)) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    return `${days > 0 ? days + " day " : ""}${hours > 0 ? hours + " hour " : ""}${minutes > 0 ? minutes + " minute " : ""}${seconds > 0 ? seconds + " second" : ""}`.trim();
}

async function sysfetchData() {
    try {
        const responseData = await fetchData('/sys');
        systemElements.version.textContent = responseData.version;
        systemElements.free_heap_size.textContent = (responseData.free_heap_size).toFixed(2) + " KB ";
        systemElements.min_ever_free_heap_size.textContent = (responseData.min_ever_free_heap_size).toFixed(2) + " KB ";
        systemElements.time_since_boot.textContent = formatTime(responseData.time_since_boot);
        systemElements.res_reason.textContent = responseData.res_reason;
    } catch (error) {
        console.error('Failed to fetch data. Status:', error);
        Object.values(systemElements).forEach(element => element.textContent = "---");
    }
}


setInterval(sysfetchData, 5000);
sysfetchData();

// Module set API

document.getElementById("module_set").addEventListener("submit", event => event.preventDefault());

async function modulesetSubmit() {
    const formData = new FormData(document.getElementById('module_set'));
    const data = Object.fromEntries(formData);
    try {
        await postData('/module_set', data);
        document.getElementById('moduleSetButton').textContent = "设置成功";
    } catch (error) {
        console.error('Error fetching data. Status:', error);
        document.getElementById('moduleSetButton').textContent = '设置失败';
    }
    setTimeout(() => document.getElementById('moduleSetButton').textContent = '设置', 2000);
}

document.getElementById('moduleSetButton').addEventListener('click', modulesetSubmit);

async function modulesetfetchData() {
    try {
        const responseData = await fetchData('/module_set_info');
        ['host_names', 'lgname', 'lgpwd'].forEach(id => document.getElementById(id).value = responseData[id]);
        document.getElementById('moduleSetButton').textContent = responseData.host_names != "物小能G1" ? '设置' : '设置';
    } catch (error) {
        console.error('Failed to fetch data. Status:', error);
    }
}

modulesetfetchData();



// OTA API

document.getElementById("otaDataForm").addEventListener("submit", event => event.preventDefault());

async function otaSubmit() {
    const formData = new FormData(document.getElementById('otaDataForm'));
    const data = Object.fromEntries(formData);
    try {
        await postData('/ota', data);
        document.getElementById('otaSubmitButton').textContent = "正在升级";
    } catch (error) {
        console.error('Error fetching data. Status:', error);
        document.getElementById('otaSubmitButton').textContent = '升级异常';
    }
    setTimeout(() => document.getElementById('otaSubmitButton').textContent = '升级', 16500);
}

document.getElementById('otaSubmitButton').addEventListener('click', otaSubmit);


// Opreate API

const observer = new MutationObserver(mutations => {
    mutations.forEach(mutation => {
        if (mutation.type === 'childList') {
            const deviceRestart = document.getElementById('deviceRestart');
            const deviceReset = document.getElementById('deviceReset');
            if (deviceRestart && deviceRestart.style.display !== 'none') {
                handleDeviceRestart();
            }
            if (deviceReset && deviceReset.style.display !== 'none') {
                handleDeviceReset();
            }
        }
    });
});

const config = { attributes: true, childList: true, subtree: true };
observer.observe(document.body, config);

async function handleDeviceRestart() {
    document.getElementById('cancelRestart').addEventListener('click', () => {
        deviceRestart.style.display = 'none';
        hasRestarted = false;
    });
    document.getElementById('restart').addEventListener('click', async () => {
        deviceRestart.style.display = 'none';
        hasRestarted = false;
        try {
            await fetchData('/operate');
            displaySuccessMessage('重启中，请稍后...');
            setTimeout(() => location.reload(), 5000);
        } catch (error) {
            console.error('Error:', error);
        }
    });
}

async function handleDeviceReset() {
    document.getElementById('cancelReset').addEventListener('click', () => {
        deviceReset.style.display = 'none';
        hasRestarted = false;
    });
    document.getElementById('restore').addEventListener('click', async () => {
        deviceReset.style.display = 'none';
        hasRestarted = false;
        try {
            await fetchData('/restore');
            displaySuccessMessage('重置中，请稍后...');
            setTimeout(() => location.reload(), 5000);
        } catch (error) {
            console.error('Error:', error);
        }
    });
}

function displaySuccessMessage(message) {
    let svg = document.getElementById('successMessage');
    svg.style.display = 'flex';
    document.getElementById('msgValue').textContent = message;
    const clone = svg.cloneNode(true);
    svg.parentNode.replaceChild(clone, svg);
    svg = clone;
    setTimeout(() => svg.style.display = 'none', 1200);
}


// log API

const detailLogTab = document.getElementById('detailLogTab');
const simpleLogTab = document.getElementById('simpleLogTab');
let currentLogType = 'detail';
let ws = null;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 5;
const MAX_LOG_SIZE = 100 * 1024; // 100KB

// 日志存储
let detailLogs = '';
let simpleLogs = '';
let autoScroll = true;

// 添加滚动事件监听
const logContent = document.getElementById('logContent');
if (logContent) {
    logContent.addEventListener('scroll', function () {
        // 检查是否滚动到底部（添加1px的容差）
        const isScrolledToBottom = logContent.scrollHeight - logContent.clientHeight <= logContent.scrollTop + 1;
        autoScroll = isScrolledToBottom;
    });
}

// WebSocket初始化函数
function initWebSocket() {
    try {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        ws = new WebSocket(`${protocol}//${window.location.host}/ws`);

        ws.onopen = () => {
            console.log('WebSocket连接已建立');
            reconnectAttempts = 0;
        };

        ws.onmessage = (event) => {
            console.log('收到WebSocket消息:', event.data);

            const logContent = document.getElementById('logContent');
            if (!logContent) {
                console.warn('找不到logContent元素');
                return;
            }

            let line = event.data.trim();
            if (!line) {
                console.log('收到空消息');
                return;
            }

            // 清理ANSI转义序列和日志前缀
            line = line.replace(/\u001b\[\d+(?:;\d+)*m/g, '')
                .replace(/\\u001b\[\d+(?:;\d+)*m/g, '')
                .replace(/\\n/g, '\n')
                .replace(/\\r/g, '\r')
                .replace(/^[EWID]\s*\(\d+\)\s*/gm, '')
                .trim();

            // 获取当前时间
            const now = new Date();
            const timeStr = `【${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}】`;

            // 根据日志类型存储日志
            if (line.includes('[SIMPLE]')) {
                // 移除[SIMPLE]标记并处理格式
                line = line.replace('[SIMPLE]', '').trim();
                // 添加时间戳，去掉多余空格
                line = timeStr + line.replace(/【\s+/g, '【').replace(/\s+】/g, '】');

                // 处理错误日志的颜色
                if (line.toLowerCase().includes('error')) {
                    line = `<span style="color: #d9534f">${line}</span>`;
                }

                // 添加新日志并检查大小
                simpleLogs += line + '\n';
                if (simpleLogs.length > MAX_LOG_SIZE) {
                    const firstNewLine = simpleLogs.indexOf('\n', simpleLogs.length - MAX_LOG_SIZE);
                    if (firstNewLine !== -1) {
                        simpleLogs = simpleLogs.substring(firstNewLine + 1);
                    }
                }

                if (currentLogType === 'simple') {
                    logContent.innerHTML = simpleLogs;
                    if (autoScroll) {
                        logContent.scrollTop = logContent.scrollHeight;
                    }
                }
            } else {
                // 处理详细日志，去掉多余空格
                line = timeStr + (line.includes('【') ?
                    line.replace(/【\s+/g, '【').replace(/\s+】/g, '】') :
                    line);

                // 处理错误日志的颜色
                if (line.toLowerCase().includes('error')) {
                    line = `<span style="color: #d9534f">${line}</span>`;
                }

                // 添加新日志并检查大小
                detailLogs += line + '\n';
                if (detailLogs.length > MAX_LOG_SIZE) {
                    const firstNewLine = detailLogs.indexOf('\n', detailLogs.length - MAX_LOG_SIZE);
                    if (firstNewLine !== -1) {
                        detailLogs = detailLogs.substring(firstNewLine + 1);
                    }
                }

                if (currentLogType === 'detail') {
                    logContent.innerHTML = detailLogs;
                    if (autoScroll) {
                        logContent.scrollTop = logContent.scrollHeight;
                    }
                }
            }
        };

        ws.onclose = () => {
            console.log('WebSocket连接已关闭');
            if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
                setTimeout(() => {
                    reconnectAttempts++;
                    console.log(`尝试重新连接 (${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS})`);
                    initWebSocket();
                }, 3000);
            }
        };

        ws.onerror = (error) => {
            console.error('WebSocket错误:', error);
        };
    } catch (error) {
        console.error('初始化WebSocket时发生错误:', error);
        setTimeout(() => {
            if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
                reconnectAttempts++;
                console.log(`尝试重新连接 (${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS})`);
                initWebSocket();
            }
        }, 3000);
    }
}

// 切换日志类型的函数
function switchLogType(type) {
    currentLogType = type;
    const logContent = document.getElementById('logContent');

    if (type === 'detail') {
        detailLogTab.style.borderBottom = '2px solid #009ee1';
        detailLogTab.style.color = '#009ee1';
        simpleLogTab.style.borderBottom = 'none';
        simpleLogTab.style.color = '#333';
        logContent.innerHTML = detailLogs;
    } else {
        simpleLogTab.style.borderBottom = '2px solid #009ee1';
        simpleLogTab.style.color = '#009ee1';
        detailLogTab.style.borderBottom = 'none';
        detailLogTab.style.color = '#333';
        logContent.innerHTML = simpleLogs;
    }

    // 切换日志类型时保持当前滚动状态
    if (autoScroll) {
        logContent.scrollTop = logContent.scrollHeight;
    }
}

// 手动滚动到底部的函数
function scrollToBottom() {
    const logContent = document.getElementById('logContent');
    if (logContent) {
        logContent.scrollTop = logContent.scrollHeight;
        autoScroll = true;
    }
}

// 清空日志函数
async function clearLog() {
    try {
        const response = await fetch('/clear_log');
        if (response.ok) {
            if (currentLogType === 'detail') {
                detailLogs = '';
            } else {
                simpleLogs = '';
            }
            document.getElementById('logContent').innerHTML = '';
            displaySuccessMessage(translations[currentLang].clearLogSuccess);
        } else {
            throw new Error('Failed to clear log');
        }
    } catch (error) {
        console.error('Failed to clear log:', error);
        displayErrorMessage(translations[currentLang].clearLogFail);
    }
}

// 导出日志函数
async function exportLog() {
    try {
        const logContent = document.getElementById('logContent');
        if (!logContent || !logContent.innerHTML) {
            displayErrorMessage(translations[currentLang].noLog || '暂无日志');
            return;
        }

        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = logContent.innerHTML;
        let logText = tempDiv.textContent;

        const blob = new Blob([logText], { type: 'text/plain' });
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');

        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const filename = `WXNG1_${timestamp}${currentLogType === 'simple' ? '_simple' : ''}.log`;

        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);

        displaySuccessMessage(translations[currentLang].exportLogSuccess || '导出日志成功');
    } catch (error) {
        console.error('导出日志失败:', error);
        displayErrorMessage(translations[currentLang].exportLogFail || '导出日志失败');
    }
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', function () {
    // 初始化WebSocket
    initWebSocket();

    // 初始化日志标签页样式
    if (detailLogTab && simpleLogTab) {
        detailLogTab.style.borderBottom = '2px solid #009ee1';
        detailLogTab.style.color = '#009ee1';
        simpleLogTab.style.borderBottom = 'none';
        simpleLogTab.style.color = '#333';
    }

    // 设置事件监听器
    detailLogTab?.addEventListener('click', () => switchLogType('detail'));
    simpleLogTab?.addEventListener('click', () => switchLogType('simple'));
    document.getElementById('clearLogButton')?.addEventListener('click', clearLog);
    document.getElementById('exportLogButton')?.addEventListener('click', exportLog);

    // 设置日志配置按钮事件
    const logConfig = document.getElementById('logConfig');
    const logConfig_m = document.getElementById('logConfig_m');

    [logConfig, logConfig_m].forEach(element => {
        element?.addEventListener('click', () => {
            if (!ws || ws.readyState !== WebSocket.OPEN) {
                initWebSocket();
            }
        });
    });

    // 监听视图切换
    const logView = document.getElementById('logView');
    if (logView) {
        const observer = new MutationObserver(mutations => {
            mutations.forEach(mutation => {
                if (mutation.target.style.display === 'none') {
                    if (ws) {
                        ws.close();
                        ws = null;
                    }
                }
            });
        });

        observer.observe(logView, {
            attributes: true,
            attributeFilter: ['style']
        });
    }
});

// System banner tree

window.onload = function () {
    // Password visibility toggle
    const passwordFields = [
        { input: 'lgpwd', openEye: 'eyeOpen', closedEye: 'eyeClosed' },
        { input: 'mqtt_password', openEye: 'mqtteyeOpen', closedEye: 'mqtteyeClosed' },
        { input: 'wifi_password', openEye: 'wifieyeOpen', closedEye: 'wifieyeClosed' }
    ];

    function togglePasswordVisibility(input, openEye, closedEye) {
        input.type = input.type === 'password' ? 'text' : 'password';
        openEye.style.display = input.type === 'password' ? 'none' : 'block';
        closedEye.style.display = input.type === 'password' ? 'block' : 'none';
    }

    passwordFields.forEach(field => {
        const input = document.getElementById(field.input);
        const openEye = document.getElementById(field.openEye);
        const closedEye = document.getElementById(field.closedEye);
        openEye.addEventListener('click', () => togglePasswordVisibility(input, openEye, closedEye));
        closedEye.addEventListener('click', () => togglePasswordVisibility(input, openEye, closedEye));
    });

    // Form validation
    var otaUrlInput = document.getElementById('ota_url');
    var otaSubmitButton = document.getElementById('otaSubmitButton');
    otaUrlInput.addEventListener('input', function () {
        if (otaUrlInput.value) {
            otaSubmitButton.disabled = false;
        } else {
            otaSubmitButton.disabled = true;
        }
    });
    var hostNamesInput = document.getElementById('host_names');
    var lgnameInput = document.getElementById('lgname');
    var lgpwdInput = document.getElementById('lgpwd');
    var moduleSetButton = document.getElementById('moduleSetButton');
    function checkInput() {
        if (hostNamesInput.value && lgnameInput.value && lgpwdInput.value) {
            moduleSetButton.disabled = false;
        } else {
            moduleSetButton.disabled = true;
        }
    }
    hostNamesInput.addEventListener('input', checkInput);
    lgnameInput.addEventListener('input', checkInput);
    lgpwdInput.addEventListener('input', checkInput);
    checkInput();
};

function toggleClass(elementId, ...classNames) {
    var element = document.getElementById(elementId);
    classNames.forEach(function (className) {
        element.classList.toggle(className);
    });
}

function switchView(activeViewId, activeLinkId, mainClass, mainTitleText, isMobile) {
    var viewIds = ['infoView', 'configurationView', 'sysView', 'advancedView', 'protocolView', 'netView', 'logView'];
    var linkIds = ['basicInfo', 'configurationDashbord', 'sysConfig', 'advancedSet', 'protocolConfig', 'netConfig', 'basicInfo_m', 'configurationDashbord_m', 'sysConfig_m', 'advancedSet_m', 'protocolConfig_m', 'netConfig_m', 'logConfig', 'logConfig_m'];
    var main = document.getElementById("main");
    var mainTitle = document.getElementById("mainTitle");

    viewIds.forEach(function (id) {
        var view = document.getElementById(id);
        if (view) {
            view.style.display = (id === activeViewId) ? 'block' : 'none';
        }
    });

    linkIds.forEach(function (id) {
        var link = document.getElementById(id);
        if (link) { // Ensure the link element exists
            if (id === activeLinkId || id === activeLinkId + '_m') {
                link.classList.add('router-link-exact-active', 'router-link-active', 'active');
                toggleClass("nav-top", "nav-off", "nav-on");
                toggleClass("app-icon", "icondaohang", "iconchahao");
                toggleClass("nav-lists", "nav-on");
                toggleClass("version-div", "nav-on");
            } else {
                link.classList.remove('router-link-exact-active', 'router-link-active', 'active');
            }
        }
    });

    if (main) {
        main.className = mainClass;
    }

    if (mainTitle) {
        mainTitle.textContent = mainTitleText;
    }
}

function addEventListenerToElement(elementId, viewId, linkId, mainClass, mainTitle, isMobile) {
    var element = document.getElementById(elementId);
    if (element) { // Ensure element exists
        element.addEventListener("click", function () {
            switchView(viewId, linkId, mainClass, mainTitle, isMobile);
            if (isMobile) {
                setTimeout(function () {
                    toggleClass("nav-top", "nav-off", "nav-on");
                    toggleClass("app-icon", "icondaohang", "iconchahao");
                    toggleClass("nav-lists", "nav-on");
                    toggleClass("version-div", "nav-on");
                }, 100);
            }
        });
    }
}

document.getElementById("app-icon-btn").addEventListener("click", function () {
    toggleClass("nav-top", "nav-off", "nav-on");
    toggleClass("app-icon", "icondaohang", "iconchahao");
    toggleClass("nav-lists", "nav-on");
    toggleClass("version-div", "nav-on");
});

function showSvg(svgId, duration) {
    var svg = document.getElementById(svgId);
    svg.style.display = 'flex';
    var clone = svg.cloneNode(true);
    svg.parentNode.replaceChild(clone, svg);
    svg = clone;
    setTimeout(function () {
        svg.style.display = 'none';
    }, duration);
}


document.getElementById("restartButton").addEventListener("click", function () {
    showSvg('deviceRestart', 6000);
    hasRestarted = false;
});

document.getElementById("resetButton").addEventListener("click", function () {
    showSvg('deviceReset', 6000);
    hasRestarted = false;
});


// i18n.js
const translations = {
    en: {
        basic_info: "Basic Information",
        sensor_info: "Sensor Information",
        device_name: "Device Name",
        current_time: "Current Time",
        net_mode: "Network Mode",
        eth_mac: "Ethernet MAC",
        eth_ip: "Ethernet IP Address",
        wifi_mac: "WiFi MAC",
        wifi_ip: "WiFi IP Address",
        ip_acquisition: "IP Acquisition Method",
        sensor_dashboard: "Sensor Dashboard",
        network_settings: "Network Settings",
        network_mode_selection: "Network Mode Selection",
        ethernet: "Ethernet",
        wifi: "WiFi",
        static_ip: "Static IP",
        wifi_name: "WiFi Name",
        wifi_password: "WiFi Password",
        scan_list: "Scan List",
        signal_strength: "Signal Strength",
        ip_address: "IP Address",
        subnet_mask: "Subnet Mask",
        gateway: "Gateway",
        search: "Search",
        submit: "Submit",
        mqttSettings: "MQTT Settings",
        mqttsubmit: "Submit",
        mqttenable: "Enable",
        mqttServerAddress: "Server Address",
        mqttServerPort: "Server Port",
        mqttUsername: "Username",
        mqttPassword: "Password",
        mqttClientID: "Client ID",
        subscribeTopic: "Subscribe Topic",
        publishTopic: "Publish Topic",
        qos: "QoS",
        retain: "Retain",
        timedReport: "Timed Report",
        mqttIntervalTime: "Interval Time",
        mqttConnectionStatus: "Connection Status",
        mqttnConnected: "Connected",
        tcpSettings: "TCP Settings",
        tcpSubmit: "Submit",
        tcpUse: "Enable",
        tcpProtocolType: "Protocol Type",
        tcpServer: "TCP Server",
        tcpClient: "TCP Client",
        tcpIntervalTime: "Interval Time",
        tcpAddress: "Server Address",
        tcpPort: "Server Port",
        tcpConn: "Connection Status",
        tcpnConn: "Connected",
        httpSettings: "HTTP/HTTPS Settings",
        requestType: "Request Type",
        http: "HTTP",
        https: "HTTPS",
        post: "POST",
        get: "GET",
        deviceTitle: "Serial Device Server",
        deviceBasicInfo: "Basic Information",
        deviceConfigurationDashbord: "Configuration Dashboard",
        deviceProtocolConfig: "Protocol Management",
        deviceWiFiConfig: "Network Management",
        deviceAdvancedSet: "Advanced Settings",
        deviceSysConfig: "System Management",
        lkWEB: "LK-WEB",
        ztList: "Configuration Dashboard",
        deviceHDvalue: "Hardware Parameters",
        sysVeren: "System Version",
        deviceFreeHeap: "Available Heap Memory",
        deviceMinHeap: "Minimum Available Heap Size",
        deviceRunTime: "System Uptime",
        deviceResReason: "Last Restart Reason",
        loginSet: "Login Settings",
        loginSubmit: "Set",
        deviceName: "Device Name",
        deviceUname: "Username",
        devicePwd: "Login Password",
        deviceOTA: "OTA Firmware Upgrade",
        otaSubmit: "Upgrade",
        otaURL: "OTA URL",
        deviceRestart: "Restart Device",
        isrestart: "Restart",
        deviceReset: "Reset Device",
        isreset: "Reset",
        isdreset: "Restart Device",
        isqreset: "Are you sure you want to restart?",
        dcancel: "Cancel",
        dreq: "Confirm",
        isdres: "Reset Device",
        isqres: "Are you sure you want to reset? The device will be reset after confirmation.",
        scancel: "Cancel",
        sreq: "Confirm",
        opsuccess: "Operation Successful",
        setopsuccess: "Settings Updated Successfully",
        valueCompensate: "Parameter Compensation",
        vcSubmit: "Set",
        httpConn: "HTTP/HTTPS Settings",
        httpSet: "Settings",
        httpIsUse: "Enable",
        httpWay: "Request Method",
        http_time: "Interval Time",
        second: "Second",
        thpsensor: 'Sensor',
        deviceLogConfig: "Log Management",
        logManage: "Log Management",
        clearLog: "Clear Log",
        noLog: "No logs available",
        clearLogSuccess: "Logs cleared successfully",
        clearLogFail: "Failed to clear logs"
    },
    zh: {
        basic_info: "设备状态",
        sensor_info: "传感器信息",
        device_name: "设备名称",
        current_time: "当前时间",
        net_mode: "网络模式",
        eth_mac: "以太网MAC",
        eth_ip: "以太网IP地址",
        wifi_mac: "WiFi MAC",
        wifi_ip: "WiFi IP地址",
        ip_acquisition: "IP获取方式",
        sensor_dashboard: "传感器仪表",
        network_settings: "网络设置",
        network_mode_selection: "网络模式选择",
        ethernet: "以太网",
        wifi: "WiFi",
        static_ip: "静态IP",
        wifi_name: "WIFI名称",
        wifi_password: "WIFI密码",
        scan_list: "扫描列表",
        signal_strength: "信号强度",
        ip_address: "IP地址",
        subnet_mask: "子网掩码",
        gateway: "网关",
        search: "搜索",
        submit: "设置",
        mqttSettings: "MQTT设置",
        mqttsubmit: "设置",
        mqttenable: "是否启用",
        mqttServerAddress: "服务器地址",
        mqttServerPort: "服务器端口",
        mqttUsername: "用户名",
        mqttPassword: "密码",
        mqttClientID: "ClientID",
        subscribeTopic: "订阅主题",
        publishTopic: "发布主题",
        qos: "QOS",
        retain: "保留(Retain)",
        timedReport: "定时上报",
        mqttIntervalTime: "间隔时间",
        mqttConnectionStatus: "连接状态",
        mqttnConnected: "未连接",
        tcpSettings: "TCP设置",
        tcpSubmit: "设置",
        tcpUse: "是否启用",
        tcpProtocolType: "协议类型",
        tcpServer: "TCPServer",
        tcpClient: "TCPClient",
        tcpIntervalTime: "间隔时间",
        tcpAddress: "服务器地址",
        tcpPort: "服务器端口",
        tcpConn: "连接状态",
        tcpnConn: "未连接",
        httpSettings: "HTTP/HTTPS设置",
        requestType: "请求方式",
        http: "HTTP",
        https: "HTTPS",
        post: "POST",
        get: "GET",
        deviceTitle: "物小能G1",
        deviceBasicInfo: "基本信息",
        deviceConfigurationDashbord: "组态仪表",
        deviceProtocolConfig: "协议管理",
        deviceWiFiConfig: "网络管理",
        deviceAdvancedSet: "高级设置",
        deviceSysConfig: "系统管理",
        lkWEB: "立控官网",
        ztList: "组态仪表",
        deviceHDvalue: "硬件参数",
        sysVeren: "系统版本",
        deviceFreeHeap: "系统可用堆内存",
        deviceMinHeap: "最小可用堆大小",
        deviceRunTime: "系统运行时间",
        deviceResReason: "上一次重启原因",
        loginSet: "登录设置",
        loginSubmit: "设置",
        deviceName: "设备名称",
        deviceUname: "用户名",
        devicePwd: "登录密码",
        deviceOTA: "OTA固件升级",
        otaSubmit: "升级",
        otaURL: "OTA地址",
        deviceRestart: "重启设备",
        isrestart: "重启",
        deviceReset: "恢复出厂参数",
        isreset: "重置",
        isdreset: "重启设备",
        isqreset: "是否确定重启？",
        dcancel: "取消",
        dreq: "确认",
        isdres: "恢复出厂参数",
        isqres: "是否确定重置？确认后设备将被重置",
        scancel: "取消",
        sreq: "确认",
        opsuccess: "操作成功",
        setopsuccess: "设置参数成功",
        valueCompensate: "参数补偿",
        vcSubmit: "设置",
        httpConn: "HTTP/HTTPS设置",
        httpSet: "设置",
        httpIsUse: "是否启用",
        httpWay: "请求方式",
        http_time: "间隔时间",
        second: "秒",
        thpsensor: "传感器",
        deviceLogConfig: "日志管理",
        logManage: "日志管理",
        clearLog: "清除日志",
        noLog: "暂无日志",
        clearLogSuccess: "清除日志成功",
        clearLogFail: "清除日志失败"
    }
};


let currentLang = 'zh';


function setLanguage(lang) {
    document.querySelectorAll("[data-translate]").forEach(el => {
        const key = el.getAttribute("data-translate");
        if (translations[lang][key]) {
            el.textContent = translations[lang][key];
        }
    });

    // Clear existing event listeners before rebinding
    ['basicInfo', 'basicInfo_m', 'configurationDashbord', 'configurationDashbord_m',
        'advancedSet', 'advancedSet_m', 'sysConfig', 'sysConfig_m',
        'protocolConfig', 'protocolConfig_m', 'netConfig', 'netConfig_m', 'logConfig', 'logConfig_m'].forEach(id => {
            var el = document.getElementById(id);
            if (el) {
                el.replaceWith(el.cloneNode(true)); // Clear event listeners
            }
        });

    // Rebind event listeners based on language
    if (lang === 'zh') {
        addEventListenerToElement("basicInfo", 'infoView', 'basicInfo', 'base-info', '基本信息', false);
        addEventListenerToElement("basicInfo_m", 'infoView', 'basicInfo', 'base-info', '基本信息', true);
        addEventListenerToElement("configurationDashbord", 'configurationView', 'configurationDashbord', 'base-info', '组态仪表', false);
        addEventListenerToElement("configurationDashbord_m", 'configurationView', 'configurationDashbord', 'base-info', '组态仪表', true);
        addEventListenerToElement("advancedSet", 'advancedView', 'advancedSet', 'security', '高级设置', false);
        addEventListenerToElement("advancedSet_m", 'advancedView', 'advancedSet', 'security', '高级设置', true);
        addEventListenerToElement("sysConfig", 'sysView', 'sysConfig', 'security', '系统管理', false);
        addEventListenerToElement("sysConfig_m", 'sysView', 'sysConfig', 'security', '系统管理', true);
        addEventListenerToElement("protocolConfig", 'protocolView', 'protocolConfig', 'security', '协议管理', false);
        addEventListenerToElement("protocolConfig_m", 'protocolView', 'protocolConfig', 'security', '协议管理', true);
        addEventListenerToElement("netConfig", 'netView', 'netConfig', 'base-info', '网络管理', false);
        addEventListenerToElement("netConfig_m", 'netView', 'netConfig', 'base-info', '网络管理', true);
        addEventListenerToElement("logConfig", 'logView', 'logConfig', 'security', '日志管理', false);
        addEventListenerToElement("logConfig_m", 'logView', 'logConfig', 'security', '日志管理', true);
    } else if (lang === 'en') {
        addEventListenerToElement("basicInfo", 'infoView', 'basicInfo', 'base-info', 'Basic Information', false);
        addEventListenerToElement("basicInfo_m", 'infoView', 'basicInfo', 'base-info', 'Basic Information', true);
        addEventListenerToElement("configurationDashbord", 'configurationView', 'configurationDashbord', 'base-info', 'Configuration Dashboard', false);
        addEventListenerToElement("configurationDashbord_m", 'configurationView', 'configurationDashbord', 'base-info', 'Configuration Dashboard', true);
        addEventListenerToElement("advancedSet", 'advancedView', 'advancedSet', 'security', 'Advanced Settings', false);
        addEventListenerToElement("advancedSet_m", 'advancedView', 'advancedSet', 'security', 'Advanced Settings', true);
        addEventListenerToElement("sysConfig", 'sysView', 'sysConfig', 'security', 'System Management', false);
        addEventListenerToElement("sysConfig_m", 'sysView', 'sysConfig', 'security', 'System Management', true);
        addEventListenerToElement("protocolConfig", 'protocolView', 'protocolConfig', 'security', 'Protocol Management', false);
        addEventListenerToElement("protocolConfig_m", 'protocolView', 'protocolConfig', 'security', 'Protocol Management', true);
        addEventListenerToElement("netConfig", 'netView', 'netConfig', 'base-info', 'Network Management', false);
        addEventListenerToElement("netConfig_m", 'netView', 'netConfig', 'base-info', 'Network Management', true);
        addEventListenerToElement("logConfig", 'logView', 'logConfig', 'security', 'Log Management', false);
        addEventListenerToElement("logConfig_m", 'logView', 'logConfig', 'security', 'Log Management', true);
    }

    currentLang = lang;
}

// Initial language setup
setLanguage(currentLang);
