/*
 * @Author: Orion
 * @Date: 2024-05-07 11:25:05
 * @LastEditors: Orion
 * @LastEditTime: 2024-06-26 16:43:02
 * @FilePath: \SERIIAL_SERVER\main\sx_init_eth.c
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */
#include "esp_eth.h"
#include "esp_event.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "ethernet_init.h"
#include "sx_web_server.h"

static const char *TAG = "ETH-TH";

/*************************************************************************************/
/*                                START OF FILE */
/*************************************************************************************/

/** Event handler for Ethernet events */
void eth_event_handler(void *arg, esp_event_base_t event_base, int32_t event_id,
                       void *event_data) {
  esp_eth_handle_t eth_handle = *(esp_eth_handle_t *)event_data;

  switch (event_id) {
  case ETHERNET_EVENT_CONNECTED:
    esp_eth_ioctl(eth_handle, ETH_CMD_G_MAC_ADDR, mac_addr);
    ESP_LOGI(TAG, "Ethernet Link Up");
    ESP_LOGI(TAG, "Ethernet HW Addr %02x:%02x:%02x:%02x:%02x:%02x", mac_addr[0],
             mac_addr[1], mac_addr[2], mac_addr[3], mac_addr[4], mac_addr[5]);
    sprintf(device_mac, "%02X%02X%02X%02X%02X%02X", mac_addr[0], mac_addr[1],
            mac_addr[2], mac_addr[3], mac_addr[4], mac_addr[5]);
    sprintf(device_mac_end, "%02X%02X", mac_addr[4], mac_addr[5]);
    break;
  case ETHERNET_EVENT_DISCONNECTED:
    ESP_LOGI(TAG, "Ethernet Link Down");
    break;
  case ETHERNET_EVENT_START:
    ESP_LOGI(TAG, "Ethernet Started");
    break;
  case ETHERNET_EVENT_STOP:
    ESP_LOGI(TAG, "Ethernet Stopped");
    break;
  default:
    break;
  }
}

/*************************************************************************************/
/*                                END OF FILE */
/*************************************************************************************/