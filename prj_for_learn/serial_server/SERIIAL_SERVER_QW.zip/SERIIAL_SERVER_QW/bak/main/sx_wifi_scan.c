/*
 * @Author: Orion
 * @Date: 2024-01-18 14:12:54
 * @LastEditors: Orion
 * @LastEditTime: 2024-09-03 14:22:47
 * @FilePath: \SERIIAL_SERVER\main\sx_wifi_scan.c
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */
#include "sx_wifi_scan.h"
#include "esp_log.h"
#include "esp_wifi.h"
#include <string.h>

static const char *TAG = "sx_wifi_scan";

/*************************************************************************************/
/*                                START OF FILE */
/*************************************************************************************/

/**
 * @description:
 * @param {WifiValueList} wifiValueList
 * @param {Total APs} scanned
 * @return {*}
 */
WifiValueList wifiSearchValue() {
  WifiValueList wifiValueList;
  uint16_t number = DEFAULT_SCAN_LIST_SIZE;
  memset(wifiValueList.ap_info, 0, sizeof(wifiValueList.ap_info));
  ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_APSTA));
  ESP_ERROR_CHECK(esp_wifi_start());
  esp_wifi_scan_start(NULL, true);
  ESP_ERROR_CHECK(esp_wifi_scan_get_ap_records(&number, wifiValueList.ap_info));
  ESP_ERROR_CHECK(esp_wifi_scan_get_ap_num(&wifiValueList.ap_count));
  ESP_LOGI(TAG, "Total APs scanned = %u", wifiValueList.ap_count);
  return wifiValueList;
}

/*************************************************************************************/
/*                                END OF FILE */
/*************************************************************************************/