require("sx_mqtt")

local uartid = 1
-- 添加libfota库
local libfota = require "libfota"
-- 经纬度
local lbsLoc2 = require("lbsLoc2")



-- 添加FOTA相关变量
local fota_buffer = ""
local fota_size = 0
local fota_received = 0
local fota_in_progress = false
local fota_file_path = "/update.bin" -- 改为根目录，因为根目录是可写的
-- 初始化串口
uart.setup(uartid, -- 串口id
115200, -- 波特率
8, -- 数据位
1, -- 停止位
uart.NONE -- 无校验位
)

-- 获取设备信息的函数

local function getDeviceInfo()
    local info = {}

    -- 获取当前时间，首先尝试从阿里云API获取，失败则使用本地时间
    local timestamp_ms, datetime = fetch_aliyun_time()
    local timestamp = datetime

    -- 如果网络获取失败，回退到本地时间
    if timestamp == "" then
        local current_time = os.date("*t")
        timestamp = string.format("%04d-%02d-%02d %02d:%02d:%02d",
            current_time.year, current_time.month, current_time.day,
            current_time.hour, current_time.min, current_time.sec)
        log.info("time", "使用本地时间", timestamp)
    end

    info.timestamp = timestamp
    info.timestamp_ms = timestamp_ms

    -- 获取IP地址
    local ip, netmask, gateway = socket.localIP()
    if ip then
        info.ip = ip
    else
        info.ip = "未连接"
    end

    -- 获取ICCID
    info.iccid = mobile.iccid()

    -- 获取IMEI
    info.imei = mobile.imei()

    -- 获取信号强度
    info.csq = mobile.csq()

    info.rssi = mobile.rssi() -- 信号强度(dBm)
    info.rsrp = mobile.rsrp() -- 参考信号接收功率
    info.rsrq = mobile.rsrq() -- 参考信号接收质量
    info.snr = mobile.snr() -- 信噪比
    -- 添加统计信息
    info.stat = {
        com = _G.stats.com,
        targets = {}
    }

    -- 将targets对象转换为数组
    for target_name, target_stats in pairs(_G.stats.targets) do
        table.insert(info.stat.targets, {
            name = target_name,
            send_frame_success = target_stats.send_frame_success or 0,
            send_byte_success = target_stats.send_byte_success or 0,
            send_frame_failed = target_stats.send_frame_failed or 0,
            send_byte_failed = target_stats.send_byte_failed or 0,
            recv_frame = target_stats.recv_frame or 0,
            recv_byte = target_stats.recv_byte or 0
        })
    end

    return info
end

-- FOTA回调函数
local function fota_cb(ret)
    log.info("fota", ret)
    if ret == 0 then
        -- 发送成功响应
        local response = {
            type = "fota_response",
            action = "end",
            status = "ok"
        }
        uart.write(uartid, json.encode(response) .. "\r\n")
        -- 延时后重启
        sys.wait(1000)
        rtos.reboot()
    else
        -- 发送失败响应
        local response = {
            type = "fota_response",
            action = "end",
            status = "error",
            message = "Update failed: " .. tostring(ret)
        }
        uart.write(uartid, json.encode(response) .. "\r\n")
    end
end

-- 处理FOTA消息
-- 添加zbuff缓冲区
local uart_zbuff = zbuff.create(1024)

-- 修改handleFotaMessage函数
local function handleFotaMessage(data)
    if data.action == "start" then
        -- 开始升级
        fota_buffer = ""
        fota_size = data.size
        fota_received = 0
        fota_in_progress = true
        -- 初始化 fota
        fota.init()

        -- 发送响应
        local response = {
            type = "fota_response",
            action = "start",
            status = "ok"
        }
        uart.write(uartid, json.encode(response) .. "\r\n")

    elseif data.action == "data" and fota_in_progress then
        -- 接收数据块
        local decoded_data = crypto.base64_decode(data.data)
        if decoded_data then
            -- 验证偏移量
            if data.offset == fota_received then
                -- 直接运行升级
                local result, isDone, cache = fota.run(decoded_data)
                log.debug("fota.run", result, isDone, cache)

                if not result then
                    -- 升级失败
                    local response = {
                        type = "fota_response",
                        action = "data",
                        status = "error",
                        message = "Update failed"
                    }
                    uart.write(uartid, json.encode(response) .. "\r\n")
                    fota_in_progress = false
                elseif isDone then
                    -- 在新任务中检查升级是否完成
                    sys.taskInit(function()
                        while true do
                            sys.wait(100)
                            local succ, fotaDone = fota.isDone()
                            if not succ then
                                fota_in_progress = false
                                local response = {
                                    type = "fota_response",
                                    action = "data",
                                    status = "error",
                                    message = "Update verification failed"
                                }
                                uart.write(uartid, json.encode(response) .. "\r\n")
                                break
                            end
                            if fotaDone then
                                -- 升级成功
                                local response = {
                                    type = "fota_response",
                                    action = "data",
                                    status = "ok",
                                    received = fota_received
                                }
                                uart.write(uartid, json.encode(response) .. "\r\n")
                                -- 延时后重启
                                sys.wait(1000)
                                rtos.reboot()
                            end
                        end
                    end)
                else
                    -- 单包写入成功
                    fota_received = fota_received + #decoded_data
                    local response = {
                        type = "fota_response",
                        action = "data",
                        status = "ok",
                        received = fota_received
                    }
                    uart.write(uartid, json.encode(response) .. "\r\n")
                end
            else
                -- 偏移量错误
                local response = {
                    type = "fota_response",
                    action = "data",
                    status = "error",
                    message = "offset mismatch"
                }
                uart.write(uartid, json.encode(response) .. "\r\n")
            end
        end
    end
end

-- 定义发送数据的函数
local function sendDeviceInfo()
    local info = getDeviceInfo()
    -- 转换为JSON字符串
    local jsonStr = json.encode(info)
    -- 添加换行符便于接收方识别
    jsonStr = jsonStr .. "\r\n"

    -- 发送数据
    uart.write(uartid, jsonStr)
    log.info("uart", "send", jsonStr)
end
-- 经纬度格式化函数
local function formatCoordinate(value)
    if not value then
        return "0"
    end
    -- 转换为字符串，保持原始精度
    local str = tostring(value)
    -- 如果第一位是0，则去掉
    if str:sub(1, 1) == "0" then
        str = str:sub(2)
    end
    return str
end
-- 添加有序JSON编码函数
local function ordered_json_encode(tbl, order)
    local pieces = {}
    if order then
        for _, key in ipairs(order) do
            if tbl[key] then
                local value = tbl[key]
                if type(value) == "table" then
                    -- 为每个部分定义顺序
                    if key == "stat" or key == "set" then
                        -- 对于stat和set部分，直接使用json.encode
                        pieces[#pieces + 1] = string.format('"%s":%s', key, json.encode(value))
                    else
                        local sub_order = {
                            sys = {"model", "config_md5", "last_config", "hard_ver", "soft_ver", "runtime"},
                            net = {"type", "connmethed", "eth_mac", "sta_mac", "ip", "iccid", "imei", "csq", "latitude",
                                   "longitude"}
                        }
                        pieces[#pieces + 1] = string.format('"%s":%s', key, ordered_json_encode(value, sub_order[key]))
                    end
                else
                    pieces[#pieces + 1] = string.format('"%s":%s', key, json.encode(value))
                end
            end
        end
    else
        for k, v in pairs(tbl) do
            pieces[#pieces + 1] = string.format('"%s":%s', k, json.encode(v))
        end
    end
    return "{" .. table.concat(pieces, ",") .. "}"
end
-- 处理设备状态信息并通过MQTT发送
local function handleDeviceStatus(data, status_type)
    -- 获取IP地址
    local ip, nm, gw = socket.localIP()

    -- 获取经纬度信息
    local lat, lng, t = lbsLoc2.request(5000)

    -- 转换统计数据格式
    local stat = {
        com = data.stat.com,
        targets = {}
    }

    -- 将targets对象转换为数组
    for _, target_stats in pairs(_G.stats.targets) do
        -- 确保每个target的统计信息包含所有必要字段
        local target_data = {
            name = target_stats.name,
            send_frame_success = target_stats.send_frame_success or 0,
            send_byte_success = target_stats.send_byte_success or 0,
            send_frame_failed = target_stats.send_frame_failed or 0,
            send_byte_failed = target_stats.send_byte_failed or 0,
            recv_frame = target_stats.recv_frame or 0,
            recv_byte = target_stats.recv_byte or 0
        }
        table.insert(stat.targets, target_data)
    end

    -- 创建一个新的有序数据结构
    local ordered_data = {
        -- 根据不同的状态类型设置不同的status值
        status = status_type or "report_info",
        sys = {
            model = data.sys.model,
            config_md5 = data.sys.config_md5 or "",
            last_config = data.sys.last_config or "",
            hard_ver = data.sys.hard_ver or "1.0.0",
            soft_ver = data.sys.soft_ver or "1.0.1",
            runtime = data.sys.runtime or 0
        },
        net = {
            type = "4G",
            connmethed = data.net.connmethed,
            eth_mac = data.sys.eth_mac,
            sta_mac = data.sys.sta_mac,
            ip = ip or "",
            iccid = mobile.iccid() or "",
            imei = mobile.imei() or "",
            csq = mobile.csq() or 0,
            latitude = formatCoordinate(lat),
            longitude = formatCoordinate(lng)
        },
        stat = stat,
        set = data.set or {}
    }

    -- 如果MQTT已连接且有发布主题配置，发送更新后的数据
    if mqttc and _G.mqtt_config and _G.mqtt_config.pub_topic then
        -- 使用有序的JSON编码，定义顺序
        local order = {"status", "sys", "net", "stat", "set"}
        local jsonStr = ordered_json_encode(ordered_data, order)
        mqttc:publish(_G.mqtt_config.pub_topic, jsonStr, _G.mqtt_config.qos or 0)
        log.info("mqtt", "发送更新后的设备信息", jsonStr)
    else
        log.warn("mqtt", "MQTT未连接或未配置发布主题")
    end
end

-- 处理串口响应数据
local function handle_uart_response(response_data)
    -- 检查是否有目标信息
    if response_data.target then
        local target = response_data.target
        if connections.mqtt[target] and connections.mqtt[target].client then
            local data_topic = connections.mqtt[target].config.data_topic
            if data_topic then
                -- 发送响应数据到对应的data_topic
                connections.mqtt[target].client:publish(data_topic, response_data.data,
                    connections.mqtt[target].config.qos or 0)
                log.info("mqtt", "发送串口响应到", target, data_topic, response_data.data)
            end
        end
    end
end

local function mqtt_send_message_by_name(target, data, data_len)
    -- 创建一个新的任务来处理消息发送
    sys.taskInit(function()
        -- 检查目标是否在MQTT连接中
        if connections.mqtt[target] and connections.mqtt[target].client then
            local data_topic = connections.mqtt[target].config.data_topic
            if data_topic then
                -- 将十六进制字符串转换为二进制数据
                local binary_data = ""
                for i = 1, #data, 2 do
                    local hex = data:sub(i, i + 1)
                    binary_data = binary_data .. string.char(tonumber(hex, 16))
                end

                log.info("mqtt", "准备发送数据", {
                    target = target,
                    topic = data_topic,
                    hex_data = data,
                    binary_length = #binary_data
                })

                -- 发送到data_topic
                local result = connections.mqtt[target].client:publish(data_topic, binary_data,
                    connections.mqtt[target].config.qos or 0)
                update_target_stats(target, result and result > 0, #binary_data, false)
                log.info("mqtt", "发送结果", target, result)
            else
                log.warn("mqtt", "目标没有配置数据主题", target)
            end
        else
            log.warn("mqtt", "目标连接不存在或未连接", target)

            -- 缓存当前需要发送的数据
            if not _G.pending_messages then
                _G.pending_messages = {}
            end
            _G.pending_messages[target] = {
                data = data,
                timestamp = os.time()
            }

            -- 发送获取配置请求到UART
            local request = {
                type = "get_config",
                target = target
            }
            local jsonStr = json.encode(request) .. "\r\n"
            uart.write(1, jsonStr)
            log.info("mqtt", "请求目标配置", target)

            -- 等待一小段时间，让配置响应能够被处理
            sys.wait(100)

            -- 检查是否已经收到配置并创建了连接
            if _G.saved_config and _G.saved_config.targets then
                for _, target_config in ipairs(_G.saved_config.targets) do
                    if target_config.name == target then
                        log.info("mqtt", "找到目标配置，创建连接", target)
                        createConnection(target_config)

                        -- 等待连接建立
                        sys.wait(1000)

                        -- 重试发送消息
                        if connections.mqtt[target] and connections.mqtt[target].client then
                            local pub_topic = connections.mqtt[target].config.pub_topic
                            if pub_topic then
                                connections.mqtt[target].client:publish(pub_topic, data,
                                    connections.mqtt[target].config.qos or 0)
                                log.info("mqtt", "重试发送数据到目标", target, pub_topic, data)
                            end
                        end
                        break
                    end
                end
            end
        end
    end)
end

-- 创建一个HTTP请求队列
local http_queue = {}
local is_sending = false

-- HTTP数据发送函数

local function http_send_data(url, data)
    if not url then
        log.warn("http", "无效的URL")
        return
    end

    -- 从connections中找到对应的target name
    local target_name = nil
    for name, conn in pairs(connections.http) do
        if conn.url == url then
            target_name = name
            break
        end
    end

    if not target_name then
        log.warn("http", "找不到对应的target name", url)
        return
    end

    -- 将十六进制字符串转换为二进制数据
    local binary_data = ""
    for i = 1, #data, 2 do
        local hex = data:sub(i, i + 1)
        binary_data = binary_data .. string.char(tonumber(hex, 16))
    end

    -- 将请求添加到队列
    table.insert(http_queue, {
        url = url,
        data = binary_data,
        target_name = target_name
    })

    -- 如果没有正在发送的请求，启动发送任务
    if not is_sending then
        is_sending = true
        sys.taskInit(function()
            while #http_queue > 0 do
                -- 获取队列中的第一个请求
                local request = table.remove(http_queue, 1)

                -- 强制执行完整的垃圾回收
                collectgarbage("collect")
                collectgarbage("collect")

                -- 等待一小段时间确保内存已释放
                sys.wait(100)

                -- 设置最简化的请求头
                local headers = {
                    ["Content-Type"] = "application/json",
                    ["Content-Length"] = tostring(#request.data)
                }

                log.info("http", "准备发送数据", {
                    target = request.target_name,
                    url = request.url,
                    data_length = #request.data
                })

                -- 尝试发送请求
                local success, response = pcall(function()
                    return http.request("POST", request.url, headers, request.data, {
                        timeout = 3000,
                        headers_only = true,
                        ssl = false
                    }).wait()
                end)

                -- 更新统计信息时使用target name
                if success and type(response) == "number" and response == 200 then
                    update_target_stats(request.target_name, true, #request.data, false)
                    log.info("http", "发送成功", request.target_name, request.url, response)
                else
                    update_target_stats(request.target_name, false, #request.data, false)
                    log.warn("http", "发送失败", request.target_name, request.url, success, response)
                end

                -- 请求之间的间隔
                sys.wait(500)
            end
            is_sending = false
        end)
    end
end
-- 清理HTTP队列的函数
local function clear_http_queue()
    http_queue = {}
    is_sending = false
    collectgarbage("collect")
end

-- 每隔一段时间检查并清理过期的请求
sys.taskInit(function()
    while true do
        if #http_queue > 10 then -- 如果队列太长，清理它
            clear_http_queue()
            log.warn("http", "队列过长，已清理")
        end
        sys.wait(10000) -- 每10秒检查一次
    end
end)

-- 获取HTTP目标URL的函数
local function get_http_target_url(target)
    -- 从connections中获取URL
    if connections.http[target] then
        return connections.http[target].url
    end
    return nil
end

-- 创建一个缓冲区来存储接收到的数据
local receive_buffer = ""

-- 创建一个消息处理任务
sys.taskInit(function()
    local msg_queue = {}

    -- UART接收回调，只负责将数据放入队列
    uart.on(uartid, "receive", function(id, len)
        local s = ""
        repeat
            s = uart.read(id, len)
            if s and #s > 0 then
                receive_buffer = receive_buffer .. s
            end
        until not s or #s == 0

        -- 查找一个完整的JSON对象
        while true do
            local start_pos = receive_buffer:find("{")
            if not start_pos then
                -- 如果没有找到开始标记，清空缓冲区
                receive_buffer = ""
                break
            end

            -- 从开始位置查找匹配的结束括号
            local pos = start_pos
            local depth = 0
            local end_pos = nil

            while pos <= #receive_buffer do
                local char = receive_buffer:sub(pos, pos)
                if char == "{" then
                    depth = depth + 1
                elseif char == "}" then
                    depth = depth - 1
                    if depth == 0 then
                        end_pos = pos
                        break
                    end
                end
                pos = pos + 1
            end

            -- 如果没有找到匹配的结束括号，退出循环等待更多数据
            if not end_pos then
                break
            end

            -- 提取完整的JSON字符串
            local json_str = receive_buffer:sub(start_pos, end_pos)

            -- 更新缓冲区，移除已处理的数据
            receive_buffer = receive_buffer:sub(end_pos + 1)

            -- 尝试解析JSON并将消息添加到队列
            local success, data = pcall(json.decode, json_str)
            if success and data then
                table.insert(msg_queue, {
                    data = data,
                    json_str = json_str
                })
            else
                log.warn("uart", "JSON解析失败", json_str)
            end
        end

        -- 如果缓冲区太大，清空它以防止内存溢出
        if #receive_buffer > 4096 then
            log.warn("uart", "缓冲区溢出，清空缓冲区")
            receive_buffer = ""
        end
    end)

    -- 消息处理循环
    while true do
        -- 检查队列中是否有消息
        if #msg_queue > 0 then
            local msg = table.remove(msg_queue, 1)
            local data = msg.data
            local json_str = msg.json_str

            -- 在协程中处理消息
            if type(data) == "table" then
                -- 添加调试日志
                log.info("uart", "收到数据类型:", type(data))
                log.info("uart", "入口处收到数据:", json_str)

                if data.sys and data.sys.model == "WXNG1" then
                    log.info("uart", "处理设备状态")
                    log.info("uart", "入口处收到数据1:", json_str)
                    log.info("uart", "入口处收到数据2:", data)

                    local status_type = "report_info"
                    if data.action == "info" then
                        status_type = "info"
                    end
                    log.info("uart", "处理设备状态", json_str)
                    handleDeviceStatus(data, status_type)
                elseif data.type then
                    if data.type == "info" then
                        log.info("uart", "处理info请求", json_str)
                        sendDeviceInfo()
                    elseif data.type == "mqtt" then
                        log.info("uart", "处理mqtt配置", json_str)
                        handleMqttConfig(data)
                    elseif data.type == "config_response" then
                        log.info("uart", "处理配置响应", json_str)
                        handleConfigResponse(data)
                    elseif data.type == "fota" then
                        log.info("uart", "处理FOTA请求", json_str)
                        handleFotaMessage(data)
                    elseif data.type == "mqtt_cmd" then
                        -- 处理从MQTT接收到的命令
                        log.info("uart", "处理MQTT命令", json_str)
                        -- 检查必要的字段
                        if data.payload and data.target then
                            -- 更新接收统计
                            update_target_stats(data.target, true, #data.payload, true)
                            -- 创建485命令对象
                            local cmd = {
                                type = "target",
                                target = data.target,
                                target_url = data.topic, -- 使用topic作为target_url
                                data = string.tohex(data.payload) -- 将二进制数据转换为十六进制字符串
                            }

                            -- 发送到485串口
                            local cmd_str = json.encode(cmd)
                            uart.write(1, cmd_str .. "\r\n")
                            log.info("uart", "发送485命令", cmd_str)
                        else
                            log.warn("uart", "MQTT命令格式不完整", json_str)
                        end
                    elseif data.type == "mqtt_response" then
                        -- 处理串口响应
                        log.info("uart", "处理串口响应", json_str)
                        handle_uart_response(data)
                    end
                elseif data.target and data.target_url and data.data then
                    -- 处理目标数据转发
                    log.info("uart", "处理数据转发", json_str)
                    local target = data.target
                    local target_url = data.target_url
                    local target_data = data.data

                    -- 检查是否是HTTP目标
                    if target_url:match("^http") then
                        -- 发送到HTTP目标
                        log.info("uart", "发送到HTTP目标", target, target_url)
                        http_send_data(target_url, target_data)
                    else
                        -- 发送到MQTT目标
                        log.info("uart", "发送到MQTT目标", target, target_url)
                        mqtt_send_message_by_name(target, target_data, #target_data)
                    end
                else
                    log.warn("uart", "数据格式不完整", json_str)
                end
            end
        end
        sys.wait(10) -- 短暂休眠，避免过度占用CPU
    end
end)
-- 启动系统
sys.run()
