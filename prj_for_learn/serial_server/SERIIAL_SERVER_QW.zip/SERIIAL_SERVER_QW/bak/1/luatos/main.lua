--[[
Author: Orion
Date: 2024-11-20 16:48:30
LastEditors: Orion
LastEditTime: 2025-03-25 15:23:01
Description:

--]]
--[[
Author: Orion
Date: 2024-11-19 14:17:34
LastEditors: Orion
LastEditTime: 2024-11-19 17:20:13
Description:

--]]

-- LuaTools需要PROJECT和VERSION这两个信息
PROJECT = "SX_4G_QW"
VERSION = "1.0.1"



-- sys库是标配
_G.sys = require("sys")
--[[特别注意, 使用mqtt库需要下列语句]]
_G.sysplus = require("sysplus")
-- _G.libgnss = require("libgnss")
-- require "mult_mqtt"

require "sx_uart"




-- 结尾总是这一句
sys.run()
-- sys.run()之后后面不要加任何语句!!!!!
