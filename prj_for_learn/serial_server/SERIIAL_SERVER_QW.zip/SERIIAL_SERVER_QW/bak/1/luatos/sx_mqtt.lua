-- 定义全局变量
_G.mqttc = nil
_G.mqtt_config = nil
_G.connections = {
    http = {},
    mqtt = {}
}
-- 修改全局统计变量结构
_G.stats = {
    com = {
        send_frame_success = 0,
        send_byte_success = 0,
        recv_frame_success = 0,
        recv_byte_success = 0
    },
    targets = {} -- 每个目标的统计信息会动态添加
}

-- 添加4G网络监控和重连相关变量
local NETWORK_CHECK_INTERVAL = 30000 -- 每60秒检查一次网络状态
local NETWORK_RECONNECT_INTERVAL = 3000 -- 网络重连间隔5秒
local MAX_NETWORK_RECONNECT_ATTEMPTS = 20 -- 最大重连次数
local network_reconnect_count = 0
local last_network_status = nil

-- 添加SIM卡状态监控相关变量
local SIM_CHECK_INTERVAL = 5000  -- 每5秒检查一次SIM卡状态
local last_sim_status = nil
local sim_absent_count = 0
local MAX_SIM_ABSENT_COUNT = 3  -- 连续3次检测不到SIM卡才确认拔出


-- 添加网络状态检查函数
local function check_network_status()
    -- 检查基本网络状态
    local status = mobile.status()
    local csq = mobile.csq()
    local ip = socket.localIP()

    -- 记录详细的网络信息用于调试
    local network_info = {
        status = status,
        csq = csq,
        ip = ip,
        rssi = mobile.rssi(),
        rsrp = mobile.rsrp(),
        rsrq = mobile.rsrq(),
        snr = mobile.snr()
    }

    log.info("network", "网络状态检查", json.encode(network_info))

    -- 判断网络是否正常
    -- status为1表示已注册网络，csq大于0表示有信号，ip不为nil表示有网络连接
    return status == 1 and csq > 0 and ip ~= nil, network_info
end

-- 添加MQTT连接状态检查函数
local function check_mqtt_connections()
    local all_connected = true

    -- 检查主MQTT连接
    if _G.mqttc then
        local is_connected = _G.mqttc:ready()
        if not is_connected then
            log.warn("mqtt", "主MQTT连接断开")
            all_connected = false
        end
    end

    -- 检查其他MQTT连接
    for name, conn in pairs(connections.mqtt) do
        if conn.client then
            local is_connected = conn.client:ready()
            if not is_connected then
                log.warn("mqtt", name, "MQTT连接断开")
                all_connected = false
            end
        end
    end

    return all_connected
end

-- 添加MQTT重连函数
local function reconnect_mqtt_connections()
    -- 重连主MQTT
    if _G.mqttc then
        log.info("mqtt", "尝试重连主MQTT")
        _G.mqttc:connect()
    end

    -- 重连其他MQTT连接
    for name, conn in pairs(connections.mqtt) do
        if conn.client then
            log.info("mqtt", "尝试重连", name)
            conn.client:connect()
        end
    end
end


-- 添加SIM卡状态检查函数
local function check_sim_status()
    -- 获取SIM卡状态
    local status = mobile.status()
    local iccid = mobile.iccid()

    -- 记录详细的SIM卡信息
    local sim_info = {
        status = status,
        iccid = iccid,
        csq = mobile.csq()
    }

    -- 如果状态发生变化
    if status ~= last_sim_status then
        log.info("sim", "SIM卡状态变化", last_sim_status, "->", status, json.encode(sim_info))

        if status == 0 then  -- SIM卡不存在
            sim_absent_count = sim_absent_count + 1
            if sim_absent_count >= MAX_SIM_ABSENT_COUNT then
                -- SIM卡确实被拔出
                log.warn("sim", "检测到SIM卡被拔出")
                -- 断开所有MQTT连接
                if _G.mqttc then
                    _G.mqttc:close()
                    _G.mqttc = nil
                end
                for name, conn in pairs(connections.mqtt) do
                    if conn.client then
                        conn.client:close()
                        conn.client = nil
                    end
                end
                -- 清空连接记录
                connections.mqtt = {}
                -- 发送状态到串口
                uart.write(1, json.encode({
                    type = "sim_status",
                    status = "removed",
                    iccid = ""
                }) .. "\r\n")
            end
        else  -- SIM卡存在
            sim_absent_count = 0
            if last_sim_status == 0 or last_sim_status == nil then
                -- SIM卡刚插入
                log.info("sim", "检测到SIM卡插入", iccid)
                -- 发送状态到串口
                uart.write(1, json.encode({
                    type = "sim_status",
                    status = "inserted",
                    iccid = iccid or ""
                }) .. "\r\n")

                -- 等待网络初始化
                sys.wait(5000)

                -- 重新初始化网络连接
                sys.taskInit(function()
                    local is_network_ok = check_network_status()
                    if is_network_ok then
                        -- 重新连接MQTT
                        reconnect_mqtt_connections()
                    end
                end)
            end
        end
        last_sim_status = status
    end

    return status ~= 0, sim_info
end

-- 添加统计更新函数
function update_target_stats(target_name, is_success, bytes, is_recv)
    -- 如果找不到对应的target名称，则跳过统计
    if not target_name or target_name == "main_mqtt" then
        return
    end

    -- 确保目标存在于统计中
    if not _G.stats.targets[target_name] then
        _G.stats.targets[target_name] = {
            name = target_name,
            send_frame_success = 0,
            send_byte_success = 0,
            send_frame_failed = 0,
            send_byte_failed = 0,
            recv_frame = 0,
            recv_byte = 0
        }
    end

    local target_stats = _G.stats.targets[target_name]
    if is_recv then
        target_stats.recv_frame = target_stats.recv_frame + 1
        target_stats.recv_byte = target_stats.recv_byte + bytes
    else
        if is_success then
            target_stats.send_frame_success = target_stats.send_frame_success + 1
            target_stats.send_byte_success = target_stats.send_byte_success + bytes
        else
            target_stats.send_frame_failed = target_stats.send_frame_failed + 1
            target_stats.send_byte_failed = target_stats.send_byte_failed + bytes
        end
    end
end
-- 设备状态发布函数
local function publishDeviceStatus(status)
    local status_msg = {
        status = status
    }
    local msg = json.encode(status_msg)

    -- 发送到主MQTT（如果存在）
    if _G.mqttc and _G.mqtt_config and _G.mqtt_config.pub_topic then
        local result = _G.mqttc:publish(_G.mqtt_config.pub_topic, msg, _G.mqtt_config.qos or 2, 1)
        update_target_stats("main_mqtt", result and result > 0, #msg, false)
        log.info("mqtt", "发布状态到主MQTT", status)
    end
end

-- 处理MQTT消息的通用函数
local function handleMqttMessage(topic, payload, target_name)
    -- 创建一个新的任务来处理消息
    sys.taskInit(function()
        -- 确保target_name有值，如果没有则使用默认值
        target_name = target_name or "main_mqtt"

        -- 更新统计信息
        update_target_stats(target_name, true, #payload, true)

        -- 尝试解析payload为JSON
        local success, parsed_payload = pcall(json.decode, payload)
        log.info("mqtt", "收到原始payload:", payload)
        log.info("mqtt", "JSON解析结果:", success, parsed_payload)

        if success and parsed_payload then
            log.info("mqtt", "解析后的payload类型:", type(parsed_payload))
            log.info("mqtt", "解析后的payload内容:", json.encode(parsed_payload))

            -- 检查是否是重启或重置命令
            if type(parsed_payload) == "table" then
                -- 获取命令（支持command或action字段）
                local cmd = parsed_payload.command or parsed_payload.action
                log.info("mqtt", "命令值:", cmd)

                if cmd then
                    log.info("mqtt", "收到命令", cmd)
                    if cmd == "restart" then
                        -- 先发布重启状态到MQTT
                        log.info("mqtt", "准备发布重启状态")
                        publishDeviceStatus("restarting")
                        sys.wait(3000)
                    elseif cmd == "reset" then
                        -- 先发布重置状态到MQTT
                        log.info("mqtt", "准备发布重置状态")
                        publishDeviceStatus("reseting")
                        sys.wait(3000)
                    end
                end
            end
            payload = json.encode(parsed_payload)
        end

        -- 构建接收到的消息的JSON格式
        local mqtt_msg = {
            type = "mqtt_message",
            topic = topic,
            payload = payload
        }
        -- 转换为JSON字符串
        local jsonStr = json.encode(mqtt_msg) .. "\r\n"
        uart.write(1, jsonStr) -- 使用UART1发送
        log.info("uart", "转发MQTT消息", jsonStr)
    end)
end

-- 处理主MQTT配置的函数

function handleMqttConfig(config)
    log.info("mqtt", "开始处理主MQTT配置", json.encode(config))

    -- 保存MQTT配置到全局变量
    _G.mqtt_config = {
        sub_topic = config.pub_topic,
        pub_topic = config.sub_topic,
        qos = config.qos or 2,
        port = config.port or 1883
    }

    -- 如果已存在MQTT连接，先断开
    if _G.mqttc then
        _G.mqttc:close()
        _G.mqttc = nil
    end

    -- 解析MQTT URL
    local url = config.url
    local host = url:match("mqtt://[^@]+@([^:]+)")
    local username = url:match("mqtt://([^:]+):")
    local password = url:match("mqtt://[^:]+:([^@]+)@")

    log.info("mqtt", "主MQTT连接参数", {
        host = host,
        port = config.port,
        username = username,
        clientid = config.clientid,
        sub_topic = config.pub_topic,
        pub_topic = config.sub_topic
    })

    -- 创建MQTT客户端
    _G.mqttc = mqtt.create(nil, host, config.port)

    if _G.mqttc then
        -- 设置认证信息和客户端ID
        _G.mqttc:auth(config.clientid, username, password)
        -- 设置保活时间
        _G.mqttc:keepalive(60)
        -- 设置自动重连
        _G.mqttc:autoreconn(true, 5000)
        -- 设置遗嘱消息
        _G.mqttc:will(_G.mqtt_config.pub_topic, json.encode({
            status = "offline"
        }), _G.mqtt_config.qos, 0)

        -- 设置MQTT回调
        _G.mqttc:on(function(mqtt_client, event, data, payload)
            log.info("mqtt", "主MQTT事件", event, data)
            if event == "conack" then
                -- 连接成功后订阅主题
                mqtt_client:subscribe(_G.mqtt_config.sub_topic, _G.mqtt_config.qos)
                log.info("mqtt", "主MQTT订阅成功", _G.mqtt_config.sub_topic)

                -- 发送上线消息
                mqtt_client:publish(_G.mqtt_config.pub_topic, json.encode({
                    status = "online"
                }), _G.mqtt_config.qos, 0)

                -- 发送连接成功状态到串口
                local status = {
                    type = "mqtt_status",
                    status = "connected",
                    clientid = config.clientid
                }
                uart.write(1, json.encode(status) .. "\r\n")
            elseif event == "recv" then
                handleMqttMessage(data, payload, "main_mqtt")
            elseif event == "disconnect" then
                log.warn("mqtt", "主MQTT断开连接")
                -- 发送断开连接状态到串口
                local status = {
                    type = "mqtt_status",
                    status = "disconnected",
                    clientid = config.clientid
                }
                uart.write(1, json.encode(status) .. "\r\n")
                -- 创建重连任务
                sys.taskInit(function()
                    -- 检查网络状态
                    local is_network_ok = check_network_status()
                    if is_network_ok then
                        -- 如果网络正常但MQTT断开，尝试重连
                        sys.wait(3000) -- 在任务中等待是安全的
                        mqtt_client:connect()
                    end
                end)
            end
        end)

        -- 连接MQTT服务器
        _G.mqttc:connect()
        log.info("mqtt", "主MQTT开始连接")
    else
        log.error("mqtt", "主MQTT客户端创建失败")
    end
end

local function toHex(str)
    return (str:gsub('.', function(c)
        return string.format('%02X', string.byte(c))
    end))
end

-- 创建新的连接
function createConnection(target)
    if not target or not target.name then
        log.error("connection", "无效的目标配置")
        return
    end

    -- 初始化目标的统计信息
    if not _G.stats.targets[target.name] then
        _G.stats.targets[target.name] = {
            name = target.name,
            send_frame_success = 0,
            send_byte_success = 0,
            send_frame_failed = 0,
            send_byte_failed = 0,
            recv_frame = 0,
            recv_byte = 0
        }
    end
    -- 检查现有连接
    if connections.mqtt[target.name] and connections.mqtt[target.name].client then
        log.info("mqtt", "关闭已存在的连接", target.name)
        connections.mqtt[target.name].client:close()
        connections.mqtt[target.name] = nil
        -- 等待一小段时间确保连接完全关闭
        sys.wait(500)
    end

    local url = target.url
    if not url then
        log.error("mqtt", "无效的URL", target.name)
        return
    end

    -- 解析URL获取协议类型
    local protocol = url:match("^(%w+)://")
    if not protocol then
        log.error("mqtt", "无效的协议", target.name, url)
        return
    end

    if protocol == "mqtt" then
        -- 解析MQTT URL
        local username = url:match("mqtt://([^:]+):")
        local password = url:match("://[^:]+:([^@]+)@")
        local host = url:match("@([^:]+)")
        local port = 1883

        -- 检查是否有指定端口
        local host_port = url:match("@([^:]+):(%d+)")
        if host_port then
            host = url:match("@([^:]+):")
            port = tonumber(url:match(":(%d+)$"))
        end

        log.info("mqtt", "连接参数", {
            name = target.name,
            host = host,
            port = port,
            username = username,
            password = password,
            clientid = target.clientid,
            cmd_topic = target.cmd_topic,
            data_topic = target.data_topic
        })

        -- 创建MQTT客户端
        local mqtt_client = mqtt.create(nil, host, port)

        if mqtt_client then
            log.info("mqtt", target.name, "MQTT客户端创建成功")

            -- 设置认证信息
            mqtt_client:auth(target.clientid, username, password)
            mqtt_client:keepalive(60)
            mqtt_client:autoreconn(true, 3000)

            -- 存储MQTT配置和客户端
            connections.mqtt[target.name] = {
                client = mqtt_client,
                config = {
                    cmd_topic = target.cmd_topic, -- 命令主题
                    data_topic = target.data_topic, -- 数据主题
                    qos = target.qos or 2
                }
            }

            -- 设置MQTT回调
            mqtt_client:on(function(client, event, data, payload)
                log.info("mqtt", target.name, "事件:", event, "数据:", data)
                if event == "conack" then
                    -- 连接成功后订阅命令主题
                    if target.cmd_topic then
                        client:subscribe(target.cmd_topic, target.qos or 0)
                        log.info("mqtt", target.name, "订阅命令主题", target.cmd_topic)
                    end
                    -- 发送上线消息
                    -- client:publish(target.data_topic, json.encode({
                    --     status = "online"
                    -- }), target.qos or 2, 1)
                elseif event == "recv" then
                    -- 处理接收到的命令
                    log.info("mqtt", target.name, "收到命令", data, payload)
                    -- handleMqttMessage(data, payload, target.name)  -- 使用target.name而不是url
                    -- 将命令发送到串口
                    -- sys.wait(50)
                    local cmd = {
                        type = "mqtt_cmd",
                        target = target.name,
                        topic = data,
                        payload = toHex(payload) -- 将二进制payload转换为十六进制字符串
                    }
                    uart.write(1, json.encode(cmd) .. "\r\n")
                elseif event == "disconnect" then
                    -- 断开连接
                    log.warn("mqtt", target.name, "连接断开")
                    -- 创建重连任务
                    sys.taskInit(function()
                        -- 检查网络状态
                        local is_network_ok = check_network_status()
                        if is_network_ok then
                            -- 如果网络正常但MQTT断开，尝试重连
                            sys.wait(3000) -- 在任务中等待是安全的
                            client:connect()
                        end
                    end)
                elseif event == "error" then
                    -- 错误事件
                    log.error("mqtt", target.name, "发生错误", data)
                end
            end)

            -- 连接MQTT服务器
            log.info("mqtt", target.name, "开始连接服务器", host, port)
            local connect_result = mqtt_client:connect()
            log.info("mqtt", target.name, "连接请求结果:", connect_result)

        else
            log.error("mqtt", target.name, "MQTT客户端创建失败")
        end
    elseif protocol == "http" then
        -- HTTP 连接处理
        connections.http[target.name] = {
            url = url
        }
        log.info("http", "添加HTTP目标", target.name, url)
    else
        log.error("connection", "不支持的协议类型", protocol)
    end
end

-- 处理set命令

function handleSetCommand(data)
    -- 首先转发原始数据到UART
    local jsonStr = json.encode(data) .. "\r\n"
    uart.write(1, jsonStr)
    log.info("uart", "转发set命令", jsonStr)

    -- 关闭现有的额外连接
    for name, conn in pairs(connections.mqtt) do
        if conn.client then
            conn.client:close()
        end
    end

    -- 清除现有连接
    connections.http = {}
    connections.mqtt = {}

    -- 创建新的连接
    if data.targets then
        for _, target in ipairs(data.targets) do
            createConnection(target)
        end
    end
end

function handleConfigResponse(config_data)
    log.info("mqtt", "处理配置响应", json.encode(config_data))

    if config_data.type == "config_response" then
        -- 创建一个新的任务来处理所有配置
        sys.taskInit(function()
            -- 首先处理主MQTT配置
            if config_data.mqtt then
                log.info("mqtt", "处理主MQTT配置")
                handleMqttConfig(config_data.mqtt)
                -- 等待主MQTT连接建立
                sys.wait(1000)
            end

            -- 然后处理其他配置
            if config_data.config then
                local config = config_data.config

                -- 关闭现有的MQTT连接
                for name, conn in pairs(connections.mqtt) do
                    if conn.client then
                        log.info("mqtt", "关闭现有连接", name)
                        conn.client:close()
                    end
                end

                -- 清除现有连接
                connections.http = {}
                connections.mqtt = {}
                log.info("mqtt", "清除所有现有连接")

                -- 创建新的连接
                if config.targets and #config.targets > 0 then
                    log.info("mqtt", "开始创建新连接，目标数量:", #config.targets)
                    for _, target in ipairs(config.targets) do
                        log.info("mqtt", "准备创建连接", target.name, target.url)
                        createConnection(target)
                        -- 等待连接建立
                        sys.wait(1000)
                    end
                end
            end
        end)
    else
        log.warn("config", "无效的配置响应")
    end
end

-- function handleMqttConfig(config)
--     log.info("mqtt", "开始处理主MQTT配置", json.encode(config))

--     -- 保存MQTT配置到全局变量
--     _G.mqtt_config = {
--         sub_topic = config.pub_topic,
--         pub_topic = config.sub_topic,
--         qos = config.qos or 2,
--         port = config.port or 1883
--     }

--     -- 如果已存在MQTT连接，先断开
--     if _G.mqttc then
--         _G.mqttc:close()
--         _G.mqttc = nil
--     end

--     -- 解析MQTT URL
--     local url = config.url
--     local host = url:match("mqtt://[^@]+@([^:]+)")
--     local username = url:match("mqtt://([^:]+):")
--     local password = url:match("mqtt://[^:]+:([^@]+)@")

--     log.info("mqtt", "主MQTT连接参数", {
--         host = host,
--         port = config.port,
--         username = username,
--         clientid = config.clientid,
--         sub_topic = config.pub_topic,
--         pub_topic = config.sub_topic
--     })

--     -- 创建MQTT客户端
--     _G.mqttc = mqtt.create(nil, host, config.port)

--     if _G.mqttc then
--         -- 设置认证信息和客户端ID
--         _G.mqttc:auth(config.clientid, username, password)
--         -- 设置保活时间
--         _G.mqttc:keepalive(60)
--         -- 设置自动重连
--         _G.mqttc:autoreconn(true, 3000)
--         -- 设置遗嘱消息
--         _G.mqttc:will(_G.mqtt_config.pub_topic, json.encode({
--             status = "offline"
--         }), _G.mqtt_config.qos, 1)
--         -- 设置MQTT回调
--         _G.mqttc:on(function(mqtt_client, event, data, payload)
--             log.info("mqtt", "主MQTT事件", event, data)
--             if event == "conack" then
--                 -- 连接成功后订阅主题
--                 mqtt_client:subscribe(_G.mqtt_config.sub_topic, _G.mqtt_config.qos)
--                 log.info("mqtt", "主MQTT订阅成功", _G.mqtt_config.sub_topic)
--                 -- 发送上线消息
--                 mqtt_client:publish(_G.mqtt_config.pub_topic, json.encode({
--                     status = "online"
--                 }), _G.mqtt_config.qos, 1)

--                 -- 发送连接成功状态
--                 local status = {
--                     type = "mqtt_status",
--                     status = "connected",
--                     clientid = config.clientid
--                 }
--                 uart.write(1, json.encode(status) .. "\r\n")
--             elseif event == "recv" then
--                 handleMqttMessage(data, payload, "main_mqtt")
--             elseif event == "disconnect" then
--                 log.warn("mqtt", "主MQTT断开连接")
--                 -- 发送断开连接状态
--                 local status = {
--                     type = "mqtt_status",
--                     status = "disconnected",
--                     clientid = config.clientid
--                 }
--                 uart.write(1, json.encode(status) .. "\r\n")
--             end
--         end)

--         -- 连接MQTT服务器
--         _G.mqttc:connect()
--         log.info("mqtt", "主MQTT开始连接")
--     else
--         log.error("mqtt", "主MQTT客户端创建失败")
--     end
-- end

-- 发布消息到所有MQTT连接
function publishToAllMqtt(message)
    local success = false
    -- 发送到主MQTT（如果存在）
    if mqttc and _G.mqtt_config and _G.mqtt_config.pub_topic then
        success = mqttc:publish(_G.mqtt_config.pub_topic, message, _G.mqtt_config.qos)
        update_target_stats("main_mqtt", success, #message, false)
        log.info("mqtt", "发布到主MQTT", _G.mqtt_config.pub_topic, message)
    end

    -- 发送到其他MQTT连接
    for name, conn in pairs(connections.mqtt) do
        if conn.client and conn.config.pub_topic then
            success = conn.client:publish(conn.config.pub_topic, message, conn.config.qos or 2)
            update_target_stats(name, success, #message, false) -- 直接使用name
            log.info("mqtt", "发布到", name, conn.config.pub_topic, message)
        end
    end
end

-- 发送到所有HTTP连接
function sendToAllHttp(message)
    for name, conn in pairs(connections.http) do
        -- 这里需要实现HTTP发送逻辑
        log.info("http", "准备发送到", name, conn.url, message)
        -- TODO: 实现HTTP发送
    end
end

-- 添加网络监控和重连任务
sys.taskInit(function()
    while true do
        local is_network_ok, network_info = check_network_status()

        if not is_network_ok then
            log.warn("network", "网络异常", json.encode(network_info))

            -- 网络异常时的重连逻辑
            while network_reconnect_count < MAX_NETWORK_RECONNECT_ATTEMPTS do
                -- 等待重连间隔
                sys.wait(NETWORK_RECONNECT_INTERVAL)

                -- 重新检查网络状态
                is_network_ok, network_info = check_network_status()
                if is_network_ok then
                    log.info("network", "网络恢复正常")
                    network_reconnect_count = 0

                    -- 网络恢复后，检查并重连MQTT
                    sys.wait(2000) -- 等待网络完全稳定
                    if not check_mqtt_connections() then
                        log.info("mqtt", "网络恢复后重连MQTT")
                        reconnect_mqtt_connections()
                    end
                    break
                end

                network_reconnect_count = network_reconnect_count + 1
                log.warn("network", "网络重连尝试", network_reconnect_count)
            end

            if network_reconnect_count >= MAX_NETWORK_RECONNECT_ATTEMPTS then
                log.error("network", "网络重连失败达到最大次数，准备重启设备")
                sys.wait(5000)
                rtos.reboot() -- 重启设备
            end
        else
            -- 网络正常时，检查MQTT连接状态
            if not check_mqtt_connections() then
                log.info("mqtt", "MQTT连接异常，尝试重连")
                reconnect_mqtt_connections()
            end
            network_reconnect_count = 0 -- 重置重连计数器
        end

        -- 定期检查间隔
        sys.wait(NETWORK_CHECK_INTERVAL)
    end
end)

-- 添加SIM卡监控任务
sys.taskInit(function()
    while true do
        local is_sim_ok, sim_info = check_sim_status()
        if not is_sim_ok then
            log.warn("sim", "SIM卡异常", json.encode(sim_info))
        end
        sys.wait(SIM_CHECK_INTERVAL)
    end
end)

-- -----------------------------
-- -----------------------------
-- -----------------------------


-- 添加HTTP状态推送相关变量
-- local HTTP_STATUS_INTERVAL = 10000  -- 每10秒推送一次状态
-- local HTTP_STATUS_URL = "http://101.126.148.124"

-- 添加HTTP时间获取函数
function fetch_aliyun_time()
    local url = "https://api.eyunwei.com/monitor/device/getAliyunTime"
    local timestamp = ""
    local datetime = ""
    local max_retries = 3
    local retry_count = 0
    local retry_delay = 2000  -- 2秒

    log.info("time", "开始获取阿里云时间...")

    -- 打印本地网络信息
    local ip, netmask, gateway = socket.localIP()
    log.info("time", "本地IP信息:", ip or "无IP", netmask or "无掩码", gateway or "无网关")

    -- 打印移动网络状态
    local mobile_status = mobile.status()
    local csq = mobile.csq()
    local rssi = mobile.rssi()
    log.info("time", "移动网络状态:", mobile_status, "信号强度:", csq, "RSSI:", rssi)

    -- 检查基本连接
    if ip then
        log.info("time", "网络连接状态: 已连接")
    else
        log.warn("time", "网络连接状态: 未连接")
    end

    while retry_count < max_retries do
        -- 使用HTTP请求获取时间，增加详细日志
        log.info("time", "===== 开始HTTP请求 =====")
        log.info("time", "尝试次数:", retry_count + 1, "/", max_retries)
        log.info("time", "请求URL:", url)

        -- 清理内存
        collectgarbage("collect")

        local request_start = os.time()
        local code, headers, body = http.request("GET", url, nil, nil, {
            timeout = 15000,  -- 15秒
            ssl = false
        }).wait()
        local request_end = os.time()
        local request_time = request_end - request_start

        log.info("time", "HTTP请求耗时:", request_time, "秒")
        log.info("time", "HTTP状态码:", code)

        if code then
            log.info("time", "HTTP响应类型:", type(body))
            log.info("time", "HTTP响应长度:", body and #body or 0)
        else
            log.error("time", "HTTP请求失败，无状态码")
        end

        if headers then
            log.info("time", "HTTP响应头:", json.encode(headers))
        end

        if code and code > 0 and body then
            -- 尝试解析JSON响应
            log.info("time", "收到响应内容:", body and #body > 100 and (body:sub(1, 100) .. "...") or body)
            local parse_success, data = pcall(json.decode, body)

            if parse_success and type(data) == "table" then
                log.info("time", "JSON解析成功:", json.encode(data))

                if data.ret == 200 and data.data then
                    timestamp = tostring(data.data.timestamp)
                    datetime = data.data.datetime
                    log.info("time", "成功获取阿里云时间", datetime, timestamp)
                    return timestamp, datetime
                else
                    log.warn("time", "API返回状态码不是200或data字段缺失")
                end
            else
                log.warn("time", "JSON解析失败:", body and #body > 100 and (body:sub(1, 100) .. "...") or body)
            end
            -- 请求成功但解析失败，不再重试
            break
        else
            -- 请求失败，增加重试计数
            retry_count = retry_count + 1
            log.warn("time", "HTTP请求失败，错误码:", code, "重试次数:", retry_count, "/", max_retries)

            -- 最后一次重试失败，记录错误
            if retry_count >= max_retries then
                log.error("time", "HTTP请求全部失败，放弃尝试")
            else
                -- 每次重试前增加垃圾回收
                collectgarbage("collect")
                -- 等待一段时间后重试
                sys.wait(retry_delay)
                log.info("time", "正在重试获取阿里云时间...")
            end
        end
    end

    log.error("time", "时间获取失败，将使用本地时间")
    return timestamp, datetime
end

-- 添加获取所有连接状态的函数
local function get_all_connections_status()
    -- 获取基本网络信息
    local ip, netmask, gateway = socket.localIP()
    local status = mobile.status()
    local csq = mobile.csq()
    local iccid = mobile.iccid() or ""
    local imei = mobile.imei() or ""

    -- 获取信号质量信息
    local rssi = mobile.rssi() -- 信号强度(dBm)
    local rsrp = mobile.rsrp() -- 参考信号接收功率
    local rsrq = mobile.rsrq() -- 参考信号接收质量
    local snr = mobile.snr()   -- 信噪比

    -- 获取当前时间，首先尝试从阿里云API获取，失败则使用本地时间
    local timestamp_ms, datetime = fetch_aliyun_time()
    local timestamp = datetime

    -- 如果网络获取失败，回退到本地时间
    if timestamp == "" then
        local current_time = os.date("*t")
        timestamp = string.format("%04d-%02d-%02d %02d:%02d:%02d",
            current_time.year, current_time.month, current_time.day,
            current_time.hour, current_time.min, current_time.sec)
        log.info("time", "使用本地时间", timestamp)
    end

    -- 获取运行时间
    local run_time = os.time()

    -- 创建状态对象
    local status_obj = {
        device = {
            imei = imei,
            iccid = iccid,
            ip = ip or "未连接",
            timestamp = timestamp,
            timestamp_ms = timestamp_ms,
            run_time = run_time,
            network = {
                status = status,
                csq = csq,
                rssi = rssi,
                rsrp = rsrp,
                rsrq = rsrq,
                snr = snr
            }
        },
        mqtt = {
            main = {
                connected = (_G.mqttc and _G.mqttc:ready()) and true or false,
                config = _G.mqtt_config
            },
            connections = {}
        },
        stats = _G.stats
    }

    -- 添加所有MQTT连接状态
    for name, conn in pairs(connections.mqtt) do
        status_obj.mqtt.connections[name] = {
            connected = (conn.client and conn.client:ready()) and true or false,
            config = conn.config
        }
    end

    -- 添加所有HTTP连接
    status_obj.http = {}
    for name, conn in pairs(connections.http) do
        status_obj.http[name] = {
            url = conn.url
        }
    end

    return status_obj
end

-- 添加HTTP状态推送函数
-- local function push_status_to_http()
--     -- 获取所有连接状态
--     local status_obj = get_all_connections_status()

--     -- 转换为JSON并记录日志
--     local json_data = json.encode(status_obj)
--     log.info("http_status", "准备发送的数据:", json_data)

--     -- 创建HTTP请求头
--     local headers = {
--         ["Content-Type"] = "application/json",
--         ["Content-Length"] = tostring(#json_data)
--     }

--     -- 发送HTTP请求前记录日志
--     log.info("http_status", "开始发送请求到", HTTP_STATUS_URL)

--     -- 使用pcall避免HTTP请求失败导致任务崩溃
--     local success, response = pcall(function()
--         return http.request("POST", HTTP_STATUS_URL, headers, json_data, {
--             timeout = 5000,
--             ssl = false
--         }).wait()
--     end)

--     -- 详细记录响应结果
--     if success then
--         if type(response) == "number" then
--             log.info("http_status", "HTTP响应状态码:", response)
--             if response >= 200 and response < 300 then
--                 log.info("http_status", "状态推送成功")
--             else
--                 log.warn("http_status", "服务器返回错误状态码:", response)
--             end
--         else
--             log.warn("http_status", "收到非数字响应:", response)
--         end
--     else
--         log.error("http_status", "HTTP请求失败:", response)
--     end
-- end

-- 添加定时推送状态的任务
-- sys.taskInit(function()
--     -- 启动后等待一段时间，确保网络和MQTT连接已初始化
--     sys.wait(15000)

--     while true do
--         -- 检查网络状态
--         local is_network_ok = check_network_status()

--         if is_network_ok then
--             -- 推送状态到HTTP
--             push_status_to_http()
--         else
--             log.warn("http_status", "网络异常，跳过状态推送")
--         end

--         -- 等待下一次推送
--         sys.wait(HTTP_STATUS_INTERVAL)
--     end
-- end)

-- 添加内存监控和垃圾回收
sys.taskInit(function()
    while true do
        -- 获取当前内存使用情况
        local mem_used = collectgarbage("count")  -- 返回KB
        log.info("memory", "当前内存使用", mem_used, "KB")

        -- 如果内存使用超过一定阈值，执行完整垃圾回收
        if mem_used > 100 then  -- 假设阈值为100KB
            log.info("memory", "执行垃圾回收")
            collectgarbage("collect")
            -- 再次获取内存使用情况
            local mem_after = collectgarbage("count")
            log.info("memory", "垃圾回收后内存使用", mem_after, "KB", "释放了", mem_used - mem_after, "KB")
        end

        -- 每60秒检查一次
        sys.wait(60000)
    end
end)
