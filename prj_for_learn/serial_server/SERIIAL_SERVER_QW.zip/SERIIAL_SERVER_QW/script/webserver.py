from flask import Flask, request, jsonify, render_template_string
import json
import logging
import os
from datetime import datetime
import threading
import time
import paho.mqtt.client as mqtt
# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("device_status.log"),
        logging.StreamHandler()
    ]
)

app = Flask(__name__)

# 存储设备状态的字典
device_statuses = {}
# 线程锁，防止并发访问问题
status_lock = threading.Lock()

# 设备离线检测时间（秒）
OFFLINE_THRESHOLD = 30
# 添加日志文件管理相关常量
LOG_FILE_PATH = "device_logs.txt"
MAX_LOG_SIZE = 5 * 1024 * 1024 * 1024  # 5GB in bytes

# MQTT配置
MQTT_BROKER = "47.116.122.204"  # MQTT服务器地址，根据实际情况修改
MQTT_PORT = 1883           # MQTT服务器端口
MQTT_KEEPALIVE = 60        # 保活时间
MQTT_USERNAME = "public"       # MQTT用户名，如果需要认证
MQTT_PASSWORD = "Aa123456"       # MQTT密码，如果需要认证

# 设备MQTT主题映射，用于存储每个设备的主题
device_topics = {}  # 格式: {imei: {"pub_topic": topic1, "sub_topic": topic2}}

# MQTT状态日志
MQTT_STATUS_LOG_FILE = "mqtt_status_log.txt"

HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>设备状态监控</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        .online { color: green; }
        .offline { color: red; }
        .device-card { margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="container mt-4">
        <h2>设备状态监控面板</h2>
        <div class="mb-3">
            <a href="/mqtt_logs" class="btn btn-info">查看MQTT日志</a>
        </div>
        <div id="devices" class="row">
            <!-- 设备数据将在这里动态显示 -->
        </div>
    </div>

    <script>
        function updateDevices() {
            $.get('/devices', function(data) {
                $('#devices').empty();
                for (let imei in data) {
                    let device = data[imei];
                    let status = device.online ?
                        '<span class="online">在线</span>' :
                        '<span class="offline">离线</span>';

                    // 添加MQTT状态显示
                    let mqttStatus = device.mqtt_status ?
                        `<span class="online">MQTT在线</span>` :
                        `<span class="offline">MQTT离线</span>`;

                    let card = `
                        <div class="col-md-6 device-card">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">设备 ${device.device.imei}</h5>
                                    <p>状态: ${status}</p>
                                    <p>MQTT状态: ${mqttStatus}</p>
                                    <p>最后更新: ${device.received_at}</p>
                                    <p>IP地址: ${device.device.ip}</p>
                                    <p>信号强度: ${device.device.network.csq}</p>
                                    <p>ICCID: ${device.device.iccid}</p>
                                    <div class="btn-group">
                                        <a href="/device_logs/${device.device.imei}" class="btn btn-primary">
                                            查看设备日志
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;
                    $('#devices').append(card);
                }
            });
        }

        // 每5秒更新一次数据
        updateDevices();
        setInterval(updateDevices, 5000);
    </script>
</body>
</html>
"""
@app.route('/', methods=['GET'])
def index():
    return render_template_string(HTML_TEMPLATE)

# 设备状态接收接口
@app.route('/', methods=['POST'])
def receive_status():
    try:
        # 获取请求数据
        data = request.get_json()

        if not data:
            return jsonify({"status": "error", "message": "无效的JSON数据"}), 400

        # 提取设备标识（使用IMEI作为唯一标识）
        device_id = data.get('device', {}).get('imei')
        if not device_id:
            return jsonify({"status": "error", "message": "缺少设备标识"}), 400

        # 添加接收时间戳
        data['received_at'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # 检查是否包含MQTT配置信息
        mqtt_config = data.get('mqtt', {}).get('main', {}).get('config', {})
        if mqtt_config and 'pub_topic' in mqtt_config and 'sub_topic' in mqtt_config:
            # 更新设备主题映射
            with status_lock:
                device_topics[device_id] = {
                    "pub_topic": mqtt_config['pub_topic'],
                    "sub_topic": mqtt_config['sub_topic']
                }

                # 确保MQTT客户端订阅了这个主题
                subscribe_to_device_topic(device_id)

                logging.info(f"更新设备 {device_id} 的MQTT主题: {device_topics[device_id]}")

        # 更新设备状态
        with status_lock:
            # 保留MQTT状态信息，如果是新设备则默认为False
            mqtt_status = device_statuses.get(device_id, {}).get('mqtt_status', False)

            # 检查MQTT连接状态
            mqtt_connected = data.get('mqtt', {}).get('main', {}).get('connected', False)

            # 如果设备报告MQTT已连接，则更新状态
            if mqtt_connected:
                mqtt_status = True
                logging.info(f"设备 {device_id} 报告MQTT已连接")

            data['mqtt_status'] = mqtt_status
            device_statuses[device_id] = data

        # 记录日志
        logging.info(f"接收到设备 {device_id} 的状态更新")

        # 可选：将状态保存到文件
        save_status_to_file(device_id, data)

        return jsonify({"status": "success", "message": "状态已接收"}), 200

    except Exception as e:
        logging.error(f"处理请求时出错: {str(e)}")
        return jsonify({"status": "error", "message": str(e)}), 500

# 获取所有设备状态的接口
@app.route('/devices', methods=['GET'])
def get_all_devices():
    with status_lock:
        # 检查设备在线状态
        current_time = time.time()
        devices_with_status = {}

        for device_id, status in device_statuses.items():
            # 计算最后一次更新到现在的时间差
            last_update = datetime.strptime(status['received_at'], "%Y-%m-%d %H:%M:%S")
            last_update_timestamp = last_update.timestamp()
            time_diff = current_time - last_update_timestamp

            # 复制状态并添加在线/离线标记
            device_status = status.copy()
            device_status['online'] = time_diff < OFFLINE_THRESHOLD
            device_status['last_seen_seconds_ago'] = int(time_diff)

            devices_with_status[device_id] = device_status

        return jsonify(devices_with_status)

# 获取特定设备状态的接口
@app.route('/devices/<device_id>', methods=['GET'])
def get_device_status(device_id):
    with status_lock:
        if device_id not in device_statuses:
            return jsonify({"status": "error", "message": "设备不存在"}), 404

        status = device_statuses[device_id]

        # 计算最后一次更新到现在的时间差
        current_time = time.time()
        last_update = datetime.strptime(status['received_at'], "%Y-%m-%d %H:%M:%S")
        last_update_timestamp = last_update.timestamp()
        time_diff = current_time - last_update_timestamp

        # 复制状态并添加在线/离线标记
        device_status = status.copy()
        device_status['online'] = time_diff < OFFLINE_THRESHOLD
        device_status['last_seen_seconds_ago'] = int(time_diff)

        return jsonify(device_status)

# 将状态保存到文件
def save_status_to_file(device_id, data):
    try:
        # 确保目录存在
        os.makedirs('device_statuses', exist_ok=True)

        # 将数据转换为日志格式
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] Device: {device_id}\n{json.dumps(data, indent=2)}\n{'='*80}\n"

        # 检查日志文件大小
        if os.path.exists(LOG_FILE_PATH):
            file_size = os.path.getsize(LOG_FILE_PATH)
            if file_size >= MAX_LOG_SIZE:
                # 如果文件超过5GB，读取后半部分内容
                with open(LOG_FILE_PATH, 'rb') as f:
                    # 定位到文件中间
                    f.seek(file_size // 2)
                    # 读取到下一个完整行的开始
                    f.readline()
                    # 读取剩余内容
                    remaining_content = f.read()

                # 将后半部分内容写回文件
                with open(LOG_FILE_PATH, 'wb') as f:
                    f.write(remaining_content)

        # 追加新的日志条目
        with open(LOG_FILE_PATH, 'a', encoding='utf-8') as f:
            f.write(log_entry)

        # 同时保存最新状态（可选）
        with open(f'device_statuses/{device_id}_latest.json', 'w') as f:
            json.dump(data, f, indent=2)

    except Exception as e:
        logging.error(f"保存状态文件时出错: {str(e)}")

# 添加日志查看接口
@app.route('/logs', methods=['GET'])
def view_logs():
    try:
        # 读取最后1000行日志
        with open(LOG_FILE_PATH, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            last_lines = lines[-1000:] if len(lines) > 1000 else lines
            log_content = ''.join(last_lines)
    except FileNotFoundError:
        log_content = "暂无日志"
    except Exception as e:
        log_content = f"读取日志出错: {str(e)}"

    # 返回日志查看页面
    return render_template_string("""
        <!DOCTYPE html>
        <html>
        <head>
            <title>设备日志查看</title>
            <meta charset="utf-8">
            <style>
                pre {
                    background-color: #f5f5f5;
                    padding: 15px;
                    border-radius: 5px;
                    white-space: pre-wrap;
                    word-wrap: break-word;
                }
            </style>
        </head>
        <body>
            <h2>设备日志</h2>
            <pre>{{ log_content }}</pre>
            <script>
                // 每60秒自动刷新
                setTimeout(function() {
                    location.reload();
                }, 60000);
            </script>
        </body>
        </html>
    """, log_content=log_content)

# 添加MQTT状态日志查看接口
@app.route('/mqtt_logs', methods=['GET'])
def view_mqtt_logs():
    try:
        # 读取最后1000行MQTT状态日志
        with open(MQTT_STATUS_LOG_FILE, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            last_lines = lines[-1000:] if len(lines) > 1000 else lines
            log_content = ''.join(last_lines)
    except FileNotFoundError:
        log_content = "暂无MQTT状态日志"
    except Exception as e:
        log_content = f"读取MQTT状态日志出错: {str(e)}"

    # 返回MQTT状态日志查看页面
    return render_template_string("""
        <!DOCTYPE html>
        <html>
        <head>
            <title>MQTT状态日志查看</title>
            <meta charset="utf-8">
            <style>
                pre {
                    background-color: #f5f5f5;
                    padding: 15px;
                    border-radius: 5px;
                    white-space: pre-wrap;
                    word-wrap: break-word;
                }
                .online { color: green; }
                .offline { color: red; }
            </style>
        </head>
        <body>
            <h2>MQTT状态日志</h2>
            <pre>{{ log_content }}</pre>
            <script>
                // 每30秒自动刷新
                setTimeout(function() {
                    location.reload();
                }, 30000);
            </script>
        </body>
        </html>
    """, log_content=log_content)

# 添加查看设备日志的路由
@app.route('/device_logs/<device_id>', methods=['GET'])
def view_device_logs(device_id):
    try:
        # 读取设备的MQTT状态日志
        device_logs = []
        if os.path.exists(MQTT_STATUS_LOG_FILE):
            with open(MQTT_STATUS_LOG_FILE, 'r', encoding='utf-8') as f:
                lines = f.readlines()
                for line in lines:
                    if f"设备 {device_id}" in line:
                        device_logs.append(line)

        # 如果没有找到日志
        if not device_logs:
            log_content = f"没有找到设备 {device_id} 的日志记录"
        else:
            # 最多显示最近100条日志
            log_content = ''.join(device_logs[-100:])

        # 返回设备日志查看页面
        return render_template_string("""
            <!DOCTYPE html>
            <html>
            <head>
                <title>设备日志查看</title>
                <meta charset="utf-8">
                <style>
                    pre {
                        background-color: #f5f5f5;
                        padding: 15px;
                        border-radius: 5px;
                        white-space: pre-wrap;
                        word-wrap: break-word;
                    }
                    .online { color: green; }
                    .offline { color: red; }
                </style>
            </head>
            <body>
                <h2>设备 {{ device_id }} 的日志</h2>
                <a href="/" class="btn btn-primary">返回首页</a>
                <pre>{{ log_content }}</pre>
                <script>
                    // 每30秒自动刷新
                    setTimeout(function() {
                        location.reload();
                    }, 30000);
                </script>
            </body>
            </html>
        """, device_id=device_id, log_content=log_content)
    except Exception as e:
        return f"读取设备日志出错: {str(e)}"

# 修改订阅设备主题的函数，移除清除retain消息的功能
def subscribe_to_device_topic(device_id):
    if mqtt_client and mqtt_client.is_connected() and device_id in device_topics:
        topic = device_topics[device_id].get("pub_topic")
        if topic:
            # 订阅主题
            mqtt_client.subscribe(topic)
            logging.info(f"订阅设备 {device_id} 的主题: {topic}")

# 启动离线设备检测线程
def check_offline_devices():
    while True:
        try:
            current_time = time.time()
            with status_lock:
                for device_id, status in list(device_statuses.items()):
                    last_update = datetime.strptime(status['received_at'], "%Y-%m-%d %H:%M:%S")
                    last_update_timestamp = last_update.timestamp()
                    time_diff = current_time - last_update_timestamp

                    if time_diff > OFFLINE_THRESHOLD:
                        logging.warning(f"设备 {device_id} 可能离线，最后更新时间: {status['received_at']}")
        except Exception as e:
            logging.error(f"检查离线设备时出错: {str(e)}")

        time.sleep(30)  # 每30秒检查一次

# MQTT客户端回调函数
def on_connect(client, userdata, flags, rc):
    logging.info(f"MQTT客户端连接结果: {rc}")

    # 连接成功后，订阅所有已知设备的主题
    with status_lock:
        for device_id, topics in device_topics.items():
            if "pub_topic" in topics:
                topic = topics["pub_topic"]
                client.subscribe(topic)
                logging.info(f"订阅设备 {device_id} 的主题: {topic}")

def on_message(client, userdata, msg):
    try:
        # 解析消息内容
        payload = msg.payload.decode('utf-8')
        topic = msg.topic

        logging.info(f"收到MQTT消息: 主题={topic}, 内容={payload}")

        # 如果是空消息，忽略处理
        if not payload.strip():
            logging.info(f"忽略空消息: 主题={topic}")
            return

        # 尝试解析JSON
        try:
            data = json.loads(payload)
        except json.JSONDecodeError:
            logging.error(f"无法解析MQTT消息为JSON: {payload}")
            return

        # 检查是否是状态消息
        if "status" in data:
            status_value = data["status"]

            # 查找对应的设备
            device_id = None
            for imei, topics in device_topics.items():
                if topics.get("pub_topic") == topic:
                    device_id = imei
                    break

            if device_id:
                # 记录MQTT状态变化
                log_mqtt_status_change(device_id, status_value)

                # 更新设备的MQTT状态
                with status_lock:
                    if device_id in device_statuses:
                        # 对于online和offline状态，直接更新MQTT状态
                        if status_value == "online":
                            device_statuses[device_id]['mqtt_status'] = True
                            logging.info(f"更新设备 {device_id} 的MQTT状态为: 在线")
                        elif status_value == "offline":
                            device_statuses[device_id]['mqtt_status'] = False
                            logging.info(f"更新设备 {device_id} 的MQTT状态为: 离线")
                        else:
                            # 对于其他状态，记录但不改变MQTT状态
                            logging.info(f"收到设备 {device_id} 的状态消息: {status_value}，不改变MQTT状态")
    except Exception as e:
        logging.error(f"处理MQTT消息时出错: {str(e)}")

def on_disconnect(client, userdata, rc):
    if rc != 0:
        logging.warning(f"MQTT客户端意外断开连接: {rc}")
    else:
        logging.info("MQTT客户端正常断开连接")

# 记录MQTT状态变化
def log_mqtt_status_change(device_id, status):
    try:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] 设备 {device_id} MQTT状态: {status}\n"

        with open(MQTT_STATUS_LOG_FILE, 'a', encoding='utf-8') as f:
            f.write(log_entry)
    except Exception as e:
        logging.error(f"记录MQTT状态变化时出错: {str(e)}")

# 初始化MQTT客户端
mqtt_client = None

def setup_mqtt_client():
    global mqtt_client

    # 创建MQTT客户端
    client_id = f"mqtt_monitor_{int(time.time())}"
    mqtt_client = mqtt.Client(client_id=client_id)

    # 设置回调函数
    mqtt_client.on_connect = on_connect
    mqtt_client.on_message = on_message
    mqtt_client.on_disconnect = on_disconnect

    # 设置认证信息（如果需要）
    if MQTT_USERNAME and MQTT_PASSWORD:
        mqtt_client.username_pw_set(MQTT_USERNAME, MQTT_PASSWORD)

    # 连接到MQTT服务器
    try:
        mqtt_client.connect(MQTT_BROKER, MQTT_PORT, MQTT_KEEPALIVE)
        mqtt_client.loop_start()  # 在后台线程中启动网络循环
        logging.info(f"MQTT客户端已连接到 {MQTT_BROKER}:{MQTT_PORT}")
    except Exception as e:
        logging.error(f"MQTT客户端连接失败: {str(e)}")
        mqtt_client = None

if __name__ == '__main__':
    # 启动离线设备检测线程
    offline_checker = threading.Thread(target=check_offline_devices, daemon=True)
    offline_checker.start()

    # 设置MQTT客户端
    setup_mqtt_client()

    # 启动Flask应用
    app.run(host='0.0.0.0', port=80, debug=False)
