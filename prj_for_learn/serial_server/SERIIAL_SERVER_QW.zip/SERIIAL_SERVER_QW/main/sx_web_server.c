/*
 * @Author: Orion
 * @Date: 2024-09-02 16:38:07
 * @LastEditors: Orion
 * @LastEditTime: 2025-02-25 22:26:03
 * @Description:
 *
 */
/*
 * @Author: Orion
 * @Date: 2024-01-23 16:09:45
 * @LastEditors: Orion
 * @LastEditTime: 2024-12-20 15:51:08
 * @FilePath: \SERIIAL_SERVER_P\main\sx_web_server.c
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */

#include "sx_web_server.h"
#include "cJSON.h"
#include "esp_eth.h"
#include "esp_event.h"
#include "esp_http_server.h"
#include "esp_log.h"
#include "esp_mac.h"
#include "esp_netif.h"
#include "esp_tls.h"
#include "esp_wifi.h"
#include "lwip/inet.h"

#include "driver/gpio.h"
#include "esp_chip_info.h"
#include "esp_netif_sntp.h"
#include "esp_sleep.h"
#include "esp_sntp.h"
#include "esp_system.h"
#include "esp_timer.h"
#include "math.h"
#include "nvs.h"
#include "nvs_flash.h"
#include "sx_4g_uart.h"
// #include "sx_async_uart.h"
#include "esp_log.h"
#include "sx_485_uart.h"
#include "sx_dns_server.h"
#include "sx_http_ota.h"
#include "sx_init_eth.h"
#include "sx_log.h"
#include "sx_mqtt_client.h"
#include "sx_tcp_client.h"
#include "sx_tcp_server.h"
#include "sx_time.h"
#include "sx_utils.h"
#include "sx_wifi_scan.h"
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/param.h>
// #include "esp_websocket_server.h"

uint8_t sta_mac[6] = {0};
uint8_t eth_mac[6] = {0};
char dIp[20];
char dNetmask[20];
char dGateway[20];
uint8_t mac_addr[6] = {0};
char device_mac[30];

char th[20] = {0};
char device_mac_end[20];
char got_ip_addrs[16];
char got_ip_netmask[16];
char got_ip_gw[16];
int httpreason = 0;

char device_sta_mac[24];
char device_eth_mac[24];
char device_name[40];

static const char *TAG = "WEBSERVER";

extern const char root_start[] asm("_binary_root_html_start");
extern const char root_end[] asm("_binary_root_html_end");

extern const char web_start[] asm("_binary_web_html_start");
extern const char web_end[] asm("_binary_web_html_end");

extern const char logo_start[] asm("_binary_logo_png_start");
extern const char logo_end[] asm("_binary_logo_png_end");

extern const char js_start[] asm("_binary_web_js_start");
extern const char js_end[] asm("_binary_web_js_end");

extern const char css_start[] asm("_binary_web_css_start");
extern const char css_end[] asm("_binary_web_css_end");

extern const char userweb_start[] asm("_binary_userweb_html_start");
extern const char userweb_end[] asm("_binary_userweb_html_end");

extern const char userwebjs_start[] asm("_binary_userweb_js_start");
extern const char userwebjs_end[] asm("_binary_userweb_js_end");

#define ESP_WIFI_SSID "WXNG1"
#define ESP_WIFI_PASS "12345678"
#define MAX_STA_CONN 8

httpd_handle_t http_server = NULL;

// 添加WebSocket相关变量
// static httpd_handle_t websocket_server = NULL;
static int client_session_id = 0;
// 定义常量和全局变量
#define MAX_WS_CLIENTS 4   // 限制最大WebSocket客户端数量
#define WS_QUEUE_SIZE 32   // WebSocket消息队列大小
#define WS_MAX_MSG_LEN 256 // 最大消息长度

typedef struct {
  int client_fd;
  bool in_use;
} ws_client_t;

static ws_client_t ws_clients[MAX_WS_CLIENTS] = {0};
static QueueHandle_t ws_msg_queue = NULL;
static TaskHandle_t ws_task_handle = NULL;

// static void disconnect_handler(void *arg, esp_event_base_t event_base,
//                                int32_t event_id, void *event_data);

/*************************************************************************************/
/*                                START OF FILE */
/*************************************************************************************/

static void wifi_event_handler(void *arg, esp_event_base_t event_base,
                               int32_t event_id, void *event_data) {
  if (event_id == WIFI_EVENT_AP_STACONNECTED) {
    wifi_event_ap_staconnected_t *event =
        (wifi_event_ap_staconnected_t *)event_data;
    ESP_LOGI(TAG, "station " MACSTR " join, AID=%d", MAC2STR(event->mac),
             event->aid);
  } else if (event_id == WIFI_EVENT_AP_STADISCONNECTED) {
    wifi_event_ap_stadisconnected_t *event =
        (wifi_event_ap_stadisconnected_t *)event_data;
    ESP_LOGI(TAG, "station " MACSTR " leave, AID=%d", MAC2STR(event->mac),
             event->aid);
  }
}

static void wifi_init_softap(void) {
  wifi_mode_t mode;
  esp_err_t err = esp_wifi_get_mode(&mode);

  if (err == ESP_ERR_WIFI_NOT_INIT) {
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
  }

  // wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
  // ESP_ERROR_CHECK(esp_wifi_init(&cfg));

  esp_netif_create_default_wifi_ap();

  ESP_ERROR_CHECK(esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID,
                                             &wifi_event_handler, NULL));

  esp_read_mac(sta_mac, ESP_MAC_WIFI_STA);
  esp_read_mac(eth_mac, ESP_MAC_ETH);

  ESP_LOGI(TAG, "ESP_MAC_WIFI_STA MAC: %02x:%02x:%02x:%02x:%02x:%02x",
           sta_mac[0], sta_mac[1], sta_mac[2], sta_mac[3], sta_mac[4],
           sta_mac[5]);
  sprintf(device_mac, "%02X%02X%02X%02X%02X%02X", sta_mac[0], sta_mac[1],
          sta_mac[2], sta_mac[3], sta_mac[4], sta_mac[5]);
  sprintf(device_mac_end, "%02X%02X", sta_mac[4], sta_mac[5]);

  // esp_read_mac(sta_mac, ESP_MAC_WIFI_STA);

  sprintf(device_sta_mac, "%02X:%02X:%02X:%02X:%02X:%02X", sta_mac[0],
          sta_mac[1], sta_mac[2], sta_mac[3], sta_mac[4], sta_mac[5]);
  sprintf(device_eth_mac, "%02X:%02X:%02X:%02X:%02X:%02X", eth_mac[0],
          eth_mac[1], eth_mac[2], eth_mac[3], eth_mac[4], eth_mac[5]);

  char ap_ssid[80] = {0};
  strcpy(ap_ssid, ESP_WIFI_SSID);
  strcat(ap_ssid, "_");
  strcat(ap_ssid, device_mac_end);

  esp_err_t ret = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
  size_t ap_name, ap_password, ap_wait_time = 0;
  ret = nvs_get_str(nvs_handle, "ap_name", NULL, &ap_name);
  nvs_get_str(nvs_handle, "ap_password", NULL, &ap_password);
  nvs_get_str(nvs_handle, "ap_wait_time", NULL, &ap_wait_time);
  switch (ret) {
  case ESP_OK:
    printf("ap_name set success");
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    printf("no ap_name set");
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "ap_name", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "ap_password", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "ap_wait_time", ""));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'ap_name': %s\n", esp_err_to_name(ret));
  } else {
    // 分配缓冲区
    char *nvs_ap_name = malloc(ap_name);
    char *nvs_ap_password = malloc(ap_password);
    char *nvs_ap_wait_time = malloc(ap_wait_time);
    if (nvs_ap_name == NULL) {
      printf("Memory allocation failed\n");
    } else {
      ret = nvs_get_str(nvs_handle, "ap_name", nvs_ap_name, &ap_name);
      nvs_get_str(nvs_handle, "ap_password", nvs_ap_password, &ap_password);
      nvs_get_str(nvs_handle, "ap_wait_time", nvs_ap_wait_time, &ap_wait_time);
      if (ret == ESP_OK) {

        if (strlen(nvs_ap_name) == 0 && strlen(nvs_ap_password) == 0) {
          wifi_config_t wifi_config = {
              .ap = {.ssid = ESP_WIFI_SSID,
                     .ssid_len = strlen(ap_ssid),
                     .password = ESP_WIFI_PASS,
                     .max_connection = MAX_STA_CONN,
                     .authmode = WIFI_AUTH_WPA_WPA2_PSK},
          };

          strcpy((char *)wifi_config.ap.ssid, ap_ssid);
          wifi_config.ap.ssid_len = strlen((char *)wifi_config.sta.ssid);

          if (strlen(ESP_WIFI_PASS) == 0) {
            wifi_config.ap.authmode = WIFI_AUTH_OPEN;
          }

          ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_APSTA));
          ESP_ERROR_CHECK(esp_wifi_set_config(ESP_IF_WIFI_AP, &wifi_config));
          ESP_ERROR_CHECK(esp_wifi_start());

          esp_netif_ip_info_t ip_info;
          esp_netif_get_ip_info(esp_netif_get_handle_from_ifkey("WIFI_AP_DEF"),
                                &ip_info);

          char ip_addr[16];
          inet_ntoa_r(ip_info.ip.addr, ip_addr, 16);
          ESP_LOGI(TAG, "Set up softAP with IP: %s", ip_addr);

          ESP_LOGI(TAG, "wifi_init_softap finished. SSID:'%s' password:'%s'",
                   ESP_WIFI_SSID, ESP_WIFI_PASS);
        } else {
          wifi_config_t wifi_config = {
              .ap = {.ssid = ESP_WIFI_SSID,
                     .ssid_len = strlen(ap_ssid),
                     .password = ESP_WIFI_PASS,
                     .max_connection = MAX_STA_CONN,
                     .authmode = WIFI_AUTH_WPA_WPA2_PSK},
          };

          strcpy((char *)wifi_config.ap.ssid, nvs_ap_name);
          strcpy((char *)wifi_config.ap.password, nvs_ap_password);
          wifi_config.ap.ssid_len = strlen((char *)wifi_config.sta.ssid);
          if (strlen(nvs_ap_password) == 0) {
            wifi_config.ap.authmode = WIFI_AUTH_OPEN;
          }

          ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_APSTA));
          ESP_ERROR_CHECK(esp_wifi_set_config(ESP_IF_WIFI_AP, &wifi_config));
          ESP_ERROR_CHECK(esp_wifi_start());

          esp_netif_ip_info_t ip_info;
          esp_netif_get_ip_info(esp_netif_get_handle_from_ifkey("WIFI_AP_DEF"),
                                &ip_info);

          char ip_addr[16];
          inet_ntoa_r(ip_info.ip.addr, ip_addr, 16);
          ESP_LOGI(TAG, "Set up softAP with IP: %s", ip_addr);

          ESP_LOGI(TAG, "wifi_init_softap finished. SSID:'%s' password:'%s'",
                   nvs_ap_name, nvs_ap_password);
        }

      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
    }
    free(nvs_ap_name);
    free(nvs_ap_password);
    free(nvs_ap_wait_time);
  }

  nvs_close(nvs_handle);
}

static esp_err_t get_devinfo_get_handler(httpd_req_t *req) {

  esp_err_t ret = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));

  size_t host_names, ntp_server, is_dhcp, netconn = 0;
  ret = nvs_get_str(nvs_handle, "host_names", NULL, &host_names);
  nvs_get_str(nvs_handle, "ntp_server", NULL, &ntp_server);
  nvs_get_str(nvs_handle, "is_dhcp", NULL, &is_dhcp);
  nvs_get_str(nvs_handle, "netconn", NULL, &netconn);
  switch (ret) {
  case ESP_OK:
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    ESP_ERROR_CHECK(
        nvs_set_str(nvs_handle, "host_names", "千瓦科技 --物小能G1"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "ntp_server", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "is_dhcp", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "netconn", ""));
    break;
  default:
    break;
  }
  ret = nvs_get_str(nvs_handle, "is_dhcp", NULL, &is_dhcp);
  switch (ret) {
  case ESP_OK:
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "is_dhcp", "1"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "netconn", "1"));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'host_names': %s\n", esp_err_to_name(ret));
  } else {
    // 分配缓冲区
    char *nvs_host_names = malloc(host_names);
    char *nvs_ntp_server = malloc(ntp_server);
    char *nvs_is_dhcp = malloc(is_dhcp);
    char *nvs_netconn = malloc(netconn);
    if (nvs_host_names == NULL) {
      printf("Memory allocation failed\n");
    } else {
      ret = nvs_get_str(nvs_handle, "host_names", nvs_host_names, &host_names);
      nvs_get_str(nvs_handle, "ntp_server", nvs_ntp_server, &ntp_server);
      nvs_get_str(nvs_handle, "is_dhcp", nvs_is_dhcp, &is_dhcp);
      nvs_get_str(nvs_handle, "netconn", nvs_netconn, &netconn);
      if (ret == ESP_OK) {

        cJSON *root = cJSON_CreateObject();
        cJSON_AddItemToObject(root, "device_sta_mac",
                              cJSON_CreateString(device_sta_mac));
        cJSON_AddItemToObject(root, "device_eth_mac",
                              cJSON_CreateString(device_eth_mac));

        cJSON_AddItemToObject(root, "netconn", cJSON_CreateString(nvs_netconn));
        // cJSON_AddItemToObject(root, "current_time",
        //                       cJSON_CreateString(strftime_buf));
        // printf("11111当前时间是: %s\n", strftime_buf);
        // printf("nvs_netconn: %s\n", nvs_netconn);
        if (atoi(nvs_netconn) == 2) {
          cJSON_AddItemToObject(root, "eth_ip", cJSON_CreateString("---"));
          cJSON_AddItemToObject(root, "sta_ip",
                                cJSON_CreateString(got_ip_addrs));
        } else {
          cJSON_AddItemToObject(root, "eth_ip",
                                cJSON_CreateString(got_ip_addrs));
          cJSON_AddItemToObject(root, "sta_ip", cJSON_CreateString("---"));
        }

        if (atoi(nvs_netconn) == 3) {
          cJSON_AddItemToObject(root, "g_ccid", cJSON_CreateString(g_ccid));
          cJSON_AddItemToObject(root, "g_cgsn", cJSON_CreateString(g_cgsn));
          cJSON_AddItemToObject(root, "g_4gip", cJSON_CreateString(g_4gip));
          if (strlen(g_4gip) > 0 && strlen(strftime_buf) > 0) {
            cJSON_AddItemToObject(root, "mqttconn", cJSON_CreateString("1"));
          } else {
            cJSON_AddItemToObject(root, "mqttconn", cJSON_CreateString("0"));
          }
        }
        cJSON_AddItemToObject(root, "is_dhcp", cJSON_CreateString(nvs_is_dhcp));
        cJSON_AddItemToObject(root, "uptime", cJSON_CreateString(strftime_buf));
        // cJSON_AddItemToObject(root,
        // "uptime", cJSON_CreateString("120"));
        cJSON_AddItemToObject(root, "host_names",
                              cJSON_CreateString(nvs_host_names));
        httpd_resp_set_hdr(req, "Connection", "close");
        httpd_resp_set_type(req, "application/json");
        // char *json_data = cJSON_Print(root);
        char *json_data = cJSON_Print(root);
        httpd_resp_send(req, json_data, strlen(json_data));

        free(json_data);
        cJSON_Delete(root);

        // get_current_time();
        // esp_netif_sntp_deinit();

      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
    }
    free(nvs_host_names);
    free(nvs_ntp_server);
    free(nvs_is_dhcp);
    free(nvs_netconn);
  }

  nvs_close(nvs_handle);

  return ESP_OK;
}

static esp_err_t get_sys_get_handler(httpd_req_t *req) {
  size_t free_heap_size_bytes = xPortGetFreeHeapSize();
  size_t min_ever_free_heap_size_bytes = xPortGetMinimumEverFreeHeapSize();
  // 将字节转换为千字节 (KB)
  float free_heap_size_kb = free_heap_size_bytes / 1024.0;
  float min_ever_free_heap_size_kb = min_ever_free_heap_size_bytes / 1024.0;
  esp_chip_info_t chip_info;
  esp_chip_info(&chip_info);
  // 获取自系统启动以来的时间（单位：微秒）
  int64_t time_since_boot = esp_timer_get_time();
  esp_reset_reason_t res_reason = esp_reset_reason();
  cJSON *root = cJSON_CreateObject();
  cJSON_AddItemToObject(root, "chip_info_cpu_core",
                        cJSON_CreateNumber(chip_info.cores));
  cJSON_AddItemToObject(root, "wifi_frq", cJSON_CreateNumber(2.4));
  cJSON_AddItemToObject(root, "free_heap_size",
                        cJSON_CreateNumber(free_heap_size_kb));
  cJSON_AddItemToObject(root, "min_ever_free_heap_size",
                        cJSON_CreateNumber(min_ever_free_heap_size_kb));
  cJSON_AddItemToObject(root, "time_since_boot",
                        cJSON_CreateNumber(time_since_boot));
  cJSON_AddItemToObject(root, "res_reason",
                        cJSON_CreateString(reset_reason_to_string(res_reason)));
  cJSON_AddItemToObject(root, "version", cJSON_CreateString(VERSION));
  char *json_data = cJSON_Print(root);
  httpd_resp_set_hdr(req, "Connection", "close");
  httpd_resp_set_type(req, "application/json");
  httpd_resp_send(req, json_data, strlen(json_data));
  free(json_data);
  // free(json_data);
  // printf("2===========================================%s\n", json_data);
  cJSON_Delete(root);
  return ESP_OK;
}

static esp_err_t root_get_handler(httpd_req_t *req) {
  const uint32_t root_len = root_end - root_start;
  // ESP_LOGI(TAG, "Serve root");
  httpd_resp_set_type(req, "text/html");
  httpd_resp_send(req, root_start, root_len);
  return ESP_OK;
}

// static esp_err_t status_post_handler(httpd_req_t *req) {
//   const uint32_t web_len = web_end - web_start;
//   httpd_resp_set_type(req, "text/html");
//   httpd_resp_send(req, web_start, web_len);
//   return ESP_OK;
// }

static esp_err_t user_dashboard_handler(httpd_req_t *req) {
  const uint32_t userweb_len = userweb_end - userweb_start;
  httpd_resp_set_type(req, "text/html");
  httpd_resp_send(req, userweb_start, userweb_len); // 返回用户页面内容
  return ESP_OK;
}

static esp_err_t admin_dashboard_handler(httpd_req_t *req) {
  const uint32_t web_len = web_end - web_start;
  httpd_resp_set_type(req, "text/html");
  httpd_resp_send(req, web_start, web_len);
  return ESP_OK;
}

// 定义dashboard页面的处理器
static esp_err_t dashboard_get_handler(httpd_req_t *req) {

  char buf[1024];
  int ret, remaining = req->content_len;

  while (remaining > 0) {
    if ((ret = httpd_req_recv(req, buf, sizeof(buf))) <= 0) {
      if (ret == HTTPD_SOCK_ERR_TIMEOUT) {
        continue;
      }
      return ESP_FAIL;
    }
    remaining -= ret;
    ESP_LOGI(TAG, "%.*s", ret, buf);
  }
  printf("%s\n", buf);
  cJSON *json = cJSON_Parse(buf);
  if (json == NULL) {
    const char *error_ptr = cJSON_GetErrorPtr();
    if (error_ptr != NULL) {
      ESP_LOGE("JSON", "Error before: %s", error_ptr);
    }
    cJSON_Delete(json);
    return 0;
  }
  cJSON *username = cJSON_GetObjectItemCaseSensitive(json, "username");
  if (cJSON_IsString(username) && (username->valuestring != NULL)) {
    ESP_LOGI("JSON", "username: %s", username->valuestring);
  }
  cJSON *password = cJSON_GetObjectItemCaseSensitive(json, "password");
  if (cJSON_IsString(password) && (password->valuestring != NULL)) {
    ESP_LOGI("JSON", "password: %s", password->valuestring);
  }

  esp_err_t rets = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));

  size_t host_names, ntp_server, lgname, lgpwd = 0;

  rets = nvs_get_str(nvs_handle, "lgname", NULL, &lgname);
  nvs_get_str(nvs_handle, "lgpwd", NULL, &lgpwd);
  nvs_get_str(nvs_handle, "host_names", NULL, &host_names);
  nvs_get_str(nvs_handle, "ntp_server", NULL, &ntp_server);

  switch (rets) {
  case ESP_OK:
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    ESP_ERROR_CHECK(
        nvs_set_str(nvs_handle, "host_names", "千瓦科技 --物小能G1"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "ntp_server", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "lgname", "wuxiaoneng"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "lgpwd", "4006303060"));
    break;
  default:
    break;
  }
  if (rets != ESP_OK) {
    printf("Error getting size of 'host_names': %s\n", esp_err_to_name(rets));
  } else {
    char *nvs_host_names = malloc(host_names);
    char *nvs_ntp_server = malloc(ntp_server);
    char *nvs_lgname = malloc(lgname);
    char *nvs_lgpwd = malloc(lgpwd);
    if (nvs_host_names == NULL) {
      printf("Memory allocation failed\n");
    } else {
      rets = nvs_get_str(nvs_handle, "host_names", nvs_host_names, &host_names);
      nvs_get_str(nvs_handle, "ntp_server", nvs_ntp_server, &ntp_server);
      nvs_get_str(nvs_handle, "lgname", nvs_lgname, &lgname);
      nvs_get_str(nvs_handle, "lgpwd", nvs_lgpwd, &lgpwd);

      if (rets == ESP_OK) {
        // printf("Value for 'host_names' is %s\n", nvs_host_names);
        // printf("Value for 'ntp_server' is %s\n", nvs_ntp_server);
        // printf("Value for 'lgname' is %s\n", nvs_lgname);
        // printf("Value for 'lgpwd' is %s\n", nvs_lgpwd);
        printf("Value for 'username->valuestring' is %s\n",
               username->valuestring);
        printf("Value for 'password->valuestring' is %s\n",
               password->valuestring);
        if (strcmp(username->valuestring, nvs_lgname) == 0 &&
            strcmp(password->valuestring, nvs_lgpwd) == 0) {
          printf("login success for regular user\n");
          httpd_resp_set_hdr(req, "Set-Cookie",
                             "session=valid; Path=/; HttpOnly");

          // 重定向到用户页面
          httpd_resp_set_status(req, "302 Found");
          httpd_resp_set_hdr(req, "Location", "/user_dashboard");
          httpd_resp_send(req, NULL, 0); // 重定向不需要发送页面内容

        } else if (strcmp(username->valuestring, "qianwa") == 0 &&
                   strcmp(password->valuestring, "Wxn6663060") == 0) {
          printf("login success for superadmin\n");
          httpd_resp_set_hdr(req, "Set-Cookie",
                             "session=valid; Path=/; HttpOnly");

          // 重定向到管理员页面
          httpd_resp_set_status(req, "302 Found");
          httpd_resp_set_hdr(req, "Location", "/admin_dashboard");
          httpd_resp_send(req, NULL, 0); // 重定向不需要发送页面内容

        } else {
          printf("login fail\n");
          httpd_resp_send(req, "fail", HTTPD_RESP_USE_STRLEN);
        }

      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(rets));
      }
      free(nvs_host_names);
      free(nvs_ntp_server);
      free(nvs_lgname);
      free(nvs_lgpwd);
    }
  }
  nvs_close(nvs_handle);
  cJSON_Delete(json);
  return ESP_OK;
}

static esp_err_t userjs_get_handler(httpd_req_t *req) {
  const uint32_t userwebjs_len = userwebjs_end - userwebjs_start;
  // ESP_LOGI(TAG, "Serve js");
  httpd_resp_set_type(req, "application/javascript");
  httpd_resp_send(req, userwebjs_start, userwebjs_len);
  return ESP_OK;
}

static esp_err_t js_get_handler(httpd_req_t *req) {
  const uint32_t js_len = js_end - js_start;
  // ESP_LOGI(TAG, "Serve js");
  httpd_resp_set_type(req, "application/javascript");
  httpd_resp_send(req, js_start, js_len);
  return ESP_OK;
}
static esp_err_t css_get_handler(httpd_req_t *req) {
  const uint32_t css_len = css_end - css_start;
  httpd_resp_set_type(req, "text/css");
  httpd_resp_send(req, css_start, css_len);
  return ESP_OK;
}

static esp_err_t post_handler(httpd_req_t *req) {
  char buf[512];
  int ret, remaining = req->content_len;
  while (remaining > 0) {
    if ((ret = httpd_req_recv(req, buf, MIN(remaining, sizeof(buf)))) <= 0) {
      if (ret == HTTPD_SOCK_ERR_TIMEOUT) {
        continue;
      }
      return ESP_FAIL;
    }
    remaining -= ret;
    ESP_LOGI(TAG, "%.*s", ret, buf);
  }
  printf("%s\n", buf);
  ESP_ERROR_CHECK(nvs_init());
  save_to_nvs(buf);
  //   save_form_data(buf);
  cJSON *root = cJSON_CreateObject();
  cJSON_AddItemToObject(root, "msg", cJSON_CreateString("success"));
  cJSON_AddItemToObject(root, "code", cJSON_CreateNumber(200));
  httpd_resp_set_hdr(req, "Connection", "close");
  httpd_resp_set_type(req, "application/json");
  char *json_data = cJSON_Print(root);
  httpd_resp_send(req, json_data, strlen(json_data));

  free(json_data);
  cJSON_Delete(root);
  return ESP_OK;
}

static esp_err_t get_mqtt_post_handler(httpd_req_t *req) {
  post_handler(req);
  return ESP_OK;
}

static esp_err_t get_net_set_post_handler(httpd_req_t *req) {
  post_handler(req);
  return ESP_OK;
}

static esp_err_t get_module_set_post_handler(httpd_req_t *req) {
  post_handler(req);
  return ESP_OK;
}

static esp_err_t get_tcp_post_handler(httpd_req_t *req) {
  post_handler(req);
  return ESP_OK;
}

static esp_err_t get_udp_post_handler(httpd_req_t *req) {
  post_handler(req);
  return ESP_OK;
}

static esp_err_t get_http_post_handler(httpd_req_t *req) {
  post_handler(req);
  return ESP_OK;
}

static esp_err_t get_ap_set_post_handler(httpd_req_t *req) {
  post_handler(req);
  return ESP_OK;
}

static esp_err_t get_update_post_handler(httpd_req_t *req) {
  char buf[1024];
  int ret, remaining = req->content_len;

  while (remaining > 0) {
    if ((ret = httpd_req_recv(req, buf, sizeof(buf))) <= 0) {
      if (ret == HTTPD_SOCK_ERR_TIMEOUT) {
        // httpd_resp_send_500(req);
        continue;
      }
      return ESP_FAIL;
    }
    remaining -= ret;
    ESP_LOGI(TAG, "%.*s", ret, buf);
  }

  printf("%s\n", buf);

  httpd_resp_send(req, "DI", HTTPD_RESP_USE_STRLEN);
  return ESP_OK;
}

static esp_err_t get_ota_post_handler(httpd_req_t *req) {
  char buf[1024];
  int ret, remaining = req->content_len;

  while (remaining > 0) {
    if ((ret = httpd_req_recv(req, buf, MIN(remaining, sizeof(buf)))) <= 0) {
      if (ret == HTTPD_SOCK_ERR_TIMEOUT) {
        continue;
      }
      return ESP_FAIL;
    }
    remaining -= ret;
    ESP_LOGI(TAG, "%.*s", ret, buf);
  }

  printf("ota post :%s\n", buf);
  cJSON *json = cJSON_Parse(buf);
  if (json == NULL) {
    const char *error_ptr = cJSON_GetErrorPtr();
    if (error_ptr != NULL) {
      fprintf(stderr, "Error before: %s\n", error_ptr);
    }
    return 1;
  }

  cJSON *ota_url = cJSON_GetObjectItemCaseSensitive(json, "ota_url");

  if (cJSON_IsString(ota_url) && (ota_url->valuestring != NULL)) {
    printf("ota_url: %s\n", ota_url->valuestring);

    cJSON *root = cJSON_CreateObject();
    cJSON_AddItemToObject(root, "msg", cJSON_CreateString("success"));
    cJSON_AddItemToObject(root, "code", cJSON_CreateNumber(200));
    httpd_resp_set_type(req, "application/json");
    char *json_data = cJSON_Print(root);
    httpd_resp_send(req, json_data, strlen(json_data));
    free(json_data);
    cJSON_Delete(root);
    simple_ota_task(ota_url->valuestring);
  }

  // 清理 cJSON 对象
  cJSON_Delete(json);

  return ESP_OK;
}

static esp_err_t get_operate_get_handler(httpd_req_t *req) {
  httpd_resp_send(req, "{\"restart\":\"success\"}", HTTPD_RESP_USE_STRLEN);
  vTaskDelay(100);
  esp_restart();
  return ESP_OK;
}

static esp_err_t get_restore_get_handler(httpd_req_t *req) {
  httpd_resp_send(req, "{\"restore\":\"success\"}", HTTPD_RESP_USE_STRLEN);
  vTaskDelay(100);
  ESP_ERROR_CHECK(nvs_flash_erase());
  vTaskDelay(100);
  esp_restart();
  return ESP_OK;
}

esp_err_t http_404_error_handler(httpd_req_t *req, httpd_err_code_t err) {
  httpd_resp_set_status(req, "302 Temporary Redirect");
  httpd_resp_set_hdr(req, "Location", "/");
  httpd_resp_send(req, "Redirect to the captive portal", HTTPD_RESP_USE_STRLEN);
  // ESP_LOGI(TAG, "Redirecting to root");
  return ESP_OK;
}

static esp_err_t get_serial_set_info_get_handler(httpd_req_t *req) {
  esp_err_t ret = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
  size_t baud_rate, data_bit, check_bit, stop_bit, frame_time, frame_len = 0;
  ret = nvs_get_str(nvs_handle, "baud_rate", NULL, &baud_rate);
  nvs_get_str(nvs_handle, "data_bit", NULL, &data_bit);
  nvs_get_str(nvs_handle, "check_bit", NULL, &check_bit);
  nvs_get_str(nvs_handle, "stop_bit", NULL, &stop_bit);
  nvs_get_str(nvs_handle, "frame_time", NULL, &frame_time);
  nvs_get_str(nvs_handle, "frame_len", NULL, &frame_len);

  // nvs_get_str(nvs_handle, "flow_ctl", NULL, &flow_ctl);
  switch (ret) {
  case ESP_OK:
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "baud_rate", "9600"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "data_bit", "8"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "check_bit", "0"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "stop_bit", "0"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "frame_time", "50"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "frame_len", "512"));
    // ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "flow_ctl", "0"));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'SERIAL': %s\n", esp_err_to_name(ret));
  } else {
    char *nvs_baud_rate = malloc(baud_rate);
    char *nvs_data_bit = malloc(data_bit);
    char *nvs_check_bit = malloc(check_bit);
    char *nvs_stop_bit = malloc(stop_bit);
    char *nvs_frame_time = malloc(frame_time);
    char *nvs_frame_len = malloc(frame_len);
    // char *nvs_flow_ctl = malloc(flow_ctl);

    if (nvs_baud_rate == NULL) {
      printf("Memory allocation failed\n");
    } else {
      ret = nvs_get_str(nvs_handle, "baud_rate", nvs_baud_rate, &baud_rate);
      nvs_get_str(nvs_handle, "data_bit", nvs_data_bit, &data_bit);
      nvs_get_str(nvs_handle, "check_bit", nvs_check_bit, &check_bit);
      nvs_get_str(nvs_handle, "stop_bit", nvs_stop_bit, &stop_bit);
      nvs_get_str(nvs_handle, "frame_time", nvs_frame_time, &frame_time);
      nvs_get_str(nvs_handle, "frame_len", nvs_frame_len, &frame_len);
      // nvs_get_str(nvs_handle, "flow_ctl", nvs_flow_ctl, &flow_ctl);
      if (ret == ESP_OK) {
        printf("Value for 'baud_rate' is %s\n", nvs_baud_rate);
        printf("Value for 'data_bit' is %s\n", nvs_data_bit);
        printf("Value for 'check_bit' is %s\n", nvs_check_bit);
        printf("Value for 'stop_bit' is %s\n", nvs_stop_bit);
        printf("Value for 'frame_time' is %s\n", nvs_frame_time);
        printf("Value for 'frame_len' is %s\n", nvs_frame_len);
        // printf("Value for 'flow_ctl' is %s\n", nvs_flow_ctl);
        cJSON *root = cJSON_CreateObject();
        cJSON_AddItemToObject(root, "baud_rate",
                              cJSON_CreateString(nvs_baud_rate));
        cJSON_AddItemToObject(root, "data_bit",
                              cJSON_CreateString(nvs_data_bit));
        cJSON_AddItemToObject(root, "check_bit",
                              cJSON_CreateString(nvs_check_bit));
        cJSON_AddItemToObject(root, "stop_bit",
                              cJSON_CreateString(nvs_stop_bit));
        cJSON_AddItemToObject(root, "frame_time",
                              cJSON_CreateString(nvs_frame_time));
        cJSON_AddItemToObject(root, "frame_len",
                              cJSON_CreateString(nvs_frame_len));
        // cJSON_AddItemToObject(root, "flow_ctl",
        //                       cJSON_CreateString(nvs_flow_ctl));
        httpd_resp_set_hdr(req, "Connection", "close");
        httpd_resp_set_type(req, "application/json");
        char *json_data = cJSON_Print(root);
        httpd_resp_send(req, json_data, strlen(json_data));
        free(json_data);
        cJSON_Delete(root);
      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_baud_rate);
      free(nvs_data_bit);
      free(nvs_check_bit);
      free(nvs_stop_bit);
      free(nvs_frame_time);
      free(nvs_frame_len);
      // free(nvs_flow_ctl);
    }
  }
  nvs_close(nvs_handle);
  return ESP_OK;
}

static esp_err_t get_mqtt_info_get_handler(httpd_req_t *req) {
  esp_err_t ret = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));

  // 读取字符串
  // 首先获取所需的缓冲区大小
  size_t use_mqtt, mqtt_type, mqtt_server, mqtt_port, mqtt_username,
      mqtt_password, mqtt_clientid, mqtt_sub_topic, mqtt_pub_topic, qos, retain,
      mqtt_send, mqtt_time, mqttconn = 0;
  ret = nvs_get_str(nvs_handle, "use_mqtt", NULL, &use_mqtt);
  nvs_get_str(nvs_handle, "mqtt_type", NULL, &mqtt_type);
  nvs_get_str(nvs_handle, "mqtt_server", NULL, &mqtt_server);
  nvs_get_str(nvs_handle, "mqtt_port", NULL, &mqtt_port);
  nvs_get_str(nvs_handle, "mqtt_username", NULL, &mqtt_username);
  nvs_get_str(nvs_handle, "mqtt_password", NULL, &mqtt_password);
  nvs_get_str(nvs_handle, "mqtt_clientid", NULL, &mqtt_clientid);
  nvs_get_str(nvs_handle, "mqtt_sub_topic", NULL, &mqtt_sub_topic);
  nvs_get_str(nvs_handle, "mqtt_pub_topic", NULL, &mqtt_pub_topic);
  nvs_get_str(nvs_handle, "qos", NULL, &qos);
  nvs_get_str(nvs_handle, "retain", NULL, &retain);
  nvs_get_str(nvs_handle, "mqtt_send", NULL, &mqtt_send);
  nvs_get_str(nvs_handle, "mqtt_time", NULL, &mqtt_time);
  nvs_get_str(nvs_handle, "mqttconn", NULL, &mqttconn);
  switch (ret) {
  case ESP_OK:
    printf("MQTT set success");
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    printf("no MQTT set");
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "use_mqtt", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_type", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_server", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_port", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_username", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_password", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_clientid", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_sub_topic", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_pub_topic", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "qos", "2"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "retain", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_send", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_time", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqttconn", ""));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'MQTT': %s\n", esp_err_to_name(ret));
  } else {
    // 分配缓冲区
    char *nvs_use_mqtt = malloc(use_mqtt);
    char *nvs_mqtt_type = malloc(mqtt_type);
    char *nvs_mqtt_server = malloc(mqtt_server);
    char *nvs_mqtt_port = malloc(mqtt_port);
    char *nvs_mqtt_username = malloc(mqtt_username);
    char *nvs_mqtt_password = malloc(mqtt_password);
    char *nvs_mqtt_clientid = malloc(mqtt_clientid);
    char *nvs_mqtt_sub_topic = malloc(mqtt_sub_topic);
    char *nvs_mqtt_pub_topic = malloc(mqtt_pub_topic);
    char *nvs_qos = malloc(qos);
    char *nvs_retain = malloc(retain);
    char *nvs_mqtt_send = malloc(mqtt_send);
    char *nvs_mqtt_time = malloc(mqtt_time);
    char *nvs_mqttconn = malloc(mqttconn);
    if (nvs_mqtt_server == NULL) {
      printf("Memory allocation failed\n");
    } else {
      // 读取字符串到分配的缓冲区
      ret = nvs_get_str(nvs_handle, "use_mqtt", nvs_use_mqtt, &use_mqtt);
      nvs_get_str(nvs_handle, "mqtt_type", nvs_mqtt_type, &mqtt_type);
      nvs_get_str(nvs_handle, "mqtt_server", nvs_mqtt_server, &mqtt_server);
      nvs_get_str(nvs_handle, "mqtt_port", nvs_mqtt_port, &mqtt_port);
      nvs_get_str(nvs_handle, "mqtt_username", nvs_mqtt_username,
                  &mqtt_username);
      nvs_get_str(nvs_handle, "mqtt_password", nvs_mqtt_password,
                  &mqtt_password);
      nvs_get_str(nvs_handle, "mqtt_clientid", nvs_mqtt_clientid,
                  &mqtt_clientid);
      nvs_get_str(nvs_handle, "mqtt_sub_topic", nvs_mqtt_sub_topic,
                  &mqtt_sub_topic);
      nvs_get_str(nvs_handle, "mqtt_pub_topic", nvs_mqtt_pub_topic,
                  &mqtt_pub_topic);
      nvs_get_str(nvs_handle, "qos", nvs_qos, &qos);
      nvs_get_str(nvs_handle, "retain", nvs_retain, &retain);
      nvs_get_str(nvs_handle, "mqtt_send", nvs_mqtt_send, &mqtt_send);
      nvs_get_str(nvs_handle, "mqtt_time", nvs_mqtt_time, &mqtt_time);

      nvs_get_str(nvs_handle, "mqttconn", nvs_mqttconn, &mqttconn);
      if (ret == ESP_OK) {
        cJSON *root = cJSON_CreateObject();
        cJSON_AddItemToObject(root, "use_mqtt",
                              cJSON_CreateString(nvs_use_mqtt));
        cJSON_AddItemToObject(root, "mqtt_type",
                              cJSON_CreateString(nvs_mqtt_type));
        cJSON_AddItemToObject(root, "mqtt_server",
                              cJSON_CreateString(nvs_mqtt_server));
        cJSON_AddItemToObject(root, "mqtt_port",
                              cJSON_CreateString(nvs_mqtt_port));
        cJSON_AddItemToObject(root, "mqtt_username",
                              cJSON_CreateString(nvs_mqtt_username));
        cJSON_AddItemToObject(root, "mqtt_password",
                              cJSON_CreateString(nvs_mqtt_password));
        cJSON_AddItemToObject(root, "mqtt_clientid",
                              cJSON_CreateString(nvs_mqtt_clientid));
        cJSON_AddItemToObject(root, "mqtt_sub_topic",
                              cJSON_CreateString(nvs_mqtt_sub_topic));
        cJSON_AddItemToObject(root, "mqtt_pub_topic",
                              cJSON_CreateString(nvs_mqtt_pub_topic));
        cJSON_AddItemToObject(root, "qos", cJSON_CreateString(nvs_qos));
        cJSON_AddItemToObject(root, "retain", cJSON_CreateString(nvs_retain));
        cJSON_AddItemToObject(root, "mqtt_send",
                              cJSON_CreateString(nvs_mqtt_send));
        cJSON_AddItemToObject(root, "mqtt_time",
                              cJSON_CreateString(nvs_mqtt_time));
        cJSON_AddItemToObject(root, "mqttconn",
                              cJSON_CreateString(nvs_mqttconn));
        httpd_resp_set_hdr(req, "Connection", "close");
        httpd_resp_set_type(req, "application/json");
        char *json_data = cJSON_Print(root);
        httpd_resp_send(req, json_data, strlen(json_data));

        free(json_data);
        cJSON_Delete(root);

      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_use_mqtt);
      free(nvs_mqtt_type);
      free(nvs_mqtt_server);
      free(nvs_mqtt_port);
      free(nvs_mqtt_username);
      free(nvs_mqtt_password);
      free(nvs_mqtt_clientid);
      free(nvs_mqtt_sub_topic);
      free(nvs_mqtt_pub_topic);
      free(nvs_qos);
      free(nvs_retain);
      free(nvs_mqtt_send);
      free(nvs_mqtt_time);
      free(nvs_mqttconn);
    }
  }

  nvs_close(nvs_handle);

  return ESP_OK;
}

static esp_err_t get_tcp_info_get_handler(httpd_req_t *req) {
  esp_err_t ret = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
  size_t use_tcp, tcpconn, tcp_server, tcp_port = 0;
  ret = nvs_get_str(nvs_handle, "use_tcp", NULL, &use_tcp);
  nvs_get_str(nvs_handle, "tcpconn", NULL, &tcpconn);
  nvs_get_str(nvs_handle, "tcp_server", NULL, &tcp_server);
  nvs_get_str(nvs_handle, "tcp_port", NULL, &tcp_port);
  switch (ret) {
  case ESP_OK:
    printf("TCP set success");
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    printf("no TCP set");
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "use_tcp", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "tcpconn", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "tcp_server", "192.168.1.100"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "tcp_port", "8888"));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'my_key': %s\n", esp_err_to_name(ret));
  } else {
    char *nvs_use_tcp = malloc(use_tcp);
    char *nvs_tcpconn = malloc(tcpconn);
    char *nvs_tcp_server = malloc(tcp_server);
    char *nvs_tcp_port = malloc(tcp_port);

    if (nvs_tcp_port == NULL) {
      printf("Memory allocation failed\n");
    } else {
      ret = nvs_get_str(nvs_handle, "use_tcp", nvs_use_tcp, &use_tcp);
      nvs_get_str(nvs_handle, "tcpconn", nvs_tcpconn, &tcpconn);
      nvs_get_str(nvs_handle, "tcp_server", nvs_tcp_server, &tcp_server);
      nvs_get_str(nvs_handle, "tcp_port", nvs_tcp_port, &tcp_port);
      if (ret == ESP_OK) {
        cJSON *root = cJSON_CreateObject();
        cJSON_AddItemToObject(root, "use_tcp", cJSON_CreateString(nvs_use_tcp));
        cJSON_AddItemToObject(root, "tcpconn", cJSON_CreateString(nvs_tcpconn));
        cJSON_AddItemToObject(root, "tcp_server",
                              cJSON_CreateString(nvs_tcp_server));
        cJSON_AddItemToObject(root, "tcp_port",
                              cJSON_CreateString(nvs_tcp_port));
        cJSON_AddItemToObject(root, "tcp_client_count",
                              cJSON_CreateNumber(tcp_client_count));
        cJSON_AddItemToObject(root, "tcp_server_conn",
                              cJSON_CreateNumber(global_tcp_server));
        httpd_resp_set_hdr(req, "Connection", "close");
        httpd_resp_set_type(req, "application/json");
        char *json_data = cJSON_Print(root);
        httpd_resp_send(req, json_data, strlen(json_data));
        free(json_data);
        cJSON_Delete(root);
      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_use_tcp);
      free(nvs_tcpconn);
      free(nvs_tcp_server);
      free(nvs_tcp_port);
    }
  }
  nvs_close(nvs_handle);
  return ESP_OK;
}

static esp_err_t get_udp_info_get_handler(httpd_req_t *req) {
  esp_err_t ret = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
  size_t use_udp, udpconn, udp_server, udp_port = 0;
  ret = nvs_get_str(nvs_handle, "use_udp", NULL, &use_udp);
  nvs_get_str(nvs_handle, "udpconn", NULL, &udpconn);
  nvs_get_str(nvs_handle, "udp_server", NULL, &udp_server);
  nvs_get_str(nvs_handle, "udp_port", NULL, &udp_port);
  switch (ret) {
  case ESP_OK:
    printf("UDP set success");
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    printf("no UDP set");
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "use_udp", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "udpconn", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "udp_server", "192.168.1.100"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "udp_port", "34210"));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'UDP': %s\n", esp_err_to_name(ret));
  } else {
    char *nvs_use_udp = malloc(use_udp);
    char *nvs_udpconn = malloc(udpconn);
    char *nvs_udp_server = malloc(udp_server);
    char *nvs_udp_port = malloc(udp_port);

    if (nvs_udp_port == NULL) {
      printf("Memory allocation failed\n");
    } else {
      ret = nvs_get_str(nvs_handle, "use_udp", nvs_use_udp, &use_udp);
      nvs_get_str(nvs_handle, "udpconn", nvs_udpconn, &udpconn);
      nvs_get_str(nvs_handle, "udp_server", nvs_udp_server, &udp_server);
      nvs_get_str(nvs_handle, "udp_port", nvs_udp_port, &udp_port);
      if (ret == ESP_OK) {
        printf("Value for 'use_udp' is %s\n", nvs_use_udp);
        printf("Value for 'udpconn' is %s\n", nvs_udpconn);
        printf("Value for 'udp_server' is %s\n", nvs_udp_server);
        printf("Value for 'udp_port' is %s\n", nvs_udp_port);
        cJSON *root = cJSON_CreateObject();
        cJSON_AddItemToObject(root, "use_udp", cJSON_CreateString(nvs_use_udp));
        cJSON_AddItemToObject(root, "udpconn", cJSON_CreateString(nvs_udpconn));
        cJSON_AddItemToObject(root, "udp_server",
                              cJSON_CreateString(nvs_udp_server));
        cJSON_AddItemToObject(root, "udp_port",
                              cJSON_CreateString(nvs_udp_port));
        httpd_resp_set_hdr(req, "Connection", "close");
        httpd_resp_set_type(req, "application/json");
        char *json_data = cJSON_Print(root);
        httpd_resp_send(req, json_data, strlen(json_data));
        free(json_data);
        cJSON_Delete(root);
      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_use_udp);
      free(nvs_udpconn);
      free(nvs_udp_server);
      free(nvs_udp_port);
    }
  }
  nvs_close(nvs_handle);
  return ESP_OK;
}

static esp_err_t get_http_info_get_handler(httpd_req_t *req) {
  esp_err_t ret = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
  size_t use_http, http_port, httpconn, http_url, http_header, http_time = 0;
  ret = nvs_get_str(nvs_handle, "use_http", NULL, &use_http);
  nvs_get_str(nvs_handle, "http_port", NULL, &http_port);
  nvs_get_str(nvs_handle, "httpconn", NULL, &httpconn);
  nvs_get_str(nvs_handle, "http_url", NULL, &http_url);
  nvs_get_str(nvs_handle, "http_header", NULL, &http_header);
  nvs_get_str(nvs_handle, "http_time", NULL, &http_time);
  switch (ret) {
  case ESP_OK:
    printf("HTTP set success");
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "use_http", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "http_port", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "httpconn", ""));
    ESP_ERROR_CHECK(
        nvs_set_str(nvs_handle, "http_url", "http://demo.sxiot.com"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "http_header", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "http_time", "5"));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'HTTP': %s\n", esp_err_to_name(ret));
  } else {
    char *nvs_use_http = malloc(use_http);
    char *nvs_http_port = malloc(http_port);
    char *nvs_httpconn = malloc(httpconn);
    char *nvs_http_url = malloc(http_url);
    char *nvs_http_header = malloc(http_header);
    char *nvs_http_time = malloc(http_time);

    if (nvs_use_http == NULL) {
      printf("Memory allocation failed\n");
    } else {
      ret = nvs_get_str(nvs_handle, "use_http", nvs_use_http, &use_http);
      nvs_get_str(nvs_handle, "http_port", nvs_http_port, &http_port);
      nvs_get_str(nvs_handle, "httpconn", nvs_httpconn, &httpconn);
      nvs_get_str(nvs_handle, "http_url", nvs_http_url, &http_url);
      nvs_get_str(nvs_handle, "http_header", nvs_http_header, &http_header);
      nvs_get_str(nvs_handle, "http_time", nvs_http_time, &http_time);

      if (ret == ESP_OK) {
        printf("Value for 'use_http' is %s\n", nvs_use_http);
        printf("Value for 'http_port' is %s\n", nvs_http_port);
        printf("Value for 'httpconn' is %s\n", nvs_httpconn);
        printf("Value for 'http_url' is %s\n", nvs_http_url);
        printf("Value for 'http_header' is %s\n", nvs_http_header);
        printf("Value for 'http_time' is %s\n", nvs_http_time);
        cJSON *root = cJSON_CreateObject();
        cJSON_AddItemToObject(root, "use_http",
                              cJSON_CreateString(nvs_use_http));
        cJSON_AddItemToObject(root, "http_port",
                              cJSON_CreateString(nvs_http_port));
        cJSON_AddItemToObject(root, "httpconn",
                              cJSON_CreateString(nvs_httpconn));
        cJSON_AddItemToObject(root, "http_url",
                              cJSON_CreateString(nvs_http_url));
        cJSON_AddItemToObject(root, "http_header",
                              cJSON_CreateString(nvs_http_header));
        cJSON_AddItemToObject(root, "http_time",
                              cJSON_CreateString(nvs_http_time));
        httpd_resp_set_hdr(req, "Connection", "close");
        httpd_resp_set_type(req, "application/json");
        char *json_data = cJSON_Print(root);
        httpd_resp_send(req, json_data, strlen(json_data));
        free(json_data);
        cJSON_Delete(root);
      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_use_http);
      free(nvs_http_port);
      free(nvs_httpconn);
      free(nvs_http_url);
      free(nvs_http_header);
      free(nvs_http_time);
    }
  }
  nvs_close(nvs_handle);
  return ESP_OK;
}

static esp_err_t get_find_wifi_get_handler(httpd_req_t *req) {

  WifiValueList data = wifiSearchValue();
  ESP_LOGI(TAG, "Total APs scanned = %u", data.ap_count);
  cJSON *root = cJSON_CreateObject();
  //   cJSON *wifiArray = cJSON_CreateArray();
  for (int i = 0; (i < DEFAULT_SCAN_LIST_SIZE) && (i < data.ap_count); i++) {
    ESP_LOGI(TAG, "SSID \t\t%s", data.ap_info[i].ssid);
    ESP_LOGI(TAG, "RSSI \t\t%d", data.ap_info[i].rssi);
    ESP_LOGI(TAG, "Channel \t\t%d\n", data.ap_info[i].primary);
    // cJSON_AddStringToObject(root, "ssid", );
    cJSON_AddNumberToObject(root, (char *)data.ap_info[i].ssid,
                            data.ap_info[i].rssi);
  }
  httpd_resp_set_hdr(req, "Connection", "close");
  httpd_resp_set_type(req, "application/json");
  char *json_data = cJSON_Print(root);
  httpd_resp_send(req, json_data, strlen(json_data));
  free(json_data);
  cJSON_Delete(root);

  return ESP_OK;
}

static esp_err_t get_exit_ap_get_handler(httpd_req_t *req) {
  httpd_resp_send(req, "EXIT AP", HTTPD_RESP_USE_STRLEN);
  vTaskDelay(500);
  ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
  return ESP_OK;
}

static esp_err_t get_net_set_info_get_handler(httpd_req_t *req) {

  esp_err_t ret = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));

  // 读取字符串
  // 首先获取所需的缓冲区大小
  size_t netconn, is_dhcp, static_ip, static_netmask, static_gateway,
      static_dns1, static_dns2, wifi_ssid, wifi_password = 0;
  ret = nvs_get_str(nvs_handle, "netconn", NULL, &netconn);
  nvs_get_str(nvs_handle, "is_dhcp", NULL, &is_dhcp);
  nvs_get_str(nvs_handle, "static_ip", NULL, &static_ip);
  nvs_get_str(nvs_handle, "static_netmask", NULL, &static_netmask);
  nvs_get_str(nvs_handle, "static_gateway", NULL, &static_gateway);
  nvs_get_str(nvs_handle, "static_dns1", NULL, &static_dns1);
  nvs_get_str(nvs_handle, "static_dns2", NULL, &static_dns2);
  nvs_get_str(nvs_handle, "wifi_ssid", NULL, &wifi_ssid);
  nvs_get_str(nvs_handle, "wifi_password", NULL, &wifi_password);
  switch (ret) {
  case ESP_OK:
    // printf("NET set success");
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    printf("no NET set");
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "netconn", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "is_dhcp", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "static_ip", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "static_netmask", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "static_gateway", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "static_dns1", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "static_dns2", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "wifi_ssid", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "wifi_password", ""));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'my_key': %s\n", esp_err_to_name(ret));
  } else {
    // 分配缓冲区
    char *nvs_netconn = malloc(netconn);
    char *nvs_is_dhcp = malloc(is_dhcp);
    char *nvs_static_ip = malloc(static_ip);
    char *nvs_static_netmask = malloc(static_netmask);
    char *nvs_static_gateway = malloc(static_gateway);
    char *nvs_static_dns1 = malloc(static_dns1);
    char *nvs_static_dns2 = malloc(static_dns2);
    char *nvs_wifi_ssid = malloc(wifi_ssid);
    char *nvs_wifi_password = malloc(wifi_password);
    if (nvs_netconn == NULL) {
      printf("Memory allocation failed\n");
    } else {
      // 读取字符串到分配的缓冲区
      ret = nvs_get_str(nvs_handle, "netconn", nvs_netconn, &netconn);
      nvs_get_str(nvs_handle, "is_dhcp", nvs_is_dhcp, &is_dhcp);
      nvs_get_str(nvs_handle, "static_ip", nvs_static_ip, &static_ip);
      nvs_get_str(nvs_handle, "static_netmask", nvs_static_netmask,
                  &static_netmask);
      nvs_get_str(nvs_handle, "static_gateway", nvs_static_gateway,
                  &static_gateway);
      nvs_get_str(nvs_handle, "static_dns1", nvs_static_dns1, &static_dns1);
      nvs_get_str(nvs_handle, "static_dns2", nvs_static_dns2, &static_dns2);
      nvs_get_str(nvs_handle, "wifi_ssid", nvs_wifi_ssid, &wifi_ssid);
      nvs_get_str(nvs_handle, "wifi_password", nvs_wifi_password,
                  &wifi_password);

      if (ret == ESP_OK) {
        cJSON *root = cJSON_CreateObject();
        cJSON_AddItemToObject(root, "netconn", cJSON_CreateString(nvs_netconn));
        cJSON_AddItemToObject(root, "is_dhcp", cJSON_CreateString(nvs_is_dhcp));
        cJSON_AddItemToObject(root, "static_ip",
                              cJSON_CreateString(nvs_static_ip));
        cJSON_AddItemToObject(root, "static_netmask",
                              cJSON_CreateString(nvs_static_netmask));
        cJSON_AddItemToObject(root, "static_gateway",
                              cJSON_CreateString(nvs_static_gateway));
        cJSON_AddItemToObject(root, "static_dns1",
                              cJSON_CreateString(nvs_static_dns1));
        cJSON_AddItemToObject(root, "static_dns2",
                              cJSON_CreateString(nvs_static_dns2));
        cJSON_AddItemToObject(root, "wifi_ssid",
                              cJSON_CreateString(nvs_wifi_ssid));
        cJSON_AddItemToObject(root, "wifi_password",
                              cJSON_CreateString(nvs_wifi_password));
        httpd_resp_set_hdr(req, "Connection", "close");
        httpd_resp_set_type(req, "application/json");
        char *json_data = cJSON_Print(root);
        httpd_resp_send(req, json_data, strlen(json_data));

        free(json_data);
        cJSON_Delete(root);

      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_netconn);
      free(nvs_is_dhcp);
      free(nvs_static_ip);
      free(nvs_static_netmask);
      free(nvs_static_gateway);
      free(nvs_static_dns1);
      free(nvs_static_dns2);
      free(nvs_wifi_ssid);
      free(nvs_wifi_password);
    }
  }

  nvs_close(nvs_handle);

  return ESP_OK;
}

static esp_err_t get_module_set_info_get_handler(httpd_req_t *req) {

  esp_err_t ret = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));

  size_t host_names, ntp_server, lgname, lgpwd = 0;

  ret = nvs_get_str(nvs_handle, "lgname", NULL, &lgname);
  nvs_get_str(nvs_handle, "lgpwd", NULL, &lgpwd);
  nvs_get_str(nvs_handle, "host_names", NULL, &host_names);
  nvs_get_str(nvs_handle, "ntp_server", NULL, &ntp_server);

  switch (ret) {
  case ESP_OK:
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    ESP_ERROR_CHECK(
        nvs_set_str(nvs_handle, "host_names", "千瓦科技 --物小能G1"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "ntp_server", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "lgname", "wuxiaoneng"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "lgpwd", "4006303060"));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'host_names': %s\n", esp_err_to_name(ret));
  } else {
    char *nvs_host_names = malloc(host_names);
    char *nvs_ntp_server = malloc(ntp_server);
    char *nvs_lgname = malloc(lgname);
    char *nvs_lgpwd = malloc(lgpwd);
    if (nvs_host_names == NULL) {
      printf("Memory allocation failed\n");
    } else {
      ret = nvs_get_str(nvs_handle, "host_names", nvs_host_names, &host_names);
      nvs_get_str(nvs_handle, "ntp_server", nvs_ntp_server, &ntp_server);
      nvs_get_str(nvs_handle, "lgname", nvs_lgname, &lgname);
      nvs_get_str(nvs_handle, "lgpwd", nvs_lgpwd, &lgpwd);

      if (ret == ESP_OK) {
        cJSON *root = cJSON_CreateObject();
        cJSON_AddItemToObject(root, "host_names",
                              cJSON_CreateString(nvs_host_names));
        cJSON_AddItemToObject(root, "ntp_server",
                              cJSON_CreateString(nvs_ntp_server));
        cJSON_AddItemToObject(root, "lgname", cJSON_CreateString(nvs_lgname));
        cJSON_AddItemToObject(root, "lgpwd", cJSON_CreateString(nvs_lgpwd));
        httpd_resp_set_hdr(req, "Connection", "close");
        httpd_resp_set_type(req, "application/json");
        char *json_data = cJSON_Print(root);
        httpd_resp_send(req, json_data, strlen(json_data));

        free(json_data);
        cJSON_Delete(root);

      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_host_names);
      free(nvs_ntp_server);
      free(nvs_lgname);
      free(nvs_lgpwd);
    }
  }

  nvs_close(nvs_handle);

  return ESP_OK;
}

static esp_err_t get_ap_set_info_get_handler(httpd_req_t *req) {

  esp_err_t ret = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
  size_t ap_name, ap_password, ap_wait_time = 0;
  ret = nvs_get_str(nvs_handle, "ap_name", NULL, &ap_name);
  nvs_get_str(nvs_handle, "ap_password", NULL, &ap_password);
  nvs_get_str(nvs_handle, "ap_wait_time", NULL, &ap_wait_time);
  switch (ret) {
  case ESP_OK:
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "ap_name", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "ap_password", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "ap_wait_time", ""));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'ap_name': %s\n", esp_err_to_name(ret));
  } else {
    // 分配缓冲区
    char *nvs_ap_name = malloc(ap_name);
    char *nvs_ap_password = malloc(ap_password);
    char *nvs_ap_wait_time = malloc(ap_wait_time);
    if (nvs_ap_name == NULL) {
      printf("Memory allocation failed\n");
    } else {
      ret = nvs_get_str(nvs_handle, "ap_name", nvs_ap_name, &ap_name);
      nvs_get_str(nvs_handle, "ap_password", nvs_ap_password, &ap_password);
      nvs_get_str(nvs_handle, "ap_wait_time", nvs_ap_wait_time, &ap_wait_time);
      if (ret == ESP_OK) {
        cJSON *root = cJSON_CreateObject();
        cJSON_AddItemToObject(root, "ap_name", cJSON_CreateString(nvs_ap_name));
        cJSON_AddItemToObject(root, "ap_password",
                              cJSON_CreateString(nvs_ap_password));
        cJSON_AddItemToObject(root, "ap_wait_time",
                              cJSON_CreateString(nvs_ap_wait_time));
        httpd_resp_set_hdr(req, "Connection", "close");
        httpd_resp_set_type(req, "application/json");
        char *json_data = cJSON_Print(root);
        httpd_resp_send(req, json_data, strlen(json_data));
        free(json_data);
        cJSON_Delete(root);
      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_ap_name);
      free(nvs_ap_password);
      free(nvs_ap_wait_time);
    }
  }

  nvs_close(nvs_handle);
  return ESP_OK;
}

// WebSocket消息发送任务
static void ws_send_task(void *pvParameters) {
  char msg_buffer[WS_MAX_MSG_LEN];
  httpd_ws_frame_t ws_pkt = {
      .type = HTTPD_WS_TYPE_TEXT, .payload = (uint8_t *)msg_buffer, .len = 0};

  while (1) {
    if (xQueueReceive(ws_msg_queue, msg_buffer, portMAX_DELAY)) {
      ws_pkt.len = strlen(msg_buffer);

      // 遍历所有客户端发送消息
      for (int i = 0; i < MAX_WS_CLIENTS; i++) {
        if (ws_clients[i].in_use) {
          esp_err_t ret = httpd_ws_send_frame_async(
              http_server, ws_clients[i].client_fd, &ws_pkt);
          if (ret != ESP_OK) {
            ESP_LOGW(TAG, "Failed to send WS message to client %d: %d", i, ret);
            // 如果发送失败，移除客户端
            ws_clients[i].in_use = false;
          }
        }
      }
    }
    // 添加小延时避免过度消耗CPU
    vTaskDelay(pdMS_TO_TICKS(10));
  }
}

// 初始化WebSocket系统
static void init_websocket(void) {
  // 创建消息队列
  ws_msg_queue = xQueueCreate(WS_QUEUE_SIZE, WS_MAX_MSG_LEN);
  if (ws_msg_queue == NULL) {
    ESP_LOGE(TAG, "Failed to create WS message queue");
    return;
  }

  // 创建WebSocket发送任务
  BaseType_t ret = xTaskCreate(ws_send_task, "ws_send_task",
                               4096, // 增加栈大小
                               NULL,
                               5, // 较高优先级
                               &ws_task_handle);
  if (ret != pdPASS) {
    ESP_LOGE(TAG, "Failed to create WS task");
    vQueueDelete(ws_msg_queue);
    ws_msg_queue = NULL;
  }
}

// WebSocket处理函数
static esp_err_t ws_handler(httpd_req_t *req) {
  if (req->method == HTTP_GET) {
    // 查找可用的客户端槽位
    int client_slot = -1;
    for (int i = 0; i < MAX_WS_CLIENTS; i++) {
      if (!ws_clients[i].in_use) {
        client_slot = i;
        break;
      }
    }

    if (client_slot >= 0) {
      ws_clients[client_slot].client_fd = httpd_req_to_sockfd(req);
      ws_clients[client_slot].in_use = true;
      // ESP_LOGI(TAG, "New WS client connected, slot: %d", client_slot);
    } else {
      // ESP_LOGW(TAG, "No free WS client slots");
      return ESP_FAIL;
    }
    return ESP_OK;
  }

  return ESP_OK;
}

// 发送日志到WebSocket的函数
void send_log_to_websocket(const char *log_msg) {
  if (!ws_msg_queue) {
    return;
  }

  // 创建临时缓冲区并复制消息
  char buffer[WS_MAX_MSG_LEN];
  strncpy(buffer, log_msg, WS_MAX_MSG_LEN - 1);
  buffer[WS_MAX_MSG_LEN - 1] = '\0';

  // 使用超时时间发送到队列
  if (xQueueSend(ws_msg_queue, buffer, pdMS_TO_TICKS(100)) != pdPASS) {
    ESP_LOGW(TAG, "WS message queue full");
  }
}

static esp_err_t get_log_handler(httpd_req_t *req) {
  esp_err_t ret = ESP_OK;
  char *log_content = NULL;
  char *json_data = NULL;

  // 创建JSON根对象
  cJSON *root = cJSON_CreateObject();
  if (!root) {
    ESP_LOGE(TAG, "Failed to create JSON object");
    return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR,
                               "Failed to create JSON object");
  }

  // 根据URL参数决定返回哪种日志
  char param[32] = {0};
  if (httpd_req_get_url_query_str(req, param, sizeof(param)) == ESP_OK) {
    char type[8] = {0};
    if (httpd_query_key_value(param, "type", type, sizeof(type)) == ESP_OK) {
      if (strcmp(type, "simple") == 0) {
        log_content = sx_log_get_simple_buffer();
        ESP_LOGI(TAG, "Getting simple log buffer");
      } else {
        log_content = sx_log_get_buffer();
        ESP_LOGI(TAG, "Getting full log buffer");
      }
    }
  } else {
    // 默认返回详细日志
    log_content = sx_log_get_buffer();
    ESP_LOGI(TAG, "Getting default full log buffer");
  }

  // 添加日志内容到JSON对象
  if (log_content != NULL) {
    if (!cJSON_AddStringToObject(root, "content", log_content)) {
      ESP_LOGE(TAG, "Failed to add log content to JSON");
      ret = ESP_FAIL;
      goto cleanup;
    }
    free(log_content);
    log_content = NULL;
  } else {
    if (!cJSON_AddStringToObject(root, "content", "暂无日志")) {
      ESP_LOGE(TAG, "Failed to add empty log message to JSON");
      ret = ESP_FAIL;
      goto cleanup;
    }
  }

  // 生成JSON字符串
  json_data = cJSON_Print(root);
  if (!json_data) {
    ESP_LOGE(TAG, "Failed to generate JSON string");
    ret = ESP_FAIL;
    goto cleanup;
  }

  // 设置响应类型和发送响应
  httpd_resp_set_type(req, "application/json");
  ret = httpd_resp_send(req, json_data, strlen(json_data));
  if (ret != ESP_OK) {
    ESP_LOGE(TAG, "Failed to send HTTP response: %d", ret);
  }

cleanup:
  // 清理资源
  if (log_content) {
    free(log_content);
  }
  if (json_data) {
    free(json_data);
  }
  if (root) {
    cJSON_Delete(root);
  }

  return ret;
}

static esp_err_t clear_log_handler(httpd_req_t *req) {
  sx_log_clear();

  cJSON *root = cJSON_CreateObject();
  cJSON_AddNumberToObject(root, "code", 200);

  char *json_data = cJSON_Print(root);
  httpd_resp_set_type(req, "application/json");
  httpd_resp_send(req, json_data, strlen(json_data));

  free(json_data);
  cJSON_Delete(root);
  return ESP_OK;
}

// 获取targets信息的处理器
static esp_err_t get_targets_handler(httpd_req_t *req) {
  // 设置响应头
  httpd_resp_set_hdr(req, "Connection", "close");
  httpd_resp_set_type(req, "application/json");

  // 从 NVS 加载配置以获取全局 targets
  cJSON *saved_config = load_config_from_nvs();
  if (!saved_config) {
    // 如果无法加载配置，至少返回uart
    cJSON *root = cJSON_CreateObject();
    cJSON *targets = cJSON_CreateArray();
    cJSON *uart_target = cJSON_CreateObject();
    cJSON_AddStringToObject(uart_target, "name", "uart");
    cJSON_AddItemToArray(targets, uart_target);
    cJSON_AddItemToObject(root, "targets", targets);

    char *json_data = cJSON_Print(root);
    httpd_resp_send(req, json_data, strlen(json_data));
    free(json_data);
    cJSON_Delete(root);
    return ESP_OK;
  }

  // 创建响应 JSON
  cJSON *root = cJSON_CreateObject();
  cJSON *targets = cJSON_CreateArray();

  // 添加串口 target
  cJSON *uart_target = cJSON_CreateObject();
  cJSON_AddStringToObject(uart_target, "name", "uart");
  cJSON_AddItemToArray(targets, uart_target);

  // 获取全局 targets
  cJSON *global_targets = cJSON_GetObjectItem(saved_config, "targets");
  if (global_targets && cJSON_IsArray(global_targets)) {
    cJSON *target;
    cJSON_ArrayForEach(target, global_targets) {
      cJSON *name = cJSON_GetObjectItem(target, "name");
      if (name && cJSON_IsString(name)) {
        cJSON *new_target = cJSON_CreateObject();
        cJSON_AddStringToObject(new_target, "name", name->valuestring);
        cJSON_AddItemToArray(targets, new_target);
        ESP_LOGI(TAG, "Added target: %s", name->valuestring);
      }
    }
  }

  cJSON_AddItemToObject(root, "targets", targets);

  char *json_data = cJSON_Print(root);
  httpd_resp_send(req, json_data, strlen(json_data));

  free(json_data);
  cJSON_Delete(root);
  cJSON_Delete(saved_config); // 清理加载的配置
  return ESP_OK;
}

static esp_err_t get_statistics_handler(httpd_req_t *req) {
  httpd_resp_set_hdr(req, "Connection", "close");
  httpd_resp_set_type(req, "application/json");

  cJSON *root = cJSON_CreateObject();
  if (root == NULL) {
    httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR,
                        "Failed to create JSON object");
    return ESP_FAIL;
  }

  // 添加串口统计
  cJSON *uart_stats_obj = cJSON_CreateObject();
  if (uart_stats_obj == NULL) {
    cJSON_Delete(root);
    httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR,
                        "Failed to create uart stats object");
    return ESP_FAIL;
  }

  // 使用全局的 uart_stats 结构体
  cJSON_AddNumberToObject(uart_stats_obj, "send_frame_success",
                          uart_stats.send_frame_success);
  cJSON_AddNumberToObject(uart_stats_obj, "send_byte_success",
                          uart_stats.send_byte_success);
  cJSON_AddNumberToObject(uart_stats_obj, "recv_frame_success",
                          uart_stats.recv_frame_success);
  cJSON_AddNumberToObject(uart_stats_obj, "recv_byte_success",
                          uart_stats.recv_byte_success);
  cJSON_AddItemToObject(root, "uart", uart_stats_obj);

  // 添加 targets 统计
  cJSON *targets_obj = cJSON_CreateObject();
  if (targets_obj == NULL) {
    cJSON_Delete(root);
    httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR,
                        "Failed to create targets object");
    return ESP_FAIL;
  }

  // 使用全局的 target_stats 数组
  for (int i = 0; i < target_stats_count; i++) {
    cJSON *target_stats_obj = cJSON_CreateObject();
    if (target_stats_obj == NULL) {
      continue;
    }

    // 使用已定义的 target_stats 结构体成员
    cJSON_AddNumberToObject(target_stats_obj, "send_frame_success",
                            target_stats[i].send_frame_success);
    cJSON_AddNumberToObject(target_stats_obj, "send_byte_success",
                            target_stats[i].send_byte_success);
    cJSON_AddNumberToObject(target_stats_obj, "send_frame_failed",
                            target_stats[i].send_frame_failed);
    cJSON_AddNumberToObject(target_stats_obj, "send_byte_failed",
                            target_stats[i].send_byte_failed);
    cJSON_AddNumberToObject(target_stats_obj, "recv_frame",
                            target_stats[i].recv_frame);
    cJSON_AddNumberToObject(target_stats_obj, "recv_byte",
                            target_stats[i].recv_byte);

    // 使用 target_stats 中的 name 字段
    cJSON_AddItemToObject(targets_obj, target_stats[i].name, target_stats_obj);
  }
  cJSON_AddItemToObject(root, "targets", targets_obj);

  char *json_data = cJSON_Print(root);
  if (json_data == NULL) {
    cJSON_Delete(root);
    httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR,
                        "Failed to generate JSON string");
    return ESP_FAIL;
  }

  esp_err_t ret = httpd_resp_send(req, json_data, strlen(json_data));

  free(json_data);
  cJSON_Delete(root);

  return ret;
}

/* 登录处理函数 */
static esp_err_t web_login_handler(httpd_req_t *req) {
  char buf[1024];
  int ret, remaining = req->content_len;

  while (remaining > 0) {
    if ((ret = httpd_req_recv(req, buf, sizeof(buf))) <= 0) {
      if (ret == HTTPD_SOCK_ERR_TIMEOUT) {
        continue;
      }
      return ESP_FAIL;
    }
    remaining -= ret;
    ESP_LOGI(TAG, "%.*s", ret, buf);
  }
  printf("%s\n", buf);
  cJSON *json = cJSON_Parse(buf);
  if (json == NULL) {
    const char *error_ptr = cJSON_GetErrorPtr();
    if (error_ptr != NULL) {
      ESP_LOGE("JSON", "Error before: %s", error_ptr);
    }
    cJSON_Delete(json);
    return 0;
  }
  cJSON *username = cJSON_GetObjectItemCaseSensitive(json, "username");
  if (cJSON_IsString(username) && (username->valuestring != NULL)) {
    ESP_LOGI("JSON", "username: %s", username->valuestring);
  }
  cJSON *password = cJSON_GetObjectItemCaseSensitive(json, "password");
  if (cJSON_IsString(password) && (password->valuestring != NULL)) {
    ESP_LOGI("JSON", "password: %s", password->valuestring);
  }

  esp_err_t rets = nvs_init();
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));

  size_t host_names, ntp_server, lgname, lgpwd = 0;

  rets = nvs_get_str(nvs_handle, "lgname", NULL, &lgname);
  nvs_get_str(nvs_handle, "lgpwd", NULL, &lgpwd);
  nvs_get_str(nvs_handle, "host_names", NULL, &host_names);
  nvs_get_str(nvs_handle, "ntp_server", NULL, &ntp_server);

  switch (rets) {
  case ESP_OK:
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    ESP_ERROR_CHECK(
        nvs_set_str(nvs_handle, "host_names", "千瓦科技 --物小能G1"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "ntp_server", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "lgname", "wuxiaoneng"));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "lgpwd", "4006303060"));
    break;
  default:
    break;
  }
  if (rets != ESP_OK) {
    printf("Error getting size of 'host_names': %s\n", esp_err_to_name(rets));
  } else {
    char *nvs_host_names = malloc(host_names);
    char *nvs_ntp_server = malloc(ntp_server);
    char *nvs_lgname = malloc(lgname);
    char *nvs_lgpwd = malloc(lgpwd);
    if (nvs_host_names == NULL) {
      printf("Memory allocation failed\n");
    } else {
      rets = nvs_get_str(nvs_handle, "host_names", nvs_host_names, &host_names);
      nvs_get_str(nvs_handle, "ntp_server", nvs_ntp_server, &ntp_server);
      nvs_get_str(nvs_handle, "lgname", nvs_lgname, &lgname);
      nvs_get_str(nvs_handle, "lgpwd", nvs_lgpwd, &lgpwd);

      if (rets == ESP_OK) {
        // printf("Value for 'host_names' is %s\n", nvs_host_names);
        // printf("Value for 'ntp_server' is %s\n", nvs_ntp_server);
        // printf("Value for 'lgname' is %s\n", nvs_lgname);
        // printf("Value for 'lgpwd' is %s\n", nvs_lgpwd);
        if (strcmp(username->valuestring, nvs_lgname) == 0 &&
            strcmp(password->valuestring, nvs_lgpwd) == 0) {
          // 普通用户登录成功
          httpd_resp_send(req, "success", HTTPD_RESP_USE_STRLEN);

        } else if (strcmp(username->valuestring, "qianwa") == 0 &&
                   strcmp(password->valuestring, "Wxn6663060") == 0) {
          // 管理员登录成功
          httpd_resp_send(req, "admin_success", HTTPD_RESP_USE_STRLEN);

        } else {
          // 登录失败
          httpd_resp_send(req, "fail", HTTPD_RESP_USE_STRLEN);
        }
      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(rets));
      }
      free(nvs_host_names);
      free(nvs_ntp_server);
      free(nvs_lgname);
      free(nvs_lgpwd);
    }
  }
  nvs_close(nvs_handle);
  cJSON_Delete(json);
  return ESP_OK;
}

static const httpd_uri_t root = {
    .uri = "/", .method = HTTP_GET, .handler = root_get_handler};

// static const httpd_uri_t get_status = {
//     .uri = "/dashboard", .method = HTTP_POST, .handler =
//     status_post_handler};

static const httpd_uri_t dashboard_uri = {
    .uri = "/dashboard", .method = HTTP_GET, .handler = dashboard_get_handler};

static const httpd_uri_t user_dashboard_uri = {.uri = "/user_dashboard",
                                               .method = HTTP_GET,
                                               .handler =
                                                   user_dashboard_handler};

static const httpd_uri_t admin_dashboard_uri = {.uri = "/admin_dashboard",
                                                .method = HTTP_GET,
                                                .handler =
                                                    admin_dashboard_handler};

static const httpd_uri_t js_uri = {
    .uri = "/web.js", .method = HTTP_GET, .handler = js_get_handler};

static const httpd_uri_t userjs_uri = {
    .uri = "/userweb.js", .method = HTTP_GET, .handler = userjs_get_handler};

static const httpd_uri_t css_uri = {
    .uri = "/web.css", .method = HTTP_GET, .handler = css_get_handler};

static const httpd_uri_t get_devinfo = {
    .uri = "/devinfo", .method = HTTP_GET, .handler = get_devinfo_get_handler};

static const httpd_uri_t get_targets_uri = {
    .uri = "/targets", .method = HTTP_GET, .handler = get_targets_handler};

static const httpd_uri_t statistics_uri = {.uri = "/statistics",
                                           .method = HTTP_GET,
                                           .handler = get_statistics_handler};

static const httpd_uri_t get_sys = {
    .uri = "/sys", .method = HTTP_GET, .handler = get_sys_get_handler};

static const httpd_uri_t get_operate = {
    .uri = "/operate", .method = HTTP_GET, .handler = get_operate_get_handler};

static const httpd_uri_t get_restore = {
    .uri = "/restore", .method = HTTP_GET, .handler = get_restore_get_handler};

static const httpd_uri_t get_module_set = {.uri = "/module_set",
                                           .method = HTTP_POST,
                                           .handler =
                                               get_module_set_post_handler};

static const httpd_uri_t get_module_set_info = {
    .uri = "/module_set_info",
    .method = HTTP_GET,
    .handler = get_module_set_info_get_handler};

static const httpd_uri_t get_mqtt = {
    .uri = "/mqtt", .method = HTTP_POST, .handler = get_mqtt_post_handler};

static const httpd_uri_t get_net_set = {.uri = "/net_set",
                                        .method = HTTP_POST,
                                        .handler = get_net_set_post_handler};

static const httpd_uri_t get_net_set_info = {.uri = "/net_set_info",
                                             .method = HTTP_GET,
                                             .handler =
                                                 get_net_set_info_get_handler};

static const httpd_uri_t get_mqtt_info = {.uri = "/mqtt_info",
                                          .method = HTTP_GET,
                                          .handler = get_mqtt_info_get_handler};
static const httpd_uri_t get_tcp_info = {.uri = "/tcp_info",
                                         .method = HTTP_GET,
                                         .handler = get_tcp_info_get_handler};
// static const httpd_uri_t get_udp_info = {.uri = "/udp_info",
//                                          .method = HTTP_GET,
//                                          .handler =
//                                          get_udp_info_get_handler};

static const httpd_uri_t get_http_info = {.uri = "/http_info",
                                          .method = HTTP_GET,
                                          .handler = get_http_info_get_handler};
static const httpd_uri_t get_tcp = {
    .uri = "/tcp", .method = HTTP_POST, .handler = get_tcp_post_handler};

// static const httpd_uri_t get_udp = {
//     .uri = "/udp", .method = HTTP_POST, .handler = get_udp_post_handler};

static const httpd_uri_t get_http = {
    .uri = "/http", .method = HTTP_POST, .handler = get_http_post_handler};

static const httpd_uri_t get_update = {
    .uri = "/update", .method = HTTP_POST, .handler = get_update_post_handler};

static const httpd_uri_t get_ota = {
    .uri = "/ota", .method = HTTP_POST, .handler = get_ota_post_handler};

static const httpd_uri_t get_find_wifi = {.uri = "/find_wifi",
                                          .method = HTTP_GET,
                                          .handler = get_find_wifi_get_handler};

static const httpd_uri_t get_ap_set = {
    .uri = "/ap_set", .method = HTTP_POST, .handler = get_ap_set_post_handler};

// static const httpd_uri_t get_log = {
//     .uri = "/detail_log", .method = HTTP_GET, .handler = get_log_handler};

// static const httpd_uri_t clear_log = {
//     .uri = "/clear_log", .method = HTTP_POST, .handler = clear_log_handler};

// 在http_server初始化时添加WebSocket路由
static const httpd_uri_t ws = {.uri = "/ws",
                               .method = HTTP_GET,
                               .handler = ws_handler,
                               .user_ctx = NULL,
                               .is_websocket = true};
// static const httpd_uri_t get_serial_set = {.uri = "/serial_set",
//                                            .method = HTTP_POST,
//                                            .handler =
//                                            get_serial_set_handler};

// static const httpd_uri_t get_serial_ctl = {.uri = "/serial_ctl",
//                                            .method = HTTP_POST,
//                                            .handler =
//                                            get_serial_ctl_handler};

// static const httpd_uri_t get_serial_set_info = {
//     .uri = "/serial_set_info",
//     .method = HTTP_GET,
//     .handler = get_serial_set_info_get_handler};

static const httpd_uri_t get_exit_ap = {
    .uri = "/exit_ap", .method = HTTP_GET, .handler = get_exit_ap_get_handler};

static const httpd_uri_t get_ap_set_info = {.uri = "/ap_set_info",
                                            .method = HTTP_GET,
                                            .handler =
                                                get_ap_set_info_get_handler};

static const httpd_uri_t web_login = {
    .uri = "/login", .method = HTTP_POST, .handler = web_login_handler};

static httpd_handle_t start_webserver(void) {

  httpd_config_t config = HTTPD_DEFAULT_CONFIG();
  config.stack_size = 10240;
  config.max_open_sockets = 13;
  config.max_uri_handlers = 32;
  config.lru_purge_enable = true;
  ESP_LOGI(TAG, "Starting http_server on port: '%d'", config.server_port);
  if (httpd_start(&http_server, &config) == ESP_OK) {
    ESP_LOGI(TAG, "Registering URI handlers");
    init_websocket();
    httpd_register_uri_handler(http_server, &root);
    // httpd_register_uri_handler(http_server, &get_status);

    httpd_register_uri_handler(http_server, &dashboard_uri);
    httpd_register_uri_handler(http_server, &user_dashboard_uri);
    httpd_register_uri_handler(http_server, &admin_dashboard_uri);

    // httpd_register_uri_handler(http_server, &get_serial_ctl);
    httpd_register_uri_handler(http_server, &js_uri);
    httpd_register_uri_handler(http_server, &userjs_uri);
    httpd_register_uri_handler(http_server, &css_uri);
    httpd_register_uri_handler(http_server, &get_devinfo);
    httpd_register_uri_handler(http_server, &get_targets_uri);
    httpd_register_uri_handler(http_server, &statistics_uri);
    httpd_register_uri_handler(http_server, &get_sys);
    httpd_register_uri_handler(http_server, &get_module_set);
    httpd_register_uri_handler(http_server, &get_module_set_info);
    httpd_register_uri_handler(http_server, &get_net_set);
    httpd_register_uri_handler(http_server, &get_net_set_info);
    httpd_register_uri_handler(http_server, &get_mqtt);
    httpd_register_uri_handler(http_server, &get_mqtt_info);
    httpd_register_uri_handler(http_server, &get_tcp);
    httpd_register_uri_handler(http_server, &get_tcp_info);
    // httpd_register_uri_handler(http_server, &get_udp);
    // httpd_register_uri_handler(http_server, &get_udp_info);
    httpd_register_uri_handler(http_server, &get_http);
    httpd_register_uri_handler(http_server, &get_http_info);
    httpd_register_uri_handler(http_server, &get_operate);
    httpd_register_uri_handler(http_server, &get_restore);
    httpd_register_uri_handler(http_server, &get_update);
    httpd_register_uri_handler(http_server, &get_ota);
    httpd_register_uri_handler(http_server, &get_find_wifi);
    httpd_register_uri_handler(http_server, &get_exit_ap);
    httpd_register_uri_handler(http_server, &get_ap_set);
    httpd_register_uri_handler(http_server, &get_ap_set_info);
    // httpd_register_uri_handler(http_server, &get_log);
    // httpd_register_uri_handler(http_server, &clear_log);
    httpd_register_uri_handler(http_server, &ws);
    httpd_register_uri_handler(http_server, &web_login);

    // httpd_register_uri_handler(http_server, &get_serial_set);
    // httpd_register_uri_handler(http_server, &get_serial_set_info);

    // httpd_register_uri_handler(http_server, &get_serial_ctl);

    httpd_register_err_handler(http_server, HTTPD_403_FORBIDDEN,
                               http_404_error_handler);
    httpd_register_err_handler(http_server, HTTPD_404_NOT_FOUND,
                               http_404_error_handler);
    httpd_register_err_handler(http_server, HTTPD_405_METHOD_NOT_ALLOWED,
                               http_404_error_handler);
  }
  return http_server;
}

// static esp_err_t stop_webserver(httpd_handle_t server)
// {
//     // Stop the httpd server
//     return httpd_stop(server);
// }

// static void disconnect_handler(void *arg, esp_event_base_t event_base,
//                                int32_t event_id, void *event_data)
// {
//     httpd_handle_t *http_server = (httpd_handle_t *)arg;
//     if (*http_server)
//     {
//         ESP_LOGI(TAG, "Stopping webserver");
//        + if (stop_webserver(*http_server) == ESP_OK)
//         {
//             *http_server = NULL;
//         }
//         else
//         {
//             ESP_LOGE(TAG, "Failed to stop http http_server");
//         }
//     }
// }

void http_server_init(void) {

  wifi_init_softap();
  start_webserver();
  start_dns_server();
  sx_log_init();
}

/*************************************************************************************/
/*                                END OF FILE */
/*************************************************************************************/
