/*
 * @Author: Orion
 * @Date: 2024-09-13 11:45:31
 * @LastEditors: Orion
 * @LastEditTime: 2025-01-10 17:44:03
 * @Description:
 *
 */

#pragma once

#ifdef __cplusplus
extern "C" {
#endif
#include <esp_err.h>
void start_4g_task(void);
extern char g_ccid[32];
extern char g_cgsn[32];
extern char g_4gip[32];
int send4gData(const char *logName, const char *data) ;
#define TXD_PIN_4G (GPIO_NUM_33)
#define RXD_PIN_4G (GPIO_NUM_32)
esp_err_t start_4g_fota(const char *url);
esp_err_t download_and_update_4g(const char *url);
#ifdef __cplusplus
}
#endif
