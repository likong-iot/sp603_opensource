/*
 * @Author: Orion
 * @Date: 2024-05-07 16:29:12
 * @LastEditors: Orion
 * @LastEditTime: 2025-04-22 11:17:51
 * @FilePath: \SERIIAL_SERVER\main\sx_time.c
 * @Description:
 *
 * Copyright (c) 2024 by SX-IOT, All Rights Reserved.
 */
#include "cJSON.h"
#include "esp_http_client.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <stdlib.h>
#include <string.h>
#define MAX_HTTP_OUTPUT_BUFFER 2048
static const char *TAG = "HTTP_CLIENT_TIME";
char strftime_buf[64];

void http_get_current_time_task(void *pvParameters) {
  char output_buffer[MAX_HTTP_OUTPUT_BUFFER] = {0};
  int content_length = 0;

  esp_http_client_config_t config;
  memset(&config, 0, sizeof(config));
  static const char *URL = "http://quan.suning.com/getSysTime.do";
  config.url = URL;
  esp_http_client_handle_t client = esp_http_client_init(&config);
  esp_http_client_set_method(client, HTTP_METHOD_GET);

  while (1) {
    esp_err_t err = esp_http_client_open(client, 0);
    if (err != ESP_OK) {
      // ESP_LOGE(TAG, "时间获取失败: %s", esp_err_to_name(err));
    } else {
      content_length = esp_http_client_fetch_headers(client);
      if (content_length < 0) {
        // ESP_LOGE(TAG, "HTTP client fetch headers failed");
      } else {
        int data_read = esp_http_client_read_response(client, output_buffer,
                                                      MAX_HTTP_OUTPUT_BUFFER);
        if (data_read >= 0) {
          // ESP_LOGI(TAG, "HTTP POST Status = %d, content_length = %" PRIu64,
          //          esp_http_client_get_status_code(client),
          //          esp_http_client_get_content_length(client));
          //   printf("data:%s\\n", output_buffer);
          char *start_of_json = strchr(output_buffer, '{');
          char *end_of_json = strrchr(output_buffer, '}');
          if (start_of_json != NULL && end_of_json != NULL) {
            *end_of_json = '\0'; // 只保留{}之间的内容
            start_of_json++;
          }
          char json_with_brackets[256];
          snprintf(json_with_brackets, sizeof(json_with_brackets), "{%s}",
                   start_of_json); // 添加{}
          // printf("data1:%s\\n", json_with_brackets);
          cJSON *root = NULL;
          root = cJSON_Parse(json_with_brackets);
          if (root == NULL) {
            // printf("请求异常.\n");
          } else {
            cJSON *time = cJSON_GetObjectItem(root, "sysTime2");
            if (time == NULL) {
              // printf("没有找到\"sysTime2\"键.\n");
              cJSON_Delete(root); // 释放内存
              return;
            }
            strcpy(strftime_buf, time->valuestring);
            printf("current time is: %s\n", strftime_buf);
          }
          cJSON_Delete(root);

        } else {
          // ESP_LOGE(TAG, "Failed to read response");
        }
      }
    }
    // esp_http_client_cleanup(client);
    esp_http_client_close(client);
    vTaskDelay(5000 / portTICK_PERIOD_MS);
  }
}
