
#include "cJSON.h"
#include "esp_log.h"
#include "esp_tls.h"
#include "hal/uart_types.h"
#include "mqtt_client.h"
#include "nvs.h"
#include "nvs_flash.h"
// #include "sx_async_uart.h"
#include "esp_event.h"
#include "esp_http_client.h"
#include "mbedtls/md5.h"
#include "sx_485_http.h"
#include "sx_485_uart.h"
#include "sx_4g_uart.h"
#include "sx_gpio.h"
#include "sx_http_ota.h"
#include "sx_log.h"
#include "sx_mqtt_client.h"
#include "sx_time.h"
#include "sx_utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char pubtopic[30] = {0};
char subtopic[30] = {0};
char mqtt_client_id[30] = {0};

// 定义全局的缓冲区来缓存分片的 MQTT 数据
char *mqtt_data_buffer = NULL;
size_t mqtt_data_len = 0;

TaskHandle_t xMqttHandle = NULL;

static const char *TAG = "SX_MQTT_CLIENT";
esp_mqtt_client_handle_t client = NULL;

mqtt_target_t mqtt_targets[MAX_MQTT_TARGETS];

int mqtt_target_count = 0; // 记录当前有多少目标服务器
#define MAX_HTTP_RECV_BUFFER 512
#define MAX_HTTP_OUTPUT_BUFFER 2048

/*************************************************************************************/
/*                                START OF FILE */
/*************************************************************************************/

int aiot_platform_publish_topic(const char *topic, const char *data, int len,
                                int qos, int retain) {
  int msg_id = esp_mqtt_client_publish(client, topic, data, len, qos, retain);
  return msg_id;
}

static void log_error_if_nonzero(const char *message, int error_code) {
  if (error_code != 0) {
    ESP_LOGE(TAG, "Last error %s: 0x%x", message, error_code);
  }
}

int mqtt_4g_publish(const char *topic, const char *data, int qos) {
  char pub_cmd[512];
  snprintf(pub_cmd, sizeof(pub_cmd), "AT+IMQTTPUB=%s,%d,\"%s\"\r\n", topic, qos,
           data);

  ESP_LOGI("4G_MQTT", "Publishing: %s", pub_cmd);
  int result = send4gData("4G_MQTT", pub_cmd);

  // 等待发布完成
  vTaskDelay(50 / portTICK_PERIOD_MS);

  return result;
}

void mqtt_public_send_device_info(void) {
  char *mqttmsg = NULL;
  esp_err_t ret = nvs_flash_init();
  if (ret == ESP_ERR_NVS_NO_FREE_PAGES ||
      ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
    ESP_ERROR_CHECK(nvs_flash_erase());
    ret = nvs_flash_init();
  }
  ESP_ERROR_CHECK(ret);

  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));

  size_t use_mqtt, mqtt_clientid, mqtt_sub_topic, mqtt_pub_topic, qos, retain,
      netconn = 0;

  // Get string sizes
  ret = nvs_get_str(nvs_handle, "use_mqtt", NULL, &use_mqtt);
  ret |= nvs_get_str(nvs_handle, "mqtt_clientid", NULL, &mqtt_clientid);
  ret |= nvs_get_str(nvs_handle, "mqtt_sub_topic", NULL, &mqtt_sub_topic);
  ret |= nvs_get_str(nvs_handle, "mqtt_pub_topic", NULL, &mqtt_pub_topic);
  ret |= nvs_get_str(nvs_handle, "qos", NULL, &qos);
  ret |= nvs_get_str(nvs_handle, "retain", NULL, &retain);
  ret |= nvs_get_str(nvs_handle, "netconn", NULL, &netconn);

  if (ret != ESP_OK) {
    ESP_LOGE(TAG, "Error getting size of keys: %s", esp_err_to_name(ret));
    nvs_close(nvs_handle);
    return;
  }

  // Allocate memory
  char *nvs_use_mqtt = malloc(use_mqtt);
  char *nvs_mqtt_clientid = malloc(mqtt_clientid);
  char *nvs_mqtt_sub_topic = malloc(mqtt_sub_topic);
  char *nvs_mqtt_pub_topic = malloc(mqtt_pub_topic);
  char *nvs_qos = malloc(qos);
  char *nvs_retain = malloc(retain);
  char *nvs_netconn = malloc(netconn);

  if (!nvs_use_mqtt || !nvs_mqtt_clientid || !nvs_mqtt_sub_topic ||
      !nvs_mqtt_pub_topic || !nvs_qos || !nvs_retain || !nvs_netconn) {
    ESP_LOGE(TAG, "Memory allocation failed");
    // Free any successfully allocated memory
    if (nvs_use_mqtt)
      free(nvs_use_mqtt);
    if (nvs_mqtt_clientid)
      free(nvs_mqtt_clientid);
    if (nvs_mqtt_sub_topic)
      free(nvs_mqtt_sub_topic);
    if (nvs_mqtt_pub_topic)
      free(nvs_mqtt_pub_topic);
    if (nvs_qos)
      free(nvs_qos);
    if (nvs_retain)
      free(nvs_retain);
    if (nvs_netconn)
      free(nvs_netconn);
    nvs_close(nvs_handle);
    return;
  }

  // Get strings
  ret = nvs_get_str(nvs_handle, "use_mqtt", nvs_use_mqtt, &use_mqtt);
  ret |= nvs_get_str(nvs_handle, "mqtt_clientid", nvs_mqtt_clientid,
                     &mqtt_clientid);
  ret |= nvs_get_str(nvs_handle, "mqtt_sub_topic", nvs_mqtt_sub_topic,
                     &mqtt_sub_topic);
  ret |= nvs_get_str(nvs_handle, "mqtt_pub_topic", nvs_mqtt_pub_topic,
                     &mqtt_pub_topic);
  ret |= nvs_get_str(nvs_handle, "qos", nvs_qos, &qos);
  ret |= nvs_get_str(nvs_handle, "retain", nvs_retain, &retain);
  ret |= nvs_get_str(nvs_handle, "netconn", nvs_netconn, &netconn);

  if (ret != ESP_OK) {
    ESP_LOGE(TAG, "Error reading keys: %s", esp_err_to_name(ret));
  } else {
    mqttmsg =
        device_basic_info(); // Ensure device_basic_info handles memory properly

    if (mqttmsg != NULL) {
      // 解析设备信息JSON
      cJSON *info_json = cJSON_Parse(mqttmsg);
      if (info_json) {
        // 添加status字段
        cJSON_AddStringToObject(info_json, "status", "info");

        // 转换为字符串并发送
        char *response_str = cJSON_PrintUnformatted(info_json);
        if (response_str) {
          if (atoi(nvs_netconn) == 3) { // 4G mode
            ESP_LOGI(TAG, "Publishing via 4G MQTT");
            mqtt_4g_publish(nvs_mqtt_sub_topic, response_str, atoi(nvs_qos));
          } else { // WiFi mode
            ESP_LOGI(TAG, "Publishing via WiFi MQTT");
            aiot_platform_publish_topic(nvs_mqtt_sub_topic, response_str,
                                        strlen(response_str), atoi(nvs_qos),
                                        atoi(nvs_retain));
          }
          free(response_str);
        }
        cJSON_Delete(info_json);
      }
      free(mqttmsg);
    } else {
      ESP_LOGE(TAG, "Failed to create MQTT message");
    }
  }

  // Free allocated memory
  free(nvs_use_mqtt);
  free(nvs_mqtt_clientid);
  free(nvs_mqtt_sub_topic);
  free(nvs_mqtt_pub_topic);
  free(nvs_qos);
  free(nvs_retain);
  free(nvs_netconn);

  nvs_close(nvs_handle);
}

void mqtt_send_task(void *pvParameters) {
  esp_err_t ret = nvs_flash_init();
  if (ret == ESP_ERR_NVS_NO_FREE_PAGES ||
      ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
    ESP_ERROR_CHECK(nvs_flash_erase());
    ret = nvs_flash_init();
  }
  ESP_ERROR_CHECK(ret);
  int task_mqtt_time = 1;
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
  size_t use_mqtt, mqtt_clientid, mqtt_send, mqtt_time = 0;
  ret = nvs_get_str(nvs_handle, "use_mqtt", NULL, &use_mqtt);
  nvs_get_str(nvs_handle, "mqtt_clientid", NULL, &mqtt_clientid);
  nvs_get_str(nvs_handle, "mqtt_send", NULL, &mqtt_send);
  nvs_get_str(nvs_handle, "mqtt_time", NULL, &mqtt_time);
  switch (ret) {
  case ESP_OK:
    printf("HTTP set success");
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "use_mqtt", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_clientid", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_send", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_time", ""));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'HTTP': %s\n", esp_err_to_name(ret));
  } else {
    char *nvs_use_mqtt = malloc(use_mqtt);
    char *nvs_mqtt_clientid = malloc(mqtt_clientid);
    char *nvs_mqtt_send = malloc(mqtt_send);
    char *nvs_mqtt_time = malloc(mqtt_time);
    if (nvs_use_mqtt == NULL) {
      printf("Memory allocation failed\n");
    } else {
      ret = nvs_get_str(nvs_handle, "use_mqtt", nvs_use_mqtt, &use_mqtt);
      nvs_get_str(nvs_handle, "mqtt_clientid", nvs_mqtt_clientid,
                  &mqtt_clientid);
      nvs_get_str(nvs_handle, "mqtt_send", nvs_mqtt_send, &mqtt_send);
      nvs_get_str(nvs_handle, "mqtt_time", nvs_mqtt_time, &mqtt_time);
      if (ret == ESP_OK) {
        task_mqtt_time = atoi(nvs_mqtt_time);
      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_use_mqtt);
      free(nvs_mqtt_clientid);
      free(nvs_mqtt_send);
      free(nvs_mqtt_time);
    }
  }
  nvs_close(nvs_handle);

  while (1) {
    vTaskDelay(1000 * task_mqtt_time / portTICK_PERIOD_MS);
    // mqtt_public_send_device_info(); TODO
  }
  vTaskDelete(NULL);
}

static bool is_target_duplicate(const char *name, const char *url,
                                const char *clientid) {
  for (int i = 0; i < mqtt_target_count; i++) {
    if (strcmp(mqtt_targets[i].name, name) == 0) {
      return true;
    }
  }
  return false;
}

// 获取MQTT目标数量
int get_mqtt_target_count(void) { return mqtt_target_count; }

// 获取MQTT目标名称
const char *get_mqtt_target_name(int index) {
  if (index >= 0 && index < mqtt_target_count) {
    return mqtt_targets[index].name;
  }
  return NULL;
}

// 添加新的函数用于保存配置到NVS
esp_err_t save_config_to_nvs(const cJSON *json_data) {
  nvs_handle_t nvs_handle;
  esp_err_t err = nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle);
  if (err != ESP_OK) {
    ESP_LOGE(TAG, "Error opening NVS handle: %s", esp_err_to_name(err));
    return err;
  }

  // 将JSON转换为字符串
  char *json_str = cJSON_PrintUnformatted(json_data);
  if (json_str == NULL) {
    ESP_LOGE(TAG, "Failed to convert JSON to string");
    nvs_close(nvs_handle);
    return ESP_FAIL;
  }

  // 保存配置到NVS
  err = nvs_set_str(nvs_handle, "device_config", json_str);
  if (err != ESP_OK) {
    ESP_LOGE(TAG, "Error saving config to NVS: %s", esp_err_to_name(err));
  } else {
    err = nvs_commit(nvs_handle);
    if (err != ESP_OK) {
      ESP_LOGE(TAG, "Error committing NVS: %s", esp_err_to_name(err));
    }
  }

  free(json_str);
  nvs_close(nvs_handle);
  return err;
}

// 添加新的函数用于从NVS加载配置
cJSON *load_config_from_nvs(void) {
  nvs_handle_t nvs_handle;
  esp_err_t err = nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle);
  if (err != ESP_OK) {
    ESP_LOGE(TAG, "Error opening NVS handle: %s", esp_err_to_name(err));
    return NULL;
  }

  size_t required_size = 0;
  err = nvs_get_str(nvs_handle, "device_config", NULL, &required_size);
  if (err != ESP_OK) {
    ESP_LOGI(TAG, "No saved config found in NVS");
    nvs_close(nvs_handle);
    return NULL;
  }

  char *json_str = malloc(required_size);
  if (json_str == NULL) {
    ESP_LOGE(TAG, "Failed to allocate memory for config");
    nvs_close(nvs_handle);
    return NULL;
  }

  err = nvs_get_str(nvs_handle, "device_config", json_str, &required_size);
  nvs_close(nvs_handle);

  if (err != ESP_OK) {
    ESP_LOGE(TAG, "Error reading config from NVS: %s", esp_err_to_name(err));
    free(json_str);
    return NULL;
  }

  cJSON *json_data = cJSON_Parse(json_str);
  free(json_str);

  if (json_data == NULL) {
    ESP_LOGE(TAG, "Failed to parse JSON config");
    return NULL;
  }

  return json_data;
}

// 添加计算MD5的辅助函数
static void calculate_md5(const char *input, char *output) {
  unsigned char md5_hash[16];
  char *md5_string = output;
  mbedtls_md5_context md5_ctx;

  mbedtls_md5_init(&md5_ctx);
  mbedtls_md5_starts(&md5_ctx);
  mbedtls_md5_update(&md5_ctx, (const unsigned char *)input, strlen(input));
  mbedtls_md5_finish(&md5_ctx, md5_hash);
  mbedtls_md5_free(&md5_ctx);

  // 转换为16进制字符串
  for (int i = 0; i < 16; i++) {
    sprintf(&md5_string[i * 2], "%02x", md5_hash[i]);
  }
  md5_string[32] = '\0';
}

// 处理set类型消息的函数
void handle_set_message(cJSON *json_data) {
  // 保存配置到NVS
  esp_err_t err = save_config_to_nvs(json_data);
  if (err != ESP_OK) {
    ESP_LOGE(TAG, "Failed to save config to NVS");
  }
  nvs_handle_t nvs_handle;
  esp_err_t ret = nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle);
  char *json_str = cJSON_PrintUnformatted(json_data);
  char md5_str[33] = {0}; // 32位MD5字符串 + 结束符
  if (json_str) {
    calculate_md5(json_str, md5_str);
    free(json_str);

    if (ret == ESP_OK) {
      ret = nvs_set_str(nvs_handle, "config_md5", md5_str);
      if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Error saving config_md5: %s", esp_err_to_name(ret));
      }
      nvs_commit(nvs_handle);
    }
  }

  // 保存最后配置时间

  if (ret == ESP_OK) {
    ret = nvs_set_str(nvs_handle, "last_config", strftime_buf);
    if (ret != ESP_OK) {
      ESP_LOGE(TAG, "Error saving last_config time: %s", esp_err_to_name(ret));
    }
    nvs_commit(nvs_handle);
  }

  // 处理params中的COM设置
  cJSON *params = cJSON_GetObjectItem(json_data, "params");
  if (params && cJSON_IsArray(params)) {
    cJSON *param = cJSON_GetArrayItem(params, 0); // 获取第一个参数
    if (param) {
      cJSON *com_type = cJSON_GetObjectItem(param, "com_type");
      cJSON *com = cJSON_GetObjectItem(param, "com");

      if (com_type && cJSON_IsString(com_type) &&
          strcmp(com_type->valuestring, "485") == 0 && com &&
          cJSON_IsString(com)) {
        ESP_LOGI(TAG, "全局COM设置: %s", com->valuestring);
        int baudrate;
        uart_parity_t parity;
        uart_word_length_t data_bits;
        uart_stop_bits_t stop_bits;

        parse_com_settings(com->valuestring, &baudrate, &parity, &data_bits,
                           &stop_bits);
        reinit_485_uart(baudrate, data_bits, parity, stop_bits, 50, 512);
      }
    }
  }

  // 启动 UART 循环任务
  start_uart_loop_task(json_data);

  // 处理targets
  cJSON *targets = cJSON_GetObjectItem(json_data, "targets");
  if (targets && cJSON_IsArray(targets)) {
    cJSON *target;
    cJSON_ArrayForEach(target, targets) {
      cJSON *name = cJSON_GetObjectItem(target, "name");
      cJSON *url = cJSON_GetObjectItem(target, "url");
      cJSON *clientid = cJSON_GetObjectItem(target, "clientid");

      // 优先检查新格式的topic
      cJSON *data_topic = cJSON_GetObjectItem(target, "data_topic");
      cJSON *cmd_topic = cJSON_GetObjectItem(target, "cmd_topic");

      // 如果新格式不存在，则使用旧格式
      if (!data_topic || !cmd_topic) {
        data_topic = cJSON_GetObjectItem(target, "pub_topic");
        cmd_topic = cJSON_GetObjectItem(target, "sub_topic");
      }

      if (name && url && cJSON_IsString(name) && cJSON_IsString(url)) {
        if (is_http_target(url->valuestring)) {
          ESP_LOGI(TAG, "添加HTTP目标: %s, URL: %s", name->valuestring,
                   url->valuestring);
          add_http_target(name->valuestring, url->valuestring);
        } else if (clientid && data_topic && cmd_topic &&
                   cJSON_IsString(clientid) && cJSON_IsString(data_topic) &&
                   cJSON_IsString(cmd_topic)) {

          if (is_target_duplicate(name->valuestring, url->valuestring,
                                  clientid->valuestring)) {
            ESP_LOGI(TAG, "跳过重复的目标: %s", name->valuestring);
            continue;
          }

          ESP_LOGI(TAG, "连接到目标: %s, URL: %s", name->valuestring,
                   url->valuestring);

          if (mqtt_target_count < MAX_MQTT_TARGETS) {
            strncpy(mqtt_targets[mqtt_target_count].name, name->valuestring,
                    sizeof(mqtt_targets[mqtt_target_count].name) - 1);
            strncpy(mqtt_targets[mqtt_target_count].url, url->valuestring,
                    sizeof(mqtt_targets[mqtt_target_count].url) - 1);
            strncpy(mqtt_targets[mqtt_target_count].clientid,
                    clientid->valuestring,
                    sizeof(mqtt_targets[mqtt_target_count].clientid) - 1);
            strncpy(mqtt_targets[mqtt_target_count].pub_topic,
                    data_topic->valuestring,
                    sizeof(mqtt_targets[mqtt_target_count].pub_topic) - 1);
            strncpy(mqtt_targets[mqtt_target_count].sub_topic,
                    cmd_topic->valuestring,
                    sizeof(mqtt_targets[mqtt_target_count].sub_topic) - 1);

            esp_mqtt_client_config_t mqtt_cfg = {
                .broker.address.uri = url->valuestring,
                .credentials.client_id = clientid->valuestring};

            mqtt_targets[mqtt_target_count].client =
                esp_mqtt_client_init(&mqtt_cfg);
            if (mqtt_targets[mqtt_target_count].client) {
              esp_mqtt_client_start(mqtt_targets[mqtt_target_count].client);
              int msg_id = esp_mqtt_client_subscribe(
                  mqtt_targets[mqtt_target_count].client,
                  cmd_topic->valuestring, 2);
              ESP_LOGI(TAG, "已订阅主题: %s, msg_id: %d",
                       cmd_topic->valuestring, msg_id);
              mqtt_target_count++;
            } else {
              ESP_LOGE(TAG, "MQTT 客户端初始化失败");
            }
          }
        }
      }
    }
  }

  if (ret != ESP_OK) {
    ESP_LOGE(TAG, "Error opening NVS handle: %s", esp_err_to_name(ret));
    return;
  }

  size_t mqtt_sub_topic_size = 0;
  size_t qos_size = 0;
  size_t retain_size = 0;

  // 获取字符串大小
  ret = nvs_get_str(nvs_handle, "mqtt_sub_topic", NULL, &mqtt_sub_topic_size);
  ret |= nvs_get_str(nvs_handle, "qos", NULL, &qos_size);
  ret |= nvs_get_str(nvs_handle, "retain", NULL, &retain_size);

  if (ret != ESP_OK) {
    ESP_LOGE(TAG, "Error getting size of keys: %s", esp_err_to_name(ret));
    nvs_close(nvs_handle);
    return;
  }

  // 分配内存
  char *nvs_mqtt_sub_topic = malloc(mqtt_sub_topic_size);
  char *nvs_qos = malloc(qos_size);
  char *nvs_retain = malloc(retain_size);

  if (!nvs_mqtt_sub_topic || !nvs_qos || !nvs_retain) {
    ESP_LOGE(TAG, "Memory allocation failed");
    if (nvs_mqtt_sub_topic)
      free(nvs_mqtt_sub_topic);
    if (nvs_qos)
      free(nvs_qos);
    if (nvs_retain)
      free(nvs_retain);
    nvs_close(nvs_handle);
    return;
  }

  // 获取字符串
  ret = nvs_get_str(nvs_handle, "mqtt_sub_topic", nvs_mqtt_sub_topic,
                    &mqtt_sub_topic_size);
  ret |= nvs_get_str(nvs_handle, "qos", nvs_qos, &qos_size);
  ret |= nvs_get_str(nvs_handle, "retain", nvs_retain, &retain_size);

  if (ret != ESP_OK) {
    ESP_LOGE(TAG, "Error reading keys: %s", esp_err_to_name(ret));
  } else {
    // 获取设备信息JSON字符串
    char *info_str = device_basic_info();
    if (info_str) {
      // 解析设备信息JSON
      cJSON *info_json = cJSON_Parse(info_str);
      if (info_json) {
        // 添加status字段
        cJSON_AddStringToObject(info_json, "status", "report_info");

        // 转换为字符串并发送
        char *response_str = cJSON_PrintUnformatted(info_json);
        if (response_str) {
          aiot_platform_publish_topic(nvs_mqtt_sub_topic, response_str,
                                      strlen(response_str), atoi(nvs_qos),
                                      atoi(nvs_retain));
          free(response_str);
        }
        cJSON_Delete(info_json);
      }
      free(info_str);
    }
  }

  // 释放内存
  free(nvs_mqtt_sub_topic);
  free(nvs_qos);
  free(nvs_retain);

  nvs_close(nvs_handle);
}

void reset_device_config(void) {
  // 从NVS中读取参数
  nvs_handle_t nvs_handle;
  esp_err_t ret = nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle);
  if (ret != ESP_OK) {
    ESP_LOGE(TAG, "Error opening NVS handle: %s", esp_err_to_name(ret));
    return;
  }

  size_t mqtt_sub_topic_size = 0;
  size_t qos_size = 0;
  size_t retain_size = 0;

  // 获取字符串大小
  ret = nvs_get_str(nvs_handle, "mqtt_sub_topic", NULL, &mqtt_sub_topic_size);
  ret |= nvs_get_str(nvs_handle, "qos", NULL, &qos_size);
  ret |= nvs_get_str(nvs_handle, "retain", NULL, &retain_size);

  if (ret != ESP_OK) {
    ESP_LOGE(TAG, "Error getting size of keys: %s", esp_err_to_name(ret));
    nvs_close(nvs_handle);
    return;
  }

  // 分配内存
  char *nvs_mqtt_sub_topic = malloc(mqtt_sub_topic_size);
  char *nvs_qos = malloc(qos_size);
  char *nvs_retain = malloc(retain_size);

  if (!nvs_mqtt_sub_topic || !nvs_qos || !nvs_retain) {
    ESP_LOGE(TAG, "Memory allocation failed");
    if (nvs_mqtt_sub_topic)
      free(nvs_mqtt_sub_topic);
    if (nvs_qos)
      free(nvs_qos);
    if (nvs_retain)
      free(nvs_retain);
    nvs_close(nvs_handle);
    return;
  }

  // 获取字符串
  ret = nvs_get_str(nvs_handle, "mqtt_sub_topic", nvs_mqtt_sub_topic,
                    &mqtt_sub_topic_size);
  ret |= nvs_get_str(nvs_handle, "qos", nvs_qos, &qos_size);
  ret |= nvs_get_str(nvs_handle, "retain", nvs_retain, &retain_size);

  if (ret != ESP_OK) {
    ESP_LOGE(TAG, "Error reading keys: %s", esp_err_to_name(ret));
  } else {
    // 发送回复消息
    const char *response = "{\"status\":\"reseting\"}";
    aiot_platform_publish_topic(nvs_mqtt_sub_topic, response, strlen(response),
                                atoi(nvs_qos), atoi(nvs_retain));
  }

  // 释放内存
  free(nvs_mqtt_sub_topic);
  free(nvs_qos);
  free(nvs_retain);

  nvs_close(nvs_handle);

  // 清除NVS中的配置
  ret = nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle);
  if (ret == ESP_OK) {
    nvs_erase_all(nvs_handle);
    nvs_commit(nvs_handle);
    nvs_close(nvs_handle);
  }

  vTaskDelay(200 / portTICK_PERIOD_MS);
  esp_restart();
}

void handle_restart() {
  // 从NVS中读取参数
  nvs_handle_t nvs_handle;
  esp_err_t ret = nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle);
  if (ret != ESP_OK) {
    ESP_LOGE(TAG, "Error opening NVS handle: %s", esp_err_to_name(ret));
    return;
  }

  size_t mqtt_sub_topic_size = 0;
  size_t qos_size = 0;
  size_t retain_size = 0;

  // 获取字符串大小
  ret = nvs_get_str(nvs_handle, "mqtt_sub_topic", NULL, &mqtt_sub_topic_size);
  ret |= nvs_get_str(nvs_handle, "qos", NULL, &qos_size);
  ret |= nvs_get_str(nvs_handle, "retain", NULL, &retain_size);

  if (ret != ESP_OK) {
    ESP_LOGE(TAG, "Error getting size of keys: %s", esp_err_to_name(ret));
    nvs_close(nvs_handle);
    return;
  }

  // 分配内存
  char *nvs_mqtt_sub_topic = malloc(mqtt_sub_topic_size);
  char *nvs_qos = malloc(qos_size);
  char *nvs_retain = malloc(retain_size);

  if (!nvs_mqtt_sub_topic || !nvs_qos || !nvs_retain) {
    ESP_LOGE(TAG, "Memory allocation failed");
    if (nvs_mqtt_sub_topic)
      free(nvs_mqtt_sub_topic);
    if (nvs_qos)
      free(nvs_qos);
    if (nvs_retain)
      free(nvs_retain);
    nvs_close(nvs_handle);
    return;
  }

  // 获取字符串
  ret = nvs_get_str(nvs_handle, "mqtt_sub_topic", nvs_mqtt_sub_topic,
                    &mqtt_sub_topic_size);
  ret |= nvs_get_str(nvs_handle, "qos", nvs_qos, &qos_size);
  ret |= nvs_get_str(nvs_handle, "retain", nvs_retain, &retain_size);

  if (ret != ESP_OK) {
    ESP_LOGE(TAG, "Error reading keys: %s", esp_err_to_name(ret));
  } else {
    // 发送回复消息
    const char *response = "{\"status\":\"restarting\"}";
    aiot_platform_publish_topic(nvs_mqtt_sub_topic, response, strlen(response),
                                atoi(nvs_qos), atoi(nvs_retain));
  }

  // 释放内存
  free(nvs_mqtt_sub_topic);
  free(nvs_qos);
  free(nvs_retain);

  nvs_close(nvs_handle);

  vTaskDelay(200 / portTICK_PERIOD_MS);
  esp_restart();
}

static void mqtt_event_handler(void *handler_args, esp_event_base_t base,
                               int32_t event_id, void *event_data) {
  esp_mqtt_event_handle_t event = event_data;
  esp_mqtt_client_handle_t client = event->client;
  int msg_id;
  esp_err_t ret = nvs_flash_init();
  if (ret == ESP_ERR_NVS_NO_FREE_PAGES ||
      ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
    ESP_ERROR_CHECK(nvs_flash_erase());
    ret = nvs_flash_init();
  }
  ESP_ERROR_CHECK(ret);
  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));
  size_t use_mqtt, mqtt_clientid, mqtt_sub_topic, mqtt_pub_topic, qos, retain,
      mqtt_send, mqtt_time = 0;
  ret = nvs_get_str(nvs_handle, "use_mqtt", NULL, &use_mqtt);
  nvs_get_str(nvs_handle, "mqtt_clientid", NULL, &mqtt_clientid);
  nvs_get_str(nvs_handle, "mqtt_sub_topic", NULL, &mqtt_sub_topic);
  nvs_get_str(nvs_handle, "mqtt_pub_topic", NULL, &mqtt_pub_topic);
  nvs_get_str(nvs_handle, "qos", NULL, &qos);
  nvs_get_str(nvs_handle, "retain", NULL, &retain);
  nvs_get_str(nvs_handle, "mqtt_send", NULL, &mqtt_send);
  nvs_get_str(nvs_handle, "mqtt_time", NULL, &mqtt_time);
  switch (ret) {
  case ESP_OK:
    break;
  case ESP_ERR_NVS_NOT_FOUND:
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "use_mqtt", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_clientid", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_sub_topic", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_pub_topic", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "qos", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "retain", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_send", ""));
    ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqtt_time", ""));
    break;
  default:
    break;
  }
  if (ret != ESP_OK) {
    printf("Error getting size of 'my_key': %s\n", esp_err_to_name(ret));
  } else {
    char *nvs_use_mqtt = malloc(use_mqtt);
    char *nvs_mqtt_clientid = malloc(mqtt_clientid);
    char *nvs_mqtt_sub_topic = malloc(mqtt_sub_topic);
    char *nvs_mqtt_pub_topic = malloc(mqtt_pub_topic);
    char *nvs_qos = malloc(qos);
    char *nvs_retain = malloc(retain);
    char *nvs_mqtt_send = malloc(mqtt_send);
    char *nvs_mqtt_time = malloc(mqtt_time);
    if (nvs_mqtt_clientid == NULL) {
      printf("Memory allocation failed\n");
    } else {
      ret = nvs_get_str(nvs_handle, "use_mqtt", nvs_use_mqtt, &use_mqtt);
      nvs_get_str(nvs_handle, "mqtt_clientid", nvs_mqtt_clientid,
                  &mqtt_clientid);
      nvs_get_str(nvs_handle, "mqtt_sub_topic", nvs_mqtt_sub_topic,
                  &mqtt_sub_topic);
      nvs_get_str(nvs_handle, "mqtt_pub_topic", nvs_mqtt_pub_topic,
                  &mqtt_pub_topic);
      nvs_get_str(nvs_handle, "qos", nvs_qos, &qos);
      nvs_get_str(nvs_handle, "retain", nvs_retain, &retain);
      nvs_get_str(nvs_handle, "mqtt_send", nvs_mqtt_send, &mqtt_send);
      nvs_get_str(nvs_handle, "mqtt_time", nvs_mqtt_time, &mqtt_time);
      if (ret == ESP_OK) {
        switch ((esp_mqtt_event_id_t)event_id) {
        case MQTT_EVENT_CONNECTED:
          msg_id = esp_mqtt_client_subscribe(client, nvs_mqtt_pub_topic,
                                             atoi(nvs_qos));
          ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqttconn", "1"));
          const char *online_msg = "{\"status\":\"online\"}";
          esp_mqtt_client_publish(client, nvs_mqtt_sub_topic, online_msg,
                                  strlen(online_msg), 2, 1);
          // if (atoi(nvs_mqtt_send) == 2) {
          //   if (xMqttHandle == NULL) {
          //     xTaskCreate(&mqtt_send_task, "mqtt_send_task", 8192, NULL, 5,
          //                 &xMqttHandle);
          //   }
          // }
          // for (int i = 0; i < mqtt_target_count; i++) {
          //   int msg_id = esp_mqtt_client_subscribe(
          //       mqtt_targets[i].client,
          //       mqtt_targets[i].sub_topic, // 这里使用 cmd_topic
          //       0);
          //   ESP_LOGI(TAG, "订阅主题 %s, msg_id=%d",
          //   mqtt_targets[i].sub_topic,
          //            msg_id);
          // }
          break;
        case MQTT_EVENT_DISCONNECTED:
          ESP_LOGI(TAG, "MQTT_EVENT_DISCONNECTED 123");
          ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqttconn", "0"));
          // ESP_ERROR_CHECK(nvs_set_str(nvs_handle, "mqttconn", "0"));
          // vTaskDelete(xMqttHandle);
          vTaskDelay(3000 / portTICK_PERIOD_MS);
          esp_mqtt_client_reconnect(client);
          break;

        case MQTT_EVENT_SUBSCRIBED:
          break;
        case MQTT_EVENT_UNSUBSCRIBED:
          break;
        case MQTT_EVENT_PUBLISHED:
          break;

        case MQTT_EVENT_DATA:
          blink_net_led();
          if (mqtt_data_buffer == NULL) {
            mqtt_data_buffer = malloc(event->data_len + 1);
            if (mqtt_data_buffer == NULL) {
              ESP_LOGE(TAG, "内存分配失败");
              break;
            }
            mqtt_data_len = 0;
          } else {
            char *temp_buffer =
                realloc(mqtt_data_buffer, mqtt_data_len + event->data_len + 1);
            if (temp_buffer == NULL) {
              ESP_LOGE(TAG, "内存重新分配失败");
              free(mqtt_data_buffer);
              mqtt_data_buffer = NULL;
              break;
            }
            mqtt_data_buffer = temp_buffer;
          }

          memcpy(mqtt_data_buffer + mqtt_data_len, event->data,
                 event->data_len);
          mqtt_data_len += event->data_len;
          mqtt_data_buffer[mqtt_data_len] = '\0';

          if (event->current_data_offset + event->data_len ==
              event->total_data_len) {
            ESP_LOGI(TAG, "收到完整消息，长度: %d", event->total_data_len);
            ESP_LOGI(TAG, "消息内容: %s", mqtt_data_buffer);

            cJSON *json_data =
                cJSON_ParseWithLength(mqtt_data_buffer, mqtt_data_len);
            if (json_data) {
              cJSON *action = cJSON_GetObjectItem(json_data, "action");

              if (action && cJSON_IsString(action)) {
                if (strcmp(action->valuestring, "set") == 0) {
                  // 处理set类型的消息
                  cJSON *params = cJSON_GetObjectItem(json_data, "params");
                  if (params && cJSON_IsArray(params)) {
                    cJSON *param =
                        cJSON_GetArrayItem(params, 0); // 获取第一个参数
                    if (param) {
                      cJSON *com = cJSON_GetObjectItem(param, "com");
                      if (com && cJSON_IsString(com)) {
                        ESP_LOGI(TAG, "全局COM设置: %s", com->valuestring);
                        int baudrate;
                        uart_parity_t parity;
                        uart_word_length_t data_bits;
                        uart_stop_bits_t stop_bits;

                        parse_com_settings(com->valuestring, &baudrate, &parity,
                                           &data_bits, &stop_bits);
                        reinit_485_uart(baudrate, data_bits, parity, stop_bits,
                                        50, 512);
                      }
                    }
                  }
                  handle_set_message(json_data);
                } else if (strcmp(action->valuestring, "info") == 0) {
                  ESP_LOGI(TAG, "发送设备信息");
                  mqtt_public_send_device_info();
                } else if (strcmp(action->valuestring, "reset") == 0) {
                  reset_device_config();
                } else if (strcmp(action->valuestring, "restart") == 0) {
                  handle_restart();
                } else if (strcmp(action->valuestring, "ota") == 0) {
                  cJSON *params = cJSON_GetObjectItem(json_data, "params");
                  if (params && cJSON_IsArray(params)) {
                    cJSON *param = cJSON_GetArrayItem(params, 0);
                    if (param) {
                      cJSON *url = cJSON_GetObjectItem(param, "url");
                      if (url && cJSON_IsString(url)) {
                        // 发送OTA开始状态
                        cJSON *response = cJSON_CreateObject();
                        cJSON_AddStringToObject(response, "status", "otaing");

                        char *response_str = cJSON_PrintUnformatted(response);
                        if (response_str) {
                          aiot_platform_publish_topic(
                              nvs_mqtt_sub_topic, response_str,
                              strlen(response_str), atoi(nvs_qos),
                              atoi(nvs_retain));
                          free(response_str);
                        }
                        cJSON_Delete(response);

                        // 执行OTA更新
                        simple_ota_task(url->valuestring);
                      } else {
                        ESP_LOGE(TAG, "无效的OTA命令：缺少或无效的URL");
                        cJSON *error_response = cJSON_CreateObject();
                        cJSON_AddStringToObject(error_response, "status",
                                                "error");

                        char *error_str =
                            cJSON_PrintUnformatted(error_response);
                        if (error_str) {
                          aiot_platform_publish_topic(
                              nvs_mqtt_sub_topic, error_str, strlen(error_str),
                              atoi(nvs_qos), atoi(nvs_retain));
                          free(error_str);
                        }
                        cJSON_Delete(error_response);
                      }
                    }
                  }
                } else if (strcmp(action->valuestring, "fota") == 0) {
                  cJSON *params = cJSON_GetObjectItem(json_data, "params");
                  if (params && cJSON_IsArray(params)) {
                    cJSON *param = cJSON_GetArrayItem(params, 0);
                    if (param) {
                      cJSON *url = cJSON_GetObjectItem(param, "url");
                      if (url && cJSON_IsString(url)) {
                        start_4g_task();
                        ESP_LOGI(TAG, "开始4G模块FOTA更新，URL: %s",
                                 url->valuestring);

                        // 发送FOTA开始状态
                        cJSON *response = cJSON_CreateObject();
                        cJSON_AddStringToObject(response, "status", "fotaing");

                        char *response_str = cJSON_PrintUnformatted(response);
                        if (response_str) {
                          aiot_platform_publish_topic(
                              nvs_mqtt_sub_topic, response_str,
                              strlen(response_str), atoi(nvs_qos),
                              atoi(nvs_retain));
                          free(response_str);
                        }
                        cJSON_Delete(response);

                        // 开始下载和更新过程
                        esp_err_t ret =
                            download_and_update_4g(url->valuestring);

                        // 发送完成状态
                        response = cJSON_CreateObject();
                        if (ret == ESP_OK) {
                          cJSON_AddStringToObject(response, "status",
                                                  "success");
                          ESP_LOGI(TAG, "4G FOTA更新成功");
                        } else {
                          cJSON_AddStringToObject(response, "status", "error");
                          ESP_LOGE(TAG, "4G FOTA更新失败: %s",
                                   esp_err_to_name(ret));
                        }

                        response_str = cJSON_PrintUnformatted(response);
                        if (response_str) {
                          aiot_platform_publish_topic(
                              nvs_mqtt_sub_topic, response_str,
                              strlen(response_str), atoi(nvs_qos),
                              atoi(nvs_retain));
                          free(response_str);
                        }
                        cJSON_Delete(response);
                      } else {
                        ESP_LOGE(TAG, "无效的FOTA命令：缺少或无效的URL");

                        cJSON *error_response = cJSON_CreateObject();
                        cJSON_AddStringToObject(error_response, "status",
                                                "error");

                        char *error_str =
                            cJSON_PrintUnformatted(error_response);
                        if (error_str) {
                          aiot_platform_publish_topic(
                              nvs_mqtt_sub_topic, error_str, strlen(error_str),
                              atoi(nvs_qos), atoi(nvs_retain));
                          free(error_str);
                        }
                        cJSON_Delete(error_response);
                      }
                    }
                  }
                }
              } else {
                ESP_LOGE(TAG, "没有找到action字段");
              }

              cJSON_Delete(json_data);
            } else {
              ESP_LOGE(TAG, "JSON解析失败");
            }

            free(mqtt_data_buffer);
            mqtt_data_buffer = NULL;
            mqtt_data_len = 0;
          }
          break;

        case MQTT_EVENT_ERROR:
          ESP_LOGI(TAG, "MQTT_EVENT_ERROR");
          if (event->error_handle->error_type ==
              MQTT_ERROR_TYPE_TCP_TRANSPORT) {
            log_error_if_nonzero("reported from esp-tls",
                                 event->error_handle->esp_tls_last_esp_err);
            log_error_if_nonzero("reported from tls stack",
                                 event->error_handle->esp_tls_stack_err);
            log_error_if_nonzero("captured as transport's socket errno",
                                 event->error_handle->esp_transport_sock_errno);
            ESP_LOGI(TAG, "Last errno string (%s)",
                     strerror(event->error_handle->esp_transport_sock_errno));
          }
          esp_mqtt_client_reconnect(client);
          break;
        default:
          ESP_LOGI(TAG, "Other event id:%d", event->event_id);
          break;
        }
      } else {
        printf("Error reading 'my_key': %s\n", esp_err_to_name(ret));
      }
      free(nvs_use_mqtt);
      free(nvs_mqtt_clientid);
      free(nvs_mqtt_sub_topic);
      free(nvs_mqtt_pub_topic);
      free(nvs_qos);
      free(nvs_retain);
      free(nvs_mqtt_send);
      free(nvs_mqtt_time);
    }
  }

  nvs_close(nvs_handle);
}

static void mqtt_target_event_handler(void *handler_args, esp_event_base_t base,
                                      int32_t event_id, void *event_data) {
  esp_mqtt_event_handle_t event = event_data;
  mqtt_target_t *target = (mqtt_target_t *)handler_args;

  // 用于缓存分片消息
  static char *mqtt_target_data_buffer = NULL;
  static size_t mqtt_target_data_len = 0;

  switch ((esp_mqtt_event_id_t)event_id) {
  case MQTT_EVENT_CONNECTED:
    ESP_LOGI(TAG, "从MQTT客户端 [%s] 已连接", target->name);
    sx_log_write_simple("【 网关-MQTT 】 (%s) 已连接", target->name);
    // 重新订阅cmd_topic
    int msg_id =
        esp_mqtt_client_subscribe(target->client, target->sub_topic, 2);
    ESP_LOGI(TAG, "从MQTT客户端 [%s] 订阅主题: %s, msg_id=%d", target->name,
             target->sub_topic, msg_id);
    break;

  case MQTT_EVENT_DISCONNECTED:
    ESP_LOGI(TAG, "从MQTT客户端 [%s] 已断开连接", target->name);
    sx_log_write_simple("【 网关-MQTT 】 (%s) 已断开连接", target->name);
    break;

  case MQTT_EVENT_DATA:
    ESP_LOGI(TAG, "从MQTT客户端 [%s] 收到:", target->name);
    sx_log_write_simple("【 网关-MQTT 】 (%s) 收到:", target->name);
    ESP_LOGI(TAG, "  主题: %.*s", event->topic_len, event->topic);
    sx_log_write_simple("  主题: %.*s", event->topic_len, event->topic);
    update_target_stats(target->name, true, event->data_len, true);

    // 打印原始数据的十六进制格式
    ESP_LOGI(TAG, "  原始数据(HEX):");
    sx_log_write_simple("  原始数据(HEX):");
    for (int i = 0; i < event->data_len; i++) {
      printf("%02X ", (uint8_t)event->data[i]);
      sx_log_write_simple("%02X ", (uint8_t)event->data[i]);
    }
    printf("\n");
    sx_log_write_simple("\n");

    // 打印ASCII格式数据
    ESP_LOGI(TAG, "  数据(ASCII): %.*s", event->data_len, event->data);
    sx_log_write_simple("  数据(ASCII): %.*s", event->data_len, event->data);
    // 处理分片消息
    if (event->total_data_len > event->data_len) {
      if (mqtt_target_data_buffer == NULL) {
        mqtt_target_data_buffer = malloc(event->total_data_len + 1);
        if (mqtt_target_data_buffer == NULL) {
          ESP_LOGE(TAG, "内存分配失败");
          break;
        }
        mqtt_target_data_len = 0;
      }

      memcpy(mqtt_target_data_buffer + event->current_data_offset, event->data,
             event->data_len);
      mqtt_target_data_len += event->data_len;

      if (event->current_data_offset + event->data_len <
          event->total_data_len) {
        break; // 等待更多数据
      }
    } else {
      // 单个完整消息
      mqtt_target_data_buffer = (char *)event->data;
      mqtt_target_data_len = event->data_len;
    }

    // 如果是cmd_topic的消息，处理命令
    if (strncmp(event->topic, target->sub_topic, event->topic_len) == 0) {
      ESP_LOGI(TAG, "收到命令消息，来自目标: %s", target->name);

      // 检查是否为纯十六进制数据
      bool is_hex_data = true;
      for (int i = 0; i < mqtt_target_data_len; i++) {
        if (!isxdigit((unsigned char)mqtt_target_data_buffer[i]) &&
            !isspace((unsigned char)mqtt_target_data_buffer[i])) {
          is_hex_data = false;
          break;
        }
      }

      uint8_t *cmd_data = NULL; // 初始化为NULL
      size_t cmd_len = 0;       // 初始化为0

      if (is_hex_data) {
        // 处理ASCII格式的十六进制字符串
        char *cmd_str = malloc(mqtt_target_data_len + 1);
        if (cmd_str) {
          int j = 0;
          for (int i = 0; i < mqtt_target_data_len; i++) {
            if (!isspace((unsigned char)mqtt_target_data_buffer[i])) {
              cmd_str[j++] = mqtt_target_data_buffer[i];
            }
          }
          cmd_str[j] = '\0';

          cmd_len = strlen(cmd_str) / 2;
          if (cmd_len > 0) { // 确保有数据要处理
            cmd_data = malloc(cmd_len);
            if (cmd_data) {
              for (size_t i = 0; i < cmd_len; i++) {
                sscanf(&cmd_str[i * 2], "%2hhx", &cmd_data[i]);
              }
            }
          }
          free(cmd_str);
        }
      } else {
        // 直接使用原始数据
        cmd_len = mqtt_target_data_len;
        if (cmd_len > 0) { // 确保有数据要处理
          cmd_data = malloc(cmd_len);
          if (cmd_data) {
            memcpy(cmd_data, mqtt_target_data_buffer, cmd_len);
          }
        }
      }

      if (cmd_data != NULL && cmd_len > 0) { // 确保有数据要处理
        // 打印处理后的命令数据
        ESP_LOGI(TAG, "处理后的命令数据(HEX):");
        for (size_t i = 0; i < cmd_len; i++) {
          printf("%02X ", cmd_data[i]);
        }
        printf("\n");

        // 发送到UART
        int txBytes = send_485_data((char *)cmd_data, cmd_len);
        ESP_LOGI(TAG, "发送命令到UART, 长度: %d", txBytes);

        // 等待并接收UART响应
        uint8_t rx_buffer[512];
        const int rxBytes = uart_read_bytes(
            UART_NUM_2, rx_buffer, sizeof(rx_buffer), 100 / portTICK_PERIOD_MS);

        if (rxBytes > 0) {
          // 打印接收到的响应数据
          ESP_LOGI(TAG, "接收到的响应数据(HEX):");
          sx_log_write_simple("【 网关-MQTT 】 (%s) 接收到的响应数据(HEX):",
                              target->name);
          for (int i = 0; i < rxBytes; i++) {
            printf("%02X ", rx_buffer[i]);
            sx_log_write_simple("%02X ", rx_buffer[i]);
          }
          printf("\n");

          // 直接发送原始字节数据
          ESP_LOGI(TAG, "发送响应到 %s", target->pub_topic);
          esp_mqtt_client_publish(target->client, target->pub_topic,
                                  (const char *)rx_buffer, rxBytes, 2, 0);
        }

        free(cmd_data);
      } else {
        ESP_LOGE(TAG, "命令数据处理失败或为空");
      }
    }

    // 清理分片消息缓冲区
    if (event->total_data_len > event->data_len) {
      free(mqtt_target_data_buffer);
      mqtt_target_data_buffer = NULL;
      mqtt_target_data_len = 0;
    }
    break;

  case MQTT_EVENT_ERROR:
    ESP_LOGI(TAG, "从MQTT客户端 [%s] 发生错误", target->name);
    sx_log_write_simple("【 网关-MQTT 】 (%s) 发生错误", target->name);
    if (event->error_handle->error_type == MQTT_ERROR_TYPE_TCP_TRANSPORT) {
      log_error_if_nonzero("报告来自esp-tls",
                           event->error_handle->esp_tls_last_esp_err);
      log_error_if_nonzero("报告来自tls栈",
                           event->error_handle->esp_tls_stack_err);
      log_error_if_nonzero("捕获为传输套接字errno",
                           event->error_handle->esp_transport_sock_errno);
      ESP_LOGI(TAG, "最后的errno字符串 (%s)",
               strerror(event->error_handle->esp_transport_sock_errno));
    }
    break;

  default:
    ESP_LOGI(TAG, "从MQTT客户端 [%s] 其他事件 id:%d", target->name,
             event->event_id);
    break;
  }
}

int mqtt_send_message_by_name(const char *name, const char *message,
                              int rxBytes) {
  for (int i = 0; i < mqtt_target_count; i++) {
    if (strcmp(mqtt_targets[i].name, name) == 0) {
      // 创建带空格的十六进制字符串
      char *formatted_hex = malloc(rxBytes + 1); // 保持原始长度，最后加结束符
      if (formatted_hex == NULL) {
        ESP_LOGE(TAG, "内存分配失败");
        return -1;
      }

      // 直接复制原始字符串，保持原有格式
      memcpy(formatted_hex, message, rxBytes);
      formatted_hex[rxBytes] = '\0';

      ESP_LOGI(TAG, "发送到 [%s]: %s", name, message);
      sx_log_write_simple("【 网关-MQTT 】(%s) 发送: [%s], 字节长度: %d", name,
                          formatted_hex, rxBytes / 2);

      // 将十六进制字符串转换为原始字节数据
      size_t data_len = rxBytes / 2;
      uint8_t *binary_data = malloc(data_len);
      if (binary_data == NULL) {
        ESP_LOGE(TAG, "内存分配失败");
        free(formatted_hex);
        return -1;
      }

      // 将十六进制字符串转换为二进制数据
      for (size_t j = 0; j < data_len; j++) {
        sscanf(&message[j * 2], "%2hhx", &binary_data[j]);
      }

      // 发送二进制数据
      int result = esp_mqtt_client_publish(
          mqtt_targets[i].client, mqtt_targets[i].pub_topic,
          (const char *)binary_data, data_len, 2, 0);

      free(binary_data);
      free(formatted_hex);

      // 根据发送结果更新统计信息
      if (result >= 0) {
        update_target_stats(name, true, rxBytes, false);
      } else {
        update_target_stats(name, false, rxBytes, false);
      }
      return result;
    }
  }

  update_target_stats(name, false, rxBytes, false);
  return -1;
}

void mqtt_app_start(void) {
  esp_err_t ret = nvs_flash_init();
  if (ret == ESP_ERR_NVS_NO_FREE_PAGES ||
      ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
    ESP_ERROR_CHECK(nvs_flash_erase());
    ret = nvs_flash_init();
  }
  ESP_ERROR_CHECK(ret);

  nvs_handle_t nvs_handle;
  ESP_ERROR_CHECK(nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle));

  // 获取所有MQTT配置参数的大小
  size_t netconn, use_mqtt, mqtt_type, mqtt_server, mqtt_port, mqtt_username,
      mqtt_password, mqtt_clientid, mqtt_sub_topic, mqtt_pub_topic, qos,
      retain = 0;

  ret = nvs_get_str(nvs_handle, "use_mqtt", NULL, &use_mqtt);
  ret |= nvs_get_str(nvs_handle, "mqtt_type", NULL, &mqtt_type);
  ret |= nvs_get_str(nvs_handle, "mqtt_server", NULL, &mqtt_server);
  ret |= nvs_get_str(nvs_handle, "mqtt_port", NULL, &mqtt_port);
  ret |= nvs_get_str(nvs_handle, "mqtt_username", NULL, &mqtt_username);
  ret |= nvs_get_str(nvs_handle, "mqtt_password", NULL, &mqtt_password);
  ret |= nvs_get_str(nvs_handle, "mqtt_clientid", NULL, &mqtt_clientid);
  ret |= nvs_get_str(nvs_handle, "mqtt_sub_topic", NULL, &mqtt_sub_topic);
  ret |= nvs_get_str(nvs_handle, "mqtt_pub_topic", NULL, &mqtt_pub_topic);
  ret |= nvs_get_str(nvs_handle, "qos", NULL, &qos);
  ret |= nvs_get_str(nvs_handle, "retain", NULL, &retain);
  ret |= nvs_get_str(nvs_handle, "netconn", NULL, &netconn);

  if (ret == ESP_OK) {

    char *nvs_use_mqtt = malloc(use_mqtt);
    char *nvs_mqtt_type = malloc(mqtt_type);
    char *nvs_mqtt_server = malloc(mqtt_server);
    char *nvs_mqtt_port = malloc(mqtt_port);
    char *nvs_mqtt_username = malloc(mqtt_username);
    char *nvs_mqtt_password = malloc(mqtt_password);
    char *nvs_mqtt_clientid = malloc(mqtt_clientid);
    char *nvs_mqtt_sub_topic = malloc(mqtt_sub_topic);
    char *nvs_mqtt_pub_topic = malloc(mqtt_pub_topic);
    char *nvs_qos = malloc(qos);
    char *nvs_retain = malloc(retain);
    char *nvs_netconn = malloc(netconn);

    if (nvs_mqtt_server != NULL) {
      nvs_get_str(nvs_handle, "netconn", nvs_netconn, &netconn);
      nvs_get_str(nvs_handle, "use_mqtt", nvs_use_mqtt, &use_mqtt);
      nvs_get_str(nvs_handle, "mqtt_type", nvs_mqtt_type, &mqtt_type);
      nvs_get_str(nvs_handle, "mqtt_server", nvs_mqtt_server, &mqtt_server);
      nvs_get_str(nvs_handle, "mqtt_port", nvs_mqtt_port, &mqtt_port);
      nvs_get_str(nvs_handle, "mqtt_username", nvs_mqtt_username,
                  &mqtt_username);
      nvs_get_str(nvs_handle, "mqtt_password", nvs_mqtt_password,
                  &mqtt_password);
      nvs_get_str(nvs_handle, "mqtt_clientid", nvs_mqtt_clientid,
                  &mqtt_clientid);
      nvs_get_str(nvs_handle, "mqtt_sub_topic", nvs_mqtt_sub_topic,
                  &mqtt_sub_topic);
      nvs_get_str(nvs_handle, "mqtt_pub_topic", nvs_mqtt_pub_topic,
                  &mqtt_pub_topic);
      nvs_get_str(nvs_handle, "qos", nvs_qos, &qos);
      nvs_get_str(nvs_handle, "retain", nvs_retain, &retain);

      if (atoi(nvs_netconn) == 3) {
        ESP_LOGI(TAG, "4G 连接MQTT");

        // 创建JSON对象
        cJSON *mqtt_json = cJSON_CreateObject();
        if (mqtt_json == NULL) {
          ESP_LOGE(TAG, "创建JSON对象失败");
          return;
        }

        // 添加MQTT连接信息到JSON对象
        cJSON_AddStringToObject(mqtt_json, "type", "mqtt");

        // 构建完整的URL（包含用户名和密码）
        char mqtt_url[256];
        snprintf(mqtt_url, sizeof(mqtt_url), "mqtt://%s:%s@%s",
                 nvs_mqtt_username, nvs_mqtt_password, nvs_mqtt_server);
        cJSON_AddStringToObject(mqtt_json, "url", mqtt_url);

        // 添加端口号
        cJSON_AddNumberToObject(mqtt_json, "port", atoi(nvs_mqtt_port));

        // 添加客户端ID
        cJSON_AddStringToObject(mqtt_json, "clientid", nvs_mqtt_clientid);

        // 添加订阅主题
        cJSON_AddStringToObject(mqtt_json, "sub_topic", nvs_mqtt_sub_topic);

        // 添加发布主题
        cJSON_AddStringToObject(mqtt_json, "pub_topic", nvs_mqtt_pub_topic);

        cJSON_AddNumberToObject(mqtt_json, "qos", atoi(nvs_qos));
        cJSON_AddNumberToObject(mqtt_json, "retain", atoi(nvs_retain));

        char *json_string = cJSON_Print(mqtt_json);
        if (json_string != NULL) {
          send4gData(TAG, json_string);
          free(json_string);
        }
        cJSON_Delete(mqtt_json);
      } else {
        char mqtt_uri[256];
        snprintf(mqtt_uri, sizeof(mqtt_uri), "%s%s%s%s%s%s%s%s", "mqtt://",
                 nvs_mqtt_username, ":", nvs_mqtt_password, "@",
                 nvs_mqtt_server, ":", nvs_mqtt_port);
        ESP_LOGI(TAG, "MQTT URI: %s", mqtt_uri);
        esp_mqtt_client_config_t mqtt_cfg = {
            .broker.address.uri = mqtt_uri,
            .credentials.client_id = nvs_mqtt_clientid,
            .session.last_will.topic = nvs_mqtt_sub_topic,
            .session.last_will.msg = "{\"status\":\"offline\"}",
            .session.last_will.qos = 2,
            .session.last_will.retain = 1,
            .session.keepalive = 60};
        if (client == NULL) {
          client = esp_mqtt_client_init(&mqtt_cfg);
          if (client != NULL) {
            esp_mqtt_client_register_event(client, ESP_EVENT_ANY_ID,
                                           mqtt_event_handler, NULL);
            ret = esp_mqtt_client_start(client);
            if (ret != ESP_OK) {
              printf("Error starting MQTT client: %s\n", esp_err_to_name(ret));
              esp_mqtt_client_destroy(client);
              client = NULL;
            }
          } else {
            printf("Failed to initialize MQTT client\n");
          }
        }
      }
    }

    free(nvs_use_mqtt);
    free(nvs_mqtt_type);
    free(nvs_mqtt_server);
    free(nvs_mqtt_port);
    free(nvs_mqtt_username);
    free(nvs_mqtt_password);
    free(nvs_mqtt_clientid);
    free(nvs_mqtt_sub_topic);
    free(nvs_mqtt_pub_topic);
    free(nvs_qos);
    free(nvs_retain);
    free(nvs_netconn);
  }

  nvs_close(nvs_handle);

  cJSON *saved_config = load_config_from_nvs();
  if (saved_config != NULL) {
    ESP_LOGI(TAG, "找到已保存的配置，开始恢复连接和任务");

    // 从params数组中获取COM设置
    cJSON *params = cJSON_GetObjectItem(saved_config, "params");
    if (params && cJSON_IsArray(params)) {
      cJSON *param = cJSON_GetArrayItem(params, 0);
      if (param) {
        cJSON *com_type = cJSON_GetObjectItem(param, "com_type");
        cJSON *com = cJSON_GetObjectItem(param, "com");

        if (com_type && cJSON_IsString(com_type) &&
            strcmp(com_type->valuestring, "485") == 0 && com &&
            cJSON_IsString(com)) {
          ESP_LOGI(TAG, "恢复全局COM设置: %s", com->valuestring);
          int baudrate;
          uart_parity_t parity;
          uart_word_length_t data_bits;
          uart_stop_bits_t stop_bits;

          parse_com_settings(com->valuestring, &baudrate, &parity, &data_bits,
                             &stop_bits);
          reinit_485_uart(baudrate, data_bits, parity, stop_bits, 50, 512);
        }
      }
    }

    // 处理保存的目标服务器配置
    cJSON *targets = cJSON_GetObjectItem(saved_config, "targets");
    if (targets && cJSON_IsArray(targets)) {
      // 获取netconn值，判断是否为4G模式
      nvs_handle_t nvs_handle;
      esp_err_t ret = nvs_open("nvs_namespace", NVS_READWRITE, &nvs_handle);
      if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Error opening NVS handle: %s", esp_err_to_name(ret));
        return;
      }

      size_t netconn_size = 0;
      bool is_4g_mode = false; // 添加标志位判断是否为4G模式

      ret = nvs_get_str(nvs_handle, "netconn", NULL, &netconn_size);
      if (ret != ESP_OK || netconn_size == 0) {
        ESP_LOGE(TAG, "Error getting size of netconn: %s",
                 esp_err_to_name(ret));
        nvs_close(nvs_handle);
      } else {
        char *nvs_netconn = malloc(netconn_size);
        if (nvs_netconn == NULL) {
          ESP_LOGE(TAG, "Memory allocation failed for netconn");
          nvs_close(nvs_handle);
        } else {
          ret = nvs_get_str(nvs_handle, "netconn", nvs_netconn, &netconn_size);
          nvs_close(nvs_handle);

          if (ret == ESP_OK) {
            // 如果是4G模式，设置标志位
            if (atoi(nvs_netconn) == 3) {
              is_4g_mode = true;
              ESP_LOGI(TAG, "4G模式下，轮询任务交给上游4G端处理");
            }
          }
          free(nvs_netconn);
        }
      }

      // 处理targets数组中的每个目标
      cJSON *target;
      cJSON_ArrayForEach(target, targets) {
        cJSON *name = cJSON_GetObjectItem(target, "name");
        cJSON *url = cJSON_GetObjectItem(target, "url");
        cJSON *clientid = cJSON_GetObjectItem(target, "clientid");

        // 优先检查新格式的topic
        cJSON *data_topic = cJSON_GetObjectItem(target, "data_topic");
        cJSON *cmd_topic = cJSON_GetObjectItem(target, "cmd_topic");

        // 如果新格式不存在，则使用旧格式
        if (!data_topic || !cmd_topic) {
          data_topic = cJSON_GetObjectItem(target, "pub_topic");
          cmd_topic = cJSON_GetObjectItem(target, "sub_topic");
        }

        if (name && url && cJSON_IsString(name) && cJSON_IsString(url)) {
          if (is_http_target(url->valuestring)) {
            ESP_LOGI(TAG, "恢复HTTP目标: %s, URL: %s", name->valuestring,
                     url->valuestring);
            add_http_target(name->valuestring, url->valuestring);
          } else if (!is_4g_mode && clientid && data_topic &&
                     cmd_topic && // 非4G模式才处理MQTT连接
                     cJSON_IsString(clientid) && cJSON_IsString(data_topic) &&
                     cJSON_IsString(cmd_topic)) {

            if (is_target_duplicate(name->valuestring, url->valuestring,
                                    clientid->valuestring)) {
              ESP_LOGI(TAG, "跳过重复的目标: %s", name->valuestring);
              continue;
            }

            ESP_LOGI(TAG, "恢复MQTT目标连接: %s, URL: %s", name->valuestring,
                     url->valuestring);

            if (mqtt_target_count < MAX_MQTT_TARGETS) {
              // 保存目标信息
              strncpy(mqtt_targets[mqtt_target_count].name, name->valuestring,
                      sizeof(mqtt_targets[mqtt_target_count].name) - 1);
              strncpy(mqtt_targets[mqtt_target_count].url, url->valuestring,
                      sizeof(mqtt_targets[mqtt_target_count].url) - 1);
              strncpy(mqtt_targets[mqtt_target_count].clientid,
                      clientid->valuestring,
                      sizeof(mqtt_targets[mqtt_target_count].clientid) - 1);
              strncpy(mqtt_targets[mqtt_target_count].pub_topic,
                      data_topic->valuestring,
                      sizeof(mqtt_targets[mqtt_target_count].pub_topic) - 1);
              strncpy(mqtt_targets[mqtt_target_count].sub_topic,
                      cmd_topic->valuestring,
                      sizeof(mqtt_targets[mqtt_target_count].sub_topic) - 1);

              // 初始化并启动MQTT客户端
              esp_mqtt_client_config_t mqtt_cfg = {
                  .broker.address.uri = url->valuestring,
                  .credentials.client_id = clientid->valuestring};

              mqtt_targets[mqtt_target_count].client =
                  esp_mqtt_client_init(&mqtt_cfg);
              if (mqtt_targets[mqtt_target_count].client) {
                // 注册事件处理程序，传入当前mqtt_target作为上下文
                esp_mqtt_client_register_event(
                    mqtt_targets[mqtt_target_count].client, ESP_EVENT_ANY_ID,
                    mqtt_target_event_handler,
                    &mqtt_targets[mqtt_target_count]);

                esp_mqtt_client_start(mqtt_targets[mqtt_target_count].client);
                mqtt_target_count++;
                ESP_LOGI(TAG, "成功初始化从MQTT客户端 [%s]", name->valuestring);
              } else {
                ESP_LOGE(TAG, "MQTT 客户端 [%s] 初始化失败", name->valuestring);
              }
            }
          }
        }
      }
    }

    // 启动 UART 循环任务
    start_uart_loop_task(saved_config);

    // 不要在这里释放 saved_config，因为 start_uart_loop_task 会处理它
  } else {
    ESP_LOGI(TAG, "未找到已保存的配置");
  }
}

/*************************************************************************************/
/*                                END OF FILE */
/*************************************************************************************/
